# HEXSHIFT — Select Anything. Create Anything.

A native macOS menu-bar utility for designers and everyday users. Select a file, an image, a PDF,
some text or a colour, press **⌥ Space**, and a hexagonal wheel opens at your pointer with the
actions that make sense for what you selected. Hold **Shift while dragging files** and a format wheel
appears — drop onto PNG, JPEG, WebP, PDF… to convert on the spot.

Everything runs locally on your Mac. No accounts, no uploads, no analytics.

```
              ┌──────────┐
     Capture  │ Convert  │  Edit
     & More ╲ └──────────┘ ╱
   ┌────────┐   ⬢ centre   ┌────────┐
   │ Colour │  (close /    │  PDF & │
   │& Insp. │   back)      │  Docs  │
   └────────┘              └────────┘
               Typography
```

## What's in the box

| Area | Highlights |
| --- | --- |
| **Radial menu** | ⌥ Space (changeable) or an optional ⌃⌥-right-click, context-aware actions, keyboard navigation (arrows, Tab, 1–6, Return, Esc), favourite tools (press **F** on any action) and most-used quick buttons, light/dark/high-contrast, Reduce Motion aware |
| **Drag to convert** | Hold Shift during any file drag → format wheel; drop on a format → converted copy next to the original. Also: drop files on the menu-bar icon |
| **Finder & Services** | Right-click → Quick Actions / Services → *Open in HEXSHIFT*; *Open With → HEXSHIFT*; Services for text and images; selected Finder files are used automatically by the shortcut |
| **Converter** | Images (PNG, JPEG, HEIC, WebP, AVIF*, TIFF, GIF, BMP, JPEG 2000, ICO, ICNS, PDF), RAW/PSD input, animated GIF/WebP/APNG, SVG → raster/PDF, raster → SVG trace, PDF ↔ images, documents (DOCX, RTF, ODT, HTML, Markdown, TXT, PDF), CSV/XLSX/JSON tables, iWork via Pages/Keynote/Numbers, video/audio via AVFoundation (+FFmpeg optional), colour-profile and matte options, batch with progress & cancel |
| **Image editor** | Crop (presets + custom ratio), rotate/flip, resize, adjustments (exposure, contrast, saturation, vibrance, warmth, tint, highlights, shadows, sharpen, B&W, auto), background removal and replacement (Vision), annotations (arrows, shapes, text, callouts, blur, pixelate), compress to a target size, undo/redo, before/after |
| **PDF toolkit** | Merge, split, extract/reorder/rotate/delete pages, compress, images → PDF, OCR to searchable PDF, **true redaction**, markup (text boxes, comments, drawing, highlights), page numbers, stamps, signature image, page size & margins, password protect/remove, metadata clean-up |
| **Font Lens** | Actual font of selected text (Accessibility) or web text (browser extension), *estimated* matches for text in images, specimens, comparison, favourites, CSS and SwiftUI snippets |
| **Colour Lens** | Screen picker, HEX/RGB/HSL/HSB/CMYK/Lab/OKLCH/P3, WCAG 2.2 + APCA contrast, palettes from images, gradient estimate, harmonies, 50–950 tonal scales, colour-blindness preview, exports (CSS, Tailwind, JSON tokens, SwiftUI, ASE, GPL, SVG, PNG) |
| **Capture & more** | Region/window/screen capture → straight into the wheel, OCR, text → image/PDF/graphic, translate (macOS 15+), QR codes, designer tools (ratios, units & print, scale exports), workflows with editable steps, favourites and their own shortcuts, optional clipboard suggestions |

\* AVIF export needs either the macOS AVIF encoder or `avifenc` (see *Requirements*). See
[docs/FEATURES.md](docs/FEATURES.md) for an honest list of what is complete, partial or not yet built,
and [docs/FORMATS.md](docs/FORMATS.md) for what each conversion keeps or loses.

## Install

1. Click the green **Code** button above, then **Download ZIP**, and unzip it.
2. In the folder, **double-click `install.command`**.
3. The first time, macOS blocks it (it's not from the App Store): click **Done**, then open
   **System Settings › Privacy & Security**, scroll down and click **Open Anyway**, then **Open**.
4. Wait a few minutes. HEXSHIFT opens and a hexagon appears in the menu bar. Press **⌥ Space**.

Needs **macOS 14 Sonoma or later**. If Apple's Command Line Tools aren't installed, the installer
asks for them first. **Illustrated step-by-step guide and troubleshooting: [INSTALL.md](INSTALL.md).**
To remove HEXSHIFT, run `uninstall.command`.

> Prefer the keyboard? Open **Terminal**, type `bash ` (with a space), drag `install.command` in and
> press Return — this skips the security prompts entirely.

## Build from the command line

You need **macOS 14 Sonoma or later** and **Xcode 15+** (or just the Command Line Tools:
`xcode-select --install`).

```bash
cd HEXSHIFT
scripts/build-app.sh --install     # builds, signs (ad-hoc) and copies HEXSHIFT.app to /Applications
open /Applications/HEXSHIFT.app
```

`scripts/build.sh` (used by `build-app.sh`) builds with Swift Package Manager when it works and otherwise
falls back to compiling directly with `swiftc` and `clang` (`scripts/build-direct.sh`), so a damaged
SwiftPM install doesn't stop you.

Other useful commands:

```bash
scripts/build.sh debug                         # debug build → ~/Library/Caches/HEXSHIFT-build/out/debug
~/Library/Caches/HEXSHIFT-build/out/debug/hexshift-cli selftest      # 35 engine tests
~/Library/Caches/HEXSHIFT-build/out/debug/hexshift-cli formats       # what this Mac can read/write
~/Library/Caches/HEXSHIFT-build/out/debug/hexshift-cli convert photo.heic webp --quality 0.8
~/Library/Caches/HEXSHIFT-build/out/debug/HEXSHIFT --smoke-test /tmp # UI wiring checks + PNG snapshots
swift test                                     # XCTest wrapper around the self-test (needs full Xcode)
```

**Tested on:** macOS 27.0.1 on Apple silicon, Swift 6.3.3 (Command Line Tools) — engine self-test 35/35
passed, UI smoke test 50/50 passed.

The first launch shows a short welcome. HEXSHIFT then lives in the menu bar (hexagon icon). Launch it
again from Spotlight any time to open Settings.

### Permissions (only asked when a feature needs them)

| Permission | Why | When |
| --- | --- | --- |
| Automation → Finder | Read which files are selected when you press the shortcut | First ⌥ Space in Finder |
| Accessibility | Read selected text (and its real font) in other apps; the optional modifier + right-click gesture | When you first use a text action, Font Lens on live text, or turn on the gesture |
| Screen Recording | Capture the screen and pick colours outside HEXSHIFT | First capture |
| Automation → Pages/Keynote/Numbers | Export iWork documents | First iWork conversion |

Ad-hoc signed builds are treated as a new app after each rebuild, so macOS may ask again. See
[docs/REQUIREMENTS.md](docs/REQUIREMENTS.md) for a stable signing set-up.

## Optional helpers

HEXSHIFT works on its own. If these are installed (e.g. with [Homebrew](https://brew.sh)) it uses them
automatically and says so in the UI:

```bash
brew install ffmpeg pandoc ghostscript libavif potrace
brew install --cask libreoffice
```

## Project layout

```
install.command         double-click installer (builds and installs HEXSHIFT.app)
uninstall.command       removes the app, its cache and settings
INSTALL.md              step-by-step install guide and troubleshooting
Package.swift
Sources/CWebP/          vendored libwebp 1.5.0 encoder (BSD-3) + tiny C shim
Sources/HexshiftKit/    conversion & analysis engine (no UI) — images, PDF, OCR, fonts, colour, media…
Sources/hexshift-cli/   command-line front end and self-test runner
Sources/HEXSHIFT/       the menu-bar app (SwiftUI + AppKit)
Tests/                  XCTest wrapper
Resources/              Info.plist, entitlements, app icon
Extras/                 Chrome extension (font inspector + page capture), Finder Quick Action
scripts/build-app.sh    builds HEXSHIFT.app
scripts/notarize.sh     Developer ID signing, notarisation and a DMG (for sharing)
docs/                   FEATURES, FORMATS, REQUIREMENTS, ARCHITECTURE, MANUAL-TESTS
```

## Privacy

Files, screenshots and text never leave the Mac. HEXSHIFT never records the screen continuously, never
logs keystrokes (the only global keyboard hook is the shortcut you choose), never overwrites originals
(results are written next to them as new files, e.g. `photo.webp`, `photo 2.webp`), and writes every
output to a temporary file first so a failed conversion can't leave a broken file behind.

Licensed components: see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
