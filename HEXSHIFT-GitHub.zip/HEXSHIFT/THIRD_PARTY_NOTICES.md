# Third-party notices

HEXSHIFT is built on Apple system frameworks (AppKit, SwiftUI, ImageIO, Core Image, Accelerate, PDFKit, Vision, AVFoundation, Core Text, QuickLook, WebKit) and the system `screencapture` tool. It bundles exactly one third-party component:

## libwebp 1.5.0 — WebP encoding

Source: https://chromium.googlesource.com/webm/libwebp (vendored, unmodified, in `Sources/CWebP/src` and `Sources/CWebP/sharpyuv`). Used only to *write* WebP and animated WebP; macOS reads WebP natively.

```
Copyright (c) 2010, Google Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

  * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution.

  * Neither the name of Google nor the names of its contributors may
    be used to endorse or promote products derived from this software
    without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

```

Additional IP rights grant (patents):

```
Additional IP Rights Grant (Patents)
------------------------------------

"These implementations" means the copyrightable works that implement the WebM
codecs distributed by Google as part of the WebM Project.

Google hereby grants to you a perpetual, worldwide, non-exclusive, no-charge,
royalty-free, irrevocable (except as stated in this section) patent license to
make, have made, use, offer to sell, sell, import, transfer, and otherwise
run, modify and propagate the contents of these implementations of WebM, where
such license applies only to those patent claims, both currently owned by
Google and acquired in the future, licensable by Google that are necessarily
infringed by these implementations of WebM. This grant does not include claims
that would be infringed only as a consequence of further modification of these
implementations. If you or your agent or exclusive licensee institute or order
or agree to the institution of patent litigation or any other patent
enforcement activity against any entity (including a cross-claim or
counterclaim in a lawsuit) alleging that any of these implementations of WebM
or any code incorporated within any of these implementations of WebM
constitute direct or contributory patent infringement, or inducement of
patent infringement, then any patent rights granted to you under this License
for these implementations of WebM shall terminate as of the date such
litigation is filed.
```

## Optional tools (not bundled)

HEXSHIFT can call these if *you* install them; they are separate programs under their own licences and are never shipped with HEXSHIFT:

| Tool | Licence | Used for |
| --- | --- | --- |
| FFmpeg | LGPL-2.1+ / GPL-2+ depending on build | WebM, MKV, AVI, MP3, FLAC |
| Pandoc | GPL-2+ | Higher-fidelity Markdown / Word / HTML |
| LibreOffice | MPL-2.0 | Word / PowerPoint / Excel → PDF |
| Ghostscript | AGPL-3.0 | EPS, legacy AI, strongest PDF compression |
| libavif (avifenc) | BSD-2-Clause | AVIF export where macOS has no encoder |
| Potrace | GPL-2+ | Smoother single-colour vector tracing |

## Google Fonts reference (font finder)

`Resources/FontReference.bin` contains small greyscale images of the letters, digits and punctuation of
159 font families from the Google Fonts collection (https://github.com/google/fonts), rendered at 56 px
per em, together with basic metrics. They are used only to compare letter shapes when HEXSHIFT estimates
which font appears in an image. The font files themselves are not included; each family can be downloaded
free from https://fonts.google.com. The families and their licences:

- **SIL Open Font License 1.1**: Abel, Abril Fatface, Albert Sans, Alegreya, Alfa Slab One, Amatic SC, Anton, Archivo, Archivo Black, Archivo Narrow, Arimo, Arvo, Asap, Assistant, Baloo 2, Barlow, Barlow Condensed, Bebas Neue, Bitter, Bree Serif, Bricolage Grotesque, Bungee, Cabin, Cardo, Catamaran, Caveat, Chakra Petch, Comfortaa, Cormorant, Cormorant Garamond, Courier Prime, Cousine, Crimson Text, DM Mono, DM Sans, DM Serif Display, Dancing Script, Domine, Dosis, EB Garamond, Encode Sans, Epilogue, Exo, Exo 2, Figtree, Fira Code, Fira Sans, Fjalla One, Fraunces, Fredoka, Gelasio, Great Vibes, Hanken Grotesk, Heebo, Hind, IBM Plex Mono, IBM Plex Sans, IBM Plex Sans Condensed, IBM Plex Serif, Inconsolata, Indie Flower, Instrument Sans, Instrument Serif, Inter, JetBrains Mono, Josefin Sans, Jost, Kanit, Karla, Kaushan Script, Lato, League Gothic, League Spartan, Lexend, Libre Baskerville, Libre Caslon Text, Libre Franklin, Lilita One, Lobster, Lora, Manrope, Maven Pro, Merriweather, Montserrat, Mukta, Mulish, Nanum Gothic, Newsreader, Noto Sans, Noto Sans Mono, Noto Serif, Nunito, Nunito Sans, Old Standard TT, Onest, Open Sans, Orbitron, Oswald, Outfit, Overpass, Oxygen, PT Mono, PT Sans, PT Sans Caption, PT Serif, Pacifico, Passion One, Patrick Hand, Playfair, Playfair Display, Plus Jakarta Sans, Poppins, Prata, Press Start 2P, Prompt, Public Sans, Questrial, Quicksand, Rajdhani, Raleway, Red Hat Display, Righteous, Roboto, Roboto Condensed, Roboto Flex, Roboto Mono, Rubik, Russo One, Sacramento, Saira, Schibsted Grotesk, Shadows Into Light, Signika, Six Caps, Sora, Source Code Pro, Source Sans 3, Source Serif 4, Space Grotesk, Space Mono, Spectral, Staatliches, Syne, Teko, Tinos, Titillium Web, Unbounded, Urbanist, Varela Round, Vollkorn, Work Sans, Yeseva One, Young Serif, Zilla Slab
- **Apache License 2.0**: Permanent Marker, Roboto Slab, Satisfy
- **Ubuntu Font Licence 1.0**: Ubuntu, Ubuntu Mono
