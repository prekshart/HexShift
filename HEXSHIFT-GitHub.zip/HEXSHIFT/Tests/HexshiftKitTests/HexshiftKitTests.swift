import HexshiftKit
import XCTest

/// Runs the same end-to-end suite as `hexshift-cli selftest`.
/// (Needs full Xcode for XCTest; with only the Command Line Tools use the CLI.)
final class HexshiftKitTests: XCTestCase {
    func testConversionSuite() async throws {
        let report = await SelfTest.run(log: { print($0) })
        XCTAssertEqual(report.failed, 0, report.failures.joined(separator: "\n"))
        XCTAssertGreaterThan(report.passed, 20)
    }

    func testColourExampleFromSpec() {
        let c = ColourMath.parse("#16A085")!
        XCTAssertEqual(ColourMath.rgbString(c), "22, 160, 133")
        XCTAssertEqual(ColourMath.hslString(c), "168°, 76%, 36%")
    }

    func testPageListParsing() {
        XCTAssertEqual(PDFEngine.parsePageList("1-3, 5", pageCount: 6), [0, 1, 2, 4])
        XCTAssertNil(PDFEngine.parsePageList("0", pageCount: 3))
        XCTAssertEqual(PDFEngine.parsePageList("all", pageCount: 2), [0, 1])
    }

    func testMarkdownRendering() {
        let html = MarkdownRenderer.html(from: "# Title\n\nSome **bold** and *italic* text.\n\n- a\n- b", standalone: false)
        XCTAssertTrue(html.contains("<h1>Title</h1>"))
        XCTAssertTrue(html.contains("<strong>bold</strong>"))
        XCTAssertTrue(html.contains("<em>italic</em>"))
        XCTAssertTrue(html.contains("<ul><li>a</li><li>b</li></ul>"))
    }

    func testCSVRoundTrip() {
        let rows = [["a", "b,c", "d\"e"], ["1", "2", "3"]]
        XCTAssertEqual(TableConverter.parseCSV(TableConverter.csvString(rows)), rows)
    }
}
