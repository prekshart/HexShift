"""Shared helpers for the font-matching lab: face discovery, rendering, sample synthesis."""
import glob, io, json, os, random
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from fontTools.ttLib import TTFont

ROOT = os.path.dirname(os.path.abspath(__file__))
GF = os.path.join(ROOT, 'gf')
WEIGHTS = [300, 400, 500, 600, 700, 800, 900]


def family_name(tt):
    name = tt['name']
    for nid in (16, 1):
        rec = name.getName(nid, 3, 1, 0x409) or name.getName(nid, 1, 0, 0)
        if rec:
            return str(rec)
    return '?'


def discover_faces(upright_only=True):
    """Every (family, weight, italic) face available, static files or variable instances."""
    faces = []
    cache = os.path.join(ROOT, 'faces.json')
    if os.path.exists(cache):
        faces = json.load(open(cache))
    else:
        for path in sorted(glob.glob(os.path.join(GF, '*', '*', '*.ttf'))):
            try:
                tt = TTFont(path, lazy=True)
            except Exception:
                continue
            fam = family_name(tt)
            italic = 'Italic' in os.path.basename(path) or bool(tt['OS/2'].fsSelection & 1)
            if 'fvar' in tt:
                axes = {a.axisTag: (a.minValue, a.defaultValue, a.maxValue) for a in tt['fvar'].axes}
                if 'wght' in axes:
                    lo, _, hi = axes['wght']
                    for w in WEIGHTS:
                        if lo <= w <= hi:
                            faces.append(dict(family=fam, weight=w, italic=italic, path=path, axes={'wght': w}))
                else:
                    faces.append(dict(family=fam, weight=tt['OS/2'].usWeightClass, italic=italic, path=path, axes={}))
            else:
                faces.append(dict(family=fam, weight=tt['OS/2'].usWeightClass, italic=italic, path=path, axes={}))
        # Drop duplicate (family, weight, italic) keeping the first.
        seen, uniq = set(), []
        for f in faces:
            k = (f['family'], f['weight'], f['italic'])
            if k not in seen:
                seen.add(k)
                uniq.append(f)
        faces = uniq
        json.dump(faces, open(cache, 'w'))
    if upright_only:
        faces = [f for f in faces if not f['italic']]
    for i, f in enumerate(faces):
        f['id'] = f"{f['family']}|{f['weight']}{'i' if f['italic'] else ''}"
    return faces


_font_cache = {}


def pil_font(face, size):
    key = (face['path'], json.dumps(face['axes'], sort_keys=True), size)
    if key in _font_cache:
        return _font_cache[key]
    f = ImageFont.truetype(face['path'], size)
    if face['axes']:
        try:
            axes = f.get_variation_axes()
            vals = []
            for a in axes:
                nm = a.get('name', b'')
                nm = nm.decode() if isinstance(nm, bytes) else nm
                tag = {'Weight': 'wght', 'Optical size': 'opsz', 'Optical Size': 'opsz', 'Width': 'wdth'}.get(nm, nm)
                if tag in face['axes']:
                    vals.append(face['axes'][tag])
                elif tag == 'opsz':
                    vals.append(min(max(size * 0.75, a['minimum']), a['maximum']))
                else:
                    vals.append(a['default'])
            f.set_variation_by_axes(vals)
        except Exception:
            pass
    if len(_font_cache) > 4000:
        _font_cache.clear()
    _font_cache[key] = f
    return f


def render_line(face, text, size, pad=None):
    """Grey ink map (0..1) of `text` set in `face` at `size` px, like a screenshot crop."""
    f = pil_font(face, size)
    l, t, r, b = f.getbbox(text, anchor='ls')
    pad = pad if pad is not None else max(4, size // 3)
    W, H = int(r - l + 2 * pad), int(b - t + 2 * pad)
    img = Image.new('L', (max(W, 4), max(H, 4)), 0)
    ImageDraw.Draw(img).text((pad - l, pad - t), text, font=f, fill=255, anchor='ls')
    return img


TEXTS = [
    "Design is how it works", "Get started for free", "The quick brown fox jumps", "Pricing plans for teams",
    "Welcome back, Sarah", "Book your table tonight", "Hello World", "Sign up in seconds", "Summer Collection 2026",
    "Fresh coffee every morning", "Learn more about us", "Download the app", "Rent made simple",
    "Find your next home", "Our Story", "Contact Support", "Typography matters", "Quality you can trust",
    "Explore the gallery", "Join the waitlist", "Upgrade to Pro", "Your order is on its way", "Make it happen",
    "Creative studio in Mumbai", "Handcrafted with love", "Terms and Conditions", "Black Friday Sale",
    "Build better products", "Analytics dashboard", "Meet the team",
]


def synth_sample(face, text, size, rng, light_on_dark=False, jpeg=None, scale=1.0, blur=0.0, mode='hinted'):
    """A realistic capture of rendered text: retina scale, rasteriser style, blur, JPEG, colours.
    mode: 'hinted' (FreeType, like Windows), 'mac' (unhinted grey AA, like macOS), 'macsmooth'
    (macOS with font smoothing: slightly emboldened stems), 'zoomed' (1x render enlarged)."""
    px = int(round(size * (scale if mode != 'zoomed' else 1)))
    if mode in ('mac', 'macsmooth'):
        big = render_line(face, text, px * 4, pad=max(4, px // 3) * 4)
        img = big.resize((max(4, big.width // 4), max(4, big.height // 4)), Image.BOX)
        if mode == 'macsmooth':
            a = np.asarray(img, dtype=np.float32) / 255.0
            a = np.clip(a ** 0.7 * 1.08, 0, 1)
            img = Image.fromarray((a * 255).astype(np.uint8))
    else:
        img = render_line(face, text, px)
    if mode == 'zoomed' and scale != 1.0:
        img = img.resize((max(4, int(img.width * scale)), max(4, int(img.height * scale))), Image.BILINEAR)
    if blur > 0:
        img = img.filter(ImageFilter.GaussianBlur(blur))
    a = np.asarray(img, dtype=np.float32) / 255.0
    fg, bg = (np.array([235, 235, 235]), np.array([28, 30, 34])) if light_on_dark else \
        (np.array(rng.choice([[20, 20, 20], [40, 40, 60], [10, 60, 120]])), np.array(rng.choice([[255, 255, 255], [246, 242, 236], [250, 250, 255]])))
    rgb = (bg[None, None, :] * (1 - a[..., None]) + fg[None, None, :] * a[..., None]).astype(np.uint8)
    out = Image.fromarray(rgb, 'RGB')
    if jpeg:
        buf = io.BytesIO()
        out.save(buf, 'JPEG', quality=jpeg)
        out = Image.open(io.BytesIO(buf.getvalue())).convert('RGB')
    return out


def ink_from_rgb(img):
    """Same normalisation as the app: luminance, Otsu, foreground → 1."""
    lum = np.asarray(img.convert('L'), dtype=np.float32) / 255.0
    hist = np.bincount(np.clip((lum * 255).astype(int), 0, 255).ravel(), minlength=256)
    t = otsu(hist) / 255.0
    dark = lum < t
    if dark.all() or (~dark).all():
        return None
    dm, lm = lum[dark].mean(), lum[~dark].mean()
    light_on_dark = dark.sum() > (~dark).sum()
    fg, bg = (lm, dm) if light_on_dark else (dm, lm)
    span = fg - bg
    if abs(span) < 0.08:
        return None
    return np.clip((lum - bg) / span, 0, 1)


def otsu(hist):
    total = hist.sum()
    s = np.dot(np.arange(256), hist)
    sB = wB = 0.0
    best, th = 0.0, 127
    for i in range(256):
        wB += hist[i]
        if wB == 0:
            continue
        wF = total - wB
        if wF == 0:
            break
        sB += i * hist[i]
        mB, mF = sB / wB, (s - sB) / wF
        between = wB * wF * (mB - mF) ** 2
        if between > best:
            best, th = between, i
    return th


def make_benchmark(faces, n, seed=1, families=None):
    rng = random.Random(seed)
    nrng = np.random.default_rng(seed)
    pool = [f for f in faces if f['weight'] in (300, 400, 500, 600, 700)]
    if families:
        pool = [f for f in pool if f['family'] in families]
    cases = []
    for k in range(n):
        face = rng.choice(pool)
        text = rng.choice(TEXTS)
        size = rng.choice([13, 15, 18, 22, 28, 36, 48, 64])
        scale = rng.choice([1.0, 1.0, 2.0])
        jpeg = rng.choice([None, None, 90, 75])
        blur = rng.choice([0, 0, 0, 0.4])
        lod = rng.random() < 0.2
        mode = rng.choice(['hinted', 'mac', 'mac', 'macsmooth', 'zoomed'])
        img = synth_sample(face, text, size, nrng, light_on_dark=lod, jpeg=jpeg, scale=scale, blur=blur, mode=mode)
        cases.append(dict(face=face, text=text, size=size, scale=scale, jpeg=jpeg, blur=blur, lod=lod, img=img, mode=mode))
    return cases
