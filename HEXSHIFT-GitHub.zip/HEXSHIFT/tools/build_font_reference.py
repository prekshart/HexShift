"""Builds HEXSHIFT's bundled Google Fonts reference: glyph bitmaps + metrics for matching.

Format (little-endian):
  magic 'HXFR' u32 version, u32 em, u32 faceCount, u32 charCount, chars[charCount] u32 (unicode scalars)
  per face: u16 nameLen, name utf8 (family), u16 slugLen, slug utf8, u16 weight, u8 italic, u8 category,
            i16 ascender, i16 descender, i16 xHeight, i16 capHeight (px at em),
            u32 blobOffset, u32 blobCompressedSize, u32 blobRawSize
  blobs: raw-deflate of, per char: u8 kind (0 none, 1 glyph, 2 advance only), [u8 w, u8 h, i8 left, i8 top, u16 advance*16, bitmap 4-bit packed] or [u16 advance*16]
"""
import struct, sys, zlib, json, re, os
import numpy as np
from PIL import Image, ImageDraw
import lib

EM = int(sys.argv[1]) if len(sys.argv) > 1 else 56
OUT = sys.argv[2] if len(sys.argv) > 2 else f'FontReference-{EM}.bin'
CHARS = [' '] + [chr(c) for c in range(33, 127)] + list('’“”–—…€£©')
CAT = {'serif': 1, 'sans-serif': 2, 'monospace': 3, 'display': 4, 'handwriting': 5}


def metadata(path):
    """Category and family name from the family's METADATA.pb."""
    meta = os.path.join(os.path.dirname(path), 'METADATA.pb')
    cat, name = 0, None
    if os.path.exists(meta):
        t = open(meta, encoding='utf-8').read()
        m = re.search(r'category:\s*"([A-Z_]+)"', t)
        if m:
            cat = {'SERIF': 1, 'SANS_SERIF': 2, 'MONOSPACE': 3, 'DISPLAY': 4, 'HANDWRITING': 5}.get(m.group(1), 0)
        m = re.search(r'^name:\s*"([^"]+)"', t, re.M)
        if m:
            name = m.group(1)
    return cat, name


def pack4(a):
    q = np.clip(np.round(a * 15), 0, 15).astype(np.uint8).ravel()
    if len(q) % 2:
        q = np.concatenate([q, np.zeros(1, np.uint8)])
    return ((q[0::2] << 4) | q[1::2]).tobytes()


def glyph(face, ch):
    f = lib.pil_font(face, EM)
    try:
        l, t, r, b = f.getbbox(ch, anchor='ls')
    except Exception:
        return None
    if r - l < 1 or b - t < 1:
        return None
    # Make sure the font really has this glyph (not .notdef / fallback box).
    from fontTools.ttLib import TTFont
    img = Image.new('L', (r - l + 4, b - t + 4), 0)
    ImageDraw.Draw(img).text((2 - l, 2 - t), ch, font=f, fill=255, anchor='ls')
    a = np.asarray(img, dtype=np.float32) / 255.0
    ys, xs = np.where(a > 0.02)
    if len(xs) == 0:
        return None
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    bmp = a[y0:y1, x0:x1]
    if bmp.shape[0] > 255 or bmp.shape[1] > 255:
        return None
    return dict(w=bmp.shape[1], h=bmp.shape[0], left=int(l + x0 - 2), top=int(t + y0 - 2),
                adv=int(round(f.getlength(ch) * 16)), bmp=bmp)


_cmaps = {}


def has_char(path, ch):
    if path not in _cmaps:
        from fontTools.ttLib import TTFont
        _cmaps[path] = set(TTFont(path, lazy=True).getBestCmap().keys())
    return ord(ch) in _cmaps[path]


def main():
    faces = lib.discover_faces(upright_only=False)
    keep = []
    for f in faces:
        if f['italic'] and f['weight'] != 400:
            continue
        keep.append(f)
    out_faces, blobs = [], []
    raw_total = 0
    for i, face in enumerate(keep):
        cat, gname = metadata(face['path'])
        fam = gname or face['family']
        recs = bytearray()
        for ch in CHARS:
            if ch == ' ':
                f = lib.pil_font(face, EM)
                recs += struct.pack('<BH', 2, int(round(f.getlength(' ') * 16)))
                continue
            g = glyph(face, ch) if has_char(face['path'], ch) else None
            if g is None:
                recs += b'\x00'
                continue
            recs += struct.pack('<BBBbbH', 1, g['w'], g['h'], max(-128, min(127, g['left'])), max(-128, min(127, g['top'])), min(65535, g['adv']))
            recs += pack4(g['bmp'])
        f = lib.pil_font(face, EM)
        def top_of(c):
            try:
                return -f.getbbox(c, anchor='ls')[1]
            except Exception:
                return 0
        asc, desc = top_of('d'), f.getbbox('p', anchor='ls')[3]
        comp = zlib.compressobj(9, zlib.DEFLATED, -15)
        blob = comp.compress(bytes(recs)) + comp.flush()
        raw_total += len(recs)
        slug = fam.replace(' ', '+')
        out_faces.append((fam, slug, face['weight'], int(face['italic']), cat, asc, desc, top_of('x'), top_of('H'), len(recs)))
        blobs.append(blob)
        if (i + 1) % 100 == 0:
            print(f'{i+1}/{len(keep)}', flush=True)
    header = bytearray(b'HXFR') + struct.pack('<IIII', 1, EM, len(out_faces), len(CHARS))
    header += b''.join(struct.pack('<I', ord(c)) for c in CHARS)
    table = bytearray()
    # compute offsets after the table
    entries = []
    for fam, slug, w, it, cat, asc, desc, xh, ch, raw in out_faces:
        nb, sb = fam.encode(), slug.encode()
        entries.append((nb, sb, w, it, cat, asc, desc, xh, ch, raw))
    table_size = sum(2 + len(e[0]) + 2 + len(e[1]) + 2 + 1 + 1 + 8 + 12 for e in entries)
    offset = len(header) + table_size
    for e, blob in zip(entries, blobs):
        nb, sb, w, it, cat, asc, desc, xh, ch, raw = e
        table += struct.pack('<H', len(nb)) + nb + struct.pack('<H', len(sb)) + sb
        table += struct.pack('<HBBhhhh', w, it, cat, asc, desc, xh, ch)
        table += struct.pack('<III', offset, len(blob), raw)
        offset += len(blob)
    data = bytes(header) + bytes(table) + b''.join(blobs)
    open(OUT, 'wb').write(data)
    print(f'{len(out_faces)} faces, {len(set(e[0] for e in entries))} families, raw {raw_total/1e6:.1f} MB -> file {len(data)/1e6:.2f} MB')


if __name__ == '__main__':
    main()
