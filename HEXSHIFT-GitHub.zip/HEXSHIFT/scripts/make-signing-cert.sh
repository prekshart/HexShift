#!/bin/bash
# Creates a free, local code-signing certificate called "HEXSHIFT Local" in your login keychain.
#
# Why: macOS remembers privacy permissions (Accessibility, Screen Recording) by an app's
# signature. Without a certificate every rebuild of HEXSHIFT looks like a new app, so the
# permissions are lost after each update. Signed with this certificate, they stay.
#
# The certificate only works on this Mac and can't be used to sign anything for other people.
# macOS asks for your login password once, to trust it for code signing.
# To remove it later: Keychain Access › login › My Certificates › "HEXSHIFT Local" › Delete.
set -euo pipefail
NAME="HEXSHIFT Local"
KC="$HOME/Library/Keychains/login.keychain-db"

if security find-identity -v -p codesigning | grep -q "\"$NAME\""; then
  echo "✓ \"$NAME\" is already set up. Nothing to do."
  exit 0
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cat > "$TMP/cert.cnf" <<CNF
[req]
distinguished_name = dn
x509_extensions = ext
prompt = no
[dn]
CN = $NAME
[ext]
basicConstraints = critical,CA:false
keyUsage = critical,digitalSignature
extendedKeyUsage = critical,codeSigning
CNF

echo "▸ Creating the certificate"
openssl req -x509 -newkey rsa:2048 -nodes -days 3650 -config "$TMP/cert.cnf" \
  -keyout "$TMP/key.pem" -out "$TMP/cert.pem" 2>/dev/null
openssl pkcs12 -export -inkey "$TMP/key.pem" -in "$TMP/cert.pem" -name "$NAME" \
  -out "$TMP/id.p12" -passout pass:hexshift 2>/dev/null

echo "▸ Adding it to your login keychain"
security import "$TMP/id.p12" -k "$KC" -P hexshift -T /usr/bin/codesign >/dev/null
echo "▸ Letting codesign use it — type your Mac login password if asked"
security set-key-partition-list -S apple-tool:,apple:,codesign: -s -l "$NAME" "$KC" >/dev/null || true

echo "▸ Trusting it for code signing — macOS will ask for your password now"
security add-trusted-cert -r trustRoot -p codeSign -k "$KC" "$TMP/cert.pem"

if security find-identity -v -p codesigning | grep -q "\"$NAME\""; then
  echo ""
  echo "✓ Done. HEXSHIFT builds will now be signed with \"$NAME\","
  echo "  so permissions you allow once stay allowed after updates."
else
  echo ""
  echo "The certificate was added but macOS doesn't trust it for code signing yet."
  echo "Open Keychain Access › login › Certificates › \"$NAME\" › Trust › Code Signing: Always Trust."
  exit 1
fi
