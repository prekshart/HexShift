#!/bin/bash
# Lets the build sign HEXSHIFT with your "HEXSHIFT Local" certificate without macOS refusing
# (the "errSecInternalComponent" error). It allows Apple's own signing tool, codesign, to use
# that one certificate's key. Nothing else in your keychain is touched.
#
# macOS asks for your Mac login password once (typing shows nothing — that's normal).
set -euo pipefail
NAME="HEXSHIFT Local"
KC="$HOME/Library/Keychains/login.keychain-db"

if ! security find-identity -v -p codesigning | grep -q "\"$NAME\""; then
  echo "The \"$NAME\" certificate isn't set up yet. Running the setup first…"
  bash "$(dirname "$0")/make-signing-cert.sh"
fi

echo "▸ Allowing codesign to use the \"$NAME\" key"
echo "  Type your Mac login password and press Return:"
security set-key-partition-list -S apple-tool:,apple:,codesign: -s -l "$NAME" "$KC" >/dev/null

echo "▸ Test signing"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
cp /usr/bin/true "$TMP/t"
if codesign --force --timestamp=none --sign "$NAME" "$TMP/t" 2>"$TMP/err"; then
  echo ""
  echo "✓ Signing works. Build and install again with:"
  echo "  ./install.command"
else
  cat "$TMP/err"
  echo ""
  echo "Signing still fails. Open Keychain Access › login › My Certificates › \"$NAME\","
  echo "expand it, double-click the key › Access Control › allow all applications, then try again."
  exit 1
fi
