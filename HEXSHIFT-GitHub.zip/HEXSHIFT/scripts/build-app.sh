#!/bin/bash
# Builds HEXSHIFT.app from source.
#
#   scripts/build-app.sh                 # release build → build/HEXSHIFT.app (ad-hoc signed)
#   scripts/build-app.sh --install       # …and copy it to /Applications (or ~/Applications)
#   SIGN_IDENTITY="HEXSHIFT Local" scripts/build-app.sh
#                                        # sign with a certificate from your keychain so macOS
#                                        # keeps Accessibility / Screen Recording permissions
#                                        # between rebuilds (see docs/REQUIREMENTS.md)
#   CONFIG=debug scripts/build-app.sh    # faster, unoptimised build
#
# Needs: macOS 14+, Xcode 15+ or the Command Line Tools (`xcode-select --install`).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CONFIG="${CONFIG:-release}"
SCRATCH="${HEXSHIFT_BUILD_DIR:-$HOME/Library/Caches/HEXSHIFT-build}"
OUT="$ROOT/build"
APP="$OUT/HEXSHIFT.app"
INSTALL=0
for arg in "$@"; do
  case "$arg" in
    --install) INSTALL=1 ;;
    -h|--help) sed -n '2,13p' "$0"; exit 0 ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

echo "▸ Building HEXSHIFT ($CONFIG)…"
cd "$ROOT"
HEXSHIFT_BUILD_DIR="$SCRATCH" bash "$ROOT/scripts/build.sh" "$CONFIG"
BIN="$SCRATCH/out/$CONFIG"

echo "▸ Assembling $APP"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$BIN/HEXSHIFT" "$APP/Contents/MacOS/HEXSHIFT"
cp "$BIN/hexshift-cli" "$APP/Contents/MacOS/hexshift-cli"
cp "$ROOT/Resources/Info.plist" "$APP/Contents/Info.plist"
printf 'APPL????' > "$APP/Contents/PkgInfo"

# Keep the version in Info.plist in step with the build number if one is given.
if [[ -n "${BUILD_NUMBER:-}" ]]; then
  /usr/libexec/PlistBuddy -c "Set :CFBundleVersion $BUILD_NUMBER" "$APP/Contents/Info.plist"
fi

if command -v iconutil >/dev/null 2>&1; then
  iconutil -c icns "$ROOT/Resources/AppIcon.iconset" -o "$APP/Contents/Resources/AppIcon.icns"
else
  echo "  (iconutil not found — app will use a generic icon)"
fi


# Optional extras shipped inside the app so Settings can install them.
if [[ -d "$ROOT/Extras/Browser Extension" ]]; then
  cp -R "$ROOT/Extras/Browser Extension" "$APP/Contents/Resources/Browser Extension"
fi
if [[ -d "$ROOT/Extras/Open in HEXSHIFT.workflow" ]]; then
  cp -R "$ROOT/Extras/Open in HEXSHIFT.workflow" "$APP/Contents/Resources/Open in HEXSHIFT.workflow"
fi
cp "$ROOT/THIRD_PARTY_NOTICES.md" "$APP/Contents/Resources/" 2>/dev/null || true
# Glyph reference of popular Google Fonts used by the font finder.
cp "$ROOT/Resources/FontReference.bin" "$APP/Contents/Resources/" 2>/dev/null || echo "  (FontReference.bin missing — font finder will use installed fonts only)"
cp "$ROOT/Sources/CWebP/LICENSE-libwebp.txt" "$APP/Contents/Resources/" 2>/dev/null || true

echo "▸ Signing"
ENTITLEMENTS="$ROOT/Resources/HEXSHIFT.entitlements"
# Use the local certificate from scripts/make-signing-cert.sh when it exists, so privacy
# permissions survive rebuilds.
if [[ -z "${SIGN_IDENTITY:-}" ]] && security find-identity -v -p codesigning 2>/dev/null | grep -q '"HEXSHIFT Local"'; then
  SIGN_IDENTITY="HEXSHIFT Local"
fi
echo "  identity: ${SIGN_IDENTITY:-ad hoc}"
if [[ -n "${SIGN_IDENTITY:-}" ]]; then
  # A real identity: hardened runtime on. Developer ID builds get a secure timestamp, which
  # notarisation requires (scripts/notarize.sh); local self-signed identities don't need one.
  TS="--timestamp=none"
  [[ "$SIGN_IDENTITY" == *"Developer ID"* ]] && TS="--timestamp"
  if ! codesign --force --options runtime $TS --sign "$SIGN_IDENTITY" "$APP/Contents/MacOS/hexshift-cli"; then
    echo ""
    echo "macOS wouldn't let the build use the \"$SIGN_IDENTITY\" certificate."
    echo "Fix it once with:  bash scripts/fix-signing.sh"
    exit 1
  fi
  codesign --force --options runtime $TS --entitlements "$ENTITLEMENTS" --sign "$SIGN_IDENTITY" "$APP"
else
  # Ad-hoc signature: runs on this Mac. macOS treats every rebuild as a new app for
  # privacy permissions, so you may need to re-allow Accessibility after rebuilding.
  codesign --force --sign - "$APP/Contents/MacOS/hexshift-cli"
  codesign --force --entitlements "$ENTITLEMENTS" --sign - "$APP"
fi
codesign --verify --strict "$APP" && echo "  signature OK"

if [[ "$INSTALL" == 1 ]]; then
  DEST="/Applications"
  [[ -w "$DEST" ]] || DEST="$HOME/Applications"
  mkdir -p "$DEST"
  echo "▸ Installing to $DEST"
  if pgrep -x HEXSHIFT >/dev/null 2>&1; then
    osascript -e 'tell application id "app.hexshift.HEXSHIFT" to quit' >/dev/null 2>&1 || pkill -x HEXSHIFT || true
    sleep 1
  fi
  rm -rf "$DEST/HEXSHIFT.app"
  cp -R "$APP" "$DEST/HEXSHIFT.app"
  # Register with Launch Services so "Open With", the URL scheme and Services appear.
  /System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$DEST/HEXSHIFT.app" || true
  /System/Library/CoreServices/pbs -update >/dev/null 2>&1 || true
  echo "  Installed: $DEST/HEXSHIFT.app"
  echo "  Launch it with: open \"$DEST/HEXSHIFT.app\""
else
  echo ""
  echo "Built: $APP"
  echo "Run it with:     open \"$APP\""
  echo "Install it with: scripts/build-app.sh --install"
fi
