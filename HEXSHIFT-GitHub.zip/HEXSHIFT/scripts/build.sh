#!/bin/bash
# Builds the HEXSHIFT app and command-line tool.
#
#   scripts/build.sh [debug|release]
#
# Binaries end up in ~/Library/Caches/HEXSHIFT-build/out/<config>/ (override with HEXSHIFT_BUILD_DIR).
# Uses Swift Package Manager when it works, otherwise falls back to scripts/build-direct.sh
# (swiftc + clang only). Set HEXSHIFT_DIRECT=1 to force the direct build.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CONFIG="${1:-debug}"
SCRATCH="${HEXSHIFT_BUILD_DIR:-$HOME/Library/Caches/HEXSHIFT-build}"
OUT="$SCRATCH/out/$CONFIG"
cd "$ROOT"

if ! command -v swiftc >/dev/null 2>&1; then
  echo "Swift was not found. Install the Command Line Tools with: xcode-select --install" >&2
  exit 1
fi

if [[ -z "${HEXSHIFT_DIRECT:-}" ]] && swift package --version >/dev/null 2>&1; then
  echo "▸ Swift Package Manager build ($CONFIG)"
  swift build -c "$CONFIG" --scratch-path "$SCRATCH" --product HEXSHIFT
  swift build -c "$CONFIG" --scratch-path "$SCRATCH" --product hexshift-cli
  BIN="$(swift build -c "$CONFIG" --scratch-path "$SCRATCH" --show-bin-path)"
  mkdir -p "$OUT"
  cp -f "$BIN/HEXSHIFT" "$BIN/hexshift-cli" "$OUT/"
else
  echo "▸ Swift Package Manager isn't usable on this Mac (swift-package failed to start)."
  echo "  Building directly with swiftc instead. Reinstalling the Command Line Tools fixes SwiftPM."
  bash "$ROOT/scripts/build-direct.sh" "$CONFIG" "$OUT"
fi
echo "Binaries: $OUT"
