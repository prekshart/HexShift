#!/bin/bash
# Builds, signs with your Developer ID, notarises and staples HEXSHIFT, then makes a DMG.
# Only needed to give HEXSHIFT to other people. Requires an Apple Developer Program membership.
#
# One-time setup:
#   1. Install your "Developer ID Application" certificate (Xcode › Settings › Accounts › Manage Certificates).
#   2. Store notarisation credentials (use an app-specific password from appleid.apple.com):
#        xcrun notarytool store-credentials HEXSHIFT-notary --apple-id you@example.com --team-id TEAMID
#
# Then:
#   SIGN_IDENTITY="Developer ID Application: Your Name (TEAMID)" scripts/notarize.sh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROFILE="${NOTARY_PROFILE:-HEXSHIFT-notary}"
: "${SIGN_IDENTITY:?Set SIGN_IDENTITY to your \"Developer ID Application: …\" certificate name}"
if [[ "$SIGN_IDENTITY" != *"Developer ID Application"* ]]; then
  echo "Notarisation needs a \"Developer ID Application\" certificate (got: $SIGN_IDENTITY)." >&2
  exit 1
fi

SIGN_IDENTITY="$SIGN_IDENTITY" "$ROOT/scripts/build-app.sh"
APP="$ROOT/build/HEXSHIFT.app"
ZIP="$ROOT/build/HEXSHIFT-notarize.zip"
DMG="$ROOT/build/HEXSHIFT.dmg"

echo "▸ Submitting for notarisation (this usually takes a few minutes)…"
rm -f "$ZIP"
ditto -c -k --keepParent "$APP" "$ZIP"
xcrun notarytool submit "$ZIP" --keychain-profile "$PROFILE" --wait
xcrun stapler staple "$APP"
rm -f "$ZIP"

echo "▸ Checking Gatekeeper"
spctl --assess --type execute --verbose=2 "$APP"

echo "▸ Making $DMG"
rm -f "$DMG"
STAGE="$(mktemp -d)"
cp -R "$APP" "$STAGE/"
ln -s /Applications "$STAGE/Applications"
hdiutil create -volname "HEXSHIFT" -srcfolder "$STAGE" -ov -format UDZO "$DMG" >/dev/null
rm -rf "$STAGE"
codesign --force --timestamp --sign "$SIGN_IDENTITY" "$DMG"
xcrun notarytool submit "$DMG" --keychain-profile "$PROFILE" --wait
xcrun stapler staple "$DMG"
echo ""
echo "Done: $DMG is signed, notarised and ready to share."
