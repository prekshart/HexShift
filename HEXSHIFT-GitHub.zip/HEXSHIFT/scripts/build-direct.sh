#!/bin/bash
# Builds HEXSHIFT with swiftc and clang directly, without Swift Package Manager.
# Used automatically when `swift build` isn't usable (for example a damaged Command Line Tools
# install where `swift-package` crashes), and handy on machines with only the bare toolchain.
#
#   scripts/build-direct.sh [debug|release] [output-dir]
#
# Produces <output-dir>/hexshift-cli and <output-dir>/HEXSHIFT.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CONFIG="${1:-debug}"
OUT="${2:-${HEXSHIFT_BUILD_DIR:-$HOME/Library/Caches/HEXSHIFT-build}/direct/$CONFIG}"
ARCH="$(uname -m)"
TARGET="$ARCH-apple-macosx14.0"
SDK="$(xcrun --show-sdk-path)"
JOBS="$(sysctl -n hw.ncpu 2>/dev/null || echo 8)"

mkdir -p "$OUT/obj/CWebP" "$OUT/modules" "$OUT/CWebP"
cd "$ROOT"

if [[ "$CONFIG" == "release" ]]; then
  SWIFT_OPT=(-O -whole-module-optimization)
  C_OPT=(-O2)
else
  SWIFT_OPT=(-Onone -g -DDEBUG)
  C_OPT=(-O1 -g)
fi

echo "▸ [direct] C: libwebp ($CONFIG)"
CWEBP="$ROOT/Sources/CWebP"
export CWEBP OUT TARGET SDK
C_FLAGS="-target $TARGET -isysroot $SDK ${C_OPT[*]} -w -DWEBP_USE_THREAD -I$CWEBP -I$CWEBP/include"
export C_FLAGS
# Compile only what changed since the last build.
find "$CWEBP" -name '*.c' -print0 | xargs -0 -P "$JOBS" -I{} bash -c '
  src="$1"; rel="${src#$CWEBP/}"; obj="$OUT/obj/CWebP/${rel//\//_}.o"
  if [[ ! -f "$obj" || "$src" -nt "$obj" ]]; then clang $C_FLAGS -c "$src" -o "$obj" || exit 255; fi
' _ {}
rm -f "$OUT/libCWebP.a"
ar rcs "$OUT/libCWebP.a" "$OUT"/obj/CWebP/*.o
cat > "$OUT/CWebP/module.modulemap" <<EOF
module CWebP {
    header "$CWEBP/include/hexwebp.h"
    export *
}
EOF

SWIFT_BASE=(-target "$TARGET" -sdk "$SDK" -swift-version 5 -j"$JOBS"
            -Xcc "-fmodule-map-file=$OUT/CWebP/module.modulemap" -I "$CWEBP/include" -I "$OUT/modules")
SWIFT_COMMON=("${SWIFT_BASE[@]}" "${SWIFT_OPT[@]}")
FRAMEWORKS=(-framework AppKit -framework PDFKit -framework Quartz -framework Vision -framework AVFoundation
            -framework AVKit -framework WebKit -framework CoreImage -framework Accelerate -framework ImageIO
            -framework CoreText -framework QuickLookThumbnailing -framework UniformTypeIdentifiers
            -framework ServiceManagement -framework Carbon -framework ApplicationServices
            -Xlinker -weak_framework -Xlinker Translation)

echo "▸ [direct] Swift: HexshiftKit"
# The engine is always optimised (image analysis is far too slow unoptimised); debug info stays on.
KIT_OPT=("${SWIFT_OPT[@]}")
if [[ "$CONFIG" != "release" ]]; then KIT_OPT=(-O -g); fi
swiftc "${SWIFT_BASE[@]}" "${KIT_OPT[@]}" -parse-as-library -module-name HexshiftKit \
  -emit-module -emit-module-path "$OUT/modules/HexshiftKit.swiftmodule" \
  -emit-library -static -o "$OUT/libHexshiftKit.a" \
  $(find Sources/HexshiftKit -name '*.swift' | sort)

echo "▸ [direct] Swift: hexshift-cli"
swiftc "${SWIFT_COMMON[@]}" -module-name hexshift_cli \
  Sources/hexshift-cli/main.swift \
  -L "$OUT" -lHexshiftKit -lCWebP "${FRAMEWORKS[@]}" -o "$OUT/hexshift-cli"

echo "▸ [direct] Swift: HEXSHIFT app"
swiftc "${SWIFT_COMMON[@]}" -module-name HEXSHIFT \
  $(find Sources/HEXSHIFT -name '*.swift' | sort) \
  -L "$OUT" -lHexshiftKit -lCWebP "${FRAMEWORKS[@]}" -o "$OUT/HEXSHIFT"

echo "Built (direct, $CONFIG): $OUT"
