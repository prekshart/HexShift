# HEXSHIFT for Chrome, Edge, Brave and Arc

Right-click text on a web page → **Inspect font with HEXSHIFT**. A card shows the computed CSS the
browser is really applying — font stack, the family that is most likely rendering, size, weight,
style, line height, letter spacing and colour — with **Copy CSS** and **Open in HEXSHIFT** (Font Lens).

You can also click the toolbar button or press **⌥⇧F**: if text is selected it is inspected,
otherwise you click the text you want.

Right-click → **Capture visible page with HEXSHIFT** saves a PNG of what's on screen to
*Downloads › HEXSHIFT Captures* and opens it in the HEXSHIFT wheel (convert, OCR, pick colours, find fonts…).

## Install (developer mode — no Web Store account needed)

1. Open `chrome://extensions` (or `edge://extensions`, `brave://extensions`).
2. Turn on **Developer mode**.
3. Click **Load unpacked** and choose this folder (`Browser Extension`).
   In HEXSHIFT: Settings › Typography › **Show Extension Folder** puts a copy where browsers can load it and shows it in Finder. You can also drag that folder onto the extensions page.

## Privacy

- Permissions: `contextMenus`, `activeTab`, `scripting` and `downloads`. There is no "read all websites"
  permission; the inspector runs in, and captures are taken of, a tab only when you ask. `downloads` is used only to
  save page captures.
- Nothing is sent over the network. **Open in HEXSHIFT** passes the values to the app on your Mac through a
  `hexshift://font?...` link (the browser asks before opening it the first time). That link can only open the
  Font Lens window — it cannot touch files.

## Limits

- Browsers don't let pages read the exact *rendered* font; the card works it out from the font stack
  (web fonts that are loaded, fonts installed on your Mac, then generic families) and says how it decided.
- Browser-internal pages (`chrome://…`, the Web Store, the PDF viewer) can't be inspected by any extension.
- Page capture covers the visible area, not the whole scrolling page.
- Safari needs a Safari Web Extension built with Xcode: `xcrun safari-web-extension-converter "Browser Extension"`
  generates one from this folder.
