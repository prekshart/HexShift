// HEXSHIFT Font Inspector — injected on demand into the page you are inspecting.
// Reads the *computed* CSS of the element (what the browser actually applies), estimates which
// family in the font stack is really rendering, and shows a small card. Nothing leaves the page
// unless you press "Open in HEXSHIFT", which hands the values to the HEXSHIFT app on this Mac.
(() => {
  if (globalThis.__hexshiftInspector) return;

  const ACCENT = "#FF6A4D";
  const GENERIC = new Set([
    "serif", "sans-serif", "monospace", "cursive", "fantasy", "system-ui", "ui-serif",
    "ui-sans-serif", "ui-monospace", "ui-rounded", "emoji", "math", "fangsong",
    "-apple-system", "blinkmacsystemfont",
  ]);

  const STYLE = `
    :host { all: initial; }
    * { box-sizing: border-box; }
    .hover { position: fixed; pointer-events: none; border: 2px solid ${ACCENT}; border-radius: 4px;
             background: rgba(255,106,77,0.08); display: none; transition: all 60ms ease-out; }
    .toast { position: fixed; left: 50%; top: 16px; transform: translateX(-50%); pointer-events: none;
             background: #1f1f1f; color: #fff; font: 500 13px/1.3 -apple-system, BlinkMacSystemFont, sans-serif;
             padding: 9px 14px; border-radius: 999px; box-shadow: 0 6px 20px rgba(0,0,0,.25); }
    .card { position: fixed; width: 320px; pointer-events: auto; color: #222; background: #FBFAF7;
            border: 1px solid rgba(0,0,0,.08); border-radius: 14px; box-shadow: 0 18px 50px rgba(0,0,0,.22);
            font: 12px/1.4 -apple-system, BlinkMacSystemFont, "Helvetica Neue", sans-serif; overflow: hidden; }
    @media (prefers-color-scheme: dark) {
      .card { color: #eee; background: #252423; border-color: rgba(255,255,255,.1); }
      .row .k { color: #9a9894 !important; }
      .sample { border-color: rgba(255,255,255,.08) !important; }
      button.secondary { background: rgba(255,255,255,.08) !important; color: #eee !important; }
    }
    .head { display: flex; align-items: center; gap: 8px; padding: 12px 14px 8px; }
    .dot { width: 10px; height: 10px; border-radius: 3px; background: ${ACCENT}; transform: rotate(30deg); }
    .title { font-weight: 700; font-size: 13px; flex: 1; }
    .close { all: unset; cursor: pointer; font-size: 16px; line-height: 1; padding: 2px 6px; border-radius: 6px; opacity: .55; }
    .close:hover { opacity: 1; background: rgba(127,127,127,.15); }
    .sample { margin: 0 14px 10px; padding: 10px 12px; border-radius: 10px; border: 1px solid rgba(0,0,0,.06);
              max-height: 92px; overflow: hidden; word-break: break-word; }
    .rows { padding: 0 14px 6px; }
    .row { display: flex; gap: 10px; padding: 3px 0; }
    .row .k { width: 96px; flex: none; color: #8a8782; }
    .row .v { flex: 1; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 11.5px; word-break: break-word; }
    .note { padding: 2px 14px 10px; color: #8a8782; font-size: 11px; }
    .swatch { display: inline-block; width: 10px; height: 10px; border-radius: 3px; vertical-align: -1px; margin-right: 6px;
              border: 1px solid rgba(0,0,0,.15); }
    .buttons { display: flex; gap: 8px; padding: 10px 14px 14px; }
    button { all: unset; cursor: pointer; text-align: center; flex: 1; padding: 7px 10px; border-radius: 8px;
             font: 600 12px/1.2 -apple-system, BlinkMacSystemFont, sans-serif; }
    button.primary { background: ${ACCENT}; color: #fff; }
    button.secondary { background: rgba(0,0,0,.06); color: #222; }
    button:focus-visible { outline: 2px solid ${ACCENT}; outline-offset: 2px; }
  `;

  let host = null, root = null, hoverBox = null, toast = null, card = null, picking = false;

  function ensureHost() {
    if (host && document.documentElement.contains(host)) return;
    host = document.createElement("hexshift-inspector");
    host.style.cssText = "all: initial; position: fixed; inset: 0; pointer-events: none; z-index: 2147483647;";
    root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = STYLE;
    root.appendChild(style);
    hoverBox = document.createElement("div");
    hoverBox.className = "hover";
    root.appendChild(hoverBox);
    document.documentElement.appendChild(host);
  }

  // ---- font analysis -------------------------------------------------------------------

  function splitFamilies(stack) {
    const out = [];
    let cur = "", quote = null;
    for (const ch of stack) {
      if (quote) { if (ch === quote) quote = null; else cur += ch; }
      else if (ch === '"' || ch === "'") quote = ch;
      else if (ch === ",") { if (cur.trim()) out.push(cur.trim()); cur = ""; }
      else cur += ch;
    }
    if (cur.trim()) out.push(cur.trim());
    return out;
  }

  function webFontLoaded(family) {
    try {
      const want = family.toLowerCase();
      for (const face of document.fonts) {
        if (face.status === "loaded" && face.family.replace(/["']/g, "").trim().toLowerCase() === want) return true;
      }
    } catch (_) { /* some pages lock down document.fonts */ }
    return false;
  }

  let canvasCtx = null;
  function localFontAvailable(family) {
    // Classic width test: if text measures differently with the family than with each
    // generic fallback, the family exists on this machine.
    canvasCtx = canvasCtx || document.createElement("canvas").getContext("2d");
    if (!canvasCtx) return false;
    const text = "mmmmmmmmmmlli1WQ@#&gy";
    const name = family.replace(/"/g, "");
    for (const base of ["monospace", "serif", "sans-serif"]) {
      canvasCtx.font = `72px ${base}`;
      const w0 = canvasCtx.measureText(text).width;
      canvasCtx.font = `72px "${name}", ${base}`;
      if (Math.abs(canvasCtx.measureText(text).width - w0) > 0.5) return true;
    }
    return false;
  }

  function likelyRendered(families) {
    for (const f of families) {
      if (GENERIC.has(f.toLowerCase())) return { name: f, how: "generic family — the browser chooses a system font" };
      if (webFontLoaded(f)) return { name: f, how: "web font loaded by this page" };
      if (localFontAvailable(f)) return { name: f, how: "installed on this computer" };
    }
    return { name: families[0] || "Unknown", how: "couldn't be confirmed" };
  }

  function toHex(colour) {
    const m = colour.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+%?))?\s*\)/i);
    if (!m) return colour;
    const h = (n) => Math.max(0, Math.min(255, Math.round(parseFloat(n)))).toString(16).padStart(2, "0");
    let hex = `#${h(m[1])}${h(m[2])}${h(m[3])}`.toUpperCase();
    if (m[4] !== undefined) {
      const a = m[4].endsWith("%") ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
      if (a < 1) hex += h(a * 255).toUpperCase();
    }
    return hex;
  }

  function sampleText(el) {
    const sel = window.getSelection();
    const selected = sel && !sel.isCollapsed ? sel.toString().trim() : "";
    const text = selected || (el.innerText || el.textContent || "").trim();
    return text.replace(/\s+/g, " ").slice(0, 160);
  }

  function analyse(el) {
    const cs = getComputedStyle(el);
    const families = splitFamilies(cs.fontFamily);
    const used = likelyRendered(families);
    return {
      family: families[0] || cs.fontFamily,
      stack: cs.fontFamily,
      used: used.name,
      usedHow: used.how,
      size: cs.fontSize,
      weight: cs.fontWeight,
      style: cs.fontStyle,
      lineHeight: cs.lineHeight,
      letterSpacing: cs.letterSpacing,
      color: toHex(cs.color),
      transform: cs.textTransform,
      features: cs.fontFeatureSettings,
      variation: cs.fontVariationSettings,
      text: sampleText(el),
      source: location.hostname || "page",
    };
  }

  function cssFor(d) {
    const lines = [
      `font-family: ${d.stack};`,
      `font-size: ${d.size};`,
      `font-weight: ${d.weight};`,
    ];
    if (d.style && d.style !== "normal") lines.push(`font-style: ${d.style};`);
    lines.push(`line-height: ${d.lineHeight};`);
    if (d.letterSpacing && d.letterSpacing !== "normal") lines.push(`letter-spacing: ${d.letterSpacing};`);
    lines.push(`color: ${d.color};`);
    if (d.transform && d.transform !== "none") lines.push(`text-transform: ${d.transform};`);
    if (d.features && d.features !== "normal") lines.push(`font-feature-settings: ${d.features};`);
    if (d.variation && d.variation !== "normal") lines.push(`font-variation-settings: ${d.variation};`);
    return lines.join("\n");
  }

  function hexshiftURL(d) {
    // encodeURIComponent (not URLSearchParams) so spaces become %20, which the app decodes.
    const params = {
      family: d.family, used: d.used, size: String(parseFloat(d.size) || ""), weight: String(d.weight),
      style: d.style, color: d.color, "line-height": d.lineHeight, "letter-spacing": d.letterSpacing,
      text: d.text, source: d.source,
    };
    return "hexshift://font?" + Object.entries(params)
      .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v ?? "")}`)
      .join("&");
  }

  // ---- UI ------------------------------------------------------------------------------

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function showToast(message, ms) {
    ensureHost();
    if (toast) toast.remove();
    toast = el("div", "toast", message);
    root.appendChild(toast);
    if (ms) { const t = toast; setTimeout(() => t.remove(), ms); }
  }

  async function copy(text) {
    try { await navigator.clipboard.writeText(text); return true; } catch (_) { /* fall back */ }
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.cssText = "position:fixed;top:-1000px;opacity:0";
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch (_) { ok = false; }
    ta.remove();
    return ok;
  }

  function closeCard() {
    if (card) { card.remove(); card = null; }
    document.removeEventListener("keydown", onCardKey, true);
  }

  function onCardKey(e) { if (e.key === "Escape") { e.stopPropagation(); closeCard(); } }

  function renderCard(target, d) {
    ensureHost();
    closeCard();
    card = el("div", "card");
    const head = el("div", "head");
    head.append(el("div", "dot"), el("div", "title", d.used));
    const x = el("button", "close", "×");
    x.setAttribute("aria-label", "Close");
    x.addEventListener("click", closeCard);
    head.append(x);
    card.append(head);

    const sample = el("div", "sample", d.text || "The quick brown fox jumps over the lazy dog");
    sample.style.fontFamily = d.stack;
    sample.style.fontWeight = d.weight;
    sample.style.fontStyle = d.style;
    sample.style.fontSize = Math.min(parseFloat(d.size) || 16, 28) + "px";
    sample.style.color = d.color;
    card.append(sample);

    const rows = el("div", "rows");
    const add = (k, v, swatch) => {
      const r = el("div", "row");
      r.append(el("div", "k", k));
      const val = el("div", "v");
      if (swatch) { const s = el("span", "swatch"); s.style.background = swatch; val.append(s); }
      val.append(document.createTextNode(v));
      r.append(val);
      rows.append(r);
    };
    add("Rendering", `${d.used}`);
    add("Font stack", d.stack);
    add("Size", d.size);
    add("Weight", String(d.weight));
    if (d.style !== "normal") add("Style", d.style);
    add("Line height", d.lineHeight);
    if (d.letterSpacing !== "normal") add("Letter spacing", d.letterSpacing);
    add("Colour", d.color, d.color);
    if (d.features && d.features !== "normal") add("Features", d.features);
    card.append(rows);
    card.append(el("div", "note", `Computed CSS. Rendering font: ${d.usedHow}.`));

    const buttons = el("div", "buttons");
    const copyBtn = el("button", "secondary", "Copy CSS");
    copyBtn.addEventListener("click", async () => {
      const ok = await copy(cssFor(d));
      copyBtn.textContent = ok ? "Copied" : "Copy failed";
      setTimeout(() => { copyBtn.textContent = "Copy CSS"; }, 1400);
    });
    const open = el("button", "primary", "Open in HEXSHIFT");
    open.addEventListener("click", () => {
      const a = document.createElement("a");
      a.href = hexshiftURL(d);
      a.rel = "noopener";
      document.body.appendChild(a);
      a.click();
      a.remove();
    });
    buttons.append(copyBtn, open);
    card.append(buttons);
    root.append(card);

    // Place next to the element, kept on screen.
    const r = target.getBoundingClientRect();
    const w = 320, h = card.getBoundingClientRect().height || 340;
    let left = r.right + 12;
    if (left + w > innerWidth - 8) left = r.left - w - 12;
    if (left < 8) left = Math.max(8, Math.min(innerWidth - w - 8, r.left));
    let top = r.top;
    if (top + h > innerHeight - 8) top = innerHeight - h - 8;
    card.style.left = `${Math.max(8, left)}px`;
    card.style.top = `${Math.max(8, top)}px`;
    document.addEventListener("keydown", onCardKey, true);
    open.focus();
  }

  // ---- picking -------------------------------------------------------------------------

  function elementAt(x, y) {
    const n = document.elementFromPoint(x, y);
    return n && n !== host ? n : null;
  }

  function onMove(e) {
    const n = elementAt(e.clientX, e.clientY);
    if (!n) return;
    const r = n.getBoundingClientRect();
    Object.assign(hoverBox.style, {
      display: "block", left: `${r.left - 2}px`, top: `${r.top - 2}px`, width: `${r.width + 4}px`, height: `${r.height + 4}px`,
    });
  }

  function swallow(e) { if (picking) { e.preventDefault(); e.stopPropagation(); } }

  function onClick(e) {
    if (!picking) return;
    swallow(e);
    const n = elementAt(e.clientX, e.clientY);
    stopPicking();
    if (n) renderCard(n, analyse(n));
  }

  function onKey(e) {
    if (picking && e.key === "Escape") { swallow(e); stopPicking(); }
  }

  const listeners = [
    ["mousemove", onMove], ["pointerdown", swallow], ["mousedown", swallow], ["mouseup", swallow],
    ["pointerup", swallow], ["click", onClick], ["keydown", onKey],
  ];

  function startPicking() {
    ensureHost();
    closeCard();
    picking = true;
    showToast("Click any text to inspect its font  ·  Esc to cancel");
    for (const [type, fn] of listeners) document.addEventListener(type, fn, true);
  }

  function stopPicking() {
    picking = false;
    for (const [type, fn] of listeners) document.removeEventListener(type, fn, true);
    if (hoverBox) hoverBox.style.display = "none";
    if (toast) { toast.remove(); toast = null; }
  }

  function selectionElement() {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || sel.rangeCount === 0) return null;
    let n = sel.getRangeAt(0).startContainer;
    if (n.nodeType === Node.TEXT_NODE) n = n.parentElement;
    return n instanceof Element ? n : null;
  }

  globalThis.__hexshiftInspector = {
    start(mode) {
      if (picking) stopPicking();
      const selected = mode !== "pick" ? selectionElement() : null;
      if (selected) renderCard(selected, analyse(selected));
      else startPicking();
    },
  };
})();
