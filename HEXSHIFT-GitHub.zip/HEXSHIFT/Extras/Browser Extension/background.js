// HEXSHIFT for Chrome — background service worker.
// Uses "activeTab": scripts run in, and screenshots are taken of, only the tab you right-clicked,
// at the moment you ask. Nothing is sent over the network.

const FONT_MENU = "hexshift-inspect-font";
const CAPTURE_MENU = "hexshift-capture-page";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: FONT_MENU,
    title: "Inspect font with HEXSHIFT",
    contexts: ["selection", "page", "link"],
  });
  chrome.contextMenus.create({
    id: CAPTURE_MENU,
    title: "Capture visible page with HEXSHIFT",
    contexts: ["page", "image", "link", "selection"],
  });
});

async function inject(tabId, frameId, mode) {
  const target = frameId != null ? { tabId, frameIds: [frameId] } : { tabId };
  try {
    await chrome.scripting.executeScript({ target, files: ["inspector.js"] });
    await chrome.scripting.executeScript({
      target,
      func: (m) => globalThis.__hexshiftInspector && globalThis.__hexshiftInspector.start(m),
      args: [mode],
    });
  } catch (err) {
    // Chrome pages, the Web Store and PDF viewers can't be scripted by any extension.
    console.warn("HEXSHIFT: this page can't be inspected —", err && err.message);
  }
}

/** Opens a hexshift:// link from inside the page, so the browser shows its normal
 *  "Open HEXSHIFT?" confirmation instead of a blank tab. */
async function openInApp(tabId, url) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (link) => {
      const a = document.createElement("a");
      a.href = link;
      a.rel = "noopener";
      document.documentElement.appendChild(a);
      a.click();
      a.remove();
    },
    args: [url],
  });
}

function waitForDownload(id) {
  return new Promise((resolve, reject) => {
    const listener = (delta) => {
      if (delta.id !== id || !delta.state) return;
      if (delta.state.current === "complete") {
        chrome.downloads.onChanged.removeListener(listener);
        chrome.downloads.search({ id }, (items) => resolve(items && items[0]));
      } else if (delta.state.current === "interrupted") {
        chrome.downloads.onChanged.removeListener(listener);
        reject(new Error("download interrupted"));
      }
    };
    chrome.downloads.onChanged.addListener(listener);
  });
}

async function capture(tab) {
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
    const host = (() => { try { return new URL(tab.url).hostname.replace(/^www\./, ""); } catch (_) { return "page"; } })();
    const stamp = new Date().toISOString().replace(/[:T]/g, "-").slice(0, 19);
    const id = await chrome.downloads.download({
      url: dataUrl,
      filename: `HEXSHIFT Captures/${host || "page"} ${stamp}.png`,
      conflictAction: "uniquify",
      saveAs: false,
    });
    const item = await waitForDownload(id);
    if (item && item.filename) {
      await openInApp(tab.id, "hexshift://open?path=" + encodeURIComponent(item.filename));
    }
  } catch (err) {
    console.warn("HEXSHIFT: couldn't capture this page —", err && err.message);
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || tab.id == null) return;
  if (info.menuItemId === FONT_MENU) inject(tab.id, info.frameId, info.selectionText ? "selection" : "pick");
  if (info.menuItemId === CAPTURE_MENU) capture(tab);
});

chrome.action.onClicked.addListener((tab) => {
  if (tab && tab.id != null) inject(tab.id, null, "auto");
});
