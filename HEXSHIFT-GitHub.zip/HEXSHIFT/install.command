#!/bin/bash
# HEXSHIFT installer
# Double-click this file in Finder (first time: right-click › Open).
# It builds HEXSHIFT from the source in this folder and puts HEXSHIFT.app in Applications.
set -uo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT" || exit 1

bold=$'\033[1m'; dim=$'\033[2m'; red=$'\033[31m'; green=$'\033[32m'; off=$'\033[0m'
say()  { echo "${bold}$*${off}"; }
fail() { echo ""; echo "${red}✗ $*${off}"; echo ""; read -r -p "Press Return to close this window." _; exit 1; }

clear
echo ""
say "  ⬢  HEXSHIFT installer"
echo "${dim}  Select anything. Create anything.${off}"
echo ""

# 1. macOS version
ver="$(sw_vers -productVersion 2>/dev/null || echo 0)"
major="${ver%%.*}"
if [[ "$major" -lt 14 ]]; then
  fail "HEXSHIFT needs macOS 14 Sonoma or later. This Mac has macOS $ver."
fi
echo "  ✓ macOS $ver"

# 2. Apple's developer tools (needed once to build the app)
if ! xcode-select -p >/dev/null 2>&1 || ! command -v swiftc >/dev/null 2>&1; then
  echo ""
  say "  Apple's Command Line Tools are needed to build HEXSHIFT."
  echo "  A window will open asking to install them. Click Install, wait for it to finish"
  echo "  (about 5–10 minutes), then double-click install.command again."
  xcode-select --install >/dev/null 2>&1 || true
  echo ""
  read -r -p "Press Return to close this window." _
  exit 0
fi
echo "  ✓ Command Line Tools ($(swiftc --version 2>/dev/null | head -1 | sed 's/.*Swift version \([0-9.]*\).*/Swift \1/'))"

# 3. Files downloaded from the internet are marked "quarantined". Clear that for this folder only.
xattr -dr com.apple.quarantine "$ROOT" >/dev/null 2>&1 || true

# 4. Build and install
echo ""
say "  Building HEXSHIFT. The first build takes a few minutes…"
echo ""
chmod +x scripts/*.sh 2>/dev/null || true
if ! bash scripts/build-app.sh --install; then
  fail "The build stopped. Scroll up for the error, and see INSTALL.md › Troubleshooting."
fi

DEST="/Applications/HEXSHIFT.app"
[[ -d "$DEST" ]] || DEST="$HOME/Applications/HEXSHIFT.app"

echo ""
echo "${green}${bold}  ✓ HEXSHIFT is installed in ${DEST%/HEXSHIFT.app}${off}"
echo ""
echo "  • Look for the hexagon icon in the menu bar."
echo "  • Press ⌥ Space (Option + Space) to open the wheel. You can change this in Settings."
echo "  • macOS will ask for permissions the first time a feature needs them."
echo ""
open "$DEST" >/dev/null 2>&1 || true
read -r -p "Press Return to close this window." _
