# How to install HEXSHIFT

This takes about **5 minutes**. You'll click a few buttons — that's it. Follow the steps in order and
you're done. The pictures show exactly what you'll see on screen.

**You need:** a Mac with **macOS 14 (Sonoma) or newer**. The first time, your Mac may download a small
free helper from Apple — that's normal, and the steps below tell you when.

---

## Step 1 — Open the folder and start the installer

Open the **HEXSHIFT** folder you just unzipped, and **double-click `install.command`**.

![The HEXSHIFT folder with install.command selected](docs/images/01-run.png)

---

## Step 2 — Your Mac shows a warning. Click **Done**.

A box pops up saying your Mac "could not verify" the file. **This is completely normal** — it happens
with every app that doesn't come from Apple's App Store. HEXSHIFT is safe.

👉 Click **Done**.

⚠️ **Do not click "Move to Trash"** — that deletes the installer.

![The warning box — click Done, not Move to Trash](docs/images/02-done.png)

Nothing seems to happen after you click Done. That's expected — the next step tells your Mac you trust
HEXSHIFT.

---

## Step 3 — Tell your Mac it's okay to run

1. Click the **Apple logo** () at the top-left of your screen → **System Settings**.
2. In the left sidebar, click **Privacy & Security**.
3. Scroll down until you see a line that says *“install.command” was blocked…*
4. Click the **Open Anyway** button next to it.
5. Your Mac asks you to confirm — use **Touch ID** or type your Mac password.

![System Settings, Privacy & Security — click Open Anyway](docs/images/03-openanyway.png)

---

## Step 4 — Click **Open**

One last box appears. Click **Open**.

![The final box — click Open](docs/images/04-open.png)

The installer now starts and a black **Terminal** window opens showing its progress. You don't need to
type anything — just let it run.

---

## Step 5 — If your Mac asks to install a helper

The very first time, a small window may appear asking to install **Apple's developer tools** (a free,
one-time helper HEXSHIFT needs to set itself up).

- Click **Install** and wait for it to finish (about **5–10 minutes**).
- When it's done, **double-click `install.command` again**. This time it opens straight away with no
  warnings, and finishes in a minute or two.

If this window doesn't appear, you can skip this step — HEXSHIFT is already finishing.

---

## 🎉 You're done!

When it finishes, a small **hexagon icon** appears in the menu bar at the top-right of your screen, and
HEXSHIFT is now in your **Applications** folder.

**To use it:** select a file, some text, or nothing at all, then press **⌥ Space** (hold the Option
key and tap the Space bar). The wheel opens right where your mouse is.

---

## The first time you use certain features

HEXSHIFT will ask your permission the first time it needs it — just click **Allow** or **OK**. It only
ever asks for what a feature needs:

- **To know which files you picked** in Finder
- **To read selected text** (and its font) in other apps
- **To capture the screen or pick a colour** from anywhere on screen

Your files and everything you do stay on your Mac. Nothing is uploaded.

---

## To remove HEXSHIFT later

Open the same folder and **double-click `uninstall.command`** (if it's blocked, repeat Steps 2–4 for
it), then type `yes` and press Return. It removes HEXSHIFT completely. Files you converted or edited
are never touched.

---

## If a step doesn't work

**You don't see an "Open Anyway" button in Step 3.**
Make sure you clicked **Done** in Step 2 first — the button only appears *after* your Mac has blocked
it once. Then look again under System Settings → Privacy & Security.

**Still stuck?**
There's a one-line shortcut that skips the warnings: open **Terminal** (press ⌘ Space, type
`Terminal`, press Return), type `bash ` and a space, then drag `install.command` from the folder into
the Terminal window and press **Return**.

**The hexagon icon doesn't appear / the wheel won't open.**
Open HEXSHIFT from your Applications folder once. If **⌥ Space** does nothing, another app may be using
it — you can pick a different shortcut in HEXSHIFT's **Settings › Activation** (click the hexagon icon
in the menu bar, then Settings).
