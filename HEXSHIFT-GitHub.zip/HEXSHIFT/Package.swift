// swift-tools-version:5.9
// HEXSHIFT — Select Anything. Create Anything.
// Native macOS creative utility. Build with `swift build` or `scripts/build-app.sh`.
import PackageDescription

let package = Package(
    name: "HEXSHIFT",
    platforms: [.macOS(.v14)],
    products: [
        .executable(name: "HEXSHIFT", targets: ["HEXSHIFT"]),
        .executable(name: "hexshift-cli", targets: ["hexshift-cli"]),
        .library(name: "HexshiftKit", targets: ["HexshiftKit"]),
    ],
    targets: [
        // Vendored libwebp 1.5.0 (BSD-3-Clause) — used only for WebP *encoding*.
        // macOS decodes WebP natively through ImageIO.
        .target(
            name: "CWebP",
            path: "Sources/CWebP",
            exclude: ["LICENSE-libwebp.txt", "PATENTS-libwebp.txt", "AUTHORS-libwebp.txt"],
            cSettings: [
                .headerSearchPath("."),
                .define("WEBP_USE_THREAD"),
                .unsafeFlags(["-w", "-O2"]),
            ]
        ),
        // The conversion / analysis engine. No UI code lives here.
        .target(
            name: "HexshiftKit",
            dependencies: ["CWebP"],
            path: "Sources/HexshiftKit"
        ),
        // Command-line front end: `hexshift-cli selftest`, `hexshift-cli convert …`
        .executableTarget(
            name: "hexshift-cli",
            dependencies: ["HexshiftKit"],
            path: "Sources/hexshift-cli"
        ),
        // The menu-bar application.
        .executableTarget(
            name: "HEXSHIFT",
            dependencies: ["HexshiftKit"],
            path: "Sources/HEXSHIFT",
            linkerSettings: [
                // Translation exists only on macOS 14.4+/15; weak-link it so the app still launches on 14.0.
                .unsafeFlags(["-Xlinker", "-weak_framework", "-Xlinker", "Translation"]),
            ]
        ),
        .testTarget(
            name: "HexshiftKitTests",
            dependencies: ["HexshiftKit"],
            path: "Tests/HexshiftKitTests"
        ),
    ]
)
