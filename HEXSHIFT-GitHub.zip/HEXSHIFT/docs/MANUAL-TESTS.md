# Manual test checklist

The automated checks (`hexshift-cli selftest`, `HEXSHIFT --smoke-test`) cover the engine and the UI wiring.
These flows involve macOS permission prompts, Finder and real mouse gestures, so they need a person.
Tick each on a fresh user account or after `tccutil reset All app.hexshift.HEXSHIFT`.

## First run
- [ ] Launch HEXSHIFT → welcome window appears, hexagon icon appears in the menu bar, no permission prompt yet.
- [ ] *Start Using HEXSHIFT* closes the window; relaunching from Spotlight opens Settings, not the welcome again.

## Shortcut & radial menu
- [ ] Press ⌥ Space on the desktop → wheel opens at the pointer with six segments; Esc closes it.
- [ ] Hover each segment → its ring opens around it without touching the hexagon; every label sits inside its tile; the centre shows the full name (e.g. "Capture & More").
- [ ] Arrow keys / 1–6 move between segments; Return opens a segment; Return on an item runs it; Esc steps back.
- [ ] Select two images in Finder, press ⌥ Space → macOS asks to let HEXSHIFT control Finder (first time only); the wheel shows image actions and the title says "2 images".
- [ ] Deny the Finder prompt → wheel still opens, HUD explains how to allow it later.
- [ ] Change the shortcut in Settings › Activation to ⌃⌥H → old shortcut stops working, new one works. Try ⌘ Space → refused as used by macOS.
- [ ] Select text in TextEdit, press ⌥ Space → asks to enable Accessibility (only after you choose a text action) → text actions and the actual font appear.
- [ ] Light, dark and *Increase Contrast* appearances all look right; *Reduce Motion* removes the opening animation.
- [ ] Hover an action in a ring and press **F** (or right-click it) → "Added to favourites"; it appears as a quick button under the wheel next time it applies; press F again to remove it.
- [ ] Settings › Activation › Modifier-click on, choose ⌃⌥ + right-click → asks for Accessibility once → ⌃⌥-right-click anywhere opens the wheel; a plain right-click still shows the app's own menu.

## Shift-drag format wheel
- [ ] Start dragging a PNG from Finder, then hold Shift → format wheel appears near the pointer.
- [ ] Drop onto WebP → `name.webp` appears next to the original; HUD shows the result with *Reveal* and *Undo*.
- [ ] Release Shift before dropping → wheel disappears, the drag continues normally.
- [ ] Ordinary drags (no Shift), text drags and window drags are unaffected.
- [ ] Drop a file on the menu-bar icon → radial menu for that file.

## Finder integration
- [ ] Right-click a file › Services (or Quick Actions after *Install Finder Quick Action*) › *Open in HEXSHIFT* → wheel opens.
- [ ] *Open With › HEXSHIFT* works for images, PDFs and documents.

## Conversions (spot checks with real files)
- [ ] iPhone HEIC → JPEG keeps orientation; GPS removed by default (check with `mdls` or Preview › Inspector).
- [ ] Transparent PNG → JPEG shows the "transparent areas will be filled with white" note and offers a background colour.
- [ ] Animated GIF → WebP stays animated in Safari; → MP4 plays in QuickTime.
- [ ] 20-page PDF → PNG asks which pages; all-pages export names files `-01`, `-02` …
- [ ] Batch of 50 photos → resize to 2000 px; Cancel half-way stops it and leaves only finished files.
- [ ] Converting the same file twice creates `name 2.ext`, never overwrites.

## PDF toolkit
- [ ] Redact a phrase → open the result in Preview, search for the phrase → not found; copy-paste the area → nothing.
- [ ] Protect with a password → Preview asks for it; *Remove Password* with the wrong password fails without leaving a file.
- [ ] Markup: add a text box, a comment, a drawing and a highlight → Save Copy → open in Preview: all four are there and still editable.
- [ ] Page Size → A4 with 10 mm margins on a US Letter PDF → pages are A4, text still selectable.
- [ ] Merge three PDFs and two images, reorder pages by drag, rotate one, delete one → result matches the preview.

## Capture, colour, fonts
- [ ] Capture › Region → macOS asks for Screen Recording the first time → after allowing, the capture opens in the wheel.
- [ ] Pick Colour outside HEXSHIFT → Colour Lens shows HEX/RGB/HSL/CMYK/Lab and contrast.
- [ ] Find Font on a screenshot of text → results are labelled *estimated*; on selected TextEdit text → labelled *actual*.
- [ ] Browser extension: right-click text on a web page › *Inspect font with HEXSHIFT* → card appears; *Open in HEXSHIFT* opens Font Lens with the same values.

## Text, clipboard & workflows
- [ ] On macOS 15+: select a paragraph, ⌥ Space › Capture › Translate → translation appears (macOS may offer to download the language first). On macOS 14 the action is absent.
- [ ] Settings › Privacy › clipboard suggestions on → copy an image in Preview → a suggestion appears; copy text → nothing; copy a password in 1Password → nothing.
- [ ] Settings › Workflows → give *Quick Web Export* a shortcut → select images in Finder, press it → WebP files appear without the wheel.

## Settings & privacy
- [ ] Turning off the menu-bar icon hides it; launching the app again from Spotlight opens Settings.
- [ ] Launch at Login toggles and survives a log-out.
- [ ] *Clear history* empties recent actions.
- [ ] No network connections are made (check with Little Snitch / LuLu, or `nettop -p HEXSHIFT`).
