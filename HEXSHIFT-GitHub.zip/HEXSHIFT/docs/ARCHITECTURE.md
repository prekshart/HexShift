# Architecture

HEXSHIFT is a SwiftPM package with four targets. The rule that shapes everything: **the engine has no UI
and the UI has no file-format logic**, so every conversion can be exercised from the command line and the
self-test.

```
┌───────────────────────────── HEXSHIFT.app (menu-bar, LSUIElement) ─────────────────────────────┐
│  Activation                Radial UI                 Windows (opened on demand)      Feedback   │
│  ─────────                 ─────────                 ───────────────────────────      ────────   │
│  HotKeyManager (Carbon)    RadialMenuController      ConvertOptions  ImageEditor     JobCenter  │
│  DragMonitor (Shift-drag)  RadialMenuModel/View      PDFToolkit      FontLens        HUD panel  │
│  MenuBarController         RadialGeometry            ColourLens      TextStudio                 │
│  Services / Quick Action   ActionCatalog ──► ActionRunner ──► MediaTools DesignerTools Settings │
│  URL scheme hexshift://    (what's offered)    (does it)       Onboarding SmallWindows          │
│  SelectionService (Finder Apple Events, Accessibility)   Permissions   AppState (prefs, store)  │
└──────────────────────────────────────────────┬──────────────────────────────────────────────────┘
                                               │ async calls, AssetInfo / ConversionTarget values
┌──────────────────────────────────────────────▼───────────── HexshiftKit (engine, no UI) ────────┐
│ Format / AssetInspector — detect by content (magic bytes) not just extension; read metadata     │
│ ConversionEngine — "what is genuinely possible for this file" + routing to the converters:      │
│   ImageEncoder (ImageIO + libwebp)  SVGSupport  VectorTracer  PDFEngine (PDFKit/CGPDF)          │
│   DocumentConverter (NSAttributedString, Markdown)  TableConverter (CSV/XLSX/JSON)              │
│   OfficeAdapters (LibreOffice, Pages/Keynote/Numbers)  MediaConverter (AVFoundation, FFmpeg)    │
│ Analysis — OCRService (Vision)  FontMatcher (Core Text)  ColourMath / Palette / Gradient        │
│ Editing — ImageEffects (Core Image)  ImageTools (target-size compression)  TextGraphics         │
│ Output safety — OutputPlanner (names, folders, never overwrite)  FileWriter (temp → validate →  │
│   atomic move)  BatchJob (bounded concurrency, progress, cancel)  Workflow (multi-step chains)  │
│ SelfTest — 35 end-to-end checks against generated fixtures                                       │
└───────────────────────────────┬──────────────────────────────────────────────────────────────────┘
                                │
                     CWebP (vendored libwebp 1.5.0, C) — WebP + animated WebP encoding
```

## Key decisions

**Content-based detection.** `Format.detect` sniffs magic bytes first (PNG, JPEG, GIF, WebP, HEIC/AVIF `ftyp`
brands, PDF, PostScript, fonts, Matroska/WebM, RIFF audio/video, etc.) and only then trusts the extension
(ZIP-based Office files are recognised by extension), so a mis-named image or PDF is handled correctly and a corrupt file is reported instead of crashing an encoder.

**Only offer what will work.** `ConversionEngine.targets(for:)` builds the list per file: it knows that a
PDF can become PNGs (one per page) but not "SVG", that an animated GIF can stay animated as WebP/APNG/MP4,
that EPS needs Ghostscript, and attaches an honest note to lossy choices ("Transparency will be flattened",
"Text and basic styling only"). Unavailable targets are shown disabled with the reason and a fix.

**Safe output.** `OutputPlanner` decides the destination (next to the original, a chosen folder, or a dated
subfolder), applies the naming rule and Finder-style " 2" suffixes, and refuses to return a path that
exists. `FileWriter` writes into a hidden temp file in the destination folder, validates it (decodable image,
openable PDF, non-empty), then moves it into place atomically. Originals are never modified.

**True redaction.** `PDFEngine.redact` rebuilds the PDF. Each page with redactions is rendered to an image
(200 dpi by default), the marked areas are painted black *into the pixels*, and the original page content —
which still contains the hidden text and vectors — is discarded. The remaining visible text is made
searchable again with an invisible OCR layer. Pages without redactions keep their vector content; document
metadata is not copied. Annotation-style "black boxes" are never used. The self-test verifies that redacted
words can no longer be extracted.

**Estimates are labelled.** Font matches for images and "rendered font" guesses in the browser are always
marked as estimates; actual metadata (Accessibility attributes, font files) is shown as actual.

**Permissions are contextual.** `Permissions` checks state lazily and the UI explains *why* before macOS shows
its prompt. Nothing is requested at launch.

**Drag detection without spying.** `DragMonitor` uses global *mouse* event monitors (no keyboard monitoring),
checks that Shift is held via `NSEvent.modifierFlags`, and confirms a file drag by watching the drag
pasteboard's change count. Ordinary drags are untouched.

**Concurrency.** UI types are `@MainActor`. Engine work runs in `Task`s and `BatchJob` runs at most four items at
once (half the CPU cores) so large batches stay responsive; every job is cancellable from the HUD.

## Testing

| Layer | How |
| --- | --- |
| Engine | `hexshift-cli selftest` — 35 end-to-end checks (every image format round-trip, WebP/animation, orientation, metadata stripping, PDF render/assemble/split/rotate/compress, OCR, searchable PDF, redaction, password protect/remove, PDF markup and page size, fonts, documents, tables, SVG, tracing, icons, colour maths incl. OKLCH/APCA/harmonies/CVD/ASE, palette/gradient, adjustments, background removal, output naming, batch + cancel, corrupt input, unreadable files and read-only folders, video, text graphics, workflows, compression targets, routing). `swift test` wraps the same checks in XCTest. |
| App | `HEXSHIFT --smoke-test <folder>` — hit-tests the wheel geometry, builds the action catalogue for several contexts, and renders the wheel (light/dark), format wheel, Settings, onboarding, menu-bar popover, editor, Colour Lens, Designer Tools and Text Studio to PNGs for visual review. |
| Manual | See `docs/MANUAL-TESTS.md` for flows that need a person (permission prompts, Finder, real drags). |
