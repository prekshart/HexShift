# Feature status — complete, partial, not yet built

This is an honest map of HEXSHIFT against its product specification. **Complete** means the feature works end
to end (UI entry point + engine). **Partial** means it works with a stated limitation. **Not built** means
there is no code for it yet, with the reason. Engine features marked *(self-test)* are exercised by
`hexshift-cli selftest`; UI wiring is exercised by `HEXSHIFT --smoke-test`. Flows that need a person
(permission prompts, real drags, Finder) are in [MANUAL-TESTS.md](MANUAL-TESTS.md).

**Verified build:** macOS 27.0.1, Apple silicon, Swift 6.3.3 — `hexshift-cli selftest` 35/35 passed and
`HEXSHIFT --smoke-test` 50/50 passed (wheel geometry, action catalogue, every main window rendered).

## Activation & Mac integration

| Feature | Status | Notes |
| --- | --- | --- |
| Menu-bar app, no Dock icon, Launch at Login (opt-in) | Complete | `LSUIElement`; `SMAppService` |
| Global shortcut ⌥ Space (changeable), wheel at the pointer | Complete | Carbon hot key — needs no permission and sees no other keys. Conflicts with macOS shortcuts are detected |
| Uses the current Finder selection / selected text | Complete | Finder via Apple Events (asks once); text via Accessibility. Password fields are never read |
| Finder: *Open in HEXSHIFT* | Complete | As a Service, as *Open With*, and as an optional Quick Action installed from Settings |
| Shift-while-dragging format wheel | Complete | Mouse-only global monitors; ordinary drags untouched |
| Drop files on the menu-bar icon | Complete | |
| Menu-bar popover (Open, Convert Clipboard, Capture, Pick Colour, Find Font, recents, Settings) | Complete | Recent actions ask for files or use the clipboard when they need input |
| Services: files, selected text, images | Complete | |
| Optional modifier + right-click gesture | Complete | ⌃⌥ / ⌥ / ⌘⌥ / ⌃⇧ + right-click. Needs Accessibility (event tap on right-clicks only) |
| `hexshift://` links (menu, capture, pick-colour, font, open, settings) | Complete | Links only open HEXSHIFT's UI; they can't convert or change files |
| Chromium extension: inspect a page font, capture the visible page | Complete | Chrome, Edge, Brave, Arc. Visible area only (no full-page scrolling capture) |
| Safari extension | Not built | Needs an Xcode Safari Web Extension target. `xcrun safari-web-extension-converter "Extras/Browser Extension"` can generate one from the Chromium extension |
| Shortcut conflicts with other apps' private shortcuts | Partial | Carbon reports clashes with registered hot keys; shortcuts other apps implement with event taps can't be detected |

## Radial menu

| Feature | Status | Notes |
| --- | --- | --- |
| Hexagon with six segments, outer ring per segment, overflow "More…" | Complete | Geometry hit-tested *(smoke test)* |
| Layout rules: equal gaps everywhere, ring always clears the hexagon's corners, 30° ring tiles centred on the open segment (mirror-symmetric), every label measured to fit inside its shape, one font size per ring, full names in the centre on hover | Complete | Checked for every context by the smoke test (no overlaps, no overflowing or truncated built-in labels) |
| Centre preview (QuickLook thumbnail, name, format, size) | Complete | |
| Context-aware actions for images, PDFs, documents, video, audio, fonts, text, nothing selected | Complete | Only valid actions are shown; unavailable ones explain why |
| Light/dark, Increase Contrast, Reduce Motion, accent colour, size, segment order | Complete | |
| Keyboard: arrows, Tab, 1–6, Return, Esc; VoiceOver labels and announcements | Complete | |
| Haptics on Force Touch trackpads | Complete | |
| Favourite tools | Complete | Hover an action and press **F**, or right-click it. Shown as quick buttons when they apply |
| Most-used actions as quick buttons | Complete | Frequency decays over two weeks |
| Choosing which actions appear inside a segment | Partial | Segment order and favourites only; segment contents are chosen automatically |

## Converter

| Feature | Status | Notes |
| --- | --- | --- |
| PNG, JPEG, HEIC, TIFF, GIF, BMP, JPEG 2000, ICO, ICNS, PDF (write) | Complete *(self-test)* | |
| WebP still, lossless and animated (write) | Complete *(self-test)* | Bundled libwebp encoder |
| AVIF (write) | Partial | Works where macOS's ImageIO can encode AVIF, or with `avifenc` installed; otherwise shown as unavailable |
| RAW, PSD, TGA (read) | Complete | PSD = flattened composite |
| Animated GIF/WebP/APNG ↔ each other and → MP4/MOV; first frame / all frames | Complete *(self-test)* | |
| SVG → raster/PDF; raster → SVG (embed) and SVG Trace | Complete *(self-test)* | Trace is an approximation; with 2 colours and Potrace installed, curves are smooth |
| PDF → images (page ranges, DPI, transparency), → TXT/MD/DOCX/RTF/HTML | Complete *(self-test)* | PDF → Word is a reconstruction (warned) |
| Documents: DOCX/DOC/ODT/RTF/HTML/MD/TXT ↔ each other and → PDF | Complete *(self-test)* | High-fidelity Word → PDF needs LibreOffice or Pages; HTML → PDF uses AppKit's HTML importer (no full CSS layout) |
| Tables: CSV/TSV/XLSX/JSON → XLSX/CSV/JSON/HTML/MD/PDF | Partial *(self-test)* | First sheet, values only (no formulas/styles) |
| Pages / Numbers / Keynote | Partial | Exported by the iWork apps themselves (must be installed) |
| PPTX → PDF/images | Partial | Needs Keynote or LibreOffice |
| EPS / legacy AI | Partial | Needs Ghostscript; PDF-compatible AI files work without it |
| MP4/MOV/M4V, GIF/WebP from video, frames, audio extraction, trimming | Complete *(self-test)* | AVFoundation presets |
| WebM, MKV, AVI, MP3/FLAC encoding | Partial | Need FFmpeg |
| Custom codec / bitrate / CRF settings | Not built | Presets only (H.264, HEVC, 1080p/720p/540p, re-wrap) |
| Batch queue with progress, cancel, per-file errors | Complete *(self-test)* | |
| Output destinations and naming templates; never overwrite | Complete *(self-test)* | Same-folder falls back to Desktop when the folder can't be written |
| Metadata: keep / strip GPS / strip all | Complete *(self-test)* | |
| Colour profile: keep / convert to sRGB / Display P3; matte colour for formats without transparency | Complete | |
| Corrupt or unreadable input, read-only destination | Complete *(self-test)* | Clean errors; no partial files |

## Image editor

| Feature | Status | Notes |
| --- | --- | --- |
| Crop (free, handles, guides), ratio presets, social presets, **custom ratio** | Complete | |
| Rotate / flip | Complete | |
| Resize (px, percentage presets and **any percentage**, aspect lock, resampling, DPI) | Complete | Upscaling is flagged as not adding detail |
| Background removal (Vision), edge refinement, new background (colour/gradient/blur/image) | Complete *(self-test)* | macOS 14 subject lifting |
| Adjustments: exposure, brightness, contrast, saturation, vibrance, warmth, tint, highlights, shadows, sharpen, B&W, auto-enhance | Complete *(self-test)* | |
| Annotate: pen, highlighter, text, arrow, rectangle, ellipse, numbered callouts, blur, pixelate | Complete | |
| Compress: quality, target size presets and **custom target size**, size estimate | Complete *(self-test)* | |
| Measure tool | Complete | Manual point-to-point |
| Undo/redo, before/after | Complete | |
| Filters (looks/LUTs), borders, image watermark | Not built | Not in the core spec; PDF has a text stamp |
| Full EXIF viewer, per-field metadata removal | Partial | Highlights only; strip GPS or all |

## PDF toolkit

| Feature | Status | Notes |
| --- | --- | --- |
| Merge, split (every page / every N / ranges), extract, delete, reorder, rotate, duplicate, insert | Complete *(self-test)* | |
| Pages → images, images → PDF | Complete *(self-test)* | |
| Compress, optimise images, remove metadata | Complete *(self-test)* | Ghostscript gives the smallest files |
| OCR → text / DOCX / searchable PDF | Complete *(self-test)* | Apple Vision, on device. The very first OCR after installing can take up to a minute while macOS prepares its recognition model; after that it takes well under a second |
| **True redaction** | Complete *(self-test)* | Content under the marks is destroyed, not covered |
| Markup: text boxes, comments, freehand drawing, highlight boxes, outlined boxes | Complete *(self-test)* | Saved as real, editable annotations |
| Highlight/underline every occurrence of a phrase | Complete | Selecting text on the page to highlight isn't supported |
| Page numbers, text stamp/watermark, visible signature image | Complete *(self-test)* | The signature is visual, not cryptographic |
| Change page size, add margins | Complete *(self-test)* | Content stays vector; links and form fields aren't carried over |
| Password protect / remove | Complete *(self-test)* | |
| Fonts used in a PDF | Complete *(self-test)* | |
| Edit existing PDF text | Not built | PDFs store positioned glyphs; editing them reliably needs a full layout engine |
| Digital (certificate) signatures | Not built | |

## Font Lens

| Feature | Status | Notes |
| --- | --- | --- |
| Actual font of selected text (family, style, weight, size, colour) | Complete | Through Accessibility, in apps that report it |
| Actual font on web pages (computed CSS incl. line height, letter spacing) | Complete | Browser extension |
| Estimated matches for text in images/screenshots | Complete *(self-test)* | Letter-by-letter comparison: the recognised text is rebuilt in each candidate font, every letter is aligned to the image, stroke weight and screen rendering are allowed for. Lab benchmark (159 families, 13–64 px, Retina, JPEG, Mac/Windows rendering): right font first in 88–97% of samples, in the top 3 in 92–100% (previous method: 73% first, 38% for small text). Always labelled *estimated*. Takes a few seconds |
| Google Fonts reference | Complete | 159 popular Google Fonts families (838 styles) built in as small glyph images, so fonts that aren't installed can still be named; shown as *Google Fonts · not installed* with **Get Font** and ready-made CSS |
| Specimens, comparison, favourites, sample text | Complete | |
| Copy CSS / **SwiftUI** code | Complete | |
| Matching against fonts that aren't installed | Partial | The 159 bundled Google Fonts families; commercial fonts (Adobe, Monotype…) only if installed. Nothing is downloaded |
| Line height / letter spacing from native apps | Partial | Most apps don't report them through Accessibility |

## Colour Lens

| Feature | Status | Notes |
| --- | --- | --- |
| Screen picker with loupe; HEX/RGB/HSL/HSB/CSS/CMYK≈/**Lab/OKLCH**/Display P3 | Complete *(self-test)* | |
| Palette extraction, gradient estimate | Complete *(self-test)* | |
| Contrast: WCAG 2.2 AA/AAA and **APCA Lc** | Complete *(self-test)* | |
| **Harmonies** (complementary, analogous, triadic, split, tetradic) and **50–950 tonal scales** | Complete *(self-test)* | Built in OKLCH |
| **Colour-vision simulation** (protan, deutan, tritan, mono) | Complete *(self-test)* | Machado 2009 |
| History, saved palettes | Complete | Local only |
| Export: CSS, **Tailwind**, JSON tokens, **SwiftUI**, **ASE**, **GPL**, SVG, PNG, HEX | Complete *(self-test)* | |

## Capture, text, designer tools, clipboard, workflows

| Feature | Status | Notes |
| --- | --- | --- |
| Region / window / screen capture → wheel, OCR, edit, annotate | Complete | macOS screenshot tool; asks for Screen Recording once |
| Automatic UI analysis (element sizes, spacing, border radius) from screenshots | Partial | Manual measuring, palette and type estimates only |
| Text → PDF/DOCX/MD/HTML/RTF/PNG/JPEG/SVG, graphics templates (quote, poster, banner…) | Complete *(self-test)* | |
| **Translate** selected text | Complete | macOS 15+ with a build from Xcode 16+ (Apple Translation, on device). Not shown on macOS 14 |
| Designer tools: ratios, units & print size, colour formats, **custom export scales** (@0.5x–@16x), icon sets, social crops | Complete | |
| Type-scale generator, typography/spacing tokens | Not built | Colour tokens only |
| Clipboard: convert clipboard, colour codes, links → QR | Complete | Reads the clipboard only when asked |
| **Optional clipboard suggestions** with app exclusions | Complete | Off by default; looks at item types only until you click; ignores password managers and concealed items |
| Link metadata / page fetch for copied URLs | Not built | Would require network access, which HEXSHIFT avoids |
| Built-in workflows (Web Export, Social Export, Transparent Asset, PDF Optimiser, Design Research) | Complete *(self-test)* | |
| Custom workflows with **editable steps** (sizes, ratios, formats, quality, target KB) | Complete | Image and PDF steps |
| **Favourite workflows** and **per-workflow shortcuts** | Complete | Shortcuts run on the files selected in Finder |

## Settings, privacy, quality

| Feature | Status | Notes |
| --- | --- | --- |
| Settings: General, Activation, Radial Menu, Conversion, Typography, Privacy, Workflows, About | Complete | |
| Contextual permissions with explanations; no network use; no keystroke logging | Complete | |
| Atomic writes with validation; originals never modified | Complete *(self-test)* | |
| Self-test, XCTest wrapper, UI smoke test with snapshots | Complete | |
| Signed, notarised distribution | Partial | `scripts/notarize.sh` is ready; needs your Apple Developer ID (see REQUIREMENTS) |
| Xcode project file | Partial | SwiftPM package — open `Package.swift` in Xcode; no `.xcodeproj` needed |

## Phase 4 (investigate later)

Not built: Figma integration (needs Figma's API and an account), AI generative background editing and ML
upscaling (would need large models or a cloud service), a plugin system, and writing layered PSD/AI/EPS
files (proprietary formats).
