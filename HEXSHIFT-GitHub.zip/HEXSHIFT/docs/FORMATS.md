# Formats — what each conversion keeps and what it loses

HEXSHIFT only offers a conversion when it can really do it on your Mac, and it puts a short note on any
choice that loses something ("Any transparent areas will be filled with white", "Keeps the first frame only").
This page collects those rules in one place. ✅ kept · ⚠️ partly kept · ❌ lost · — not applicable.

Run `hexshift-cli formats` to see what this particular Mac can read and write (it depends on the macOS
version and which optional helpers are installed).

## Images

| From → to | Transparency | Animation | Layers | Metadata (EXIF/IPTC/XMP) | Colour profile |
| --- | --- | --- | --- | --- | --- |
| Any → **PNG** | ✅ | ❌ (✅ as *APNG* from animated sources) | ❌ flattened | ✅ per your metadata setting | ✅ embedded |
| Any → **JPEG** | ❌ filled with white (or the matte colour you pick) | ❌ | ❌ | ✅ per setting | ✅ embedded |
| Any → **HEIC** | ✅ | ❌ | ❌ | ✅ per setting | ✅ embedded |
| Any → **WebP** (libwebp) | ✅ | ✅ from GIF/APNG/WebP | ❌ | ❌ not written | ⚠️ converted to sRGB |
| Any → **AVIF** | ✅ | ❌ | ❌ | ✅ via ImageIO · ❌ via avifenc | ✅ / ⚠️ sRGB via avifenc |
| Any → **TIFF** | ✅ | ❌ | ❌ flattened | ✅ per setting | ✅ embedded |
| Any → **GIF** | ⚠️ 1-bit (on/off) | ✅ from animated sources | ❌ | ❌ | ⚠️ reduced to 256 colours |
| Any → **BMP** | ❌ flattened | ❌ | ❌ | ❌ | ❌ |
| Any → **JPEG 2000** | ✅ | ❌ | ❌ | ✅ per setting | ✅ |
| Any → **ICO** | ✅ | — | — | — | sRGB · sizes 16, 24, 32, 48, 64, 128, 256 |
| Any → **ICNS** | ✅ | — | — | — | sRGB · sizes 16–1024 incl. @2x |
| Any → **PDF** | ✅ | ❌ (first frame) | ❌ | ❌ | ✅ |
| Raster → **SVG** | ✅ | ❌ | — | ❌ | Pixels embedded in an SVG wrapper — **not** editable vectors |
| Raster → **SVG Trace** | ✅ | ❌ | — | ❌ | Real vector paths, posterised to a limited palette; an approximation |

**Metadata setting** (Settings › Conversion › Metadata): *Remove location (GPS) only* (default), *Remove all*,
or *Preserve all*. Orientation is always applied to the pixels and reset, so results look the same in every app.

**Colour profile** (convert window): *Keep the original* (default), *Convert to sRGB* or *Convert to Display P3*.
**Matte colour:** when a format can't store transparency you choose the background colour (white by default).

**Bit depth:** 16-bit PNG/TIFF sources stay 16-bit when they pass through unchanged; resizing, edits and
flattening produce 8-bit output. HDR gain maps in HEIC/JPEG are not carried over.

**Inputs that are read but never written:** PSD (flattened composite — the file must have been saved with
*Maximize Compatibility*), camera RAW (CR2/CR3, NEF, ARW, DNG, RAF… whatever macOS supports; output is a
developed, flattened image), TGA.

## Vector

| From → to | Notes |
| --- | --- |
| **SVG → PNG/JPEG/WebP/HEIC/TIFF/GIF/ICO/ICNS** | Rendered at 2× the SVG's size (adjustable). Uses macOS's SVG renderer, falling back to WebKit for SVGs it can't draw (filters, CSS, web fonts). |
| **SVG → PDF** | Stays vector when the SVG renders natively; WebKit fallback produces a vector PDF too. |
| **AI → PDF / images** | Works for Illustrator files saved with *Create PDF Compatible File* (the default) — the PDF inside is used. Layers are flattened, artboards beyond the first may be missing. Old PostScript-only AI files need Ghostscript. |
| **EPS → PDF / images** | Needs Ghostscript (macOS 14 removed PostScript rendering). |
| **PDF → SVG** | Not offered. PDF → PNG and then *SVG Trace* is possible but approximate. |

## PDF

| Conversion | Keeps | Loses / notes |
| --- | --- | --- |
| **PDF → images** | One image per page at 72, 150 or 300 dpi; choose all pages or a range | Links, forms, text selectability |
| **PDF → TXT / Markdown** | Text in reading order; scanned pages are OCR'd | Layout, images |
| **PDF → DOCX / RTF / HTML** | Text, bold/italic, font sizes, paragraphs | Columns, tables, floating images, headers/footers — PDFs store positioned glyphs, so Word output is a reconstruction |
| **Images → PDF** | One page per image at full resolution; page size fits each image or A3/A4/A5/Letter/Legal | — |
| **Merge / split / reorder / rotate / delete pages** | Vector content, text, links and annotations on the kept pages | Bookmarks (outline) aren't carried into merged files |
| **Compress** | Text and vectors stay sharp; images are re-encoded | Quality depends on the preset; Ghostscript gives the smallest files |
| **OCR → searchable PDF** | Original page images, plus an invisible text layer | — |
| **Redact** | Unredacted pages unchanged | Redacted pages become images (200 dpi) with the areas burned in; the hidden text is destroyed; visible text is made searchable again with OCR; document metadata is removed |
| **Password protect / remove** | Everything | Removing needs the current password |
| **Markup** (text boxes, comments, drawing, highlight boxes) | Everything; markup is added as standard annotations, editable in Preview/Acrobat | — |
| **Page size & margins** | Text and vectors (still selectable); visible annotation appearance | Links and form fields; content is scaled to fit the new page |

## Documents

Built-in engine: macOS's document system (`NSAttributedString`) plus HEXSHIFT's own Markdown renderer.

| From → to | Keeps | Loses / notes |
| --- | --- | --- |
| DOCX / DOC / ODT / RTF / HTML ↔ each other | Text, fonts, sizes, bold/italic/underline, colours, basic lists and tables | Headers/footers, footnotes, comments, tracked changes, complex tables, embedded objects |
| → **Markdown** | Headings, emphasis, links, lists, code | Fonts, colours, tables become plain text |
| Markdown → DOCX / HTML / PDF / RTF | Headings, emphasis, links, lists, code blocks, block quotes, simple tables | — |
| → **TXT** | Text only | All formatting |
| Word → **PDF** | With **LibreOffice**: page layout, headers/footers, images. Without: text and basic styling re-flowed onto pages. |
| **Pages** → PDF / DOCX / TXT | Exported by Pages itself — full fidelity | Needs Pages installed; asks for Automation permission once |
| Install **Pandoc** for better Markdown ↔ Word ↔ HTML (footnotes, nested lists, tables) | | |

## Spreadsheets & presentations

| From → to | Notes |
| --- | --- |
| **CSV ↔ XLSX ↔ JSON / HTML / Markdown table / PDF** | Values only — formulas become their last calculated values, formatting and charts are dropped. XLSX input uses the first sheet. CSV encoding and delimiter are auto-detected. |
| **Numbers** → XLSX / CSV / PDF | Exported by Numbers (needs Numbers installed) |
| **PPTX / KEY → PDF / PNG / JPEG** | Exported by Keynote if installed, otherwise rendered by LibreOffice; one image per slide |
| **KEY → PPTX** | Exported by Keynote |

## Video & audio

Built-in engine: AVFoundation (hardware-accelerated). FFmpeg is used only for what AVFoundation can't do.

| From → to | Notes |
| --- | --- |
| MP4 / MOV / M4V ↔ each other | H.264 or HEVC, 1080p/720p/540p presets or a fast re-wrap without re-encoding; trim start/end |
| Video → **GIF / animated WebP** | First 10 s unless trimmed; frame rate and width adjustable; sound dropped |
| Video → **PNG / JPEG** | A single frame at the time you choose |
| Video → **M4A / WAV / AIFF** | Audio track only |
| GIF / WebP / APNG → **MP4 / MOV** | Transparency becomes white |
| Audio M4A / WAV / AIFF (and MP3/AAC input) → M4A / WAV / AIFF | — |
| **WebM, MKV, AVI** in or out, **MP3**, **FLAC** | Need FFmpeg |
| DRM-protected files (Apple TV/Music purchases, streaming downloads) | Can't be converted — macOS blocks it |

## Fonts

TTF/OTF files can be turned into a **specimen** (PNG or PDF) showing the character set, weights and sizes.
HEXSHIFT does not convert between font formats (TTF ↔ OTF ↔ WOFF) — that changes the font's outlines and
hinting and is a job for a font editor.
