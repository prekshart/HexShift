# What else HEXSHIFT needs — and why

HEXSHIFT is complete source code for a native Mac app plus a build script. This page lists everything
outside the code that is needed to build it, run it, give it to other people, and unlock the optional
extras, with the reason for each.

## 1. Required to build and run it yourself

| What | Why it's needed | Cost |
| --- | --- | --- |
| **A Mac running macOS 14 Sonoma or later** (Apple silicon or Intel) | HEXSHIFT is a native macOS app. It uses macOS-only frameworks (AppKit, SwiftUI, ImageIO, PDFKit, Vision, AVFoundation) and some macOS 14 APIs (Vision's subject-lift background removal, the modern `NSApp.activate()`, `SMAppService` launch-at-login). It cannot run on Windows, Linux or iPad. | — |
| **Xcode 15 or later**, or the **Command Line Tools** (`xcode-select --install`) | Provides the Swift compiler and the macOS SDK. Apple only allows macOS apps to be compiled on a Mac. The Command Line Tools are enough for `scripts/build-app.sh` and `hexshift-cli selftest`; full Xcode is needed to run `swift test` (XCTest) and is nicer for debugging. Building with Xcode 16 or later (Swift 6 compiler) also includes the on-device **Translate** action for macOS 15+. | Free |
| *If `swift build` crashes* (`dyld: Symbol not found … swift-package`) | That means the Command Line Tools install is damaged. HEXSHIFT's build script works around it by compiling with `swiftc` directly, but to repair SwiftPM run `sudo rm -rf /Library/Developer/CommandLineTools` and then `xcode-select --install`. | Free |
| **About 2 GB of free disk space** | Build cache in `~/Library/Caches/HEXSHIFT-build`. The finished app is small (≈10–20 MB). | — |
| **Your permission for a few macOS privacy settings** (asked only when you use the feature) | macOS protects these by design; no app can turn them on for you. See the table below. | — |

### Privacy permissions and why each one exists

| Permission (System Settings › Privacy & Security) | What HEXSHIFT uses it for | What happens without it |
| --- | --- | --- |
| **Automation › Finder** | Ask Finder which files are selected when you press ⌥ Space. | The wheel still opens; use *Open in HEXSHIFT*, drag-and-drop or *Browse…* instead. |
| **Accessibility** | Read the text (and its real font) you selected in another app; the optional modifier + right-click gesture. Password fields are never read. | Text and Font Lens actions on other apps' selections, and the gesture, are unavailable; everything file-based still works. |
| **Screen Recording** | Region/window/screen capture and picking colours outside HEXSHIFT's windows. | Capture and the screen colour picker can't see other apps. |
| **Automation › Pages / Keynote / Numbers** | Ask those apps to export iWork files (only when you convert one). | iWork conversions are unavailable. |

HEXSHIFT never asks for Full Disk Access, Input Monitoring, camera or microphone. macOS may also ask once before HEXSHIFT reads files in Desktop, Documents or Downloads — that's the standard folder-access prompt for any app.

## 2. Strongly recommended: a stable code-signing identity (free)

`scripts/build-app.sh` signs the app *ad hoc* by default. That is enough to run on the Mac that built it,
but macOS ties privacy permissions to the app's signature, and an ad-hoc signature changes on every
rebuild — so after rebuilding you would have to re-allow Accessibility and Screen Recording.

Fix (one-time, free):

1. Open **Keychain Access › Certificate Assistant › Create a Certificate…**
2. Name: `HEXSHIFT Local`, Identity Type: *Self-Signed Root*, Certificate Type: **Code Signing** → Create.
3. Build with `SIGN_IDENTITY="HEXSHIFT Local" scripts/build-app.sh --install`.

Permissions now survive rebuilds. (Builds signed this way still only run on Macs that trust that certificate.)

## 3. Required only if you want to give HEXSHIFT to other people

| What | Why | Cost |
| --- | --- | --- |
| **Apple Developer Program membership** | Needed for a *Developer ID Application* certificate. Without it, macOS Gatekeeper refuses to open the app on other Macs ("can't be opened because Apple cannot check it"). | US$99 / year |
| **Notarisation** (`xcrun notarytool submit … --wait`, then `xcrun stapler staple HEXSHIFT.app`) | Apple scans the app for malware and issues a ticket; macOS requires this for apps downloaded from the internet. The build script already enables the *hardened runtime* when you pass a real `SIGN_IDENTITY`, which notarisation requires. | Included with membership |
| **A download page or GitHub Releases + a .dmg or .zip** | Somewhere to host the signed app. | Free–small |
| **Optional: an update mechanism** (e.g. Sparkle) | So users get fixes automatically. Not included. | Free (open source) |

**Why not the Mac App Store?** App Store apps must run in the App Sandbox. The sandbox does not allow the
things HEXSHIFT is built around: reading Finder's selection via Apple Events, reading selected text in
other apps through Accessibility, writing converted files next to originals anywhere on disk, and running
helper tools such as FFmpeg. Utilities in this category (e.g. Raycast, Alfred, PopClip) ship outside the
App Store for the same reason.

## 4. Optional helper tools — and what each unlocks

HEXSHIFT detects these automatically (Settings › Conversion › *Optional helper tools* shows what it found). They are not
bundled because of their size and licences (several are GPL/AGPL, which would impose conditions on
distributing HEXSHIFT itself). Easiest install is [Homebrew](https://brew.sh):

```bash
brew install ffmpeg pandoc ghostscript libavif potrace
brew install --cask libreoffice
```

| Tool | Unlocks | Why macOS alone can't do it |
| --- | --- | --- |
| **FFmpeg** | WebM / MKV / AVI input and output, MP3 and FLAC export, audio from those videos | AVFoundation only reads/writes Apple-supported containers (MP4, MOV, M4V, M4A, WAV, AIFF, CAF). It has no WebM, MKV, MP3 or FLAC encoder. |
| **LibreOffice** | High-fidelity Word (.docx/.doc/.odt), PowerPoint (.pptx) and Excel (.xlsx) → PDF and images | macOS's built-in Word reader keeps text and basic styling but not page layout, headers/footers, columns or embedded objects. PowerPoint files can't be rendered at all without Keynote or LibreOffice. |
| **Pandoc** | Better Markdown ↔ Word ↔ HTML (tables, footnotes, nested lists) | HEXSHIFT's built-in Markdown converter covers common syntax only. |
| **Ghostscript** | EPS and old PostScript-based Illustrator files; strongest PDF compression | Apple removed PostScript rendering from macOS 14. Modern .ai files contain a PDF and work without it. |
| **libavif** (`avifenc`) | AVIF export on Macs whose ImageIO has no AVIF encoder | macOS reads AVIF, but writing it depends on the OS version and hardware. |
| **Potrace** | Smooth Bézier tracing of logos and line art (used automatically for SVG Trace with 2 colours) | The built-in tracer handles colour artwork but its curves are straight-segment approximations. |
| **Pages, Keynote, Numbers** (free on the App Store) | Converting .pages, .key and .numbers files; Keynote is also the best PowerPoint renderer | Apple's iWork formats are proprietary and undocumented; only those apps can export them faithfully. |

## 5. Optional: the browser Font Inspector

| What | Why |
| --- | --- |
| **Chrome, Edge, Brave or Arc** | The included extension (`Extras/Browser Extension`) reads the computed CSS of text on web pages for Font Lens, and captures the visible page into HEXSHIFT. Load it via *Developer mode › Load unpacked* — no account needed. It asks for the *downloads* permission because captures are saved to Downloads › HEXSHIFT Captures before HEXSHIFT opens them. |
| **Chrome Web Store developer account** (US$5 once) | Only if you want to publish the extension so others can install it from the store. |
| **Safari** | Needs a *Safari Web Extension* wrapped in an Xcode app project, which Apple only builds with full Xcode. Not included, but `xcrun safari-web-extension-converter "Extras/Browser Extension"` generates that project from the Chromium extension; it then needs signing with your Apple ID. |

## 6. Limits that no extra tool can remove

These are platform or file-format limits, and HEXSHIFT says so in the UI rather than pretending:

- **Fonts in images are estimates.** A picture doesn't contain font names. HEXSHIFT rebuilds the text in
  every installed font and in 159 popular Google Fonts families, compares the letter shapes and labels results
  as *estimated matches*. Commercial fonts can only be named if they're installed. Exact fonts are
  only available for live text (Accessibility or the browser extension).
- **Layered formats can't be written.** HEXSHIFT reads PSD, AI, PDF and TIFF but exports flattened images.
  Writing layered PSDs or editable Illustrator files would need Adobe's proprietary formats.
- **Figma, Sketch, XD and Affinity files** are proprietary; export from those apps first.
- **Protected content** — DRM video/music, password-protected PDFs without the password, and apps that
  block screen capture — can't be converted or captured.
- **Some apps don't report their selection.** Accessibility text reading works in most Apple and Cocoa apps
  and in browsers; some cross-platform apps (some Electron apps, games, remote desktops) don't expose it.
  Copy the text and use *Clipboard* actions instead.
- **OCR quality** depends on the image: Apple's Vision OCR is excellent on clear text but can't recover blurry
  or tiny text.
- **PDF → Word is a reconstruction.** PDFs store positioned glyphs, not paragraphs. Text and basic styling
  come across; complex layouts, columns and tables need tidying.
