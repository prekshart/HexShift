#!/bin/bash
# HEXSHIFT uninstaller
# Double-click this file in Finder (first time: right-click › Open).
# Removes HEXSHIFT.app, its build cache and its settings. Your own files are never touched.
set -uo pipefail

bold=$'\033[1m'; green=$'\033[32m'; off=$'\033[0m'
clear
echo ""
echo "${bold}  ⬢  Uninstall HEXSHIFT${off}"
echo ""
echo "  This removes:"
echo "   • HEXSHIFT.app from Applications"
echo "   • HEXSHIFT's build cache (~/Library/Caches/HEXSHIFT-build)"
echo "   • HEXSHIFT's settings"
echo "  Files you converted or edited stay where they are."
echo ""
read -r -p "  Type yes and press Return to uninstall: " ans
if [[ "$ans" != "yes" ]]; then
  echo "  Nothing was removed."
  read -r -p "Press Return to close this window." _
  exit 0
fi

osascript -e 'tell application id "app.hexshift.HEXSHIFT" to quit' >/dev/null 2>&1 || pkill -x HEXSHIFT >/dev/null 2>&1 || true
sleep 1

for app in "/Applications/HEXSHIFT.app" "$HOME/Applications/HEXSHIFT.app"; do
  if [[ -d "$app" ]]; then
    /System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -u "$app" >/dev/null 2>&1 || true
    rm -rf "$app" && echo "  ✓ Removed $app"
  fi
done
rm -rf "$HOME/Library/Caches/HEXSHIFT-build" && echo "  ✓ Removed the build cache"
defaults delete app.hexshift.HEXSHIFT >/dev/null 2>&1 && echo "  ✓ Removed settings" || true

echo ""
echo "${green}${bold}  ✓ HEXSHIFT is uninstalled.${off}"
echo "  To also remove its privacy permissions, open System Settings › Privacy & Security"
echo "  › Accessibility and Screen Recording, and delete HEXSHIFT from each list."
echo ""
read -r -p "Press Return to close this window." _
