import AppKit
import Combine
import HexshiftKit
import SwiftUI

struct Toast: Identifiable {
    enum Kind { case success, info, error }
    let id = UUID()
    var kind: Kind
    var title: String
    var detail: String?
    var outputs: [URL] = []
    var failures: [BatchFailure] = []
    var canUndo = false
    var created = Date()
    /// An optional extra button ("Open in HEXSHIFT" for clipboard suggestions, for example).
    var actionTitle: String?
    var action: (() -> Void)?
}

/// Runs background jobs and shows their progress and results in a compact HUD.
@MainActor
final class JobCenter: ObservableObject {
    static let shared = JobCenter()

    @Published private(set) var running: [BatchJob] = []
    @Published private(set) var toasts: [Toast] = []
    private var cancellables: [UUID: AnyCancellable] = [:]

    enum Delivery { case files, clipboard }

    /// Starts a batch. `operation` runs off the main thread with bounded concurrency.
    @discardableResult
    func run(title: String, items: [URL], delivery: Delivery = .files, concurrency: Int? = nil,
             successTitle: String? = nil, operation: @escaping BatchJob.Operation) -> BatchJob {
        let job = BatchJob(title: title, items: items, concurrency: concurrency ?? AppState.shared.prefs.batchConcurrency, operation: operation)
        running.append(job)
        HUDController.shared.refresh()
        // Re-render the HUD as progress changes.
        cancellables[job.id] = job.objectWillChange.sink { _ in
            DispatchQueue.main.async { HUDController.shared.refresh() }
        }
        job.onFinish = { [weak self] job in self?.finished(job, delivery: delivery, successTitle: successTitle) }
        return job
    }

    /// Runs a single async task with the same progress/toast behaviour.
    func runTask(title: String, delivery: Delivery = .files, successTitle: String? = nil,
                 _ work: @escaping @Sendable () async throws -> [URL]) {
        let marker = URL(fileURLWithPath: "/\(title)")
        run(title: title, items: [marker], delivery: delivery, concurrency: 1, successTitle: successTitle) { _ in
            try await work()
        }
    }

    private func finished(_ job: BatchJob, delivery: Delivery, successTitle: String?) {
        running.removeAll { $0.id == job.id }
        cancellables.removeValue(forKey: job.id)
        let outputs = job.outputs
        if delivery == .clipboard, !outputs.isEmpty {
            copyOutputsToClipboard(outputs)
        }
        if job.isCancelled {
            show(Toast(kind: .info, title: job.summary, outputs: outputs, canUndo: !outputs.isEmpty))
        } else if job.failures.isEmpty {
            var title = successTitle ?? (outputs.count > 1 ? "\(outputs.count) files created" : "Converted successfully")
            if delivery == .clipboard { title = "Copied to the clipboard" }
            show(Toast(kind: .success, title: title,
                       detail: outputs.count == 1 ? outputs[0].lastPathComponent : (job.total > 1 ? job.summary : nil),
                       outputs: outputs, canUndo: delivery == .files && !outputs.isEmpty))
        } else if job.succeeded == 0 {
            let message = job.failures.count == 1 ? job.failures[0].message : job.summary
            show(Toast(kind: .error, title: job.total == 1 ? "That didn't work" : job.summary, detail: message,
                       failures: job.total > 1 ? job.failures : []))
        } else {
            show(Toast(kind: .info, title: job.summary,
                       detail: "\(job.failures.count) item\(job.failures.count == 1 ? "" : "s") failed.",
                       outputs: outputs, failures: job.failures, canUndo: true))
        }
        HUDController.shared.refresh()
    }

    func copyOutputsToClipboard(_ outputs: [URL]) {
        if outputs.count == 1, let format = Format.detect(outputs[0]), format.category == .raster,
           let image = try? ImageLoader.load(outputs[0]).image {
            Clipboard.copy(image: image)
        } else if outputs.count == 1, let format = Format.detect(outputs[0]), [.txt, .md, .html, .json, .csv, .svg].contains(format),
                  let s = try? String(contentsOf: outputs[0]) {
            Clipboard.copy(s)
        } else {
            Clipboard.copy(files: outputs)
        }
    }

    func show(_ toast: Toast) {
        toasts.insert(toast, at: 0)
        if toasts.count > 4 { toasts.removeLast(toasts.count - 4) }
        HUDController.shared.refresh()
        let id = toast.id
        let delay: Double = toast.kind == .error || !toast.failures.isEmpty ? 12 : 7
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self, !HUDController.shared.isHovered else {
                DispatchQueue.main.asyncAfter(deadline: .now() + 4) { self?.dismiss(id) }
                return
            }
            self.dismiss(id)
        }
    }

    func message(_ title: String, detail: String? = nil, kind: Toast.Kind = .info) {
        show(Toast(kind: kind, title: title, detail: detail))
    }

    func error(_ error: Error, title: String = "That didn't work") {
        let text = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        show(Toast(kind: .error, title: title, detail: text))
    }

    func dismiss(_ id: UUID) {
        toasts.removeAll { $0.id == id }
        HUDController.shared.refresh()
    }

    /// "Undo" for conversions: move the newly created files to the Trash (originals are untouched).
    func undo(_ toast: Toast) {
        var moved = 0
        for url in toast.outputs where FileManager.default.fileExists(atPath: url.path) {
            if (try? FileManager.default.trashItem(at: url, resultingItemURL: nil)) != nil { moved += 1 }
        }
        dismiss(toast.id)
        message(moved == 1 ? "Moved the new file to the Trash" : "Moved \(moved) new files to the Trash")
    }

    var isEmpty: Bool { running.isEmpty && toasts.isEmpty }
}
