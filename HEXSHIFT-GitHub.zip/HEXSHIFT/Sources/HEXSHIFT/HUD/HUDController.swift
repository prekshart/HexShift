import AppKit
import HexshiftKit
import SwiftUI

/// The small floating panel in the top-right corner showing progress and results.
@MainActor
final class HUDController {
    static let shared = HUDController()

    private var panel: NSPanel?
    private var host: NSHostingView<AnyView>?
    var isHovered = false
    private let width: CGFloat = 340

    func refresh() {
        let center = JobCenter.shared
        if center.isEmpty {
            panel?.orderOut(nil)
            return
        }
        let panel = ensurePanel()
        host?.rootView = AnyView(HUDView(center: center, hovered: { [weak self] h in self?.isHovered = h })
            .environmentObject(AppState.shared)
            .hexAppearance(AppState.shared))
        host?.layoutSubtreeIfNeeded()
        let fitting = host?.fittingSize ?? CGSize(width: width, height: 80)
        let height = min(560, max(60, fitting.height))
        let screen = NSScreen.main ?? NSScreen.screens[0]
        let visible = screen.visibleFrame
        let frame = NSRect(x: visible.maxX - width - 14, y: visible.maxY - height - 10, width: width, height: height)
        panel.setFrame(frame, display: true)
        if !panel.isVisible { panel.orderFrontRegardless() }
    }

    private func ensurePanel() -> NSPanel {
        if let panel { return panel }
        let p = NSPanel(contentRect: NSRect(x: 0, y: 0, width: width, height: 80),
                        styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: true)
        p.isFloatingPanel = true
        p.level = .statusBar
        p.backgroundColor = .clear
        p.isOpaque = false
        p.hasShadow = false
        p.hidesOnDeactivate = false
        p.isReleasedWhenClosed = false
        p.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .ignoresCycle]
        let h = NSHostingView(rootView: AnyView(EmptyView()))
        h.frame = p.contentRect(forFrameRect: p.frame)
        h.autoresizingMask = [.width, .height]
        p.contentView = h
        panel = p
        host = h
        return p
    }
}

@MainActor
struct HUDView: View {
    @ObservedObject var center: JobCenter
    var hovered: (Bool) -> Void
    @EnvironmentObject var state: AppState

    var body: some View {
        VStack(alignment: .trailing, spacing: 8) {
            ForEach(center.running) { job in
                JobRow(job: job)
            }
            ForEach(center.toasts) { toast in
                ToastRow(toast: toast)
            }
        }
        .padding(10)
        .frame(width: 340, alignment: .topTrailing)
        .fixedSize(horizontal: false, vertical: true)
        .onHover { hovered($0) }
    }
}

@MainActor
private struct HUDCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(.regularMaterial)
                    .shadow(color: .black.opacity(0.18), radius: 12, y: 4)
            )
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).strokeBorder(Color.primary.opacity(0.08)))
    }
}

@MainActor
private struct JobRow: View {
    @ObservedObject var job: BatchJob
    @EnvironmentObject var state: AppState

    var body: some View {
        HUDCard {
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Image(systemName: "hexagon.fill").foregroundStyle(state.accentColor)
                    Text(job.title).font(.system(size: 12.5, weight: .semibold)).lineLimit(1)
                    Spacer()
                    Button("Cancel") { job.cancel() }
                        .buttonStyle(.borderless)
                        .font(.system(size: 11.5))
                        .disabled(job.isCancelled)
                }
                if job.total > 1 {
                    ProgressView(value: job.fractionComplete)
                        .tint(state.accentColor)
                    Text("\(job.completed) of \(job.total)" + (job.failures.isEmpty ? "" : " · \(job.failures.count) failed"))
                        .font(.system(size: 11))
                        .foregroundStyle(.secondary)
                } else {
                    ProgressView().controlSize(.small).progressViewStyle(.linear).tint(state.accentColor)
                }
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(job.title), \(job.completed) of \(job.total) done")
    }
}

@MainActor
private struct ToastRow: View {
    let toast: Toast
    @EnvironmentObject var state: AppState
    @State private var showFailures = false

    private var icon: (String, Color) {
        switch toast.kind {
        case .success: return ("checkmark.circle.fill", state.accentColor)
        case .info: return ("info.circle.fill", .secondary)
        case .error: return ("exclamationmark.triangle.fill", .orange)
        }
    }

    var body: some View {
        HUDCard {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: icon.0).foregroundStyle(icon.1).font(.system(size: 15))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(toast.title).font(.system(size: 12.5, weight: .semibold)).fixedSize(horizontal: false, vertical: true)
                        if let d = toast.detail {
                            Text(d).font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(4).fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    Spacer(minLength: 0)
                    Button {
                        JobCenter.shared.dismiss(toast.id)
                    } label: {
                        Image(systemName: "xmark").font(.system(size: 9, weight: .bold))
                    }
                    .buttonStyle(.borderless)
                    .accessibilityLabel("Dismiss")
                }
                if let title = toast.actionTitle, let action = toast.action {
                    HStack(spacing: 6) {
                        Button(title) {
                            JobCenter.shared.dismiss(toast.id)
                            action()
                        }
                        .buttonStyle(.borderedProminent)
                        Button("Not Now") { JobCenter.shared.dismiss(toast.id) }
                            .buttonStyle(.bordered)
                    }
                    .controlSize(.small)
                }
                if !toast.outputs.isEmpty || !toast.failures.isEmpty {
                    HStack(spacing: 6) {
                        if toast.outputs.count == 1 {
                            Button("Open") { NSWorkspace.shared.open(toast.outputs[0]) }
                        }
                        if !toast.outputs.isEmpty {
                            Button("Reveal in Finder") { NSWorkspace.shared.activateFileViewerSelecting(toast.outputs) }
                            Button("Copy") { JobCenter.shared.copyOutputsToClipboard(toast.outputs) }
                        }
                        if toast.canUndo {
                            Button("Undo") { JobCenter.shared.undo(toast) }
                                .help("Move the new file(s) to the Trash. Originals are never touched.")
                        }
                        if !toast.failures.isEmpty {
                            Button(showFailures ? "Hide" : "View \(toast.failures.count) failed") { showFailures.toggle() }
                        }
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                }
                if showFailures {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(toast.failures) { f in
                            VStack(alignment: .leading, spacing: 1) {
                                Text(f.item.lastPathComponent).font(.system(size: 11, weight: .medium))
                                Text(f.message).font(.system(size: 10.5)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                    .padding(.top, 2)
                }
            }
        }
    }
}
