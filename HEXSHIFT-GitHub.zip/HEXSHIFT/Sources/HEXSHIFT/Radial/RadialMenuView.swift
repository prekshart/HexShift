import AppKit
import HexshiftKit
import SwiftUI

/// The signature radial menu: a round wheel around a hexagon hub.
@MainActor
struct RadialMenuView: View {
    @ObservedObject var model: RadialMenuModel
    @EnvironmentObject var state: AppState
    @Environment(\.colorScheme) private var scheme
    @Environment(\.colorSchemeContrast) private var contrast
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private var g: RadialGeometry { model.geometry }
    private var palette: HexPalette { HexPalette.make(scheme: scheme, contrast: contrast, accent: state.prefs.accentRGB) }
    private var hairline: CGFloat { palette.highContrast ? 1.5 : 0.75 }
    private var dark: Bool { scheme == .dark }

    private var look: WheelLook { WheelLook(dark: scheme == .dark, accent: state.prefs.accentRGB, highContrast: palette.highContrast) }

    /// A tile that looks gently raised: lit from above (lighter top, deeper bottom), a bright
    /// rim along its top edge and a dark rim along its bottom edge, both kept inside the shape.
    /// Top and bottom of `shape` as unit points of the wheel canvas, so a gradient runs down
    /// each tile on its own instead of across the whole wheel.
    private func span<S: Shape>(_ shape: S) -> (top: UnitPoint, bottom: UnitPoint) {
        let c = max(1, g.canvas)
        let r = shape.path(in: CGRect(x: 0, y: 0, width: c, height: c)).boundingRect
        return (UnitPoint(x: r.midX / c, y: r.minY / c), UnitPoint(x: r.midX / c, y: r.maxY / c))
    }

    @ViewBuilder
    private func raised<S: Shape>(_ shape: S, _ pair: WheelLook.Pair, rim: CGFloat = 1) -> some View {
        let sp = span(shape)
        ZStack {
            shape.fill(LinearGradient(colors: [pair.top, pair.bottom], startPoint: sp.top, endPoint: sp.bottom))
            shape.stroke(LinearGradient(stops: [.init(color: Color.white.opacity(look.rimTop * rim), location: 0),
                                                .init(color: Color.white.opacity(look.rimTop * 0.25 * rim), location: 0.35),
                                                .init(color: Color.clear, location: 0.6),
                                                .init(color: Color.black.opacity(look.rimBottom * rim), location: 1)],
                                        startPoint: sp.top, endPoint: sp.bottom),
                         lineWidth: 2.4 * g.scale)
                .clipShape(shape)
        }
    }

    private var spring: Animation? {
        if reduceMotion || state.prefs.animationSpeed == .off { return .easeOut(duration: 0.12) }
        let f = state.prefs.animationSpeed.factor
        return .spring(response: 0.3 * f, dampingFraction: 0.8)
    }

    var body: some View {
        let p = palette
        ZStack {
            // Nearly invisible disc so the whole wheel area receives the pointer
            // (fully transparent pixels would pass clicks to the app underneath).
            if !model.isPreview {
                Circle()
                    .fill(Color.black.opacity(0.012))
                    .frame(width: 2 * (g.ringOuter + 12 * g.scale), height: 2 * (g.ringOuter + 12 * g.scale))
                    .position(g.centre)
                    .allowsHitTesting(false)
            }

            // Solid dark round plate: a shallow dish (dark rim at the top, faint light rim at
            // the bottom) that the raised tiles sit in. Drawn as a sized circle so nothing paints
            // outside it — everything around the wheel stays fully transparent.
            Circle()
                .fill(LinearGradient(colors: [look.plate.top, look.plate.bottom], startPoint: .top, endPoint: .bottom))
                .overlay(Circle().stroke(LinearGradient(colors: [Color.black.opacity(0.55 * look.shadow), Color.white.opacity(look.dark ? 0.07 : 0.6)],
                                                        startPoint: .top, endPoint: .bottom), lineWidth: 3 * g.scale)
                            .clipShape(Circle()))
                .overlay(Circle().stroke(look.plateEdge, lineWidth: 1))
                .frame(width: 2 * g.plateRadius, height: 2 * g.plateRadius)
                .shadow(color: Color.black.opacity(0.45 * look.shadow), radius: 18 * g.scale, x: 0, y: 8 * g.scale)
                .position(g.centre)
                .allowsHitTesting(false)

            let labels = WheelLayout.primary(g, titles: (0..<6).map { model.segment($0).shortTitle })
            ZStack {
                ForEach(0..<6, id: \.self) { i in
                    primarySegment(i, p, labels)
                }
            }
            // A small contact shadow under the slices lifts them off the plate.
            .compositingGroup()
            .shadow(color: Color.black.opacity(0.55 * look.shadow), radius: 1.5 * g.scale, x: 0, y: 1.5 * g.scale)
            .shadow(color: Color.black.opacity(0.3 * look.shadow), radius: 5 * g.scale, x: 0, y: 4 * g.scale)

            if let open = model.openPrimary {
                ring(for: open, p)
                    .transition(.opacity.combined(with: .scale(scale: reduceMotion ? 1 : 0.96, anchor: .center)))
                    .id(open)
            }

            centre(p)

            if state.prefs.showRecentActions && model.openPrimary == nil {
                recents(p)
            }

        }
        .frame(width: g.canvas, height: g.canvas)
        .contentShape(Rectangle())   // the whole window answers clicks; off-wheel clicks close it
        .onContinuousHover(coordinateSpace: .local) { phase in
            switch phase {
            case let .active(location): withAnimation(spring) { model.hover(at: location) }
            case .ended: withAnimation(spring) { model.hover(at: nil) }
            }
        }
        .gesture(SpatialTapGesture(coordinateSpace: .local).onEnded { value in
            withAnimation(spring) { model.click(at: value.location) }
        })
        .scaleEffect(model.isShown || reduceMotion ? 1 : 0.9)
        .opacity(model.isShown ? 1 : 0)
        .animation(spring, value: model.isShown)
        .animation(spring, value: model.openPrimary)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("HEXSHIFT menu")
    }

    // MARK: Primary segments

    @ViewBuilder
    private func primarySegment(_ i: Int, _ p: HexPalette, _ labels: PrimaryLabelLayout) -> some View {
        let seg = model.segment(i)
        let enabled = model.isEnabled(i)
        let hovered = model.hoveredPrimary == i && enabled
        let open = model.openPrimary == i
        let shape = HexSegmentShape(index: i, geometry: g)
        let lifted = hovered && !open
        ZStack {
            raised(shape, open ? look.selected : (lifted ? look.hovered : look.tile), rim: open ? 0.55 : 1)
            if open {
                // One thin line all the way round the open slice, drawn inside its edge.
                shape.stroke(look.selectedEdge, lineWidth: 2.4 * g.scale).clipShape(shape)
            } else if look.highContrast {
                shape.stroke(look.text.opacity(0.55), lineWidth: 1.5)
            }
            VStack(spacing: labels.spacing) {
                Image(systemName: seg.symbol)
                    .font(.system(size: 16 * g.scale * seg.symbolScale, weight: .regular))
                    .frame(height: labels.iconSize)
                    .foregroundStyle(open ? look.accentIcon : look.text)
                Text(seg.shortTitle)
                    .font(.system(size: labels.fontSize, weight: .medium))
                    .lineLimit(1)
                    .fixedSize()
                    .foregroundStyle(look.text)
            }
            .position(g.primaryLabelPoint(i))
        }
        .opacity(enabled ? 1 : 0.38)
        .allowsHitTesting(false)
        .accessibilityElement()
        .accessibilityLabel(seg.title)
        .accessibilityHint(enabled ? "\(model.actions(forPrimary: i).count) actions. Shortcut: \(i + 1)" : "Not available for this selection")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction { model.openSegment(i) }
    }

    // MARK: Secondary ring

    @ViewBuilder
    private func ring(for seg: Int, _ p: HexPalette) -> some View {
        let actions = Array(model.actions(forPrimary: seg).prefix(RadialGeometry.maxRingItems))
        let layout = WheelLayout.ring(g, segment: seg, actions: actions)
        let half = RadialGeometry.ringTileAngle / 2
        ZStack {
            ForEach(Array(actions.enumerated()), id: \.element.id) { idx, action in
                let item = layout.items[idx]
                let focused = (model.hoveredRing == idx || model.keyboardRingIndex == idx) && action.enabled
                let shape = RingSectorShape(centre: g.centre, inner: g.ringInner, outer: g.ringOuter,
                                            startAngle: item.angle - half, endAngle: item.angle + half,
                                            gap: g.gap, corner: g.ringCorner)
                ZStack {
                    raised(shape, !action.enabled ? look.off : (focused ? look.hovered : look.tile), rim: action.enabled ? 1 : 0.5)
                    if look.highContrast { shape.stroke(look.text.opacity(0.55), lineWidth: 1.5) }
                    VStack(spacing: layout.spacing) {
                        Image(systemName: action.symbol)
                            .font(.system(size: 14 * g.scale, weight: .regular))
                            .frame(height: layout.iconSize)
                            .foregroundStyle(!action.enabled ? look.offIcon : (focused ? look.accentIcon : look.text))
                        Text(item.text)
                            .font(.system(size: layout.fontSize, weight: .medium))
                            .multilineTextAlignment(.center)
                            .fixedSize()
                            .foregroundStyle(action.enabled ? look.text : look.offText)
                        if let badge = action.badge, action.enabled {
                            Text(badge)
                                .font(.system(size: 8 * g.scale, weight: .bold))
                                .foregroundStyle(look.secondaryText)
                                .padding(.horizontal, 5 * g.scale)
                                .frame(height: 12 * g.scale)
                                .background(Capsule().fill(look.text.opacity(0.1)))
                                .fixedSize()
                        }
                    }
                    .position(item.centre)
                }
                .allowsHitTesting(false)
                .accessibilityElement()
                .accessibilityLabel(action.title)
                .accessibilityHint(action.enabled ? action.detail : "Unavailable: " + (action.reason ?? action.badge ?? "not available for this selection"))
                .accessibilityAddTraits(.isButton)
                .accessibilityAction { model.perform(action) }
            }
        }
        // A small contact shadow (as under the slices) and one soft shadow for the whole ring.
        .compositingGroup()
        .shadow(color: Color.black.opacity(0.55 * look.shadow), radius: 1.5 * g.scale, x: 0, y: 1.5 * g.scale)
        .shadow(color: Color.black.opacity(0.4 * look.shadow), radius: 10 * g.scale, x: 0, y: 5 * g.scale)
    }

    // MARK: Centre

    @ViewBuilder
    private func centre(_ p: HexPalette) -> some View {
        let hex = HexagonShape(apothem: g.centreApothem, centre: g.centre, corner: g.centreCorner)
        let s = g.scale
        ZStack {
            raised(hex, model.openPrimary != nil || model.hoveredPrimary != nil ? look.hub : look.hubIdle)
            if look.highContrast { hex.stroke(look.text.opacity(0.55), lineWidth: 1.5) }
            // The centre doubles as the hover message: what's under the pointer and one line
            // about it (its shortcut, what it does, or why it's greyed out).
            if let action = model.focusedAction ?? model.hoveredRingAction {
                hubLabel(symbol: action.symbol, title: action.title,
                         message: action.enabled ? action.detail : (action.reason ?? action.badge ?? "Not available for this selection"),
                         messageIsWarning: !action.enabled)
                    .id("a." + action.id)
                    .transition(.opacity)
            } else if let shown = model.hoveredPrimary ?? model.openPrimary {
                hubLabel(symbol: model.segment(shown).symbol, title: model.segment(shown).shortTitle,
                         message: model.isEnabled(shown) ? "Press \(shown + 1)" : "Nothing here for this selection",
                         messageIsWarning: !model.isEnabled(shown))
                    .id("p\(shown)")
                    .transition(.opacity)
            } else {
                let isFiles: Bool = { if case .files = model.context { return true }; return false }()
                let isText: Bool = { if case .text = model.context { return true }; return false }()
                let layout = CentreText.layout(g, imageSize: model.thumbnail != nil ? 34 * s : 24 * s,
                                               title: model.centreTitle, titleSize: 11 * s, titleLines: isText ? 2 : 1,
                                               truncateTitleInMiddle: isFiles,
                                               subtitle: model.centreSubtitle, subtitleSize: 9 * s, subtitleLines: 2)
                if let y = layout.imageY {
                    Group {
                        if let thumb = model.thumbnail {
                            Image(nsImage: thumb)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: layout.imageSize, height: layout.imageSize)
                                .clipShape(RoundedRectangle(cornerRadius: 6 * s, style: .continuous))
                        } else {
                            Image(systemName: centreSymbol)
                                .font(.system(size: 20 * s, weight: .light))
                                .foregroundStyle(look.accentIcon)
                                .frame(height: layout.imageSize)
                        }
                    }
                    .position(x: g.centre.x, y: g.centre.y + y)
                }
                centreText(layout, p)
            }
        }
        .compositingGroup()
        .shadow(color: Color.black.opacity(0.5 * look.shadow), radius: 2 * g.scale, x: 0, y: 2 * g.scale)
        .allowsHitTesting(false)
        .accessibilityElement(children: .combine)
    }

    /// Icon above a one- or two-line name, fitted inside the hexagon.
    private func hubLabel(symbol: String, title: String, message: String, messageIsWarning: Bool) -> some View {
        let s = g.scale
        let short = message.count <= 14
        let layout = CentreText.layout(g, imageSize: short ? 16 * s : nil, title: title, titleSize: (short ? 12.5 : 11.5) * s, titleLines: short ? 2 : 1,
                                       subtitle: message, subtitleSize: (short ? 10 : 9) * s, subtitleLines: 3)
        return ZStack {
            if let y = layout.imageY {
                Image(systemName: symbol)
                    .font(.system(size: 15 * s))
                    .foregroundStyle(look.accentIcon)
                    .frame(height: layout.imageSize)
                    .position(x: g.centre.x, y: g.centre.y + y)
            }
            ForEach(layout.lines) { line in
                Text(line.text)
                    .font(.system(size: line.size, weight: line.isTitle ? .medium : .regular))
                    .foregroundStyle(line.isTitle ? look.text : (messageIsWarning ? look.warning : (short ? look.accentIcon : look.secondaryText)))
                    .lineLimit(1)
                    .fixedSize()
                    .position(x: g.centre.x, y: g.centre.y + line.y)
            }
        }
    }

    @ViewBuilder
    private func centreText(_ layout: CentreText, _ p: HexPalette) -> some View {
        ForEach(layout.lines) { line in
            Text(line.text)
                .font(.system(size: line.size, weight: line.isTitle ? .semibold : .regular))
                .foregroundStyle(line.isTitle ? look.text : look.secondaryText)
                .lineLimit(1)
                .fixedSize()
                .position(x: g.centre.x, y: g.centre.y + line.y)
        }
    }

    private var centreSymbol: String {
        switch model.context {
        case .text: return "text.quote"
        case .empty: return "hexagon"
        case .files: return "doc"
        }
    }

    // MARK: Recent actions

    @ViewBuilder
    private func recents(_ p: HexPalette) -> some View {
        let items = model.quickActions(state)
        if !items.isEmpty {
            let d = g.recentChipDiameter
            ForEach(Array(items.enumerated()), id: \.element.action.id) { idx, entry in
                let item = entry.action
                let hovered = model.hoveredRecent == item.id
                Button {
                    model.perform(item)
                } label: {
                    Image(systemName: item.symbol)
                        .font(.system(size: 11.5 * g.scale, weight: .medium))
                        .foregroundStyle(hovered ? look.accentIcon : look.text)
                        .frame(width: d, height: d)
                        .background(raised(Circle(), hovered ? look.hovered : look.tile))
                        .overlay(Circle().stroke(entry.favourite ? look.selectedEdge : Color.clear, lineWidth: 1.2))
                        .shadow(color: p.shadow.opacity(0.5), radius: 6 * g.scale, y: 2 * g.scale)
                }
                .buttonStyle(.plain)
                .onHover { inside in model.hoveredRecent = inside ? item.id : (model.hoveredRecent == item.id ? nil : model.hoveredRecent) }
                .help(entry.favourite ? "Favourite: \(item.title)" : "Recent: \(item.title)")
                .accessibilityLabel(entry.favourite ? "Favourite action: \(item.title)" : "Recent action: \(item.title)")
                .position(g.recentChipCentre(index: idx, count: items.count))
            }
        }
    }
}

/// The wheel's own colours, from the approved design: neutral tiles lit softly from above, the
/// selection in your accent colour with a thin edge, and a solid plate. Follows light / dark
/// mode and the accent colour chosen in Preferences (Indigo gives the original purple).
struct WheelLook {
    typealias Pair = (top: Color, bottom: Color)
    let highContrast: Bool
    let dark: Bool

    let plate: Pair, plateEdge: Color
    let tile: Pair, hovered: Pair, selected: Pair, off: Pair
    let hub: Pair, hubIdle: Pair
    let selectedEdge: Color
    let text: Color, secondaryText: Color, accentIcon: Color, offText: Color, offIcon: Color
    let warning: Color, tipBackground: Color, tipDetail: Color
    /// Rim light: top highlight and bottom shade opacities.
    let rimTop: Double, rimBottom: Double
    /// Multiplies every drop shadow (light mode uses softer shadows).
    let shadow: Double

    static func rgb(_ hex: UInt32) -> Color {
        Color(.sRGB, red: Double((hex >> 16) & 0xFF) / 255, green: Double((hex >> 8) & 0xFF) / 255, blue: Double(hex & 0xFF) / 255, opacity: 1)
    }
    private static func mix(_ a: RGBAColour, _ hex: UInt32, _ t: Double) -> Color {
        let r = Double((hex >> 16) & 0xFF) / 255, g = Double((hex >> 8) & 0xFF) / 255, b = Double(hex & 0xFF) / 255
        return Color(.sRGB, red: a.r * (1 - t) + r * t, green: a.g * (1 - t) + g * t, blue: a.b * (1 - t) + b * t, opacity: 1)
    }

    init(dark: Bool, accent: RGBAColour, highContrast: Bool = false) {
        self.dark = dark
        self.highContrast = highContrast
        let rgb = Self.rgb, mix = Self.mix
        if dark {
            plate = (rgb(0x232326), rgb(0x18181A)); plateEdge = rgb(0x2E2E32)
            tile = (rgb(0x434349), rgb(0x2A2A2E)); hovered = (rgb(0x505057), rgb(0x34343A))
            off = (rgb(0x2A2A2D), rgb(0x222225)); hubIdle = (rgb(0x3A3A40), rgb(0x26262A))
            selected = (mix(accent, 0x1E1E24, 0.35), mix(accent, 0x1E1E24, 0.55))
            hub = (mix(accent, 0x1E1E24, 0.5), mix(accent, 0x1E1E24, 0.68))
            selectedEdge = mix(accent, 0xFFFFFF, 0.3).opacity(0.9)
            accentIcon = mix(accent, 0xFFFFFF, 0.5)
            text = .white; secondaryText = rgb(0xB8B8BE); offText = rgb(0x7C7C82); offIcon = rgb(0x6A6A70)
            warning = rgb(0xF2B36B); tipBackground = rgb(0x3A3A3E); tipDetail = rgb(0xC7C7CC)
            rimTop = 0.22; rimBottom = 0.45; shadow = 1
        } else {
            plate = (rgb(0xECECF0), rgb(0xDCDCE2)); plateEdge = rgb(0xCFCFD6)
            tile = (rgb(0xFFFFFF), rgb(0xEDEDF1)); hovered = (rgb(0xFFFFFF), rgb(0xE2E2E8))
            off = (rgb(0xEFEFF2), rgb(0xE6E6EA)); hubIdle = (rgb(0xFAFAFC), rgb(0xE9E9ED))
            selected = (mix(accent, 0xFFFFFF, 0.78), mix(accent, 0xFFFFFF, 0.64))
            hub = (mix(accent, 0xFFFFFF, 0.84), mix(accent, 0xFFFFFF, 0.70))
            selectedEdge = accent.color.opacity(0.85)
            accentIcon = mix(accent, 0x000000, 0.18)
            text = rgb(0x1D1D1F); secondaryText = rgb(0x55555B); offText = rgb(0x9A9AA0); offIcon = rgb(0xA8A8AE)
            warning = rgb(0xA65A00); tipBackground = rgb(0xFFFFFF); tipDetail = rgb(0x55555B)
            rimTop = 0.9; rimBottom = 0.12; shadow = 0.45
        }
    }

    func gradient(_ pair: Pair) -> LinearGradient {
        LinearGradient(colors: [pair.top, pair.bottom], startPoint: .top, endPoint: .bottom)
    }
}

private extension RGBAColour {
    var color: Color { Color(.sRGB, red: r, green: g, blue: b, opacity: 1) }
}
