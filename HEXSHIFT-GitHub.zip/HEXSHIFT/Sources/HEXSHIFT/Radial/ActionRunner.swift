import AppKit
import CoreImage
import HexshiftKit
import UniformTypeIdentifiers

/// Namespace for opening tool windows (each window file adds its own entry point).
@MainActor
enum Windows {}

/// Executes radial-menu actions.
@MainActor
final class ActionRunner {
    static let shared = ActionRunner()
    private var state: AppState { .shared }
    private var jobs: JobCenter { .shared }

    func perform(_ action: RadialAction, context: RadialContext) {
        let id = action.id
        inputLog.notice("run \(id, privacy: .public)")
        let assets = context.assets
        let asset = context.singleAsset

        if id.hasPrefix("convert:") { convert(assets, targetID: String(id.dropFirst("convert:".count))); return }
        if id.hasPrefix("workflow:") { runWorkflow(String(id.dropFirst("workflow:".count)), assets: assets); return }
        if id.hasPrefix("text.export:") {
            guard case let .text(t) = context, let f = Format(rawValue: String(id.dropFirst("text.export:".count))) else { return unavailable() }
            Windows.openTextStudio(text: t.text, attributed: t.attributed, format: f)
            return
        }
        if id.hasPrefix("more.recentFile:") {
            let i = Int(id.dropFirst("more.recentFile:".count)) ?? 0
            let files = state.recentFileURLs
            guard i < files.count else { return }
            showMenu(for: [files[i]])
            return
        }
        if id.hasPrefix("more.panel.") {
            overflowMenu(segment: String(id.dropFirst("more.panel.".count)), context: context)
            return
        }

        switch id {
        // MARK: Convert
        case "convert.more":
            guard !assets.isEmpty else { return unavailable() }
            Windows.openConvertOptions(assets: assets, preselect: nil)

        // MARK: Image edits
        case "edit.crop", "edit.resize", "edit.removebg", "edit.adjust", "edit.annotate", "edit.compress", "edit.metadata", "edit.measure", "edit.firstFrame":
            guard let a = asset else { return unavailable() }
            Windows.openEditor(asset: a, tool: EditorTool(actionID: id))
        case "edit.rotate":
            guard let a = asset else { return unavailable() }
            withPlanner { planner, delivery in
                self.jobs.runTask(title: "Rotating", delivery: delivery, successTitle: "Rotated copy saved") {
                    [try QuickImageEdits.rotate(a, clockwise: true, planner: planner)]
                }
            }
        case "edit.scales":
            guard let a = asset else { return unavailable() }
            exportScales(a)
        case "edit.frames":
            guard let a = asset else { return unavailable() }
            withPlanner { planner, _ in
                self.jobs.runTask(title: "Extracting frames", successTitle: "Frames saved") {
                    let (frames, _) = try ImageLoader.loadAnimation(a.url)
                    let folder = planner.folderURL(for: a.url, name: "\(a.baseName) frames")
                    try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                    var out: [URL] = []
                    for (i, f) in frames.enumerated() {
                        let u = folder.appendingPathComponent(String(format: "frame-%03d.png", i + 1))
                        try ImageEncoder.write(f.image, format: .png, to: u)
                        out.append(u)
                    }
                    return [folder]
                }
            }

        // MARK: Batch edits
        case "batch.resize", "batch.compress":
            Windows.openBatchOptions(assets: assets, mode: id == "batch.resize" ? .resize : .compress)
        case "batch.stripGPS":
            withPlanner { planner, delivery in
                self.jobs.run(title: "Removing location data", items: assets.map(\.url), delivery: delivery, successTitle: "Location data removed (copies saved)") { url in
                    [try QuickImageEdits.stripMetadata(AssetInspector.inspect(url), gpsOnly: true, planner: planner)]
                }
            }
        case "batch.rotate":
            withPlanner { planner, delivery in
                self.jobs.run(title: "Rotating", items: assets.map(\.url), delivery: delivery) { url in
                    [try QuickImageEdits.rotate(AssetInspector.inspect(url), clockwise: true, planner: planner)]
                }
            }

        // MARK: Text from images
        case "doc.ocr":
            guard let a = asset else { return unavailable() }
            recogniseText(in: a)
        case "doc.ocrBatch":
            withPlanner { planner, delivery in
                let urls = assets.map(\.url)
                self.jobs.runTask(title: "Extracting text", delivery: delivery, successTitle: "Text extracted") {
                    var parts: [String] = []
                    for u in urls {
                        try Task.checkCancellation()
                        let r = try OCRService.recognize(url: u)
                        parts.append("— \(u.lastPathComponent) —\n\(r.text)")
                    }
                    let dest = planner.url(for: urls.first, baseName: "Extracted text", ext: "txt")
                    try FileWriter.writeAtomically(to: dest) { try Data(parts.joined(separator: "\n\n").utf8).write(to: $0) }
                    return [dest]
                }
            }

        // MARK: PDF
        case "pdf.fromImages":
            guard let a = asset else { return unavailable() }
            withPlanner { planner, delivery in
                self.jobs.runTask(title: "Making PDF", delivery: delivery) {
                    let dest = planner.url(for: a.url, ext: "pdf", format: "PDF")
                    try PDFEngine.makePDF(fromImages: [a.url], output: dest)
                    return [dest]
                }
            }
        case "pdf.searchableImage":
            guard let a = asset else { return unavailable() }
            withPlanner { planner, delivery in
                self.jobs.runTask(title: "Making searchable PDF", delivery: delivery) {
                    let tmp = try FileWriter.makeTemporaryDirectory()
                    defer { try? FileManager.default.removeItem(at: tmp) }
                    let plain = tmp.appendingPathComponent("page.pdf")
                    try PDFEngine.makePDF(fromImages: [a.url], output: plain)
                    let dest = planner.url(for: a.url, ext: "pdf", format: "PDF")
                    try PDFEngine.makeSearchable(plain, output: dest, skipPagesWithText: false)
                    return [dest]
                }
            }
        case "pdf.mergeSelection":
            mergeFiles(assets.map(\.url))
        case "pdf.mergeBrowse", "pdf.imagesBrowse":
            if let urls = choose(files: true, multiple: true, types: [.pdf, .image]) { mergeFiles(urls) }
        case "pdf.organize", "pdf.redact", "pdf.sign", "pdf.markup":
            guard let a = asset else { return unavailable() }
            let mode: PDFToolkitMode = id == "pdf.redact" ? .redact : id == "pdf.sign" ? .sign : id == "pdf.markup" ? .markup : .organize
            Windows.openPDFToolkit(urls: [a.url], mode: mode)
        case "pdf.merge":
            guard let a = asset else { return unavailable() }
            Windows.openPDFToolkit(urls: [a.url], mode: .organize, promptInsert: true)
        case "pdf.pageNumbers", "pdf.stamp", "pdf.highlight", "pdf.split", "pdf.extract", "pdf.compress", "pdf.password", "pdf.pageSize":
            guard let a = asset else { return unavailable() }
            Windows.openPDFTask(asset: a, task: PDFTask(actionID: id))
        case "pdf.ocr":
            guard let a = asset else { return unavailable() }
            withPlanner { planner, delivery in
                self.jobs.runTask(title: "Recognising text (OCR)", delivery: delivery, successTitle: "Searchable PDF saved") {
                    let dest = planner.url(for: a.url, baseName: a.baseName + "-searchable", ext: "pdf")
                    let n = try PDFEngine.makeSearchable(a.url, output: dest)
                    if n == 0 { throw HexError.message("Every page already has selectable text, so OCR wasn't needed.") }
                    return [dest]
                }
            }
        case "pdf.extractText":
            guard let a = asset else { return unavailable() }
            jobs.message("Extracting text…")
            Task.detached {
                do {
                    let r = try PDFEngine.extractText(a.url)
                    await MainActor.run {
                        Windows.openTextResult(title: "Text from \(a.name)", text: r.text, source: a,
                                               note: r.usedOCR ? "Some pages were recognised with OCR\(r.lowConfidenceLines > 0 ? " — \(r.lowConfidenceLines) line(s) were uncertain; please check them" : "")." : nil)
                    }
                } catch {
                    await MainActor.run { JobCenter.shared.error(error) }
                }
            }
        case "pdf.stripMeta":
            guard let a = asset else { return unavailable() }
            withPlanner { planner, delivery in
                self.jobs.runTask(title: "Removing PDF metadata", delivery: delivery, successTitle: "Clean copy saved") {
                    let dest = planner.url(for: a.url, baseName: a.baseName + "-clean", ext: "pdf")
                    try PDFEngine.stripMetadata(a.url, output: dest)
                    return [dest]
                }
            }
        case "pdf.rotateAll":
            guard let a = asset else { return unavailable() }
            withPlanner { planner, delivery in
                self.jobs.runTask(title: "Rotating pages", delivery: delivery) {
                    let doc = try PDFEngine.open(a.url)
                    PDFEngine.rotate(doc, pages: Array(0..<doc.pageCount), by: 90)
                    let dest = planner.url(for: a.url, baseName: a.baseName + "-rotated", ext: "pdf")
                    try PDFEngine.save(doc, to: dest)
                    return [dest]
                }
            }

        // MARK: Documents
        case "doc.studio", "doc.studioPDF", "text.graphicFromFile":
            guard let a = asset, let f = a.format else { return unavailable() }
            do {
                let attr = try DocumentConverter.attributedString(from: a.url, format: f)
                if id == "text.graphicFromFile" {
                    let lines = attr.string.split(separator: "\n").prefix(3).joined(separator: "\n")
                    Windows.openTextStudio(text: lines, attributed: nil, format: .png, graphic: true)
                } else {
                    Windows.openTextStudio(text: attr.string, attributed: attr, format: .pdf, sourceName: a.baseName)
                }
            } catch {
                jobs.error(error)
            }
        case "doc.copyText":
            guard let a = asset, let f = a.format, let attr = try? DocumentConverter.attributedString(from: a.url, format: f) else { return unavailable() }
            Clipboard.copy(attr.string)
            jobs.message("Text copied", detail: "\(DocumentConverter.statistics(attr.string).words) words")
        case "doc.stats":
            guard let a = asset, let f = a.format, let attr = try? DocumentConverter.attributedString(from: a.url, format: f) else { return unavailable() }
            let s = DocumentConverter.statistics(attr.string)
            jobs.message("\(s.words) words", detail: "\(s.characters) characters · \(s.lines) lines · about \(s.readingMinutes) min read")

        // MARK: Typography
        case "type.findFont":
            if let a = asset {
                if let image = previewImage(for: a) { Windows.openFontLens(.estimate(image: image, text: nil)) } else { unavailable() }
            } else {
                captureThen { url in
                    if let img = try? ImageLoader.load(url).image { Windows.openFontLens(.estimate(image: img, text: nil)) }
                }
            }
        case "type.inspectSelection":
            guard case let .text(t) = context else { return unavailable() }
            if let font = t.font {
                Windows.openFontLens(.actual(font, sample: t.text))
            } else {
                jobs.message("No exact font information was available", detail: "Drag around the text to find visually similar fonts.")
                captureThen { url in
                    if let img = try? ImageLoader.load(url).image { Windows.openFontLens(.estimate(image: img, text: nil)) }
                }
            }
        case "type.compare":
            var sample = state.prefs.fontSampleText
            if case let .text(t) = context { sample = String(t.text.prefix(80)) }
            Windows.openFontLens(.compare(sample: sample))
        case "type.browse":
            Windows.openFontLens(.browse)
        case "type.fontsInFile":
            guard let a = asset else { return unavailable() }
            Windows.openFontLens(.fontsInFile(a))
        case "type.fontFile":
            guard let a = asset else { return unavailable() }
            Windows.openFontLens(.fontFile(a.url))
        case "type.fontBook":
            guard let a = asset else { return unavailable() }
            if let fontBook = NSWorkspace.shared.urlForApplication(withBundleIdentifier: "com.apple.FontBook") {
                NSWorkspace.shared.open([a.url], withApplicationAt: fontBook, configuration: NSWorkspace.OpenConfiguration())
            }
        case "type.graphic", "text.graphic":
            var text = "Select anything.\nCreate anything."
            if case let .text(t) = context { text = t.text }
            Windows.openTextStudio(text: text, attributed: nil, format: .png, graphic: true)
        case "text.studio":
            Windows.openTextStudio(text: "", attributed: nil, format: .pdf)

        // MARK: Colour
        case "colour.pick":
            pickColour()
        case "colour.pickImage", "colour.palette", "colour.gradient":
            guard let a = asset ?? assets.first, let image = previewImage(for: a, maxPixel: 2400) else { return unavailable() }
            Windows.openColourLens(.image(image, name: a.name, focus: id == "colour.gradient" ? .gradient : id == "colour.palette" ? .palette : .pick))
        case "colour.paletteCapture":
            captureThen { url in
                if let img = try? ImageLoader.load(url).image { Windows.openColourLens(.image(img, name: "Screen capture", focus: .palette)) }
            }
        case "colour.contrast":
            Windows.openColourLens(.contrast)
        case "colour.lens":
            Windows.openColourLens(.history)
        case "text.colour":
            guard case let .text(t) = context, let c = ColourMath.parse(t.text) else { return unavailable() }
            state.addColourToHistory(c)
            Windows.openColourLens(.colour(c, p3: nil))

        // MARK: Inspect
        case "inspect.info":
            guard let a = asset else { return unavailable() }
            Windows.openInspector(asset: a)
        case "inspect.transparency":
            guard let a = asset else { return unavailable() }
            let t = TransparencyCheck.hasTransparentPixels(a.url)
            jobs.message(t == true ? "This image uses transparency" : "No transparent pixels",
                         detail: t == true ? "Some pixels are partly or fully transparent." : "It has an alpha channel, but every pixel is opaque — it could be saved without one.")
        case "inspect.measureCapture":
            captureThen { url in Windows.openEditor(asset: AssetInspector.inspect(url), tool: .measure) }
        case "designer.tools":
            Windows.openDesignerTools()

        // MARK: Capture
        case "capture.region": captureAndShowMenu(.region)
        case "capture.window": captureAndShowMenu(.window)
        case "capture.display": captureAndShowMenu(.display)
        case "capture.edit":
            captureThen { url in Windows.openEditor(asset: AssetInspector.inspect(url), tool: .crop) }
        case "capture.annotate":
            captureThen { url in Windows.openEditor(asset: AssetInspector.inspect(url), tool: .annotate) }
        case "capture.ocr":
            captureThen { url in self.recogniseText(in: AssetInspector.inspect(url), copy: true) }
        case "capture.research":
            captureThen { url in self.designResearch(url) }

        // MARK: Media
        case "media.trim", "media.gif", "media.frame":
            guard let a = asset else { return unavailable() }
            Windows.openMediaTools(asset: a, mode: id == "media.gif" ? .gif : id == "media.frame" ? .frame : .trim)
        case "media.reduce":
            guard let a = asset else { return unavailable() }
            var o = state.conversionOptions(for: .mp4)
            o.video.quality = .hevc
            let videoOptions = o.video
            let target = ConversionTarget(a.format == .mov ? .mov : .mp4)
            withPlanner { planner, delivery in
                self.jobs.runTask(title: "Reducing video size", delivery: delivery) {
                    let dest = planner.url(for: a.url, baseName: a.baseName + "-smaller", ext: target.format.fileExtension)
                    try await MediaConverter.exportVideo(a.url, to: target.format, output: dest, options: videoOptions)
                    let before = a.fileSize, after = PDFEngine.fileSize(dest)
                    if after >= before { try? FileManager.default.removeItem(at: dest); throw HexError.message("This video is already efficiently encoded; re-encoding would not make it smaller.") }
                    return [dest]
                }
            }
        case "media.audio":
            guard let a = asset else { return unavailable() }
            convert([a], targetID: "m4a.standard")

        // MARK: Text selection
        case "text.copyPlain", "text.upper", "text.lower", "text.title", "text.clean":
            guard case let .text(t) = context else { return unavailable() }
            var s = t.text
            switch id {
            case "text.upper": s = s.uppercased()
            case "text.lower": s = s.lowercased()
            case "text.title": s = s.capitalized
            case "text.clean":
                s = s.replacingOccurrences(of: "[ \\t]+", with: " ", options: .regularExpression)
                    .replacingOccurrences(of: "\\n{3,}", with: "\n\n", options: .regularExpression)
                    .trimmingCharacters(in: .whitespacesAndNewlines)
            default: break
            }
            Clipboard.copy(s)
            jobs.message("Copied", detail: String(s.prefix(60)))
        case "text.copyMarkdown":
            guard case let .text(t) = context else { return unavailable() }
            let md = t.attributed.map { MarkdownWriter.markdown(from: $0) } ?? t.text
            Clipboard.copy(md.trimmingCharacters(in: .whitespacesAndNewlines))
            jobs.message("Copied as Markdown")
        case "text.stats":
            guard case let .text(t) = context else { return unavailable() }
            let s = DocumentConverter.statistics(t.text)
            jobs.message("\(s.words) words", detail: "\(s.characters) characters · \(s.lines) lines · about \(s.readingMinutes) min read")
        case "text.translate":
            guard case let .text(t) = context else { return unavailable() }
            Windows.openTranslate(text: t.text)
        case "text.qr":
            guard case let .text(t) = context else { return unavailable() }
            makeQRCode(t.text.trimmingCharacters(in: .whitespacesAndNewlines))

        // MARK: Files
        case "more.copy":
            guard !assets.isEmpty else { return unavailable() }
            if let a = asset, a.kind == .image, let img = try? ImageLoader.load(a.url).image {
                Clipboard.copy(image: img)
                NSPasteboard.general.writeObjects([a.url as NSURL])
            } else {
                Clipboard.copy(files: assets.map(\.url))
            }
            jobs.message("Copied to the clipboard")
        case "more.copyPath":
            Clipboard.copy(assets.map(\.url.path).joined(separator: "\n"))
            jobs.message("Path copied")
        case "more.reveal":
            NSWorkspace.shared.activateFileViewerSelecting(assets.map(\.url))
        case "more.settings":
            Windows.openSettings()
        case "more.browse":
            if let urls = choose(files: true, multiple: true, types: nil) { showMenu(for: urls) }
        case "more.browseEdit":
            if let urls = choose(files: true, multiple: false, types: [.image]), let u = urls.first {
                Windows.openEditor(asset: AssetInspector.inspect(u), tool: .adjust)
            }
        case "more.clipboard":
            convertClipboard()

        default:
            unavailable()
        }
    }

    // MARK: - Helpers

    func unavailable() {
        jobs.message("That action isn't available for this selection")
    }

    /// Replays a recent action from somewhere that has no selection (the menu-bar popover).
    /// Actions that need input get it the obvious way: text actions use the clipboard text,
    /// file actions ask for files first.
    func replayRecent(_ recent: RecentAction) {
        let action = RadialAction(id: recent.id, title: recent.title, detail: "", symbol: recent.symbol)
        let emptyCatalog = ActionCatalog.build(for: .empty, state: state).values.flatMap { $0 }
        if emptyCatalog.contains(where: { $0.id == recent.id && $0.enabled }) {
            perform(action, context: .empty)
            return
        }
        if recent.id.hasPrefix("text."), let text = NSPasteboard.general.string(forType: .string), !text.isEmpty {
            perform(action, context: .text(SelectedText(text: text, attributed: nil, font: nil, sourceApp: "Clipboard")))
            return
        }
        NSApp.activate()
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = false
        panel.prompt = "Choose"
        panel.message = "Choose the files for “\(recent.title)”."
        panel.level = .modalPanel   // stay above other apps, so it can't hide behind them
        guard panel.runModal() == .OK, !panel.urls.isEmpty else { return }
        let assets = panel.urls.map { AssetInspector.inspect($0) }
        perform(action, context: .files(assets))
    }

    /// Shows the radial menu for files (Finder Quick Action, Open With, browse…).
    func showMenu(for urls: [URL], at point: NSPoint? = nil) {
        let assets = urls.map { AssetInspector.inspect($0) }
        RadialMenuController.shared.show(context: assets.isEmpty ? .empty : .files(assets), at: point)
    }

    /// Resolves the output destination ("Ask every time" and "Clipboard only" included).
    func withPlanner(destination: OutputDestination? = nil, _ body: @escaping (OutputPlanner, JobCenter.Delivery) -> Void) {
        var settings = state.prefs.output
        if let destination { settings.destination = destination }
        switch settings.destination {
        case .askEveryTime:
            NSApp.activate()
            let panel = NSOpenPanel()
            panel.canChooseDirectories = true
            panel.canChooseFiles = false
            panel.canCreateDirectories = true
            panel.prompt = "Save Here"
            panel.message = "Choose where HEXSHIFT should save the result."
            panel.level = .modalPanel   // stay above other apps, so it can't hide behind them
            guard panel.runModal() == .OK, let dir = panel.url else { return }
            body(OutputPlanner(settings: settings, folderOverride: dir), .files)
        case .clipboardOnly:
            body(OutputPlanner(settings: settings, folderOverride: OutputPlanner.clipboardStagingFolder()), .clipboard)
        default:
            body(OutputPlanner(settings: settings), .files)
        }
    }

    func convert(_ assets: [AssetInfo], targetID: String) {
        guard let first = assets.first else { return unavailable() }
        guard let target = ConversionEngine.targets(for: first).first(where: { $0.id == targetID }) else { return unavailable() }
        guard target.isAvailable else {
            jobs.message("\(target.label) isn't available", detail: target.note, kind: .error)
            return
        }
        if assets.count == 1 && target.prefersOptions {
            Windows.openConvertOptions(assets: assets, preselect: target)
            return
        }
        startConversion(assets, target: target, options: state.conversionOptions(for: target.format))
    }

    func startConversion(_ assets: [AssetInfo], target: ConversionTarget, options: ConversionOptions,
                         destination: OutputDestination? = nil) {
        withPlanner(destination: destination) { planner, delivery in
            let title = assets.count == 1 ? "Converting to \(target.label)" : "Converting \(assets.count) files to \(target.label)"
            self.jobs.run(title: title, items: assets.map(\.url), delivery: delivery) { url in
                let asset = AssetInspector.inspect(url)
                let t = ConversionEngine.targets(for: asset).first { $0.id == target.id } ?? target
                return try await ConversionEngine.convert(asset, to: t, options: options, planner: planner)
            }
        }
    }

    func runWorkflow(_ idString: String, assets: [AssetInfo]) {
        guard let wf = state.allWorkflows.first(where: { $0.id.uuidString == idString }) else { return unavailable() }
        let defaults = state.imageExportDefaults
        withPlanner { planner, delivery in
            let clipboard = wf.steps.contains(.copyToClipboard)
            self.jobs.run(title: wf.name, items: assets.map(\.url), delivery: clipboard ? .clipboard : delivery,
                          successTitle: "\(wf.name) done") { url in
                let r = try await WorkflowEngine.run(wf, on: AssetInspector.inspect(url), planner: planner, defaults: defaults)
                return r.outputs
            }
        }
    }

    func mergeFiles(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        withPlanner { planner, delivery in
            self.jobs.runTask(title: "Combining into PDF", delivery: delivery, successTitle: "PDF created") {
                let first = urls[0]
                let dest = planner.url(for: first, baseName: first.deletingPathExtension().lastPathComponent + "-combined", ext: "pdf")
                try PDFEngine.merge(urls, output: dest)
                return [dest]
            }
        }
    }

    func choose(files: Bool, multiple: Bool, types: [UTType]?) -> [URL]? {
        NSApp.activate()
        let panel = NSOpenPanel()
        panel.canChooseFiles = files
        panel.canChooseDirectories = !files
        panel.allowsMultipleSelection = multiple
        if let types { panel.allowedContentTypes = types }
        panel.level = .modalPanel   // stay above other apps, so it can't hide behind them
        guard panel.runModal() == .OK, !panel.urls.isEmpty else { return nil }
        return panel.urls
    }

    /// A still image representing the asset (image, first frame, PDF page 1, SVG, video frame).
    func previewImage(for a: AssetInfo, maxPixel: Int = 3000) -> CGImage? {
        switch a.kind {
        case .image, .rawImage, .animatedImage:
            return (try? ImageLoader.load(a.url).image).map { ImageOps.limit($0, maxPixelSize: maxPixel) }
        case .pdf:
            guard let doc = try? PDFEngine.open(a.url), let page = doc.page(at: 0) else { return nil }
            return PDFEngine.render(page, dpi: 200)
        case .vector where a.format == .svg:
            return SVGSupport.renderNative(a.url, scale: 2)
        case .vector where a.format == .ai:
            guard let doc = try? PDFEngine.open(a.url), let page = doc.page(at: 0) else { return nil }
            return PDFEngine.render(page, dpi: 150)
        default:
            return nil
        }
    }

    func recogniseText(in a: AssetInfo, copy: Bool = false) {
        guard let image = previewImage(for: a, maxPixel: 6000) else { return unavailable() }
        let name = a.name
        Task.detached {
            do {
                let r = try OCRService.recognize(image)
                await MainActor.run {
                    guard !r.text.isEmpty else {
                        JobCenter.shared.message("No readable text was found", kind: .info)
                        return
                    }
                    if copy { Clipboard.copy(r.text) }
                    let uncertain = r.uncertainLines.count
                    Windows.openTextResult(title: copy ? "Text copied to the clipboard" : "Text from \(name)", text: r.text, source: a,
                                           note: uncertain > 0 ? "\(uncertain) line(s) were recognised with low confidence — please check them." : nil)
                }
            } catch {
                await MainActor.run { JobCenter.shared.error(error) }
            }
        }
    }

    func pickColour() {
        Task { @MainActor in
            guard let colour = await ColourPicker.pick() else { return }
            let d = ColourPicker.describe(colour)
            self.state.addColourToHistory(d.srgb)
            if self.state.prefs.autoCopyPickedColour {
                Clipboard.copy(ColourFormatting.string(d.srgb, format: self.state.prefs.colourCopyFormat))
            }
            Windows.openColourLens(.colour(d.srgb, p3: d.p3))
        }
    }

    func captureThen(_ mode: CaptureMode = .region, _ body: @escaping (URL) -> Void) {
        Task { @MainActor in
            guard let url = await ScreenCapture.capture(mode) else { return }
            body(url)
        }
    }

    func captureAndShowMenu(_ mode: CaptureMode) {
        captureThen(mode) { url in
            RadialMenuController.shared.show(context: .files([AssetInspector.inspect(url)]))
        }
    }

    func convertClipboard() {
        switch SelectionService.readClipboard() {
        case let .files(urls):
            showMenu(for: urls)
        case let .image(img):
            do {
                let url = try SelectionService.stageClipboardImage(img)
                showMenu(for: [url])
            } catch { jobs.error(error) }
        case let .colour(c, _):
            state.addColourToHistory(c)
            Windows.openColourLens(.colour(c, p3: nil))
        case let .url(u):
            RadialMenuController.shared.show(context: .text(SelectedText(text: u.absoluteString, attributed: nil, font: nil, sourceApp: "Clipboard")))
        case let .text(t):
            RadialMenuController.shared.show(context: .text(SelectedText(text: t, attributed: nil, font: nil, sourceApp: "Clipboard")))
        case .empty:
            jobs.message("The clipboard is empty")
        }
    }

    func exportScales(_ a: AssetInfo) {
        NSApp.activate()
        let alert = NSAlert()
        alert.messageText = "Export @1x, @2x and @3x"
        alert.informativeText = a.format == .svg ? "SVGs are rendered sharply at each scale." : "Which scale is this image? Smaller variants are created from it (upscaling is never used)."
        let popup = NSPopUpButton(frame: NSRect(x: 0, y: 0, width: 200, height: 26))
        popup.addItems(withTitles: ["It's @3x", "It's @2x", "It's @1x"])
        if a.format != .svg { alert.accessoryView = popup }
        alert.addButton(withTitle: "Export")
        alert.addButton(withTitle: "Cancel")
        alert.window.level = .modalPanel   // stay above other apps, so it can't hide behind them
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let source = Double(a.format == .svg ? 1 : 3 - popup.indexOfSelectedItem)
        let scales: [Double] = a.format == .svg ? [1, 2, 3] : Array(1...Int(source)).map(Double.init)
        withPlanner { planner, delivery in
            self.jobs.runTask(title: "Exporting scales", delivery: delivery, successTitle: "Scale variants saved") {
                try await QuickImageEdits.exportScales(a, scales: scales, sourceScale: source, planner: planner)
            }
        }
    }

    func makeQRCode(_ text: String) {
        guard let filter = CIFilter(name: "CIQRCodeGenerator") else { return }
        filter.setValue(Data(text.utf8), forKey: "inputMessage")
        filter.setValue("M", forKey: "inputCorrectionLevel")
        guard let out = filter.outputImage?.transformed(by: CGAffineTransform(scaleX: 16, y: 16)),
              let cg = CIContext().createCGImage(out, from: out.extent) else { return }
        let padded = ImageOps.flatten(cg)
        withPlanner { planner, delivery in
            self.jobs.runTask(title: "Making QR code", delivery: delivery, successTitle: "QR code saved") {
                let dest = planner.url(for: nil, baseName: "QR code", ext: "png")
                try ImageEncoder.write(padded, format: .png, to: dest)
                return [dest]
            }
        }
    }

    func designResearch(_ captureURL: URL) {
        jobs.runTask(title: "Building design reference", successTitle: "Design reference saved") {
            let image = try ImageLoader.load(captureURL).image
            let palette = PaletteExtractor.extract(from: image, count: 6)
            var fonts: [FontCandidate] = []
            var text: String?
            if let report = try? FontMatcher.analyse(image: image, limit: 4) {
                fonts = report.candidates
                text = report.recognisedText
            }
            guard let board = DesignReference.board(capture: image, palette: palette, fonts: fonts, text: text) else {
                throw HexError.message("The reference board could not be drawn.")
            }
            let desktop = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first!
            let planner = OutputPlanner(settings: OutputSettings(destination: .custom(path: desktop.path), naming: .originalName))
            let png = planner.url(for: nil, baseName: "Design reference", ext: "png")
            try ImageEncoder.write(board, format: .png, to: png)
            let tokens = PaletteExporter.designTokensJSON(palette.enumerated().map { (name: "colour-\($0.offset + 1)", colour: $0.element.colour) })
            let json = planner.url(for: nil, baseName: "Design reference tokens", ext: "json")
            try FileWriter.writeAtomically(to: json) { try Data(tokens.utf8).write(to: $0) }
            return [png, json]
        }
    }

    // MARK: Overflow ("More…") menu

    private var menuTargets: [MenuActionTarget] = []

    func overflowMenu(segment raw: String, context: RadialContext) {
        guard let seg = PrimarySegment(rawValue: raw) else { return }
        let all: [RadialAction]
        switch context {
        case .empty: all = ActionCatalog.emptyMenu(state)[seg] ?? []
        case let .text(t): all = ActionCatalog.textMenu(t, state: state)[seg] ?? []
        case let .files(a): all = (a.count == 1 ? ActionCatalog.singleFileMenu(a[0], state: state) : ActionCatalog.multiFileMenu(a, state: state))[seg] ?? []
        }
        let menu = NSMenu()
        menuTargets = []
        for action in all.dropFirst(ActionCatalog.maxRingItems - 1) {
            let target = MenuActionTarget { [weak self] in self?.perform(action, context: context) }
            menuTargets.append(target)
            let item = NSMenuItem(title: action.title, action: #selector(MenuActionTarget.run), keyEquivalent: "")
            item.target = target
            item.image = NSImage(systemSymbolName: action.symbol, accessibilityDescription: nil)
            item.toolTip = action.detail
            item.isEnabled = action.enabled
            menu.addItem(item)
        }
        menu.popUp(positioning: nil, at: NSEvent.mouseLocation, in: nil)
    }
}

final class MenuActionTarget: NSObject {
    let block: () -> Void
    init(_ block: @escaping () -> Void) { self.block = block }
    @objc func run() { block() }
}

enum ColourFormatting {
    static func string(_ c: RGBAColour, format: ColourCopyFormat) -> String {
        switch format {
        case .hex: return c.hex
        case .rgb: return ColourMath.rgbString(c)
        case .hsl: return ColourMath.hslString(c)
        case .css: return ColourMath.cssRGB(c)
        }
    }
}
