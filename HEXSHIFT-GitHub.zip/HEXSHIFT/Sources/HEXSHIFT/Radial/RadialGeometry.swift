import AppKit
import CoreGraphics
import SwiftUI

/// Geometry of the wheel. All values are in points in a top-left-origin coordinate space
/// (SwiftUI), y growing downward, angles in degrees clockwise from +x.
///
/// Layout, from the centre out:
///   hexagon hub → gap → six equal slices → plate padding → round plate
///   → clearance → round ring of 30° tiles.
/// Each slice's inner edge is one flat side of the hub, its sides run along the radial
/// lines through the hub's corners and its outer edge is an arc, so all six slices are the
/// same shape turned about the centre. Every gap between neighbouring shapes is `gap` wide,
/// the ring sits the same distance from the plate all the way round, and ring tiles are
/// centred on the open slice, so the wheel is mirror-symmetric about that slice's axis.
struct RadialGeometry {
    var scale: CGFloat = 1

    var gap: CGFloat { 5 * scale }
    var centreApothem: CGFloat { 44 * scale }
    var centreCorner: CGFloat { 11 * scale }
    var primaryInner: CGFloat { centreApothem + gap }
    var primaryOuter: CGFloat { 136 * scale }
    var segmentCorner: CGFloat { 9 * scale }
    var platePadding: CGFloat { 8 * scale }
    var plateRadius: CGFloat { primaryOuter + platePadding }
    var ringClearance: CGFloat { 8 * scale }
    var ringInner: CGFloat { plateRadius + ringClearance }
    var ringOuter: CGFloat { ringInner + 68 * scale }
    var ringCorner: CGFloat { 9 * scale }
    /// Space kept between a label block and the edge of its shape.
    var labelPadding: CGFloat { 4.5 * scale }
    var margin: CGFloat { 22 * scale }

    var canvas: CGFloat { (2 * (ringOuter + margin)).rounded(.up) }
    var centre: CGPoint { CGPoint(x: canvas / 2, y: canvas / 2) }

    /// Every ring tile spans the same angle, whatever the number of items.
    static let ringTileAngle: CGFloat = 30
    static let maxRingItems = 10

    /// Direction (degrees) of the axis of slice `i` (0 = top, clockwise).
    static func primaryAngle(_ i: Int) -> CGFloat { -90 + 60 * CGFloat(i) }

    static func rad(_ deg: CGFloat) -> CGFloat { deg * .pi / 180 }

    static func normalise(_ deg: CGFloat) -> CGFloat {
        var d = deg.truncatingRemainder(dividingBy: 360)
        if d > 180 { d -= 360 }
        if d <= -180 { d += 360 }
        return d
    }

    func point(angle: CGFloat, radius: CGFloat) -> CGPoint {
        CGPoint(x: centre.x + radius * cos(Self.rad(angle)), y: centre.y + radius * sin(Self.rad(angle)))
    }

    /// Where a slice's label block is centred: halfway between the slice's inner edge and
    /// its outer edge on its axis, the same for all six slices. (This is also where a level
    /// label has the most room in the four side slices.)
    func primaryLabelPoint(_ i: Int) -> CGPoint {
        point(angle: Self.primaryAngle(i), radius: sliceLabelRadius)
    }

    var sliceLabelRadius: CGFloat { (primaryInner + primaryOuter) / 2 }

    // MARK: Ring layout

    /// Angular width (degrees) of each ring item.
    static func itemAngle(count n: Int) -> CGFloat { n > 0 ? ringTileAngle : 0 }

    func ringItemAngle(segment: Int, index: Int, count: Int) -> CGFloat {
        Self.primaryAngle(segment) + (CGFloat(index) - CGFloat(count - 1) / 2) * Self.ringTileAngle
    }

    func ringItemLabelPoint(segment: Int, index: Int, count: Int) -> CGPoint {
        point(angle: ringItemAngle(segment: segment, index: index, count: count), radius: (ringInner + ringOuter) / 2)
    }

    /// Full-circle ring used by the drag-to-convert wheel.
    func formatAngle(index: Int, count: Int) -> CGFloat {
        -90 + CGFloat(index) * 360 / CGFloat(max(1, count))
    }

    /// Recent / favourite chips sit in a straight row under the plate's flat bottom edge.
    var recentChipDiameter: CGFloat { 28 * scale }
    func recentChipCentre(index: Int, count: Int) -> CGPoint {
        let d = recentChipDiameter, spacing = 8 * scale
        let total = CGFloat(count) * d + CGFloat(max(0, count - 1)) * spacing
        return CGPoint(x: centre.x - total / 2 + d / 2 + CGFloat(index) * (d + spacing),
                       y: centre.y + plateRadius + ringClearance + d / 2)
    }

    // MARK: Outlines

    /// Outline of slice `i` as dense points (absolute coordinates), rounded corners included.
    /// Inner edge: the flat line `gap` outside the hub's side; sides: the radial lines through
    /// the hub's corners, pulled in by half a gap; outer edge: an arc of radius `primaryOuter`.
    func segmentOutline(_ i: Int) -> [CGPoint] {
        let phi = Self.primaryAngle(i)
        let u = unit(phi)
        let e1 = phi - 30, e2 = phi + 30
        let n1 = unit(e1 + 90), n2 = unit(e2 - 90)
        let h = gap / 2
        let a = Self.meet(u, primaryInner, n1, h)          // inner corner on the start side
        let d = Self.meet(u, primaryInner, n2, h)          // inner corner on the end side
        let sector = SectorGeometry(centre: .zero, inner: primaryInner, outer: primaryOuter,
                                    startAngle: e1, endAngle: e2, gap: gap, corner: segmentCorner)
        guard let f = sector.fillets else { return [] }
        let rc = sector.filletRadius
        var pts: [CGPoint] = []
        pts += lineFillet(corner: a, from: d, to: f.oA.onLine, radius: rc)
        pts.append(f.oA.onLine)
        pts += arcPoints(centre: f.oA.centre, radius: rc, from: f.oA.onLine, to: f.oA.onCircle)
        pts += arcPoints(centre: .zero, radius: primaryOuter, from: f.oA.onCircle, to: f.oB.onCircle)
        pts += arcPoints(centre: f.oB.centre, radius: rc, from: f.oB.onCircle, to: f.oB.onLine)
        pts += lineFillet(corner: d, from: f.oB.onLine, to: a, radius: rc)
        return pts.map { CGPoint(x: centre.x + $0.x, y: centre.y + $0.y) }
    }

    /// Points of a circular fillet of radius `rc` at the corner `p` of the path from → p → to.
    private func lineFillet(corner p: CGPoint, from a: CGPoint, to b: CGPoint, radius rc: CGFloat) -> [CGPoint] {
        func norm(_ v: CGPoint) -> CGPoint { let l = max(1e-9, hypot(v.x, v.y)); return CGPoint(x: v.x / l, y: v.y / l) }
        let u1 = norm(CGPoint(x: a.x - p.x, y: a.y - p.y)), u2 = norm(CGPoint(x: b.x - p.x, y: b.y - p.y))
        let theta = acos(max(-1, min(1, u1.x * u2.x + u1.y * u2.y)))
        guard theta > 1e-3 else { return [p] }
        let t = rc / tan(theta / 2)
        let t1 = CGPoint(x: p.x + u1.x * t, y: p.y + u1.y * t), t2 = CGPoint(x: p.x + u2.x * t, y: p.y + u2.y * t)
        let bis = norm(CGPoint(x: u1.x + u2.x, y: u1.y + u2.y))
        let c = CGPoint(x: p.x + bis.x * rc / sin(theta / 2), y: p.y + bis.y * rc / sin(theta / 2))
        return arcPoints(centre: c, radius: rc, from: t1, to: t2)
    }

    /// Dense outline of ring tile centred at `angle` (degrees).
    func ringTileOutline(angle: CGFloat) -> [CGPoint] {
        SectorGeometry(centre: centre, inner: ringInner, outer: ringOuter,
                       startAngle: angle - Self.ringTileAngle / 2, endAngle: angle + Self.ringTileAngle / 2,
                       gap: gap, corner: ringCorner).outlinePoints()
    }

    /// Half the width of the centre hexagon at vertical offset `dy` from its middle.
    func centreHalfWidth(atOffset dy: CGFloat) -> CGFloat {
        let r = centreApothem / cos(.pi / 6)
        return max(0, r - abs(dy) * tan(.pi / 6))
    }

    private func unit(_ deg: CGFloat) -> CGPoint { CGPoint(x: cos(Self.rad(deg)), y: sin(Self.rad(deg))) }

    /// Intersection of the lines p·n1 = c1 and p·n2 = c2 (relative to the centre).
    static func meet(_ n1: CGPoint, _ c1: CGFloat, _ n2: CGPoint, _ c2: CGFloat) -> CGPoint {
        let det = n1.x * n2.y - n1.y * n2.x
        return CGPoint(x: (c1 * n2.y - n1.y * c2) / det, y: (n1.x * c2 - c1 * n2.x) / det)
    }

    // MARK: Hit testing

    enum Region: Equatable {
        case centre
        case primary(Int)
        case ring(Int)
        case gap
        case outside
    }

    func region(at p: CGPoint, openSegment: Int?, ringCount: Int) -> Region {
        let dx = p.x - centre.x, dy = p.y - centre.y
        let r = (dx * dx + dy * dy).squareRoot()
        let angle = atan2(dy, dx) * 180 / .pi
        // Which hexagon edge normal are we nearest to?
        let k = Int(((angle + 90) / 60).rounded()).mod(6)
        let hexDistance = r * cos(Self.rad(Self.normalise(angle - Self.primaryAngle(k))))
        if hexDistance < primaryInner - gap / 2 { return .centre }
        if r <= plateRadius { return .primary(k) }
        if let seg = openSegment, ringCount > 0, r >= ringInner - gap, r <= ringOuter + 12 * scale {
            let w = Self.ringTileAngle
            let delta = Self.normalise(angle - Self.primaryAngle(seg))
            let idx = Int(floor(delta / w + CGFloat(ringCount) / 2))
            if idx >= 0 && idx < ringCount { return .ring(idx) }
        }
        if r > ringOuter + margin { return .outside }
        return .gap
    }

    func formatIndex(at p: CGPoint, count: Int, innerRadius: CGFloat, outerRadius: CGFloat) -> Int? {
        let dx = p.x - centre.x, dy = p.y - centre.y
        let r = (dx * dx + dy * dy).squareRoot()
        guard count > 0, r >= innerRadius - 4, r <= outerRadius + 24 else { return nil }
        let w = 360 / CGFloat(count)
        var a = atan2(dy, dx) * 180 / .pi + 90 + w / 2
        a = a.truncatingRemainder(dividingBy: 360)
        if a < 0 { a += 360 }
        return Int(a / w) % count
    }
}

extension Int {
    func mod(_ n: Int) -> Int { ((self % n) + n) % n }
}

// MARK: - Shapes

/// Polygon with rounded corners (tangent arcs).
func roundedPolygon(_ pts: [CGPoint], radius: CGFloat, corners: Set<Int>? = nil) -> Path {
    var path = Path()
    guard pts.count >= 3 else { return path }
    let n = pts.count
    let start = CGPoint(x: (pts[n - 1].x + pts[0].x) / 2, y: (pts[n - 1].y + pts[0].y) / 2)
    path.move(to: start)
    for i in 0..<n {
        let p = pts[i], next = pts[(i + 1) % n]
        if corners == nil || corners!.contains(i) {
            path.addArc(tangent1End: p, tangent2End: next, radius: radius)
        } else {
            path.addLine(to: p)
        }
    }
    path.closeSubpath()
    return path
}

/// The same rounded polygon as `roundedPolygon`, as a dense list of outline points.
func roundedPolygonPoints(_ pts: [CGPoint], radius rc: CGFloat) -> [CGPoint] {
    var out: [CGPoint] = []
    let n = pts.count
    guard n >= 3 else { return pts }
    for i in 0..<n {
        let p = pts[i], a = pts[(i + n - 1) % n], b = pts[(i + 1) % n]
        let u1 = normalised(CGPoint(x: a.x - p.x, y: a.y - p.y)), u2 = normalised(CGPoint(x: b.x - p.x, y: b.y - p.y))
        let theta = acos(max(-1, min(1, u1.x * u2.x + u1.y * u2.y)))
        let t = rc / tan(theta / 2)
        let t1 = CGPoint(x: p.x + u1.x * t, y: p.y + u1.y * t), t2 = CGPoint(x: p.x + u2.x * t, y: p.y + u2.y * t)
        let bis = normalised(CGPoint(x: u1.x + u2.x, y: u1.y + u2.y))
        let c = CGPoint(x: p.x + bis.x * rc / sin(theta / 2), y: p.y + bis.y * rc / sin(theta / 2))
        out.append(contentsOf: arcPoints(centre: c, radius: rc, from: t1, to: t2))
    }
    return out
}

private func normalised(_ v: CGPoint) -> CGPoint {
    let l = max(1e-9, (v.x * v.x + v.y * v.y).squareRoot())
    return CGPoint(x: v.x / l, y: v.y / l)
}

/// Points along the shorter arc of a circle between two points on it.
func arcPoints(centre c: CGPoint, radius r: CGFloat, from p0: CGPoint, to p1: CGPoint) -> [CGPoint] {
    let a0 = atan2(p0.y - c.y, p0.x - c.x)
    var d = atan2(p1.y - c.y, p1.x - c.x) - a0
    while d > .pi { d -= 2 * .pi }
    while d < -.pi { d += 2 * .pi }
    let steps = max(2, Int(abs(d) / (.pi / 45)))
    return (0...steps).map { k in
        let a = a0 + d * CGFloat(k) / CGFloat(steps)
        return CGPoint(x: c.x + r * cos(a), y: c.y + r * sin(a))
    }
}

/// One slice of the wheel (see `RadialGeometry.segmentOutline`).
struct HexSegmentShape: Shape {
    let index: Int
    let geometry: RadialGeometry

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let pts = geometry.segmentOutline(index)
        guard let first = pts.first else { return path }
        path.move(to: first)
        path.addLines(Array(pts.dropFirst()))
        path.closeSubpath()
        return path
    }
}

/// Rounded hexagon (flat top) centred in the canvas.
struct HexagonShape: Shape {
    let apothem: CGFloat
    let centre: CGPoint
    var corner: CGFloat = 10

    func path(in rect: CGRect) -> Path {
        let r = apothem / cos(.pi / 6)
        let pts = (0..<6).map { i -> CGPoint in
            let a = CGFloat(i) * .pi / 3
            return CGPoint(x: centre.x + r * cos(a), y: centre.y + r * sin(a))
        }
        return roundedPolygon(pts, radius: corner)
    }
}

/// Geometry of one annular-sector tile: straight sides kept `gap / 2` from its radial edges
/// (so the gap between neighbouring tiles has the same width all the way out) and true
/// circular fillets at all four corners. Plain value type, usable off the main actor.
struct SectorGeometry {
    let centre: CGPoint
    let inner: CGFloat
    let outer: CGFloat
    /// Degrees, clockwise from +x.
    let startAngle: CGFloat
    let endAngle: CGFloat
    var gap: CGFloat = 5
    var corner: CGFloat = 10

    struct Fillet {
        let centre: CGPoint      // relative to the ring centre
        let onCircle: CGPoint
        let onLine: CGPoint
    }

    private func fillet(edge deg: CGFloat, inward: CGFloat, radius big: CGFloat, outerArc: Bool, rc: CGFloat) -> Fillet {
        let d = CGPoint(x: cos(RadialGeometry.rad(deg)), y: sin(RadialGeometry.rad(deg)))
        let n = CGPoint(x: cos(RadialGeometry.rad(deg + inward)), y: sin(RadialGeometry.rad(deg + inward)))
        let off = gap / 2 + rc
        let dist = outerArc ? big - rc : big + rc
        let s = max(0, dist * dist - off * off).squareRoot()
        let c = CGPoint(x: n.x * off + d.x * s, y: n.y * off + d.y * s)
        let len = max(1e-9, (c.x * c.x + c.y * c.y).squareRoot())
        return Fillet(centre: c, onCircle: CGPoint(x: c.x * big / len, y: c.y * big / len),
                      onLine: CGPoint(x: c.x - n.x * rc, y: c.y - n.y * rc))
    }

    /// Fillet radius actually used (never more than the tile can spare).
    var filletRadius: CGFloat {
        let arcAtInner = RadialGeometry.rad(endAngle - startAngle) * inner - gap
        return max(0, min(corner, (outer - inner) / 2 - 0.5, arcAtInner / 2 - 0.5))
    }

    /// Outer-start, outer-end, inner-start, inner-end fillets.
    var fillets: (oA: Fillet, oB: Fillet, iA: Fillet, iB: Fillet)? {
        guard endAngle > startAngle, outer > inner else { return nil }
        let rc = filletRadius
        return (fillet(edge: startAngle, inward: 90, radius: outer, outerArc: true, rc: rc),
                fillet(edge: endAngle, inward: -90, radius: outer, outerArc: true, rc: rc),
                fillet(edge: startAngle, inward: 90, radius: inner, outerArc: false, rc: rc),
                fillet(edge: endAngle, inward: -90, radius: inner, outerArc: false, rc: rc))
    }

    func absolute(_ p: CGPoint) -> CGPoint { CGPoint(x: centre.x + p.x, y: centre.y + p.y) }

    /// The outline as dense points (absolute coordinates), for label fitting.
    func outlinePoints() -> [CGPoint] {
        guard let f = fillets else { return [] }
        let rc = filletRadius
        let o = CGPoint.zero
        var pts: [CGPoint] = [f.iA.onLine, f.oA.onLine]
        pts += arcPoints(centre: f.oA.centre, radius: rc, from: f.oA.onLine, to: f.oA.onCircle)
        pts += arcPoints(centre: o, radius: outer, from: f.oA.onCircle, to: f.oB.onCircle)
        pts += arcPoints(centre: f.oB.centre, radius: rc, from: f.oB.onCircle, to: f.oB.onLine)
        pts.append(f.iB.onLine)
        pts += arcPoints(centre: f.iB.centre, radius: rc, from: f.iB.onLine, to: f.iB.onCircle)
        pts += arcPoints(centre: o, radius: inner, from: f.iB.onCircle, to: f.iA.onCircle)
        pts += arcPoints(centre: f.iA.centre, radius: rc, from: f.iA.onCircle, to: f.iA.onLine)
        return pts.map(absolute)
    }
}

/// A ring tile drawn from `SectorGeometry`.
struct RingSectorShape: Shape {
    let centre: CGPoint
    let inner: CGFloat
    let outer: CGFloat
    /// Degrees, clockwise from +x.
    let startAngle: CGFloat
    let endAngle: CGFloat
    var gap: CGFloat = 5
    var corner: CGFloat = 10

    private var sector: SectorGeometry {
        SectorGeometry(centre: centre, inner: inner, outer: outer, startAngle: startAngle, endAngle: endAngle, gap: gap, corner: corner)
    }

    private func angle(_ p: CGPoint) -> Angle { .radians(Double(atan2(p.y, p.x))) }

    /// Adds the shorter arc around `c` (relative coordinates) from `p0` to `p1`.
    /// (`clockwise: false` makes the angle increase, whatever the coordinate system.)
    private func addFillet(_ path: inout Path, _ sg: SectorGeometry, around c: CGPoint, radius rc: CGFloat,
                           from p0: CGPoint, to p1: CGPoint) {
        let a0 = atan2(p0.y - c.y, p0.x - c.x)
        var d = atan2(p1.y - c.y, p1.x - c.x) - a0
        while d > .pi { d -= 2 * .pi }
        while d < -.pi { d += 2 * .pi }
        path.addArc(center: sg.absolute(c), radius: rc, startAngle: .radians(Double(a0)), endAngle: .radians(Double(a0 + d)),
                    clockwise: d < 0)
    }

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let sg = sector
        guard let f = sg.fillets else { return path }
        let rc = sg.filletRadius
        path.move(to: sg.absolute(f.iA.onLine))
        path.addLine(to: sg.absolute(f.oA.onLine))
        addFillet(&path, sg, around: f.oA.centre, radius: rc, from: f.oA.onLine, to: f.oA.onCircle)
        // Outer edge runs with increasing angle, the inner edge back with decreasing angle.
        path.addArc(center: centre, radius: outer, startAngle: angle(f.oA.onCircle), endAngle: angle(f.oB.onCircle), clockwise: false)
        addFillet(&path, sg, around: f.oB.centre, radius: rc, from: f.oB.onCircle, to: f.oB.onLine)
        path.addLine(to: sg.absolute(f.iB.onLine))
        addFillet(&path, sg, around: f.iB.centre, radius: rc, from: f.iB.onLine, to: f.iB.onCircle)
        path.addArc(center: centre, radius: inner, startAngle: angle(f.iB.onCircle), endAngle: angle(f.iA.onCircle), clockwise: true)
        addFillet(&path, sg, around: f.iA.centre, radius: rc, from: f.iA.onCircle, to: f.iA.onLine)
        path.closeSubpath()
        return path
    }
}
