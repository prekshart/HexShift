import AppKit
import SwiftUI

/// Measures text and fits label blocks inside the wheel's shapes, so every label is
/// guaranteed to sit fully inside its tile with the same padding on all sides.
enum TextMetrics {
    static func font(_ size: CGFloat, _ weight: NSFont.Weight) -> NSFont { NSFont.systemFont(ofSize: size, weight: weight) }

    static func width(_ s: String, size: CGFloat, weight: NSFont.Weight = .semibold) -> CGFloat {
        ceil((s as NSString).size(withAttributes: [.font: font(size, weight)]).width)
    }

    /// Line height SwiftUI uses for the system font at this size.
    static func lineHeight(_ size: CGFloat, _ weight: NSFont.Weight = .semibold) -> CGFloat {
        let f = font(size, weight)
        return ceil(f.ascender - f.descender + f.leading)
    }

    /// Shortens `s` with an ellipsis until it fits `maxWidth`.
    static func truncate(_ s: String, to maxWidth: CGFloat, size: CGFloat, weight: NSFont.Weight = .semibold) -> String {
        if width(s, size: size, weight: weight) <= maxWidth { return s }
        var chars = Array(s)
        while !chars.isEmpty {
            chars.removeLast()
            let candidate = String(chars).trimmingCharacters(in: .whitespaces) + "…"
            if width(candidate, size: size, weight: weight) <= maxWidth { return candidate }
        }
        return "…"
    }

    /// Shortens `s` in the middle (keeps the start and the extension of a file name).
    static func truncateMiddle(_ s: String, to maxWidth: CGFloat, size: CGFloat, weight: NSFont.Weight = .semibold) -> String {
        if width(s, size: size, weight: weight) <= maxWidth { return s }
        let chars = Array(s)
        var keep = chars.count - 1
        while keep > 1 {
            let head = keep - keep / 2, tail = keep / 2
            let candidate = String(chars[..<head]) + "…" + String(chars[(chars.count - tail)...])
            if width(candidate, size: size, weight: weight) <= maxWidth { return candidate }
            keep -= 1
        }
        return "…"
    }

    /// Wraps a "part · part · part" string so line breaks fall between parts and no line
    /// starts or ends with the separator. Falls back to word wrapping if a part is too wide.
    static func wrapParts(_ s: String, widths: [CGFloat], maxLines: Int, size: CGFloat, weight: NSFont.Weight) -> [String] {
        let sep = " · "
        let parts = s.components(separatedBy: sep)
        func limit(_ line: Int) -> CGFloat { widths.isEmpty ? .greatestFiniteMagnitude : widths[min(line, widths.count - 1)] }
        if parts.count > 1 {
            var lines: [String] = []
            var current = ""
            var ok = true
            for part in parts {
                let candidate = current.isEmpty ? part : current + sep + part
                if width(candidate, size: size, weight: weight) <= limit(lines.count) { current = candidate; continue }
                if current.isEmpty || width(part, size: size, weight: weight) > limit(lines.count + 1) { ok = false; break }
                lines.append(current)
                current = part
            }
            if ok {
                if !current.isEmpty { lines.append(current) }
                if lines.count <= maxLines { return lines }
                var kept = Array(lines.prefix(maxLines))
                kept[maxLines - 1] = truncate(kept[maxLines - 1] + sep + lines[maxLines...].joined(separator: sep),
                                              to: limit(maxLines - 1), size: size, weight: weight)
                return kept
            }
        }
        return wrap(s, widths: widths, maxLines: maxLines, size: size, weight: weight, truncateLast: true) ?? [s]
    }

    /// Greedy word wrap where line `k` may use `widths[k]` (the last width repeats).
    /// Returns nil if a single word is wider than its line or more lines are needed than `maxLines`
    /// (unless `truncateLast`, in which case the last line is shortened with an ellipsis).
    static func wrap(_ s: String, widths: [CGFloat], maxLines: Int, size: CGFloat,
                     weight: NSFont.Weight, truncateLast: Bool) -> [String]? {
        let words = s.split(separator: " ", omittingEmptySubsequences: true).map(String.init)
        guard !words.isEmpty, maxLines > 0 else { return [] }
        func limit(_ line: Int) -> CGFloat { widths.isEmpty ? .greatestFiniteMagnitude : widths[min(line, widths.count - 1)] }
        var lines: [String] = []
        var current = ""
        var i = 0
        while i < words.count {
            let maxW = limit(lines.count)
            let candidate = current.isEmpty ? words[i] : current + " " + words[i]
            if width(candidate, size: size, weight: weight) <= maxW {
                current = candidate
                i += 1
                continue
            }
            if current.isEmpty {
                // A single word wider than the line.
                guard truncateLast else { return nil }
                current = truncate(words[i], to: maxW, size: size, weight: weight)
                i += 1
            }
            if lines.count == maxLines - 1 {
                // Last allowed line: whatever is left has to go here.
                guard truncateLast else { return nil }
                let rest = ([current] + words[i...]).joined(separator: " ")
                lines.append(truncate(rest, to: maxW, size: size, weight: weight))
                return lines
            }
            lines.append(current)
            current = ""
        }
        if !current.isEmpty { lines.append(current) }
        return lines
    }
}

enum LabelFit {
    private static func inside(_ poly: [CGPoint], _ p: CGPoint) -> Bool {
        var c = false
        var j = poly.count - 1
        for i in 0..<poly.count {
            let a = poly[i], b = poly[j]
            if (a.y > p.y) != (b.y > p.y), p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x { c.toggle() }
            j = i
        }
        return c
    }

    private static func distance(_ poly: [CGPoint], _ p: CGPoint) -> CGFloat {
        var m = CGFloat.greatestFiniteMagnitude
        for i in 0..<poly.count {
            let a = poly[i], b = poly[(i + 1) % poly.count]
            let abx = b.x - a.x, aby = b.y - a.y
            let t = max(0, min(1, ((p.x - a.x) * abx + (p.y - a.y) * aby) / max(1e-9, abx * abx + aby * aby)))
            let dx = p.x - (a.x + abx * t), dy = p.y - (a.y + aby * t)
            m = min(m, (dx * dx + dy * dy).squareRoot())
        }
        return m
    }

    /// Widest horizontal box of height `height`, centred at `centre`, that stays at least `pad`
    /// inside `outline` (a closed list of points; need not be convex).
    static func width(outline: [CGPoint], centre: CGPoint, height: CGFloat, pad: CGFloat) -> CGFloat {
        guard outline.count >= 3 else { return 0 }
        func fits(_ w: CGFloat) -> Bool {
            let steps = 6
            for s in 0...steps {
                let f = CGFloat(s) / CGFloat(steps)
                let probes = [CGPoint(x: -w / 2 + w * f, y: -height / 2), CGPoint(x: -w / 2 + w * f, y: height / 2),
                              CGPoint(x: -w / 2, y: -height / 2 + height * f), CGPoint(x: w / 2, y: -height / 2 + height * f)]
                for q in probes {
                    let p = CGPoint(x: centre.x + q.x, y: centre.y + q.y)
                    if !inside(outline, p) || distance(outline, p) < pad { return false }
                }
            }
            return true
        }
        guard fits(0) else { return 0 }
        var lo: CGFloat = 0, hi: CGFloat = 320
        for _ in 0..<14 {
            let mid = (lo + hi) / 2
            if fits(mid) { lo = mid } else { hi = mid }
        }
        return floor(lo)
    }
}

// MARK: - Primary segment labels

struct PrimaryLabelLayout {
    let fontSize: CGFloat
    let iconSize: CGFloat
    let spacing: CGFloat
}

// MARK: - Ring labels

struct RingItemLayout {
    let angle: CGFloat
    let centre: CGPoint
    /// Label text with explicit line breaks; rendered without further wrapping.
    let text: String
    let lineCount: Int
    let textWidth: CGFloat
}

struct RingLayout {
    let fontSize: CGFloat
    let iconSize: CGFloat
    let spacing: CGFloat
    let items: [RingItemLayout]
}

@MainActor
enum WheelLayout {
    /// Shorter labels used in the ring only when the full title doesn't fit its tile.
    /// The full title (and a description) always shows in the centre on hover.
    static let ringShortTitles: [String: String] = [
        "edit.scales": "@1x–3x",
        "type.browse": "Fonts",
        "capture.edit": "Edit Shot",
        "pdf.stripMeta": "Clean Meta",
        "batch.compress": "Compress",
        "capture.research": "Research",
        "designer.tools": "Designer",
        "type.inspectSelection": "Font Info",
        "more.browseEdit": "Open…",
        "pdf.pageNumbers": "Page No.",
        "media.reduce": "Shrink",
        "pdf.searchableImage": "OCR PDF",
        "type.graphic": "Graphic",
        "inspect.transparency": "Alpha",
        "text.upper": "UPPER",
        "text.lower": "lower",
        "pdf.mergeBrowse": "Merge…",
        "pdf.imagesBrowse": "To PDF…",
        "batch.stripGPS": "No GPS",
        "type.fontsInFile": "Fonts",
        "colour.lens": "Lens",
        "doc.stats": "Words",
    ]
    static let ringShortByTitle: [String: String] = [
        "Images → PDF": "To PDF",
        "Merge PDF": "Merge",
        "Specimen PNG": "Spec PNG",
        "Specimen PDF": "Spec PDF",
        // Built-in workflows (user-named workflows fall back to automatic shortening).
        "Social Media Export": "Social Export",
        "Transparent Asset": "Cut-out Asset",
        "PDF Optimiser": "Slim PDF",
    ]

    /// For the smoke test: why a ring could not use `size` (label, width needed, width available).
    static func ringDiagnostics(_ g: RadialGeometry, segment: Int, actions: [RadialAction], size: CGFloat) -> [String] {
        let n = actions.count
        let s = g.scale
        return (0..<n).compactMap { i -> String? in
            let a = actions[i]
            let angle = g.ringItemAngle(segment: segment, index: i, count: n)
            let outline = g.ringTileOutline(angle: angle)
            let c = g.ringItemLabelPoint(segment: segment, index: i, count: n)
            let extra: CGFloat = a.badge == nil ? 0 : 14 * s
            let w1 = LabelFit.width(outline: outline, centre: c, height: 14 * s + 2 * s + TextMetrics.lineHeight(size) + extra, pad: g.labelPadding)
            let w2 = LabelFit.width(outline: outline, centre: c, height: 14 * s + 2 * s + 2 * TextMetrics.lineHeight(size) + extra, pad: g.labelPadding)
            let label = ringShortTitles[a.id] ?? ringShortByTitle[a.title] ?? a.title
            let need = TextMetrics.width(label, size: size)
            if need <= w1 || balancedTwoLines(label, width: w2, size: size) != nil { return nil }
            return "\(label) needs \(Int(need)) has \(Int(w1))/\(Int(w2)) at \(Int(angle))°"
        }
    }

    private static var primaryCache: [String: PrimaryLabelLayout] = [:]
    private static var ringCache: [String: RingLayout] = [:]

    /// One font size for all six segment labels: the largest at which every label fits.
    static func primary(_ g: RadialGeometry, titles: [String]) -> PrimaryLabelLayout {
        let key = "\(g.scale)|" + titles.joined(separator: "|")
        if let hit = primaryCache[key] { return hit }
        let s = g.scale
        let icon = 17 * s, spacing = 2 * s
        var chosen = PrimaryLabelLayout(fontSize: 10.5 * s, iconSize: icon, spacing: spacing)
        for size in [13, 12.5, 12, 11.5, 11, 10.5].map({ CGFloat($0) * s }) {
            let h = icon + spacing + TextMetrics.lineHeight(size)
            let ok = titles.enumerated().allSatisfy { i, t in
                let w = LabelFit.width(outline: g.segmentOutline(i), centre: g.primaryLabelPoint(i), height: h, pad: g.labelPadding)
                return TextMetrics.width(t, size: size) <= w
            }
            if ok { chosen = PrimaryLabelLayout(fontSize: size, iconSize: icon, spacing: spacing); break }
        }
        primaryCache[key] = chosen
        return chosen
    }

    /// Lays out every tile of the ring opened from `segment`. All tiles share one font size.
    static func ring(_ g: RadialGeometry, segment: Int, actions: [RadialAction]) -> RingLayout {
        let key = "\(g.scale)|\(segment)|" + actions.map { "\($0.id)~\($0.title)~\($0.badge ?? "")" }.joined(separator: "|")
        if let hit = ringCache[key] { return hit }
        let s = g.scale
        let icon = 16 * s, spacing = 2 * s
        let n = actions.count
        let angles = (0..<n).map { g.ringItemAngle(segment: segment, index: $0, count: n) }
        let centres = (0..<n).map { g.ringItemLabelPoint(segment: segment, index: $0, count: n) }
        let outlines = angles.map { g.ringTileOutline(angle: $0) }
        let badgeHeight = 12 * s + 2 * s

        func fitWidth(_ i: Int, lines: Int, size: CGFloat) -> CGFloat {
            let h = icon + spacing + CGFloat(lines) * TextMetrics.lineHeight(size) + (actions[i].badge == nil ? 0 : badgeHeight)
            return LabelFit.width(outline: outlines[i], centre: centres[i], height: h, pad: g.labelPadding)
        }

        func attempt(_ i: Int, size: CGFloat, allowTruncation: Bool) -> RingItemLayout? {
            let a = actions[i]
            var candidates = [a.title]
            if let short = ringShortTitles[a.id] ?? ringShortByTitle[a.title], short != a.title { candidates.append(short) }
            let w1 = fitWidth(i, lines: 1, size: size)
            let w2 = fitWidth(i, lines: 2, size: size)
            for c in candidates {
                if TextMetrics.width(c, size: size) <= w1 {
                    return RingItemLayout(angle: angles[i], centre: centres[i], text: c, lineCount: 1, textWidth: w1)
                }
                if let lines = balancedTwoLines(c, width: w2, size: size) {
                    return RingItemLayout(angle: angles[i], centre: centres[i], text: lines.joined(separator: "\n"), lineCount: 2, textWidth: w2)
                }
            }
            guard allowTruncation else { return nil }
            let c = candidates.last ?? a.title
            let lines = TextMetrics.wrap(c, widths: [w2], maxLines: 2, size: size, weight: .semibold, truncateLast: true)
                ?? [TextMetrics.truncate(c, to: w1, size: size)]
            return RingItemLayout(angle: angles[i], centre: centres[i], text: lines.joined(separator: "\n"),
                                  lineCount: max(1, lines.count), textWidth: lines.count > 1 ? w2 : w1)
        }

        let sizes = [12, 11.5, 11, 10.5, 10, 9.5].map { CGFloat($0) * s }
        var result: RingLayout?
        for size in sizes {
            let items = (0..<n).map { attempt($0, size: size, allowTruncation: false) }
            if items.allSatisfy({ $0 != nil }) {
                result = RingLayout(fontSize: size, iconSize: icon, spacing: spacing, items: items.compactMap { $0 })
                break
            }
        }
        if result == nil {
            // Something is too long even at the smallest size: keep that size for the whole
            // ring (consistency) and shorten only the labels that don't fit.
            let size = sizes[sizes.count - 1]
            result = RingLayout(fontSize: size, iconSize: icon, spacing: spacing,
                                items: (0..<n).map { attempt($0, size: size, allowTruncation: true)! })
        }
        ringCache[key] = result!
        if ringCache.count > 200 { ringCache.removeAll() }
        return result!
    }

    private static var formatCache: [String: (CGFloat, [String])] = [:]

    /// Labels for the drag-to-convert wheel: one bold size for every tile, the largest that fits.
    static func formatRing(scale s: CGFloat, centre: CGPoint, inner: CGFloat, outer: CGFloat, gap: CGFloat, corner: CGFloat,
                           labels: [String], notes: [Bool], pad: CGFloat) -> (fontSize: CGFloat, texts: [String]) {
        let key = "\(s)|\(inner)|\(outer)|" + zip(labels, notes).map { "\($0)\($1)" }.joined(separator: "|")
        if let hit = formatCache[key] { return hit }
        let n = labels.count
        guard n > 0 else { return (13 * s, []) }
        let w = 360 / CGFloat(n)
        let outlines = (0..<n).map { i -> [CGPoint] in
            let mid = -90 + CGFloat(i) * w
            return SectorGeometry(centre: centre, inner: inner, outer: outer, startAngle: mid - w / 2, endAngle: mid + w / 2,
                                  gap: gap, corner: corner).outlinePoints()
        }
        let mids = (0..<n).map { i -> CGPoint in
            let a = RadialGeometry.rad(-90 + CGFloat(i) * w), r = (inner + outer) / 2
            return CGPoint(x: centre.x + r * cos(a), y: centre.y + r * sin(a))
        }
        let noteHeight = 11 * s
        var result: (CGFloat, [String])?
        for size in [13, 12, 11, 10].map({ CGFloat($0) * s }) {
            var texts: [String] = []
            var ok = true
            for i in 0..<n {
                let extra = notes[i] ? noteHeight : 0
                let w1 = LabelFit.width(outline: outlines[i], centre: mids[i], height: TextMetrics.lineHeight(size, .bold) + extra, pad: pad)
                if TextMetrics.width(labels[i], size: size, weight: .bold) <= w1 { texts.append(labels[i]); continue }
                let w2 = LabelFit.width(outline: outlines[i], centre: mids[i], height: 2 * TextMetrics.lineHeight(size, .bold) + extra, pad: pad)
                let words = labels[i].split(separator: " ").map(String.init)
                if words.count >= 2, words.allSatisfy({ TextMetrics.width($0, size: size, weight: .bold) <= w2 }),
                   let lines = TextMetrics.wrap(labels[i], widths: [w2], maxLines: 2, size: size, weight: .bold, truncateLast: false) {
                    texts.append(lines.joined(separator: "\n")); continue
                }
                ok = false
                texts.append(TextMetrics.truncate(labels[i], to: w1, size: size, weight: .bold))
            }
            result = (size, texts)
            if ok { break }
        }
        formatCache[key] = result!
        return result!
    }

    /// Splits a multi-word label over two lines as evenly as possible, if both lines fit.
    static func balancedTwoLines(_ s: String, width: CGFloat, size: CGFloat) -> [String]? {
        let words = s.split(separator: " ").map(String.init)
        guard words.count >= 2 else { return nil }
        var best: (CGFloat, [String])?
        for k in 1..<words.count {
            let a = words[..<k].joined(separator: " "), b = words[k...].joined(separator: " ")
            let m = max(TextMetrics.width(a, size: size), TextMetrics.width(b, size: size))
            if m <= width, best == nil || m < best!.0 { best = (m, [a, b]) }
        }
        return best?.1
    }
}

// MARK: - Centre hexagon text

/// Text laid out line by line inside the centre hexagon, each line as wide as the hexagon
/// allows at its height.
struct CentreText {
    struct Line: Identifiable {
        let id: Int
        let text: String
        let size: CGFloat
        let weight: NSFont.Weight
        let isTitle: Bool
        let y: CGFloat          // centre of the line, relative to the hexagon's centre
    }
    let lines: [Line]
    let imageY: CGFloat?         // centre of the image/icon, if any
    let imageSize: CGFloat

    static func layout(_ g: RadialGeometry, imageSize: CGFloat?, title: String, titleSize: CGFloat, titleLines: Int = 1,
                       truncateTitleInMiddle: Bool = false,
                       subtitle: String?, subtitleSize: CGFloat, subtitleLines: Int = 2,
                       apothem: CGFloat? = nil) -> CentreText {
        let pad = g.labelPadding + 3 * g.scale
        let hexRadius = (apothem ?? g.centreApothem) / cos(.pi / 6)
        func halfWidth(_ dy: CGFloat) -> CGFloat { max(0, hexRadius - abs(dy) * tan(.pi / 6)) }
        let gapAfterImage = 5 * g.scale, gapAfterTitle = 3 * g.scale
        let th = TextMetrics.lineHeight(titleSize), sh = TextMetrics.lineHeight(subtitleSize, .regular)
        var tLines = [title], sLines = subtitle.map { [$0] } ?? []
        var result = CentreText(lines: [], imageY: nil, imageSize: imageSize ?? 0)
        // Two passes: positions depend on the line counts, widths depend on the positions.
        for _ in 0..<3 {
            let imageBlock = imageSize.map { $0 + gapAfterImage } ?? 0
            let total = imageBlock + CGFloat(tLines.count) * th + (sLines.isEmpty ? 0 : gapAfterTitle + CGFloat(sLines.count) * sh)
            var y = -total / 2
            let imageY: CGFloat? = imageSize.map { y + $0 / 2 }
            y += imageBlock
            func width(top: CGFloat, height: CGFloat) -> CGFloat {
                2 * min(halfWidth(top), halfWidth(top + height)) - 2 * pad
            }
            let tWidths = (0..<titleLines).map { k in width(top: y + CGFloat(k) * th, height: th) }
            let newT = truncateTitleInMiddle
                ? [TextMetrics.truncateMiddle(title, to: tWidths[0], size: titleSize)]
                : (TextMetrics.wrap(title, widths: tWidths, maxLines: titleLines, size: titleSize, weight: .semibold, truncateLast: true) ?? [title])
            var lines: [Line] = []
            for t in newT {
                lines.append(Line(id: lines.count, text: t, size: titleSize, weight: .semibold, isTitle: true, y: y + th / 2))
                y += th
            }
            var newS: [String] = []
            if let subtitle, !subtitle.isEmpty {
                y += gapAfterTitle
                let sWidths = (0..<subtitleLines).map { k in width(top: y + CGFloat(k) * sh, height: sh) }
                newS = TextMetrics.wrapParts(subtitle, widths: sWidths, maxLines: subtitleLines, size: subtitleSize, weight: .regular)
                for t in newS {
                    lines.append(Line(id: lines.count, text: t, size: subtitleSize, weight: .regular, isTitle: false, y: y + sh / 2))
                    y += sh
                }
            }
            result = CentreText(lines: lines, imageY: imageY, imageSize: imageSize ?? 0)
            if newT.count == tLines.count && newS.count == sLines.count { break }
            tLines = newT
            sLines = newS
        }
        return result
    }
}
