import AppKit
import Combine
import HexshiftKit
import QuickLookThumbnailing
import SwiftUI

@MainActor
final class RadialMenuModel: ObservableObject {
    @Published private(set) var context: RadialContext = .empty
    @Published private(set) var segments: [PrimarySegment: [RadialAction]] = [:]
    @Published private(set) var order: [PrimarySegment] = PrimarySegment.allCases
    @Published var hoveredPrimary: Int?
    @Published var openPrimary: Int?
    @Published var hoveredRing: Int?
    @Published var keyboardRingIndex: Int?
    @Published var hoveredRecent: String?
    @Published var thumbnail: NSImage?
    @Published var isShown = false
    @Published var geometry = RadialGeometry()
    /// Small message shown when the pointer rests on a slice ("Capture · press 6") or on a
    /// greyed-out action (why it's unavailable).
    @Published private(set) var tip: WheelTip?
    /// Settings / onboarding previews: no invisible hit area behind the wheel.
    var isPreview = false

    var onPerform: ((RadialAction) -> Void)?
    var onDismiss: (() -> Void)?

    private var openTask: Task<Void, Never>?
    private var tipTask: Task<Void, Never>?
    private var tipKey: String?
    private var pointer: CGPoint = .zero
    private var lastHapticRegion: String?

    // MARK: Setup

    func configure(context: RadialContext, state: AppState) {
        self.context = context
        segments = ActionCatalog.build(for: context, state: state).mapValues { list in
            list.map { action in
                var a = action
                if a.badge == nil, state.isFavourite(a.id) { a.badge = "★" }
                return a
            }
        }
        order = state.prefs.segmentOrder.count == 6 ? state.prefs.segmentOrder : PrimarySegment.allCases
        geometry = RadialGeometry(scale: state.prefs.wheelSize.scale)
        hoveredPrimary = nil
        hoveredRing = nil
        keyboardRingIndex = nil
        openPrimary = nil
        thumbnail = nil
        clearTip()
        loadThumbnail()
    }

    func actions(forPrimary i: Int) -> [RadialAction] {
        guard i >= 0, i < order.count else { return [] }
        return segments[order[i]] ?? []
    }

    func segment(_ i: Int) -> PrimarySegment { order[i] }

    func isEnabled(_ i: Int) -> Bool { actions(forPrimary: i).contains { $0.enabled } }

    var openActions: [RadialAction] { openPrimary.map { actions(forPrimary: $0) } ?? [] }

    /// Quick buttons under the wheel: favourites first, then most-used actions — only the ones
    /// that apply to what's selected.
    func quickActions(_ state: AppState) -> [(action: RadialAction, favourite: Bool)] {
        let available = Dictionary(segments.values.flatMap { $0 }.filter(\.enabled).map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        var out: [(action: RadialAction, favourite: Bool)] = []
        for f in state.store.favouriteActions {
            if let a = available[f.id] { out.append((action: a, favourite: true)) }
        }
        for r in state.rankedRecentActions where out.count < 5 && !out.contains(where: { $0.action.id == r.id }) {
            if let a = available[r.id] { out.append((action: a, favourite: false)) }
        }
        return Array(out.prefix(5))
    }

    /// Pins or unpins the hovered / focused action (F key or right-click).
    func toggleFavourite(_ action: RadialAction? = nil) {
        guard let a = action ?? focusedAction, a.enabled else { NSSound.beep(); return }
        let state = AppState.shared
        let nowFavourite = state.toggleFavourite(a)
        configure(keepingOpenState: true, state: state)
        JobCenter.shared.message(nowFavourite ? "Added “\(a.title)” to favourites" : "Removed “\(a.title)” from favourites")
    }

    /// Rebuilds the catalog without closing the open ring (used after pinning).
    private func configure(keepingOpenState: Bool, state: AppState) {
        let open = openPrimary, ring = hoveredRing, key = keyboardRingIndex
        segments = ActionCatalog.build(for: context, state: state).mapValues { list in
            list.map { action in
                var a = action
                if a.badge == nil, state.isFavourite(a.id) { a.badge = "★" }
                return a
            }
        }
        openPrimary = open
        hoveredRing = ring
        keyboardRingIndex = key
    }

    func secondaryClick(at p: CGPoint) {
        let region = geometry.region(at: p, openSegment: openPrimary, ringCount: openActions.count)
        if case let .ring(i) = region, i < openActions.count {
            toggleFavourite(openActions[i])
        }
    }

    /// The ring action under the pointer, enabled or not (for the hub's message).
    var hoveredRingAction: RadialAction? {
        guard let h = hoveredRing, h < openActions.count else { return nil }
        return openActions[h]
    }

    var focusedAction: RadialAction? {
        let list = openActions
        if let h = hoveredRing, h < list.count { return list[h] }
        if let k = keyboardRingIndex, k < list.count { return list[k] }
        return nil
    }

    // MARK: Centre content

    var centreTitle: String {
        switch context {
        case let .files(a): return a.count == 1 ? a[0].name : "\(a.count) files"
        case let .text(t): return "“" + String(t.text.prefix(28)).replacingOccurrences(of: "\n", with: " ") + (t.text.count > 28 ? "…”" : "”")
        case .empty: return "HEXSHIFT"
        }
    }

    var centreSubtitle: String {
        switch context {
        case let .files(a):
            if a.count == 1 { return a[0].summary }
            let kinds = Set(a.map { $0.format?.displayName ?? $0.kind.title })
            let total = a.reduce(Int64(0)) { $0 + $1.fileSize }
            return kinds.sorted().joined(separator: ", ") + " · " + ByteCountFormatter.string(fromByteCount: total, countStyle: .file)
        case let .text(t):
            let w = DocumentConverter.statistics(t.text).words
            return "\(w) word\(w == 1 ? "" : "s")" + (t.sourceApp.map { " · \($0)" } ?? "")
        case .empty:
            return "Select anything. Create anything."
        }
    }

    private func loadThumbnail() {
        guard case let .files(assets) = context, let first = assets.first else { return }
        let url = first.url
        let size = CGSize(width: 76, height: 76)
        let request = QLThumbnailGenerator.Request(fileAt: url, size: size, scale: 2, representationTypes: .thumbnail)
        thumbnail = NSWorkspace.shared.icon(forFile: url.path)
        QLThumbnailGenerator.shared.generateBestRepresentation(for: request) { [weak self] rep, _ in
            guard let image = rep?.nsImage else { return }
            DispatchQueue.main.async {
                guard let self, case let .files(current) = self.context, current.first?.url == url else { return }
                self.thumbnail = image
            }
        }
    }

    // MARK: Pointer

    func hover(at p: CGPoint?) {
        guard let p else {
            hoveredRing = nil
            hoveredPrimary = nil
            clearTip()
            return
        }
        pointer = p
        let region = geometry.region(at: p, openSegment: openPrimary, ringCount: openActions.count)
        updateTip(for: region)
        switch region {
        case let .primary(i):
            hoveredRing = nil
            if hoveredPrimary != i {
                hoveredPrimary = i
                haptic("p\(i)")
                scheduleOpen(i)
            }
        case let .ring(i):
            hoveredPrimary = nil
            openTask?.cancel()
            if hoveredRing != i {
                hoveredRing = i
                keyboardRingIndex = nil
                haptic("r\(i)")
            }
        case .centre, .gap, .outside:
            hoveredPrimary = nil
            hoveredRing = nil
            openTask?.cancel()
        }
    }

    // MARK: Hover tip

    /// The tip for a region, if it has one.
    func tipContent(for region: RadialGeometry.Region) -> (key: String, title: String, detail: String)? {
        switch region {
        case let .primary(i):
            let title = segment(i).shortTitle
            return isEnabled(i) ? ("p\(i)", title, "press \(i + 1)") : ("p\(i)", title, "nothing here for this selection")
        case let .ring(i):
            let list = openActions
            guard i < list.count else { return nil }
            let a = list[i]
            let detail = a.enabled ? a.detail : (a.reason ?? a.badge ?? "not available for this selection")
            guard !detail.isEmpty else { return nil }
            return ("r\(openPrimary ?? -1).\(a.id)", a.title, detail)
        default:
            return nil
        }
    }

    private func updateTip(for region: RadialGeometry.Region) {
        let content = tipContent(for: region)
        guard content?.key != tipKey else { return }
        clearTip()
        guard let content else { return }
        tipKey = content.key
        tipTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 350_000_000)
            guard !Task.isCancelled, let self, self.tipKey == content.key else { return }
            let slice: Int? = content.key.hasPrefix("p") ? Int(content.key.dropFirst()) : nil
            self.tip = WheelTip(title: content.title, detail: content.detail,
                                anchor: slice.map { self.geometry.primaryLabelPoint($0) } ?? self.pointer, slice: slice)
        }
    }

    private func clearTip() {
        tipTask?.cancel()
        tipTask = nil
        tipKey = nil
        if tip != nil { tip = nil }
    }

    private func scheduleOpen(_ i: Int) {
        openTask?.cancel()
        guard isEnabled(i) else { return }
        if openPrimary == nil {
            openSegment(i)
            return
        }
        // Short intent delay when switching between rings avoids flicker while crossing segments.
        openTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 90_000_000)
            guard !Task.isCancelled, let self, self.hoveredPrimary == i else { return }
            self.openSegment(i)
        }
    }

    func openSegment(_ i: Int) {
        guard isEnabled(i) else { return }
        if openPrimary != i {
            openPrimary = i
            hoveredRing = nil
            keyboardRingIndex = nil
        }
    }

    func click(at p: CGPoint) {
        let region = geometry.region(at: p, openSegment: openPrimary, ringCount: openActions.count)
        inputLog.notice("wheel click at \(Int(p.x), privacy: .public),\(Int(p.y), privacy: .public) region=\(String(describing: region), privacy: .public) open=\(String(describing: self.openPrimary), privacy: .public)")
        switch region {
        case let .primary(i):
            guard isEnabled(i) else { return }
            let acts = actions(forPrimary: i)
            if acts.count == 1, acts[0].enabled {
                perform(acts[0])
            } else {
                openSegment(i)
            }
        case let .ring(i):
            let list = openActions
            if i < list.count, list[i].enabled { perform(list[i]) }
        case .outside:
            onDismiss?()
        case .centre, .gap:
            break
        }
    }

    func perform(_ action: RadialAction) {
        guard action.enabled else { NSSound.beep(); return }
        onPerform?(action)
    }

    private func haptic(_ region: String) {
        guard AppState.shared.prefs.haptics, region != lastHapticRegion else { return }
        lastHapticRegion = region
        NSHapticFeedbackManager.defaultPerformer.perform(.alignment, performanceTime: .now)
    }

    // MARK: Keyboard

    /// Returns true when the key was handled.
    func handleKey(_ event: NSEvent) -> Bool {
        clearTip()
        let code = Int(event.keyCode)
        switch code {
        case 53: // Esc
            if openPrimary != nil && keyboardRingIndex != nil {
                keyboardRingIndex = nil
            } else if openPrimary != nil {
                openPrimary = nil
            } else {
                onDismiss?()
            }
            return true
        case 123, 126: // ←, ↑
            step(-1)
            return true
        case 124, 125: // →, ↓
            step(1)
            return true
        case 48: // Tab
            step(event.modifierFlags.contains(.shift) ? -1 : 1)
            return true
        case 36, 76, 49: // Return, Enter, Space
            if let a = focusedAction { perform(a); return true }
            let i = openPrimary ?? hoveredPrimary ?? 0
            openSegment(i)
            if !openActions.isEmpty { keyboardRingIndex = openActions.firstIndex(where: \.enabled) ?? 0 }
            return true
        case 3 where event.modifierFlags.intersection([.command, .option, .control]).isEmpty: // F
            toggleFavourite()
            return true
        default:
            if let ch = event.charactersIgnoringModifiers, let n = Int(ch), n >= 1, n <= 6 {
                openSegment(n - 1)
                hoveredPrimary = n - 1
                keyboardRingIndex = nil
                return true
            }
            return false
        }
    }

    private func step(_ delta: Int) {
        if let k = keyboardRingIndex, !openActions.isEmpty {
            keyboardRingIndex = (k + delta).mod(openActions.count)
            hoveredRing = nil
            return
        }
        let current = openPrimary ?? hoveredPrimary ?? -1
        var next = current
        for _ in 0..<6 {
            next = (next + delta).mod(6)
            if isEnabled(next) { break }
        }
        hoveredPrimary = next
        openSegment(next)
    }
}

/// A hover message: bold title, then a quieter detail.
struct WheelTip: Equatable {
    let title: String
    let detail: String
    /// Where the tip belongs (wheel coordinates): the slice's label centre for a slice, the
    /// pointer for a ring tile.
    let anchor: CGPoint
    /// The slice the tip describes, if it describes one.
    var slice: Int? = nil
}
