import AppKit
import HexshiftKit

/// The six primary segments of the hexagonal wheel.
enum PrimarySegment: String, CaseIterable, Codable, Identifiable {
    case convert, edit, documents, typography, colour, capture

    var id: String { rawValue }

    var title: String {
        switch self {
        case .convert: return "Convert"
        case .edit: return "Edit"
        case .documents: return "PDF & Documents"
        case .typography: return "Typography"
        case .colour: return "Colour & Inspect"
        case .capture: return "Capture & More"
        }
    }

    /// One-word label drawn inside the wheel; the full title shows in the centre on hover.
    var shortTitle: String {
        switch self {
        case .convert: return "Convert"
        case .edit: return "Edit"
        case .documents: return "Documents"
        case .typography: return "Typography"
        case .colour: return "Colour"
        case .capture: return "Capture"
        }
    }

    var symbol: String {
        switch self {
        case .convert: return "arrow.triangle.2.circlepath"
        case .edit: return "slider.horizontal.3"
        case .documents: return "doc.text"
        case .typography: return "textformat"
        case .colour: return "eyedropper.halffull"
        case .capture: return "camera.viewfinder"
        }
    }

    /// Optical size correction so every segment icon has the same visual weight
    /// ("Aa" is a wide glyph and reads larger than the outline icons at the same point size).
    var symbolScale: CGFloat { self == .typography ? 0.88 : 1 }

    /// Uses `name` if this macOS has that SF Symbol, otherwise `fallback`.
    static func available(_ name: String, fallback: String) -> String {
        NSImage(systemSymbolName: name, accessibilityDescription: nil) != nil ? name : fallback
    }
}

struct RadialAction: Identifiable, Equatable {
    let id: String
    let title: String
    let detail: String
    let symbol: String
    var enabled = true
    var badge: String?
    /// Why the action is greyed out (shown when the pointer rests on it).
    var reason: String?
}

enum RadialContext: Equatable {
    case files([AssetInfo])
    case text(SelectedText)
    case empty

    var assets: [AssetInfo] {
        if case let .files(a) = self { return a }
        return []
    }

    var singleAsset: AssetInfo? {
        let a = assets
        return a.count == 1 ? a[0] : nil
    }
}

/// Builds the context-aware menu. Only relevant actions are shown; segments
/// with nothing to offer are dimmed rather than removed, so the shape stays familiar.
@MainActor
enum ActionCatalog {
    static let maxRingItems = 10

    static func build(for context: RadialContext, state: AppState) -> [PrimarySegment: [RadialAction]] {
        var s: [PrimarySegment: [RadialAction]] = [:]
        switch context {
        case .empty:
            s = emptyMenu(state)
        case let .text(t):
            s = textMenu(t, state: state)
        case let .files(assets):
            if assets.count == 1 { s = singleFileMenu(assets[0], state: state) } else { s = multiFileMenu(assets, state: state) }
        }
        // Capture & More is always useful.
        var more = s[.capture] ?? []
        if !more.contains(where: { $0.id == "more.settings" }) {
            more.append(RadialAction(id: "more.settings", title: "Settings", detail: "HEXSHIFT preferences", symbol: "gearshape"))
        }
        s[.capture] = more
        for key in s.keys { s[key] = limit(s[key] ?? [], segment: key) }
        return s
    }

    private static func limit(_ actions: [RadialAction], segment: PrimarySegment) -> [RadialAction] {
        guard actions.count > maxRingItems else { return actions }
        var kept = Array(actions.prefix(maxRingItems - 1))
        let id = segment == .convert ? "convert.more" : "more.panel.\(segment.rawValue)"
        kept.append(RadialAction(id: id, title: "More…", detail: "All options for this selection", symbol: "ellipsis.circle"))
        return kept
    }

    // MARK: Common pieces

    static func formatSymbol(_ f: Format) -> String {
        switch f.category {
        case .raster: return "photo"
        case .vector: return f == .pdf ? "doc.richtext" : "scribble.variable"
        case .document: return "doc.text"
        case .spreadsheet: return "tablecells"
        case .presentation: return "rectangle.on.rectangle"
        case .video: return "film"
        case .audio: return "waveform"
        case .font: return "textformat"
        case .other: return "doc"
        }
    }

    static func convertActions(_ asset: AssetInfo, state: AppState) -> [RadialAction] {
        ConversionEngine.targets(for: asset, preferredOrder: state.prefs.preferredFormats).map { t in
            RadialAction(id: "convert:\(t.id)", title: t.label,
                         detail: t.note ?? "Convert to \(t.format.displayName)",
                         symbol: t.variant == .trace ? "scribble.variable" : t.variant == .ocr ? "text.viewfinder" : formatSymbol(t.format),
                         enabled: t.isAvailable, badge: t.isAvailable ? nil : "Needs tool",
                         reason: t.isAvailable ? nil : (t.note ?? "Needs an extra tool"))
        }
    }

    static func captureActions(includeRegionOnly: Bool = false) -> [RadialAction] {
        var a = [RadialAction(id: "capture.region", title: "Region", detail: "Capture part of the screen (Space toggles window mode)", symbol: "rectangle.dashed")]
        if !includeRegionOnly {
            a.append(RadialAction(id: "capture.window", title: "Window", detail: "Capture a window", symbol: "macwindow"))
            a.append(RadialAction(id: "capture.display", title: "Display", detail: "Capture the display under the pointer", symbol: "display"))
            a.append(RadialAction(id: "capture.edit", title: "Capture & Edit", detail: "Capture a region and open it in the editor", symbol: "crop"))
        }
        return a
    }

    static func workflowActions(for kind: AssetKind, state: AppState) -> [RadialAction] {
        state.allWorkflows.filter { $0.applies(to: kind) }.map {
            RadialAction(id: "workflow:\($0.id.uuidString)", title: $0.name, detail: $0.summary, symbol: $0.symbol)
        }
    }

    static func fileUtilityActions() -> [RadialAction] {
        [
            RadialAction(id: "more.copy", title: "Copy", detail: "Copy to the clipboard", symbol: "doc.on.doc"),
            RadialAction(id: "more.reveal", title: "Reveal", detail: "Show in Finder", symbol: "folder"),
            RadialAction(id: "more.copyPath", title: "Copy Path", detail: "Copy the file path", symbol: "link"),
        ]
    }

    // MARK: Menus

    static func emptyMenu(_ state: AppState) -> [PrimarySegment: [RadialAction]] {
        var convert: [RadialAction] = []
        if SelectionService.clipboardHasContent {
            convert.append(RadialAction(id: "more.clipboard", title: "Clipboard", detail: "Convert what's on the clipboard", symbol: "doc.on.clipboard"))
        }
        convert.append(RadialAction(id: "more.browse", title: "Browse…", detail: "Choose files to convert", symbol: "folder"))
        for (i, url) in state.recentFileURLs.prefix(5).enumerated() {
            convert.append(RadialAction(id: "more.recentFile:\(i)", title: String(url.deletingPathExtension().lastPathComponent.prefix(12)),
                                        detail: "Recent: \(url.lastPathComponent)", symbol: "clock.arrow.circlepath"))
        }
        return [
            .convert: convert,
            .edit: [
                RadialAction(id: "more.browseEdit", title: "Open Image…", detail: "Edit an image file", symbol: "photo"),
                RadialAction(id: "capture.edit", title: "Capture & Edit", detail: "Capture a region and edit it", symbol: "crop"),
                RadialAction(id: "capture.annotate", title: "Annotate", detail: "Capture a region and annotate it", symbol: "pencil.tip.crop.circle"),
            ],
            .documents: [
                RadialAction(id: "pdf.mergeBrowse", title: "Merge PDFs…", detail: "Combine PDFs and images into one PDF", symbol: "arrow.triangle.merge"),
                RadialAction(id: "pdf.imagesBrowse", title: "Images → PDF", detail: "Make a PDF from images", symbol: "doc.badge.plus"),
                RadialAction(id: "capture.ocr", title: "Grab Text", detail: "Capture a region and extract its text (OCR)", symbol: "text.viewfinder"),
                RadialAction(id: "text.studio", title: "Text Studio", detail: "Write or paste text and export it", symbol: "doc.text"),
            ],
            .typography: [
                RadialAction(id: "type.findFont", title: "Find Font", detail: "Capture text on screen and find similar fonts", symbol: "textformat.size"),
                RadialAction(id: "type.compare", title: "Compare", detail: "Compare installed fonts side by side", symbol: "textformat.alt"),
                RadialAction(id: "type.browse", title: "Browse Fonts", detail: "Preview installed fonts", symbol: "character.book.closed"),
                RadialAction(id: "type.graphic", title: "Text Graphic", detail: "Create a graphic from text", symbol: "textbox"),
            ],
            .colour: [
                RadialAction(id: "colour.pick", title: "Pick Colour", detail: "Sample any pixel on screen", symbol: "eyedropper"),
                RadialAction(id: "colour.paletteCapture", title: "Palette", detail: "Capture a region and extract its colours", symbol: "paintpalette"),
                RadialAction(id: "colour.contrast", title: "Contrast", detail: "Check text/background contrast (WCAG)", symbol: "circle.lefthalf.filled"),
                RadialAction(id: "colour.lens", title: "Colour Lens", detail: "History, palettes and exports", symbol: "swatchpalette"),
                RadialAction(id: "inspect.measureCapture", title: "Measure", detail: "Capture a region and measure it", symbol: "ruler"),
                RadialAction(id: "designer.tools", title: "Designer Tools", detail: "Ratios, units, print size, colour maths", symbol: "wrench.and.screwdriver"),
            ],
            .capture: captureActions() + [
                RadialAction(id: "capture.research", title: "Design Research", detail: "Capture → palette + fonts + text → reference board", symbol: "rectangle.and.text.magnifyingglass"),
            ],
        ]
    }

    static func textMenu(_ t: SelectedText, state: AppState) -> [PrimarySegment: [RadialAction]] {
        let exports: [(Format, String)] = [(.pdf, "doc.richtext"), (.docx, "doc.text"), (.md, "number"), (.html, "chevron.left.forwardslash.chevron.right"),
                                          (.rtf, "doc.text"), (.txt, "doc.plaintext"), (.png, "photo"), (.jpeg, "photo"), (.svg, "scribble.variable")]
        var colourActions: [RadialAction] = []
        if let c = ColourMath.parse(t.text), t.text.count <= 40 {
            colourActions.append(RadialAction(id: "text.colour", title: c.hex, detail: "Show this colour in HEX, RGB, HSL and CSS", symbol: "paintpalette"))
        }
        colourActions.append(RadialAction(id: "colour.pick", title: "Pick Colour", detail: "Sample any pixel on screen", symbol: "eyedropper"))
        colourActions.append(RadialAction(id: "colour.contrast", title: "Contrast", detail: "Check contrast", symbol: "circle.lefthalf.filled"))
        let stats = DocumentConverter.statistics(t.text)
        var more = captureActions(includeRegionOnly: true)
        if let u = URL(string: t.text.trimmingCharacters(in: .whitespacesAndNewlines)), u.scheme?.hasPrefix("http") == true {
            more.insert(RadialAction(id: "text.qr", title: "QR Code", detail: "Make a QR code PNG for this link", symbol: "qrcode"), at: 0)
        }
        if TranslateSupport.isAvailable {
            more.append(RadialAction(id: "text.translate", title: "Translate", detail: "Translate on this Mac (Apple Translation)", symbol: "character.bubble"))
        }
        return [
            .convert: exports.map { f, sym in
                RadialAction(id: "text.export:\(f.rawValue)", title: f.shortName, detail: "Export the selected text as \(f.displayName)", symbol: sym)
            },
            .edit: [
                RadialAction(id: "text.copyPlain", title: "Plain Text", detail: "Copy without formatting", symbol: "doc.plaintext"),
                RadialAction(id: "text.copyMarkdown", title: "Markdown", detail: "Copy as Markdown", symbol: "number"),
                RadialAction(id: "text.upper", title: "UPPERCASE", detail: "Copy in upper case", symbol: "textformat.abc.dottedunderline"),
                RadialAction(id: "text.lower", title: "lowercase", detail: "Copy in lower case", symbol: "textformat.abc"),
                RadialAction(id: "text.title", title: "Title Case", detail: "Copy in title case", symbol: "textformat"),
                RadialAction(id: "text.clean", title: "Clean", detail: "Copy with extra spaces and line breaks removed", symbol: "wand.and.stars"),
            ],
            .documents: [
                RadialAction(id: "text.export:pdf", title: "Export PDF", detail: "Preview, choose page size and export", symbol: "doc.richtext"),
                RadialAction(id: "text.export:docx", title: "Export Word", detail: "Save as a Word document", symbol: "doc.text"),
                RadialAction(id: "text.stats", title: "\(stats.words) words", detail: "\(stats.characters) characters · \(stats.lines) lines · about \(stats.readingMinutes) min read", symbol: "number.circle"),
            ],
            .typography: [
                RadialAction(id: "type.inspectSelection", title: "Inspect Font", detail: t.font != nil ? "Font reported by \(t.sourceApp ?? "the app")" : "Capture the text to find similar fonts", symbol: "textformat.size"),
                RadialAction(id: "text.graphic", title: "Text Graphic", detail: "Turn this text into a designed graphic", symbol: "textbox"),
                RadialAction(id: "type.compare", title: "Compare", detail: "Compare fonts with this text", symbol: "textformat.alt"),
            ],
            .colour: colourActions,
            .capture: more,
        ]
    }

    static func singleFileMenu(_ a: AssetInfo, state: AppState) -> [PrimarySegment: [RadialAction]] {
        var s: [PrimarySegment: [RadialAction]] = [.convert: convertActions(a, state: state)]
        let inspect = RadialAction(id: "inspect.info", title: "Inspect", detail: "Dimensions, resolution, colour profile, metadata", symbol: "info.circle")
        let workflows = workflowActions(for: a.kind, state: state)
        switch a.kind {
        case .image, .rawImage:
            var edit = [
                RadialAction(id: "edit.crop", title: "Crop", detail: "Crop with presets (1:1, 4:5, 9:16, Instagram…)", symbol: "crop"),
                RadialAction(id: "edit.resize", title: "Resize", detail: "Pixels, percentage or DPI", symbol: "arrow.up.left.and.arrow.down.right"),
                RadialAction(id: "edit.removebg", title: "Remove BG", detail: "Isolate the subject (on-device)", symbol: "person.crop.rectangle"),
                RadialAction(id: "edit.adjust", title: "Enhance", detail: "Exposure, contrast, colour, sharpness", symbol: "wand.and.stars"),
                RadialAction(id: "edit.annotate", title: "Annotate", detail: "Arrows, shapes, text, blur, callouts", symbol: "pencil.tip.crop.circle"),
                RadialAction(id: "edit.compress", title: "Compress", detail: "Smaller file with a quality slider or target size", symbol: "arrow.down.right.and.arrow.up.left"),
                RadialAction(id: "edit.rotate", title: "Rotate", detail: "Rotate 90° clockwise (saves a copy)", symbol: "rotate.right"),
                RadialAction(id: "edit.metadata", title: "Metadata", detail: a.hasGPS ? "Contains location data — remove it" : "View or remove EXIF data", symbol: a.hasGPS ? "location.slash" : "list.bullet.rectangle"),
                RadialAction(id: "edit.scales", title: "@1x @2x @3x", detail: "Export scale variants", symbol: "square.stack.3d.up"),
            ]
            if a.isScreenshot {
                edit.insert(RadialAction(id: "edit.measure", title: "Measure", detail: "Measure distances (estimates from pixels)", symbol: "ruler"), at: 2)
            }
            s[.edit] = edit
            var docs = [
                RadialAction(id: "doc.ocr", title: "Extract Text", detail: "Recognise the text in this image", symbol: "text.viewfinder"),
                RadialAction(id: "pdf.fromImages", title: "Make PDF", detail: "Create a PDF from this image", symbol: "doc.badge.plus"),
                RadialAction(id: "pdf.searchableImage", title: "Searchable PDF", detail: "PDF with an invisible OCR text layer", symbol: "doc.text.magnifyingglass"),
            ]
            if a.isScreenshot { docs.swapAt(0, 0) }
            s[.documents] = docs
            s[.typography] = [
                RadialAction(id: "type.findFont", title: "Find Font", detail: "Identify visually similar fonts in this image", symbol: "textformat.size"),
                RadialAction(id: "type.compare", title: "Compare", detail: "Compare installed fonts", symbol: "textformat.alt"),
            ]
            var colour = [
                RadialAction(id: "colour.pickImage", title: "Pick Colour", detail: "Click any pixel of this image", symbol: "eyedropper"),
                RadialAction(id: "colour.palette", title: "Palette", detail: "Extract the dominant colours", symbol: "paintpalette"),
                RadialAction(id: "colour.gradient", title: "Gradient", detail: "Estimate a CSS gradient", symbol: "square.fill.on.square.fill"),
                inspect,
            ]
            if a.hasAlpha == true {
                colour.append(RadialAction(id: "inspect.transparency", title: "Transparency", detail: "Check whether transparent pixels are used", symbol: "checkerboard.rectangle"))
            }
            s[.colour] = colour
            s[.capture] = workflows + fileUtilityActions() + captureActions(includeRegionOnly: true)
            if a.isScreenshot {
                // Screenshots: text and type first (Example D in the brief).
                s[.documents] = docs
            }
        case .animatedImage:
            s[.edit] = [
                RadialAction(id: "edit.frames", title: "Extract Frames", detail: "Save every frame as PNG", symbol: "square.stack"),
                RadialAction(id: "edit.firstFrame", title: "Edit Frame", detail: "Open the first frame in the editor", symbol: "crop"),
            ]
            s[.documents] = [RadialAction(id: "doc.ocr", title: "Extract Text", detail: "Recognise text in the first frame", symbol: "text.viewfinder")]
            s[.typography] = [RadialAction(id: "type.findFont", title: "Find Font", detail: "Similar fonts from the first frame", symbol: "textformat.size")]
            s[.colour] = [
                RadialAction(id: "colour.palette", title: "Palette", detail: "Dominant colours", symbol: "paintpalette"),
                inspect,
            ]
            s[.capture] = fileUtilityActions()
        case .pdf:
            s[.edit] = [
                RadialAction(id: "pdf.organize", title: "Pages", detail: "Reorder, rotate, delete, duplicate pages", symbol: "square.grid.2x2"),
                RadialAction(id: "pdf.markup", title: "Markup", detail: "Text boxes, comments, drawing, highlights", symbol: "pencil.tip.crop.circle"),
                RadialAction(id: "pdf.pageNumbers", title: "Page Numbers", detail: "Insert page numbers", symbol: "list.number"),
                RadialAction(id: "pdf.highlight", title: "Highlight", detail: "Highlight or underline a phrase everywhere", symbol: "highlighter"),
                RadialAction(id: "pdf.stamp", title: "Stamp", detail: "Add a text watermark (DRAFT, CONFIDENTIAL…)", symbol: "seal"),
                RadialAction(id: "pdf.sign", title: "Sign", detail: "Place a signature image", symbol: "signature"),
                RadialAction(id: "pdf.rotateAll", title: "Rotate", detail: "Rotate every page 90° (saves a copy)", symbol: "rotate.right"),
            ]
            s[.documents] = [
                RadialAction(id: "pdf.merge", title: "Merge", detail: "Combine with other PDFs or images", symbol: "arrow.triangle.merge"),
                RadialAction(id: "pdf.split", title: "Split", detail: "One file per page, or by ranges", symbol: "rectangle.split.3x1"),
                RadialAction(id: "pdf.extract", title: "Extract Pages", detail: "Copy chosen pages into a new PDF", symbol: "doc.on.doc"),
                RadialAction(id: "pdf.pageSize", title: "Page Size", detail: "Change page size or add margins", symbol: "rectangle.expand.vertical"),
                RadialAction(id: "pdf.compress", title: "Compress", detail: "Reduce file size", symbol: "arrow.down.right.and.arrow.up.left"),
                RadialAction(id: "pdf.ocr", title: "OCR", detail: "Make scanned pages searchable", symbol: "doc.text.magnifyingglass"),
                RadialAction(id: "pdf.redact", title: "Redact", detail: "Permanently remove text or areas", symbol: "eye.slash"),
                RadialAction(id: "pdf.extractText", title: "Extract Text", detail: "Copy or save the text", symbol: "text.viewfinder"),
                RadialAction(id: "pdf.stripMeta", title: "Clean Metadata", detail: "Remove title, author, creator…", symbol: "trash.slash"),
                RadialAction(id: "pdf.password", title: "Password", detail: "Protect with a password, or remove one", symbol: "lock"),
            ]
            s[.typography] = [
                RadialAction(id: "type.fontsInFile", title: "Fonts Used", detail: "Fonts embedded in this PDF (actual metadata)", symbol: "textformat"),
                RadialAction(id: "type.findFont", title: "Find Font", detail: "Similar fonts from page 1 (estimated)", symbol: "textformat.size"),
            ]
            s[.colour] = [
                RadialAction(id: "colour.pickImage", title: "Pick Colour", detail: "Click a pixel on page 1", symbol: "eyedropper"),
                RadialAction(id: "colour.palette", title: "Palette", detail: "Dominant colours of page 1", symbol: "paintpalette"),
                inspect,
            ]
            s[.capture] = workflows + fileUtilityActions()
        case .vector:
            s[.edit] = [RadialAction(id: "edit.scales", title: "@1x @2x @3x", detail: "Export PNGs at several scales", symbol: "square.stack.3d.up")]
            s[.colour] = [
                RadialAction(id: "colour.palette", title: "Palette", detail: "Dominant colours", symbol: "paintpalette"),
                RadialAction(id: "colour.pickImage", title: "Pick Colour", detail: "Click a pixel", symbol: "eyedropper"),
                inspect,
            ]
            s[.capture] = fileUtilityActions()
        case .document:
            s[.edit] = [RadialAction(id: "doc.studio", title: "Reformat", detail: "Open in Text Studio to restyle and export", symbol: "textformat.alt")]
            s[.documents] = [
                RadialAction(id: "doc.studioPDF", title: "Export PDF", detail: "Choose page size and font, then export", symbol: "doc.richtext"),
                RadialAction(id: "doc.copyText", title: "Copy Text", detail: "Copy the document's text", symbol: "doc.on.doc"),
                RadialAction(id: "doc.stats", title: "Word Count", detail: "Words, characters, reading time", symbol: "number.circle"),
            ]
            s[.typography] = [
                RadialAction(id: "type.fontsInFile", title: "Fonts Used", detail: "Fonts in this document (actual metadata)", symbol: "textformat"),
                RadialAction(id: "text.graphicFromFile", title: "Text Graphic", detail: "Make a graphic from the first lines", symbol: "textbox"),
            ]
            s[.colour] = [inspect]
            s[.capture] = fileUtilityActions()
        case .spreadsheet, .presentation:
            s[.colour] = [inspect]
            s[.capture] = fileUtilityActions()
        case .video:
            s[.edit] = [
                RadialAction(id: "media.trim", title: "Trim", detail: "Trim and export", symbol: "scissors"),
                RadialAction(id: "media.gif", title: "Make GIF", detail: "Choose range, frame rate and width", symbol: "photo.stack"),
                RadialAction(id: "media.frame", title: "Frame", detail: "Save a frame as an image", symbol: "photo"),
                RadialAction(id: "media.reduce", title: "Reduce Size", detail: "Re-encode with HEVC", symbol: "arrow.down.right.and.arrow.up.left"),
                RadialAction(id: "media.audio", title: "Audio", detail: "Extract the soundtrack (M4A)", symbol: "waveform"),
            ]
            s[.colour] = [inspect]
            s[.capture] = fileUtilityActions()
        case .audio:
            s[.edit] = [RadialAction(id: "media.trim", title: "Trim", detail: "Trim and export", symbol: "scissors")]
            s[.colour] = [inspect]
            s[.capture] = fileUtilityActions()
        case .font:
            s[.typography] = [
                RadialAction(id: "type.fontFile", title: "Preview", detail: "Preview this font file", symbol: "textformat"),
                RadialAction(id: "type.fontBook", title: "Font Book", detail: "Open in Font Book to install", symbol: "character.book.closed"),
            ]
            s[.capture] = fileUtilityActions()
        case .unknown:
            s[.colour] = [inspect]
            s[.capture] = fileUtilityActions()
        }
        return s
    }

    static func multiFileMenu(_ assets: [AssetInfo], state: AppState) -> [PrimarySegment: [RadialAction]] {
        // Conversions valid for every selected file.
        var common: [String]?
        var labels: [String: RadialAction] = [:]
        for a in assets {
            let actions = convertActions(a, state: state).filter(\.enabled)
            for act in actions where labels[act.id] == nil { labels[act.id] = act }
            let ids = actions.map(\.id)
            common = common.map { c in c.filter { ids.contains($0) } } ?? ids
        }
        let convert = (common ?? []).compactMap { labels[$0] }.map {
            RadialAction(id: $0.id, title: $0.title, detail: "Batch: \($0.detail)", symbol: $0.symbol, enabled: $0.enabled, badge: $0.badge)
        }
        let kinds = Set(assets.map(\.kind))
        let allImages = kinds.isSubset(of: [.image, .rawImage])
        let pdfOrImages = kinds.isSubset(of: [.image, .rawImage, .pdf])
        var s: [PrimarySegment: [RadialAction]] = [.convert: convert]
        if allImages {
            s[.edit] = [
                RadialAction(id: "batch.resize", title: "Resize All", detail: "Fit every image within a size", symbol: "arrow.up.left.and.arrow.down.right"),
                RadialAction(id: "batch.compress", title: "Compress All", detail: "Re-encode at a chosen quality", symbol: "arrow.down.right.and.arrow.up.left"),
                RadialAction(id: "batch.stripGPS", title: "Remove GPS", detail: "Remove location data from every image", symbol: "location.slash"),
                RadialAction(id: "batch.rotate", title: "Rotate All", detail: "Rotate 90° clockwise", symbol: "rotate.right"),
            ]
            s[.colour] = [RadialAction(id: "colour.palette", title: "Palette", detail: "Colours of the first image", symbol: "paintpalette")]
        }
        if pdfOrImages {
            s[.documents] = [
                RadialAction(id: "pdf.mergeSelection", title: allImages ? "Images → PDF" : "Merge PDF", detail: "Combine the selection into one PDF, in order", symbol: "arrow.triangle.merge"),
            ]
            if allImages {
                s[.documents]?.append(RadialAction(id: "doc.ocrBatch", title: "Extract Text", detail: "OCR every image into one text file", symbol: "text.viewfinder"))
            }
        }
        if let first = assets.first {
            let wf = workflowActions(for: first.kind, state: state).filter { w in assets.allSatisfy { a in state.allWorkflows.first { "workflow:\($0.id.uuidString)" == w.id }?.applies(to: a.kind) ?? false } }
            s[.capture] = wf + [RadialAction(id: "more.reveal", title: "Reveal", detail: "Show in Finder", symbol: "folder"),
                                RadialAction(id: "more.copy", title: "Copy", detail: "Copy files", symbol: "doc.on.doc")]
        }
        return s
    }
}
