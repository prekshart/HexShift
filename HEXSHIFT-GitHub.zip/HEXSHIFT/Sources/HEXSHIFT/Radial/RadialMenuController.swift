import AppKit
import HexshiftKit
import os
import SwiftUI

/// Input trail for diagnosing clicks: `log show --predicate 'subsystem == "app.hexshift"'`.
let inputLog = Logger(subsystem: "app.hexshift", category: "input")

/// Hosting view that takes the very first click, even while another app is in front, so a
/// click on the wheel is never swallowed just to bring its window forward.
final class FirstClickHostingView<Content: View>: NSHostingView<Content> {
    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }
}

/// Borderless floating panel that can take keyboard focus without activating HEXSHIFT,
/// so the app you were using stays frontmost.
final class FloatingPanel: NSPanel {
    var keyHandler: ((NSEvent) -> Bool)?
    /// Right-clicks, in top-left-origin content coordinates.
    var rightClickHandler: ((CGPoint) -> Void)?

    override func sendEvent(_ event: NSEvent) {
        if event.type == .leftMouseDown || event.type == .leftMouseUp {
            let p = event.locationInWindow
            inputLog.notice("panel \(event.type == .leftMouseDown ? "down" : "up", privacy: .public) at \(Int(p.x), privacy: .public),\(Int(p.y), privacy: .public) key=\(self.isKeyWindow, privacy: .public)")
        }
        if event.type == .rightMouseDown, let handler = rightClickHandler, let content = contentView {
            let p = event.locationInWindow
            handler(CGPoint(x: p.x, y: content.bounds.height - p.y))
            return
        }
        super.sendEvent(event)
    }

    init(size: CGSize) {
        super.init(contentRect: NSRect(origin: .zero, size: size),
                   styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: true)
        isFloatingPanel = true
        level = .popUpMenu
        backgroundColor = .clear
        isOpaque = false
        hasShadow = false
        hidesOnDeactivate = false
        isMovable = false
        isReleasedWhenClosed = false
        collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .transient, .ignoresCycle]
        acceptsMouseMovedEvents = true
        // Transparent windows normally let clicks fall through wherever macOS thinks nothing
        // is drawn — and SwiftUI's layer drawing can look "empty" to it, so every click would
        // go to the app behind the wheel. Setting this explicitly makes the panel receive
        // every click inside its frame; clicks off the wheel itself close it.
        ignoresMouseEvents = false
        animationBehavior = .none
    }

    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }

    override func keyDown(with event: NSEvent) {
        if keyHandler?(event) != true { super.keyDown(with: event) }
    }
}

@MainActor
final class RadialMenuController {
    static let shared = RadialMenuController()

    let model = RadialMenuModel()
    private var panel: FloatingPanel?
    private var hosting: FirstClickHostingView<AnyView>?
    private var clickMonitor: Any?
    private var keyMonitor: Any?
    private(set) var isVisible = false
    private var hideWork: DispatchWorkItem?

    private init() {
        model.onPerform = { [weak self] action in self?.perform(action) }
        model.onDismiss = { [weak self] in self?.dismiss() }
    }

    private func ensurePanel() -> FloatingPanel {
        let size = CGSize(width: model.geometry.canvas, height: model.geometry.canvas)
        if let panel {
            if panel.frame.size != size { panel.setContentSize(size) }
            return panel
        }
        let p = FloatingPanel(size: size)
        let view = AnyView(RadialMenuView(model: model).environmentObject(AppState.shared).hexAppearance(AppState.shared))
        let host = FirstClickHostingView(rootView: view)
        host.frame = NSRect(origin: .zero, size: size)
        host.autoresizingMask = [.width, .height]
        p.contentView = host
        p.keyHandler = { [weak self] event in self?.model.handleKey(event) ?? false }
        p.rightClickHandler = { [weak self] point in
            Task { @MainActor in self?.model.secondaryClick(at: point) }
        }
        panel = p
        hosting = host
        return p
    }

    /// Opens the wheel around a screen point (defaults to the mouse location).
    func show(context: RadialContext, at point: NSPoint? = nil) {
        hideWork?.cancel()
        let state = AppState.shared
        model.configure(context: context, state: state)
        if case let .files(assets) = context { state.recordFiles(assets.map(\.url)) }
        let panel = ensurePanel()
        // Refresh the root view so appearance changes apply.
        hosting?.rootView = AnyView(RadialMenuView(model: model).environmentObject(state).hexAppearance(state))
        let size = CGSize(width: model.geometry.canvas, height: model.geometry.canvas)
        panel.setFrame(frame(around: point ?? NSEvent.mouseLocation, size: size), display: false)
        panel.alphaValue = 1
        model.isShown = false
        panel.orderFrontRegardless()
        panel.makeKey()
        isVisible = true
        DispatchQueue.main.async { self.model.isShown = true }
        installMonitors()
        UIAccessibilityHelper.announce("HEXSHIFT menu. Use arrow keys to choose, Return to open, Escape to close.")
    }

    /// Keeps the whole wheel on screen, clear of the menu bar, Dock and camera housing.
    func frame(around point: NSPoint, size: CGSize) -> NSRect {
        let screen = NSScreen.screens.first { NSMouseInRect(point, $0.frame, false) } ?? NSScreen.main ?? NSScreen.screens[0]
        let visible = screen.visibleFrame.insetBy(dx: 4, dy: 4)
        var origin = NSPoint(x: point.x - size.width / 2, y: point.y - size.height / 2)
        origin.x = min(max(origin.x, visible.minX), visible.maxX - size.width)
        origin.y = min(max(origin.y, visible.minY), visible.maxY - size.height)
        return NSRect(origin: origin, size: size)
    }

    func dismiss(animated: Bool = true) {
        guard isVisible else { return }
        isVisible = false
        removeMonitors()
        model.isShown = false
        model.openPrimary = nil
        let work = DispatchWorkItem { [weak self] in self?.panel?.orderOut(nil) }
        hideWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + (animated ? 0.14 : 0), execute: work)
    }

    private func installMonitors() {
        removeMonitors()
        clickMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown, .otherMouseDown]) { [weak self] _ in
            Task { @MainActor in self?.dismiss() }
        }
        keyMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            guard let self, self.isVisible else { return event }
            return self.model.handleKey(event) ? nil : event
        }
    }

    private func removeMonitors() {
        if let m = clickMonitor { NSEvent.removeMonitor(m) }
        if let m = keyMonitor { NSEvent.removeMonitor(m) }
        clickMonitor = nil
        keyMonitor = nil
    }

    private func perform(_ action: RadialAction) {
        inputLog.notice("perform \(action.id, privacy: .public)")
        let context = model.context
        dismiss(animated: true)
        AppState.shared.recordAction(id: action.id, title: action.title, symbol: action.symbol)
        // Let the panel disappear before captures or windows appear.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            ActionRunner.shared.perform(action, context: context)
        }
    }
}

enum UIAccessibilityHelper {
    static func announce(_ message: String) {
        guard NSWorkspace.shared.isVoiceOverEnabled else { return }
        NSAccessibility.post(element: NSApp as Any, notification: .announcementRequested,
                             userInfo: [.announcement: message, .priority: NSAccessibilityPriorityLevel.high.rawValue])
    }
}
