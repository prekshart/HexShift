import AppKit
import Carbon.HIToolbox
import HexshiftKit
import SwiftUI

/// Global shortcuts assigned to individual workflows. A workflow shortcut runs the workflow
/// on the files selected in Finder (no wheel in between).
@MainActor
enum WorkflowHotKeys {
    private static var registered: [UInt32] = []
    private static let baseID: UInt32 = 100

    static func registerAll() {
        for id in registered { HotKeyManager.shared.unregister(id: id) }
        registered = []
        let state = AppState.shared
        for (i, wf) in state.allWorkflows.enumerated() {
            guard let combo = state.store.workflowShortcuts[wf.id.uuidString] else { continue }
            let hkID = baseID + UInt32(i)
            let wfID = wf.id.uuidString
            let result = HotKeyManager.shared.register(id: hkID, combo: combo) {
                Task { @MainActor in run(workflowID: wfID) }
            }
            if result == .ok {
                registered.append(hkID)
            } else {
                JobCenter.shared.message("The shortcut for “\(wf.name)” couldn't be registered",
                                         detail: "\(combo.display) is already in use. Choose another in Settings › Workflows.", kind: .error)
            }
        }
    }

    static func run(workflowID: String) {
        let snapshot = SelectionService.snapshot(of: NSWorkspace.shared.frontmostApplication)
        guard !snapshot.files.isEmpty else {
            JobCenter.shared.message("Select files in Finder first", detail: "Workflow shortcuts run on the files selected in Finder.")
            return
        }
        ActionRunner.shared.runWorkflow(workflowID, assets: snapshot.files.map { AssetInspector.inspect($0) })
    }
}

/// A compact "record a shortcut" control. Requires ⌘, ⌥ or ⌃ (or a function key) and refuses
/// combinations macOS itself uses.
@MainActor
struct ShortcutRecorder: View {
    @Binding var combo: HotKeyCombo?
    @State private var recording = false
    @State private var monitor: Any?
    @State private var problem: String?

    var body: some View {
        HStack(spacing: 6) {
            Text(recording ? "Press keys…" : (combo?.display ?? "No shortcut"))
                .font(.system(size: 11.5, weight: .medium, design: .rounded))
                .foregroundStyle(combo == nil && !recording ? .secondary : .primary)
                .frame(minWidth: 96)
                .padding(.vertical, 3)
                .padding(.horizontal, 6)
                .background(RoundedRectangle(cornerRadius: 6).strokeBorder(recording ? Color.accentColor : Color.primary.opacity(0.15)))
            Button(recording ? "Cancel" : "Record") { recording ? stop() : start() }
                .controlSize(.small)
            if combo != nil && !recording {
                Button { combo = nil } label: { Image(systemName: "xmark.circle.fill") }
                    .buttonStyle(.borderless)
                    .help("Remove shortcut")
            }
            if let problem { Text(problem).font(.system(size: 10.5)).foregroundStyle(.orange) }
        }
        .onDisappear { stop() }
    }

    private func start() {
        problem = nil
        recording = true
        monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { event in
            let mods = HotKeyManager.carbonModifiers(from: event.modifierFlags)
            if event.keyCode == UInt16(kVK_Escape) && mods == 0 { stop(); return nil }
            let isFunctionKey = (96...122).contains(Int(event.keyCode))
            guard mods & UInt32(cmdKey | optionKey | controlKey) != 0 || isFunctionKey else {
                problem = "Use ⌘, ⌥ or ⌃"
                return nil
            }
            let new = HotKeyCombo(keyCode: UInt32(event.keyCode), modifiers: mods,
                                  display: HotKeyManager.displayString(modifiers: mods, keyName: HotKeyManager.keyName(for: event)))
            if HotKeyManager.systemConflict(new) != nil {
                problem = "Used by macOS"
                return nil
            }
            if new == AppState.shared.prefs.hotKey {
                problem = "That's the main shortcut"
                return nil
            }
            combo = new
            stop()
            return nil
        }
    }

    private func stop() {
        if let monitor { NSEvent.removeMonitor(monitor) }
        monitor = nil
        recording = false
    }
}
