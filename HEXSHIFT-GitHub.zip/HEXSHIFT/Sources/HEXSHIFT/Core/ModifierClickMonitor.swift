import AppKit
import ApplicationServices

/// The optional modifier + right-click gesture (e.g. ⌃⌥-right-click) that opens the wheel at the
/// pointer. Uses a session event tap that only listens for right mouse buttons, so it needs
/// Accessibility permission; the matching click is consumed so the app's context menu doesn't
/// also appear. Keystrokes are never seen.
final class ModifierClickMonitor {
    static let shared = ModifierClickMonitor()

    private var tap: CFMachPort?
    private var source: CFRunLoopSource?
    private var swallowNextUp = false
    private var required: NSEvent.ModifierFlags = [.control, .option]

    var isRunning: Bool { tap != nil }

    /// Returns false when Accessibility hasn't been allowed yet.
    @discardableResult
    func start(flags: NSEvent.ModifierFlags) -> Bool {
        stop()
        required = flags.intersection([.command, .option, .control, .shift])
        guard AXIsProcessTrusted() else { return false }
        let mask = (CGEventMask(1) << CGEventType.rightMouseDown.rawValue) | (CGEventMask(1) << CGEventType.rightMouseUp.rawValue)
        let refcon = Unmanaged.passUnretained(self).toOpaque()
        guard let tap = CGEvent.tapCreate(tap: .cgSessionEventTap, place: .headInsertEventTap, options: .defaultTap,
                                          eventsOfInterest: mask,
                                          callback: { _, type, event, refcon in
                                              guard let refcon else { return Unmanaged.passUnretained(event) }
                                              let monitor = Unmanaged<ModifierClickMonitor>.fromOpaque(refcon).takeUnretainedValue()
                                              return monitor.handle(type: type, event: event)
                                          },
                                          userInfo: refcon) else { return false }
        let source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, tap, 0)
        CFRunLoopAddSource(CFRunLoopGetMain(), source, .commonModes)
        CGEvent.tapEnable(tap: tap, enable: true)
        self.tap = tap
        self.source = source
        return true
    }

    func stop() {
        if let tap { CGEvent.tapEnable(tap: tap, enable: false) }
        if let source { CFRunLoopRemoveSource(CFRunLoopGetMain(), source, .commonModes) }
        tap = nil
        source = nil
        swallowNextUp = false
    }

    private func handle(type: CGEventType, event: CGEvent) -> Unmanaged<CGEvent>? {
        switch type {
        case .tapDisabledByTimeout, .tapDisabledByUserInput:
            if let tap { CGEvent.tapEnable(tap: tap, enable: true) }
            return Unmanaged.passUnretained(event)
        case .rightMouseDown:
            let current = NSEvent.ModifierFlags(rawValue: UInt(event.flags.rawValue)).intersection([.command, .option, .control, .shift])
            guard current == required else { return Unmanaged.passUnretained(event) }
            swallowNextUp = true
            Task { @MainActor in HotKeyAction.invoke() }
            return nil
        case .rightMouseUp where swallowNextUp:
            swallowNextUp = false
            return nil
        default:
            return Unmanaged.passUnretained(event)
        }
    }
}
