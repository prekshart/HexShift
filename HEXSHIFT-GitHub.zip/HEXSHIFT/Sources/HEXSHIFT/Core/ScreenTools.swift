import AppKit
import HexshiftKit

enum CaptureMode {
    case region, window, display
}

/// User-initiated screen capture using macOS's own screenshot tool (crosshair,
/// Space to toggle window mode, Esc to cancel). Never records continuously.
@MainActor
enum ScreenCapture {
    static var capturesFolder: URL {
        let caches = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!
        let dir = caches.appendingPathComponent("HEXSHIFT/Captures", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    /// Returns the captured PNG, or nil if the user cancelled or permission is missing.
    static func capture(_ mode: CaptureMode) async -> URL? {
        guard Permissions.screenRecordingGranted else {
            Permissions.explain(.screenRecording)
            return nil
        }
        cleanOldCaptures()
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd 'at' HH.mm.ss"
        let url = capturesFolder.appendingPathComponent("HEXSHIFT Capture \(f.string(from: Date())).png")
        var args = ["-x", "-t", "png"]
        switch mode {
        case .region: args += ["-i"]
        case .window: args += ["-i", "-W", "-o"]
        case .display:
            let mouse = NSEvent.mouseLocation
            let index = (NSScreen.screens.firstIndex { NSMouseInRect(mouse, $0.frame, false) } ?? 0) + 1
            args += ["-D", "\(index)"]
        }
        args.append(url.path)
        let finalArgs = args
        let status: Int32 = await Task.detached {
            let p = Process()
            p.executableURL = URL(fileURLWithPath: "/usr/sbin/screencapture")
            p.arguments = finalArgs
            do {
                try p.run()
                p.waitUntilExit()
                return p.terminationStatus
            } catch {
                return -1
            }
        }.value
        guard status == 0, FileManager.default.fileExists(atPath: url.path) else { return nil }
        return url
    }

    /// Captures are temporary: anything older than a day is removed.
    static func cleanOldCaptures() {
        let fm = FileManager.default
        guard let items = try? fm.contentsOfDirectory(at: capturesFolder, includingPropertiesForKeys: [.creationDateKey]) else { return }
        let cutoff = Date().addingTimeInterval(-24 * 3600)
        for item in items {
            let d = (try? item.resourceValues(forKeys: [.creationDateKey]))?.creationDate ?? .distantPast
            if d < cutoff { try? fm.removeItem(at: item) }
        }
    }
}

/// The system colour loupe (magnified pixel view). Needs no screen-recording permission.
@MainActor
enum ColourPicker {
    private static var sampler: NSColorSampler?

    static func pick() async -> NSColor? {
        await withCheckedContinuation { (cont: CheckedContinuation<NSColor?, Never>) in
            let s = NSColorSampler()
            sampler = s
            s.show { colour in
                cont.resume(returning: colour)
                Task { @MainActor in ColourPicker.sampler = nil }
            }
        }
    }

    /// sRGB value plus the Display-P3 value for wide-gamut CSS.
    static func describe(_ colour: NSColor) -> (srgb: RGBAColour, p3: (Double, Double, Double)?) {
        let srgb = RGBAColour(nsColor: colour)
        var p3: (Double, Double, Double)?
        if let c = colour.usingColorSpace(.displayP3) {
            p3 = (Double(c.redComponent), Double(c.greenComponent), Double(c.blueComponent))
        }
        return (srgb, p3)
    }
}
