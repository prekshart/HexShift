import AppKit
import HexshiftKit
import SwiftUI

/// The compact menu-bar icon and its popover. Files can also be dropped on the icon.
@MainActor
final class MenuBarController: NSObject, NSWindowDelegate, NSPopoverDelegate, NSDraggingDestination {
    static let shared = MenuBarController()

    private var item: NSStatusItem?
    private let popover = NSPopover()

    func install() {
        guard item == nil else { return }
        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        if let button = item.button {
            button.image = Self.icon()
            button.image?.accessibilityDescription = "HEXSHIFT"
            button.target = self
            button.action = #selector(toggle(_:))
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
            button.toolTip = "HEXSHIFT — drop files here, or press \(AppState.shared.prefs.hotKey.display)"
            // Accept file drops on the icon.
            button.window?.registerForDraggedTypes([.fileURL])
            button.window?.delegate = self
        }
        self.item = item
        popover.behavior = .transient
        popover.animates = true
        popover.delegate = self
    }

    func setVisible(_ visible: Bool) {
        if visible { install() } else if let item {
            NSStatusBar.system.removeStatusItem(item)
            self.item = nil
        }
    }

    /// Template hexagon icon drawn in code (follows light/dark menu bar automatically).
    static func icon() -> NSImage {
        let size = NSSize(width: 18, height: 18)
        let image = NSImage(size: size, flipped: false) { rect in
            let c = CGPoint(x: rect.midX, y: rect.midY)
            let r: CGFloat = 7.6
            let path = NSBezierPath()
            for i in 0..<6 {
                let a = CGFloat(i) * .pi / 3
                let p = CGPoint(x: c.x + r * cos(a), y: c.y + r * sin(a))
                if i == 0 { path.move(to: p) } else { path.line(to: p) }
            }
            path.close()
            path.lineWidth = 1.6
            path.lineJoinStyle = .round
            NSColor.black.setStroke()
            path.stroke()
            // Inner arrow-ish chevrons suggesting "shift"
            let inner = NSBezierPath()
            inner.move(to: CGPoint(x: c.x - 3, y: c.y - 2.2))
            inner.line(to: CGPoint(x: c.x, y: c.y + 1.4))
            inner.line(to: CGPoint(x: c.x + 3, y: c.y - 2.2))
            inner.lineWidth = 1.6
            inner.lineCapStyle = .round
            inner.lineJoinStyle = .round
            inner.stroke()
            return true
        }
        image.isTemplate = true
        return image
    }

    @objc private func toggle(_ sender: NSStatusBarButton) {
        if popover.isShown {
            popover.performClose(nil)
            return
        }
        let view = MenuBarPopoverView(close: { [weak self] in self?.popover.performClose(nil) })
            .environmentObject(AppState.shared)
            .hexAppearance(AppState.shared)
        popover.contentViewController = NSHostingController(rootView: view)
        popover.show(relativeTo: sender.bounds, of: sender, preferredEdge: .minY)
        popover.contentViewController?.view.window?.makeKey()
    }

    var buttonScreenPoint: NSPoint? {
        guard let button = item?.button, let window = button.window else { return nil }
        let rect = window.convertToScreen(button.convert(button.bounds, to: nil))
        return NSPoint(x: rect.midX, y: rect.minY)
    }

    // MARK: Drop files on the menu-bar icon

    nonisolated func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation { .copy }

    nonisolated func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        let urls = (sender.draggingPasteboard.readObjects(forClasses: [NSURL.self], options: [.urlReadingFileURLsOnly: true]) as? [URL]) ?? []
        guard !urls.isEmpty else { return false }
        Task { @MainActor in
            let point = self.buttonScreenPoint.map { NSPoint(x: $0.x, y: $0.y - 200) }
            ActionRunner.shared.showMenu(for: urls, at: point)
        }
        return true
    }
}

@MainActor
struct MenuBarPopoverView: View {
    @EnvironmentObject var state: AppState
    let close: () -> Void
    /// The Home window opens the wheel at the pointer rather than under the menu bar icon.
    var wheelAtPointer = false

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack(spacing: 8) {
                Image(systemName: "hexagon.fill").foregroundStyle(state.accentColor).font(.system(size: 16))
                VStack(alignment: .leading, spacing: 0) {
                    Text("HEXSHIFT").font(.system(size: 13, weight: .bold))
                    Text("Select anything. Create anything.").font(.system(size: 10.5)).foregroundStyle(.secondary)
                }
                Spacer()
                Text(state.prefs.hotKey.display)
                    .font(.system(size: 10.5, weight: .medium, design: .rounded))
                    .padding(.horizontal, 6).padding(.vertical, 2)
                    .background(Capsule().fill(Color.primary.opacity(0.07)))
            }
            .padding(.horizontal, 10)
            .padding(.bottom, 8)

            row("Open the Wheel", "hexagon") {
                let anchor = wheelAtPointer ? nil : MenuBarController.shared.buttonScreenPoint.map { NSPoint(x: $0.x, y: $0.y - 220) }
                RadialMenuController.shared.show(context: .empty, at: anchor)
            }
            row("Convert Clipboard", "doc.on.clipboard") { ActionRunner.shared.convertClipboard() }
            row("Capture Screen", "camera.viewfinder") { ActionRunner.shared.captureAndShowMenu(.region) }
            row("Pick Colour", "eyedropper") { ActionRunner.shared.pickColour() }
            row("Find Font", "textformat.size") {
                ActionRunner.shared.perform(RadialAction(id: "type.findFont", title: "Find Font", detail: "", symbol: "textformat.size"), context: .empty)
            }
            Divider().padding(.vertical, 4)
            Text("RECENT ACTIONS").font(.system(size: 9.5, weight: .semibold)).foregroundStyle(.secondary).padding(.horizontal, 10).padding(.top, 2)
            if state.topRecentActions.isEmpty {
                Text("Nothing yet").font(.system(size: 11.5)).foregroundStyle(.secondary).padding(.horizontal, 10).padding(.vertical, 4)
            }
            ForEach(state.topRecentActions) { r in
                row(r.title, r.symbol) {
                    ActionRunner.shared.replayRecent(r)
                }
            }
            if !state.recentFileURLs.isEmpty {
                Menu {
                    ForEach(state.recentFileURLs.prefix(10), id: \.self) { url in
                        Button(url.lastPathComponent) { ActionRunner.shared.showMenu(for: [url]) }
                    }
                } label: {
                    Label("Recent Files", systemImage: "clock.arrow.circlepath")
                }
                .menuStyle(.borderlessButton)
                .padding(.horizontal, 10)
                .padding(.vertical, 4)
            }
            Divider().padding(.vertical, 4)
            row("Designer Tools", "wrench.and.screwdriver") { Windows.openDesignerTools() }
            row("Colour Lens", "swatchpalette") { Windows.openColourLens(.history) }
            row("Preferences…", "gearshape") { Windows.openSettings() }
            row("Quit HEXSHIFT", "power") { NSApp.terminate(nil) }
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 6)
        .frame(width: 270)
    }

    private func row(_ title: String, _ symbol: String, action: @escaping () -> Void) -> some View {
        PopoverRow(title: title, symbol: symbol) {
            close()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) { action() }
        }
    }
}

@MainActor
private struct PopoverRow: View {
    let title: String
    let symbol: String
    let action: () -> Void
    @State private var hovering = false
    @EnvironmentObject var state: AppState

    var body: some View {
        Button(action: action) {
            HStack(spacing: 9) {
                Image(systemName: symbol).frame(width: 18).foregroundStyle(hovering ? .white : state.accentColor)
                Text(title).font(.system(size: 12.5))
                Spacer()
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .foregroundStyle(hovering ? Color.white : Color.primary)
            .background(RoundedRectangle(cornerRadius: 6).fill(hovering ? state.accentColor : Color.clear))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .onHover { hovering = $0 }
    }
}
