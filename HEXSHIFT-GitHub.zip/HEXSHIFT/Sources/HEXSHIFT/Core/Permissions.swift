import AppKit
import ApplicationServices
import CoreGraphics
import SwiftUI

enum Permission: String, CaseIterable, Identifiable {
    case accessibility, screenRecording, automation

    var id: String { rawValue }

    var title: String {
        switch self {
        case .accessibility: return "Accessibility"
        case .screenRecording: return "Screen & System Audio Recording"
        case .automation: return "Automation (Finder)"
        }
    }

    /// Why HEXSHIFT asks — shown before macOS's own prompt.
    var reason: String {
        switch self {
        case .accessibility:
            return "Allow Accessibility so HEXSHIFT can read text you have selected in other apps and the font it uses. HEXSHIFT never monitors your typing."
        case .screenRecording:
            return "Allow screen capture to identify colours, text and fonts from visible screen content. HEXSHIFT only captures when you ask it to and never records continuously."
        case .automation:
            return "Allow HEXSHIFT to ask Finder which files are selected, so the shortcut can act on them."
        }
    }

    var settingsURL: URL {
        let anchor: String
        switch self {
        case .accessibility: anchor = "Privacy_Accessibility"
        case .screenRecording: anchor = "Privacy_ScreenCapture"
        case .automation: anchor = "Privacy_Automation"
        }
        return URL(string: "x-apple.systempreferences:com.apple.preference.security?\(anchor)")!
    }
}

@MainActor
enum Permissions {
    static var accessibilityGranted: Bool { AXIsProcessTrusted() }
    static var screenRecordingGranted: Bool { CGPreflightScreenCaptureAccess() }

    /// noErr = allowed, -1743 = denied, -1744 = not yet asked, -600 = Finder not running.
    static func automationStatus(bundleID: String = "com.apple.finder", ask: Bool = false) -> OSStatus {
        let target = NSAppleEventDescriptor(bundleIdentifier: bundleID)
        guard let desc = target.aeDesc else { return OSStatus(procNotFound) }
        return AEDeterminePermissionToAutomateTarget(desc, AEEventClass(typeWildCard), AEEventID(typeWildCard), ask)
    }

    static func isGranted(_ p: Permission) -> Bool {
        switch p {
        case .accessibility: return accessibilityGranted
        case .screenRecording: return screenRecordingGranted
        case .automation: return automationStatus() == noErr
        }
    }

    static func request(_ p: Permission) {
        switch p {
        case .accessibility:
            let options = ["AXTrustedCheckOptionPrompt": true] as CFDictionary
            _ = AXIsProcessTrustedWithOptions(options)
        case .screenRecording:
            if !CGRequestScreenCaptureAccess() { openSettings(p) }
        case .automation:
            _ = automationStatus(ask: true)
        }
    }

    static func openSettings(_ p: Permission) {
        NSWorkspace.shared.open(p.settingsURL)
    }

    /// Explains a missing permission in plain words, with a way to fix it.
    static func explain(_ p: Permission) {
        let alert = NSAlert()
        alert.messageText = "\(p.title) permission is required for this action."
        alert.informativeText = p.reason + "\n\nAfter allowing it in System Settings, you may need to quit and reopen HEXSHIFT."
        alert.addButton(withTitle: "Open System Settings")
        alert.addButton(withTitle: "Not Now")
        alert.alertStyle = .informational
        NSApp.activate()
        alert.window.level = .modalPanel   // stay above other apps, so it can't hide behind them
        if alert.runModal() == .alertFirstButtonReturn {
            if p == .accessibility || p == .screenRecording { request(p) }
            openSettings(p)
        }
    }
}
