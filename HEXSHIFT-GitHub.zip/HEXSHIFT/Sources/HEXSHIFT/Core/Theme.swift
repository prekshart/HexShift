import AppKit
import HexshiftKit
import SwiftUI

/// HEXSHIFT's visual language: warm off-white surfaces, charcoal type, one accent.
struct HexPalette {
    let surface: Color
    let surfaceStrong: Color
    let plateTint: Color
    let text: Color
    let secondaryText: Color
    let stroke: Color
    let accent: Color
    let accentSoft: Color
    let onAccent: Color
    let shadow: Color
    let highContrast: Bool

    static func make(scheme: ColorScheme, contrast: ColorSchemeContrast, accent: RGBAColour) -> HexPalette {
        let hc = contrast == .increased
        let acc = Color(.sRGB, red: accent.r, green: accent.g, blue: accent.b, opacity: 1)
        if scheme == .dark {
            return HexPalette(
                surface: Color(.sRGB, red: 0.19, green: 0.18, blue: 0.17, opacity: hc ? 1 : 0.94),
                surfaceStrong: Color(.sRGB, red: 0.24, green: 0.225, blue: 0.21, opacity: 1),
                plateTint: Color(.sRGB, red: 0.12, green: 0.11, blue: 0.105, opacity: hc ? 0.95 : 0.55),
                text: Color(.sRGB, red: 0.96, green: 0.94, blue: 0.91, opacity: 1),
                secondaryText: Color(.sRGB, red: 0.68, green: 0.65, blue: 0.61, opacity: hc ? 1 : 0.95),
                stroke: Color.white.opacity(hc ? 0.55 : 0.09),
                accent: acc,
                accentSoft: acc.opacity(0.22),
                onAccent: .white,
                shadow: Color.black.opacity(0.45),
                highContrast: hc
            )
        }
        return HexPalette(
            surface: Color(.sRGB, red: 1.0, green: 0.992, blue: 0.976, opacity: hc ? 1 : 0.93),
            surfaceStrong: Color(.sRGB, red: 0.965, green: 0.945, blue: 0.918, opacity: 1),
            plateTint: Color(.sRGB, red: 0.985, green: 0.965, blue: 0.94, opacity: hc ? 0.98 : 0.6),
            text: Color(.sRGB, red: 0.17, green: 0.165, blue: 0.157, opacity: 1),
            secondaryText: Color(.sRGB, red: 0.45, green: 0.43, blue: 0.40, opacity: 1),
            stroke: Color.black.opacity(hc ? 0.6 : 0.07),
            accent: acc,
            accentSoft: acc.opacity(0.14),
            onAccent: .white,
            shadow: Color(.sRGB, red: 0.25, green: 0.18, blue: 0.12, opacity: 0.22),
            highContrast: hc
        )
    }
}

/// Environment-aware palette for any SwiftUI view.
@MainActor
struct PaletteReader<Content: View>: View {
    @EnvironmentObject var state: AppState
    @Environment(\.colorScheme) var scheme
    @Environment(\.colorSchemeContrast) var contrast
    let content: (HexPalette) -> Content

    var body: some View {
        content(HexPalette.make(scheme: scheme, contrast: contrast, accent: state.prefs.accentRGB))
    }
}

/// NSVisualEffectView with an optional shape mask (behind-window blur).
struct VisualEffectBackground: NSViewRepresentable {
    var material: NSVisualEffectView.Material = .popover
    var blending: NSVisualEffectView.BlendingMode = .behindWindow
    var maskPath: CGPath?
    var size: CGSize = .zero

    func makeNSView(context: Context) -> NSVisualEffectView {
        let v = NSVisualEffectView()
        v.state = .active
        v.material = material
        v.blendingMode = blending
        update(v)
        return v
    }

    func updateNSView(_ v: NSVisualEffectView, context: Context) {
        v.material = material
        v.blendingMode = blending
        update(v)
    }

    private func update(_ v: NSVisualEffectView) {
        guard let path = maskPath, size.width > 0 else {
            v.maskImage = nil
            return
        }
        let s = size
        v.maskImage = NSImage(size: s, flipped: true) { _ in
            guard let ctx = NSGraphicsContext.current?.cgContext else { return false }
            ctx.addPath(path)
            ctx.setFillColor(NSColor.black.cgColor)
            ctx.fillPath()
            return true
        }
    }
}

// MARK: - Small shared components

@MainActor
struct SectionCard<Content: View>: View {
    var title: String?
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let title {
                Text(title).font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary).textCase(.uppercase)
            }
            content
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.primary.opacity(0.04)))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).strokeBorder(Color.primary.opacity(0.06)))
    }
}

struct AccentButtonStyle: ButtonStyle {
    @EnvironmentObject var state: AppState
    var prominent = true

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 12.5, weight: .semibold))
            .padding(.horizontal, 14)
            .padding(.vertical, 7)
            .foregroundStyle(prominent ? Color.white : state.accentColor)
            .background(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(prominent ? state.accentColor : state.accentColor.opacity(0.12))
            )
            .opacity(configuration.isPressed ? 0.8 : 1)
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
    }
}

@MainActor
struct CopyField: View {
    let label: String
    let value: String
    @State private var copied = false

    var body: some View {
        HStack(spacing: 8) {
            Text(label)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.secondary)
                .frame(width: 74, alignment: .leading)
            Text(value)
                .font(.system(size: 12.5, design: .monospaced))
                .textSelection(.enabled)
                .lineLimit(1)
                .truncationMode(.middle)
            Spacer(minLength: 4)
            Button {
                Clipboard.copy(value)
                copied = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { copied = false }
            } label: {
                Image(systemName: copied ? "checkmark" : "doc.on.doc")
                    .frame(width: 16)
            }
            .buttonStyle(.borderless)
            .help("Copy \(label)")
            .accessibilityLabel("Copy \(label)")
        }
        .padding(.vertical, 2)
    }
}

@MainActor
struct Swatch: View {
    let colour: RGBAColour
    var size: CGFloat = 28
    var selected = false

    var body: some View {
        RoundedRectangle(cornerRadius: size * 0.25, style: .continuous)
            .fill(Color(.sRGB, red: colour.r, green: colour.g, blue: colour.b, opacity: colour.a))
            .frame(width: size, height: size)
            .overlay(RoundedRectangle(cornerRadius: size * 0.25, style: .continuous).strokeBorder(Color.primary.opacity(selected ? 0.8 : 0.12), lineWidth: selected ? 2 : 1))
            .accessibilityLabel("\(ColourMath.approximateName(colour)) \(colour.hex)")
    }
}

/// Checkerboard used behind transparent images.
@MainActor
struct Checkerboard: View {
    var size: CGFloat = 10
    var body: some View {
        Canvas { ctx, s in
            let cols = Int(ceil(s.width / size)), rows = Int(ceil(s.height / size))
            ctx.fill(Path(CGRect(origin: .zero, size: s)), with: .color(Color(white: 0.96)))
            for r in 0..<rows {
                for c in 0..<cols where (r + c) % 2 == 0 {
                    ctx.fill(Path(CGRect(x: CGFloat(c) * size, y: CGFloat(r) * size, width: size, height: size)), with: .color(Color(white: 0.86)))
                }
            }
        }
    }
}

enum Clipboard {
    /// The pasteboard change count after HEXSHIFT's own last write, so the clipboard monitor
    /// doesn't make suggestions about things HEXSHIFT itself copied.
    static var lastOwnChangeCount = -1

    static func copy(_ string: String) {
        let pb = NSPasteboard.general
        pb.clearContents()
        pb.setString(string, forType: .string)
        lastOwnChangeCount = pb.changeCount
    }

    static func copy(image: CGImage) {
        let pb = NSPasteboard.general
        pb.clearContents()
        let rep = NSBitmapImageRep(cgImage: image)
        pb.declareTypes([.png, .tiff], owner: nil)
        if let png = rep.representation(using: .png, properties: [:]) { pb.setData(png, forType: .png) }
        if let tiff = rep.tiffRepresentation { pb.setData(tiff, forType: .tiff) }
        lastOwnChangeCount = pb.changeCount
    }

    static func copy(files: [URL]) {
        let pb = NSPasteboard.general
        pb.clearContents()
        pb.writeObjects(files as [NSURL])
        lastOwnChangeCount = pb.changeCount
    }
}

extension RGBAColour {
    var swiftUIColor: Color { Color(.sRGB, red: r, green: g, blue: b, opacity: a) }
    var nsColor: NSColor { NSColor(srgbRed: r, green: g, blue: b, alpha: a) }

    init(nsColor: NSColor) {
        let c = nsColor.usingColorSpace(.sRGB) ?? nsColor.usingColorSpace(.deviceRGB) ?? .black
        self.init(r: Double(c.redComponent), g: Double(c.greenComponent), b: Double(c.blueComponent), a: Double(c.alphaComponent))
    }

    init(color: Color) {
        self.init(nsColor: NSColor(color))
    }
}

extension View {
    /// Applies the user's light/dark preference.
    @MainActor
    func hexAppearance(_ state: AppState) -> some View {
        preferredColorScheme(state.prefs.appearance.colorScheme)
    }
}

/// Converts NSImage <-> CGImage conveniently.
extension NSImage {
    var cgImageValue: CGImage? {
        var rect = CGRect(origin: .zero, size: size)
        return cgImage(forProposedRect: &rect, context: nil, hints: nil)
    }

    convenience init(cg: CGImage) {
        self.init(cgImage: cg, size: NSSize(width: cg.width, height: cg.height))
    }
}
