import AppKit
import Foundation
import HexshiftKit

/// Browsers can't load an unpacked extension from inside an app bundle, so a copy is kept in
/// ~/Library/Application Support/HEXSHIFT/Browser Extension and refreshed in place on update
/// (an already-loaded extension keeps pointing at the same folder).
enum BrowserExtensionInstaller {
    static func prepare() -> URL? {
        guard let source = Bundle.main.url(forResource: "Browser Extension", withExtension: nil) else { return nil }
        let fm = FileManager.default
        guard let support = try? fm.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true) else {
            return source
        }
        let base = support.appendingPathComponent("HEXSHIFT", isDirectory: true)
        let dest = base.appendingPathComponent("Browser Extension", isDirectory: true)
        do {
            try fm.createDirectory(at: base, withIntermediateDirectories: true)
            if fm.fileExists(atPath: dest.path) {
                for item in try fm.contentsOfDirectory(at: source, includingPropertiesForKeys: nil) {
                    let target = dest.appendingPathComponent(item.lastPathComponent)
                    if fm.fileExists(atPath: target.path) { try fm.removeItem(at: target) }
                    try fm.copyItem(at: item, to: target)
                }
            } else {
                try fm.copyItem(at: source, to: dest)
            }
            return dest
        } catch {
            return source
        }
    }
}

/// The optional Finder Quick Action ("Open in HEXSHIFT" under right-click › Quick Actions).
/// It is a tiny Automator workflow that runs `open -b app.hexshift.HEXSHIFT <files>`; the app's
/// own Services entry works without it, but Finder lists Quick Actions more prominently.
enum QuickActionInstaller {
    static let bundledName = "Open in HEXSHIFT"

    static var installedURL: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/Services", isDirectory: true)
            .appendingPathComponent("\(bundledName).workflow", isDirectory: true)
    }

    static var bundledURL: URL? { Bundle.main.url(forResource: bundledName, withExtension: "workflow") }
    static var isInstalled: Bool { FileManager.default.fileExists(atPath: installedURL.path) }

    static func install() throws {
        guard let source = bundledURL else { throw CocoaError(.fileNoSuchFile) }
        let fm = FileManager.default
        try fm.createDirectory(at: installedURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        if fm.fileExists(atPath: installedURL.path) { try fm.removeItem(at: installedURL) }
        try fm.copyItem(at: source, to: installedURL)
        refreshServices()
    }

    /// Removes only the workflow HEXSHIFT installed (moved to the Trash, so it can be restored).
    static func uninstall() throws {
        guard isInstalled else { return }
        try FileManager.default.trashItem(at: installedURL, resultingItemURL: nil)
        refreshServices()
    }

    static func refreshServices() {
        NSUpdateDynamicServices()
        DispatchQueue.global(qos: .utility).async {
            _ = try? ExternalTools.run("/System/Library/CoreServices/pbs", ["-update"], timeout: 20)
        }
    }
}
