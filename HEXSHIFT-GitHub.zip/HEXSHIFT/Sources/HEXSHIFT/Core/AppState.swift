import AppKit
import Carbon.HIToolbox
import Combine
import HexshiftKit
import SwiftUI

// MARK: - Preference types

struct HotKeyCombo: Codable, Equatable, Hashable {
    var keyCode: UInt32
    /// Carbon modifier mask (cmdKey, optionKey, controlKey, shiftKey)
    var modifiers: UInt32
    var display: String

    static let optionSpace = HotKeyCombo(keyCode: UInt32(kVK_Space), modifiers: UInt32(optionKey), display: "⌥ Space")
}

enum WheelSize: String, Codable, CaseIterable, Identifiable {
    case small, medium, large
    var id: String { rawValue }
    var scale: CGFloat {
        switch self {
        case .small: return 0.86
        case .medium: return 1
        case .large: return 1.14
        }
    }
    var title: String { rawValue.capitalized }
}

enum AccentChoice: String, Codable, CaseIterable, Identifiable {
    case coral, orange, amber, green, teal, blue, indigo, pink, graphite
    var id: String { rawValue }
    var title: String { rawValue.capitalized }
    var rgb: RGBAColour {
        switch self {
        case .coral: return RGBAColour(r: 1.0, g: 0.416, b: 0.302)
        case .orange: return RGBAColour(r: 0.98, g: 0.55, b: 0.18)
        case .amber: return RGBAColour(r: 0.95, g: 0.70, b: 0.15)
        case .green: return RGBAColour(r: 0.20, g: 0.68, b: 0.42)
        case .teal: return RGBAColour(r: 0.09, g: 0.63, b: 0.52)
        case .blue: return RGBAColour(r: 0.20, g: 0.47, b: 0.96)
        case .indigo: return RGBAColour(r: 0.36, g: 0.36, b: 0.86)
        case .pink: return RGBAColour(r: 0.93, g: 0.32, b: 0.55)
        case .graphite: return RGBAColour(r: 0.42, g: 0.41, b: 0.40)
        }
    }
}

enum AnimationSpeed: String, Codable, CaseIterable, Identifiable {
    case gentle, normal, fast, off
    var id: String { rawValue }
    var title: String { rawValue.capitalized }
    var factor: Double {
        switch self {
        case .gentle: return 1.4
        case .normal: return 1
        case .fast: return 0.65
        case .off: return 0
        }
    }
}

enum AppearanceChoice: String, Codable, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var title: String { rawValue.capitalized }
    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}

enum ColourCopyFormat: String, Codable, CaseIterable, Identifiable {
    case hex, rgb, hsl, css
    var id: String { rawValue }
    var title: String {
        switch self {
        case .hex: return "HEX (#16A085)"
        case .rgb: return "RGB (22, 160, 133)"
        case .hsl: return "HSL (168°, 76%, 36%)"
        case .css: return "CSS rgb()"
        }
    }
}

enum ModifierClickChoice: String, Codable, CaseIterable, Identifiable {
    case controlOption, option, commandOption, controlShift
    var id: String { rawValue }
    var title: String {
        switch self {
        case .controlOption: return "⌃⌥ + right-click"
        case .option: return "⌥ + right-click"
        case .commandOption: return "⌘⌥ + right-click"
        case .controlShift: return "⌃⇧ + right-click"
        }
    }
    var flags: NSEvent.ModifierFlags {
        switch self {
        case .controlOption: return [.control, .option]
        case .option: return [.option]
        case .commandOption: return [.command, .option]
        case .controlShift: return [.control, .shift]
        }
    }
}

struct Preferences: Codable, Equatable {
    // General
    var showMenuBarIcon = true
    /// Opening HEXSHIFT from Applications / Spotlight / Launchpad shows the Home window.
    var showHomeOnLaunch = true
    var output = OutputSettings()
    // Activation
    var hotKeyEnabled = true
    var hotKey = HotKeyCombo.optionSpace
    var dragConvertEnabled = true
    var dragAskForSettings = false
    // Radial menu
    var wheelSize: WheelSize = .medium
    var accent: AccentChoice = .coral
    var customAccentHex: String?
    var animationSpeed: AnimationSpeed = .normal
    var appearance: AppearanceChoice = .system
    var segmentOrder: [PrimarySegment] = PrimarySegment.allCases
    var showRecentActions = true
    // Optional modifier + right-click gesture that opens the wheel (needs Accessibility).
    var modifierClickEnabled = false
    var modifierClick: ModifierClickChoice = .controlOption
    // Clipboard suggestions (off by default; nothing is stored)
    var clipboardSuggestions = false
    var clipboardExcludedApps: [String] = ClipboardDefaults.exclusions
    var haptics = true
    // Conversion
    var preferredFormats: [Format] = [.png, .jpeg, .webp, .heic, .pdf, .svg, .avif, .tiff, .gif, .ico]
    var jpegQuality = 0.85
    var heicQuality = 0.80
    var webpQuality = 0.82
    var avifQuality = 0.60
    var metadataPolicy: MetadataPolicy = .stripGPS
    var pdfDPI = 150.0
    var batchConcurrency = 0
    var useExternalEngines = true
    var svgRenderScale = 2.0
    // Colour
    var autoCopyPickedColour = true
    var colourCopyFormat: ColourCopyFormat = .hex
    // Typography
    var fontMatchAllWeights = true
    var fontSampleText = "Sphinx of black quartz, judge my vow"
    // Privacy
    var rememberRecents = true
    // Onboarding
    var hasCompletedOnboarding = false

    func quality(for format: Format) -> Double {
        switch format {
        case .jpeg, .jp2: return jpegQuality
        case .heic: return heicQuality
        case .webp: return webpQuality
        case .avif: return avifQuality
        default: return 0.9
        }
    }

    var accentRGB: RGBAColour {
        if let hex = customAccentHex, let c = RGBAColour(hex: hex) { return c }
        return accent.rgb
    }

    /// Loads stored preferences, filling any missing keys from defaults
    /// (so new versions never lose a user's settings).
    static func load(from defaults: UserDefaults) -> Preferences {
        guard let stored = defaults.data(forKey: "preferences.v1") else { return Preferences() }
        do {
            let base = try JSONSerialization.jsonObject(with: JSONEncoder().encode(Preferences())) as? [String: Any] ?? [:]
            let saved = try JSONSerialization.jsonObject(with: stored) as? [String: Any] ?? [:]
            let merged = base.merging(saved) { _, new in new }
            let data = try JSONSerialization.data(withJSONObject: merged)
            return try JSONDecoder().decode(Preferences.self, from: data)
        } catch {
            return Preferences()
        }
    }

    func save(to defaults: UserDefaults) {
        if let data = try? JSONEncoder().encode(self) { defaults.set(data, forKey: "preferences.v1") }
    }
}

// MARK: - Persistent local state

struct RecentAction: Codable, Identifiable, Equatable {
    var id: String
    var title: String
    var symbol: String
    var count: Int
    var lastUsed: Date
}

struct NamedColour: Codable, Identifiable, Equatable, Hashable {
    var id = UUID()
    var name: String
    var colour: RGBAColour
}

struct SavedPalette: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var colours: [NamedColour]
    var created = Date()
}

struct FavouriteAction: Codable, Identifiable, Equatable {
    var id: String
    var title: String
    var symbol: String
}

struct LocalStore: Codable {
    var recentActions: [RecentAction] = []
    var recentFiles: [String] = []
    var colourHistory: [RGBAColour] = []
    var palettes: [SavedPalette] = []
    var favouriteFonts: [String] = []
    var workflows: [Workflow] = []
    var favouriteActions: [FavouriteAction] = []
    /// Workflow id (uuidString) → its own global shortcut.
    var workflowShortcuts: [String: HotKeyCombo] = [:]

    /// Tolerant loading: fields added in newer versions get their defaults instead of failing.
    static func load(from data: Data) -> LocalStore? {
        guard let base = try? JSONSerialization.jsonObject(with: JSONEncoder().encode(LocalStore())) as? [String: Any],
              let saved = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        let merged = base.merging(saved) { _, new in new }
        guard let mergedData = try? JSONSerialization.data(withJSONObject: merged) else { return nil }
        return try? JSONDecoder().decode(LocalStore.self, from: mergedData)
    }
}

/// Central app state: preferences + locally stored history. Nothing here leaves the Mac.
@MainActor
final class AppState: ObservableObject {
    static let shared = AppState()

    let defaults: UserDefaults
    @Published var prefs: Preferences {
        didSet {
            guard prefs != oldValue else { return }
            prefs.save(to: defaults)
            prefsChanged.send((oldValue, prefs))
        }
    }

    @Published var store = LocalStore() {
        didSet { scheduleSave() }
    }

    /// (old, new) — observers re-register hotkeys, toggle the drag monitor, etc.
    let prefsChanged = PassthroughSubject<(Preferences, Preferences), Never>()

    private var saveTask: Task<Void, Never>?
    let storeURL: URL

    init(defaults: UserDefaults = .standard, storeURL: URL? = nil) {
        self.defaults = defaults
        prefs = Preferences.load(from: defaults)
        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
            .appendingPathComponent("HEXSHIFT", isDirectory: true)
        try? FileManager.default.createDirectory(at: support, withIntermediateDirectories: true)
        self.storeURL = storeURL ?? support.appendingPathComponent("local-store.json")
        if let data = try? Data(contentsOf: self.storeURL), let s = LocalStore.load(from: data) {
            store = s
        }
    }

    private func scheduleSave() {
        saveTask?.cancel()
        let url = storeURL
        let snapshot = store
        saveTask = Task {
            try? await Task.sleep(nanoseconds: 400_000_000)
            guard !Task.isCancelled else { return }
            if let data = try? JSONEncoder().encode(snapshot) {
                try? data.write(to: url, options: .atomic)
            }
        }
    }

    // MARK: Derived

    var accentColor: Color { Color(nsColor: accentNSColor) }
    var accentNSColor: NSColor {
        let c = prefs.accentRGB
        return NSColor(srgbRed: c.r, green: c.g, blue: c.b, alpha: 1)
    }

    var allWorkflows: [Workflow] { Workflow.builtIns + store.workflows }

    var imageExportDefaults: ImageExportOptions {
        var o = ImageExportOptions()
        o.metadata = prefs.metadataPolicy
        return o
    }

    func conversionOptions(for format: Format) -> ConversionOptions {
        var o = ConversionOptions()
        o.image.quality = prefs.quality(for: format)
        o.image.metadata = prefs.metadataPolicy
        o.pdfDPI = prefs.pdfDPI
        o.svgScale = prefs.svgRenderScale
        o.document.useExternalEngines = prefs.useExternalEngines
        return o
    }

    // MARK: History

    func recordAction(id: String, title: String, symbol: String) {
        guard prefs.rememberRecents else { return }
        var list = store.recentActions
        if let i = list.firstIndex(where: { $0.id == id }) {
            list[i].count += 1
            list[i].lastUsed = Date()
            list[i].title = title
        } else {
            list.append(RecentAction(id: id, title: title, symbol: symbol, count: 1, lastUsed: Date()))
        }
        // Keep the 30 most relevant.
        list.sort { score($0) > score($1) }
        store.recentActions = Array(list.prefix(30))
    }

    private func score(_ r: RecentAction) -> Double {
        let ageDays = Date().timeIntervalSince(r.lastUsed) / 86400
        return Double(r.count) * exp(-ageDays / 14)
    }

    /// The three most frequently used actions (frequency decays over two weeks).
    var topRecentActions: [RecentAction] { Array(rankedRecentActions.prefix(3)) }

    /// Every remembered action, most relevant first.
    var rankedRecentActions: [RecentAction] { store.recentActions.sorted { score($0) > score($1) } }

    func recordFiles(_ urls: [URL]) {
        guard prefs.rememberRecents else { return }
        var files = store.recentFiles
        for u in urls where !OutputPlanner.isInternalFolder(u.deletingLastPathComponent()) {
            files.removeAll { $0 == u.path }
            files.insert(u.path, at: 0)
        }
        store.recentFiles = Array(files.prefix(12))
    }

    var recentFileURLs: [URL] {
        store.recentFiles.map { URL(fileURLWithPath: $0) }.filter { FileManager.default.fileExists(atPath: $0.path) }
    }

    func addColourToHistory(_ c: RGBAColour) {
        var h = store.colourHistory
        h.removeAll { $0.hex == c.hex }
        h.insert(c, at: 0)
        store.colourHistory = Array(h.prefix(48))
    }

    func clearHistory() {
        store.recentActions = []
        store.recentFiles = []
        store.colourHistory = []
    }

    // MARK: Favourite tools (pinned in the wheel)

    func isFavourite(_ actionID: String) -> Bool { store.favouriteActions.contains { $0.id == actionID } }

    /// Returns true if the action is now a favourite.
    @discardableResult
    func toggleFavourite(_ action: RadialAction) -> Bool {
        if isFavourite(action.id) {
            store.favouriteActions.removeAll { $0.id == action.id }
            return false
        }
        store.favouriteActions.append(FavouriteAction(id: action.id, title: action.title, symbol: action.symbol))
        if store.favouriteActions.count > 8 { store.favouriteActions.removeFirst(store.favouriteActions.count - 8) }
        return true
    }

    func toggleFavouriteFont(_ postScriptName: String) {
        if store.favouriteFonts.contains(postScriptName) {
            store.favouriteFonts.removeAll { $0 == postScriptName }
        } else {
            store.favouriteFonts.append(postScriptName)
        }
    }
}
