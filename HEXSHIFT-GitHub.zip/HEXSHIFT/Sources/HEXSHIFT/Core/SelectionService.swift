import AppKit
import ApplicationServices
import HexshiftKit

/// Font information read from the app that owns a text selection (actual metadata).
struct ActualFontInfo: Equatable {
    var family: String
    var postScriptName: String?
    var displayName: String?
    var size: Double?
    var weight: Int?
    var italic: Bool = false
    var colourHex: String?
    var lineHeight: String?
    var letterSpacing: String?
    /// Where the facts came from, e.g. "Safari (Accessibility)" or "Chrome (computed CSS)".
    var source: String
}

struct SelectedText: Equatable {
    var text: String
    var attributed: NSAttributedString?
    var font: ActualFontInfo?
    var sourceApp: String?
}

enum ClipboardContent {
    case files([URL])
    case image(CGImage)
    case colour(RGBAColour, String)
    case url(URL)
    case text(String)
    case empty

    var summary: String {
        switch self {
        case let .files(u): return u.count == 1 ? u[0].lastPathComponent : "\(u.count) files"
        case .image: return "Image"
        case let .colour(_, s): return s
        case let .url(u): return u.host ?? u.absoluteString
        case let .text(t): return String(t.prefix(40))
        case .empty: return "Empty"
        }
    }
}

/// Reads what the user has selected — only at the moment they invoke HEXSHIFT.
@MainActor
enum SelectionService {
    struct Snapshot {
        var files: [URL] = []
        var text: SelectedText?
        var finderDenied = false
        var app: NSRunningApplication?
    }

    private static var finderScript: NSAppleScript? = {
        NSAppleScript(source: """
        tell application id "com.apple.finder"
            set out to ""
            repeat with itm in (get selection)
                try
                    set out to out & (POSIX path of (itm as alias)) & linefeed
                end try
            end repeat
            return out
        end tell
        """)
    }()

    static func snapshot(of app: NSRunningApplication?) -> Snapshot {
        var s = Snapshot()
        s.app = app
        guard let app else { return s }
        if app.bundleIdentifier == "com.apple.finder" {
            switch finderSelection() {
            case let .success(urls): s.files = urls
            case .failure: s.finderDenied = true
            }
            return s
        }
        if app.bundleIdentifier == Bundle.main.bundleIdentifier { return s }
        if Permissions.accessibilityGranted {
            s.text = selectedText(in: app)
        }
        return s
    }

    enum FinderError: Error { case denied, failed }

    static func finderSelection() -> Result<[URL], FinderError> {
        guard let script = finderScript else { return .failure(.failed) }
        var error: NSDictionary?
        let result = script.executeAndReturnError(&error)
        if let error {
            let code = (error[NSAppleScript.errorNumber] as? Int) ?? 0
            return .failure(code == -1743 ? .denied : .failed)
        }
        let paths = (result.stringValue ?? "").split(separator: "\n").map(String.init).filter { !$0.isEmpty }
        return .success(paths.map { URL(fileURLWithPath: $0) })
    }

    // MARK: Accessibility (selected text + its real font)

    static func selectedText(in app: NSRunningApplication) -> SelectedText? {
        let appElement = AXUIElementCreateApplication(app.processIdentifier)
        AXUIElementSetMessagingTimeout(appElement, 0.35)
        if let r = readSelection(appElement, appName: app.localizedName) { return r }
        // Chromium / Electron apps build their accessibility tree on request.
        let bundle = (app.bundleIdentifier ?? "").lowercased()
        if bundle.contains("chrome") || bundle.contains("electron") || bundle.contains("brave") || bundle.contains("edge")
            || bundle.contains("arc") || bundle.contains("vivaldi") || bundle.contains("opera") {
            AXUIElementSetAttributeValue(appElement, "AXManualAccessibility" as CFString, kCFBooleanTrue)
            return readSelection(appElement, appName: app.localizedName)
        }
        return nil
    }

    private static func readSelection(_ appElement: AXUIElement, appName: String?) -> SelectedText? {
        var focusedRef: CFTypeRef?
        guard AXUIElementCopyAttributeValue(appElement, kAXFocusedUIElementAttribute as CFString, &focusedRef) == .success,
              let focusedRef, CFGetTypeID(focusedRef) == AXUIElementGetTypeID() else { return nil }
        let element = focusedRef as! AXUIElement
        // Never read from password fields.
        var subroleRef: CFTypeRef?
        if AXUIElementCopyAttributeValue(element, kAXSubroleAttribute as CFString, &subroleRef) == .success,
           let subrole = subroleRef as? String, subrole == (kAXSecureTextFieldSubrole as String) {
            return nil
        }
        var textRef: CFTypeRef?
        guard AXUIElementCopyAttributeValue(element, kAXSelectedTextAttribute as CFString, &textRef) == .success,
              let text = textRef as? String, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return nil }
        var result = SelectedText(text: text, attributed: nil, font: nil, sourceApp: appName)
        var rangeRef: CFTypeRef?
        if AXUIElementCopyAttributeValue(element, kAXSelectedTextRangeAttribute as CFString, &rangeRef) == .success, let rangeRef {
            var attrRef: CFTypeRef?
            if AXUIElementCopyParameterizedAttributeValue(element, kAXAttributedStringForRangeParameterizedAttribute as CFString,
                                                          rangeRef, &attrRef) == .success,
               let attributed = attrRef as? NSAttributedString, attributed.length > 0 {
                result.attributed = attributed
                result.font = fontInfo(from: attributed, appName: appName ?? "App")
            }
        }
        return result
    }

    private static func fontInfo(from attributed: NSAttributedString, appName: String) -> ActualFontInfo? {
        let attrs = attributed.attributes(at: 0, effectiveRange: nil)
        guard let font = attrs[NSAttributedString.Key("AXFont")] as? [String: Any] else { return nil }
        let family = (font["AXFontFamily"] as? String) ?? (font["AXVisibleName"] as? String) ?? (font["AXFontName"] as? String) ?? "Unknown"
        var info = ActualFontInfo(family: family, postScriptName: font["AXFontName"] as? String,
                                  displayName: font["AXVisibleName"] as? String,
                                  size: (font["AXFontSize"] as? NSNumber)?.doubleValue,
                                  source: "\(appName) (reported by the app)")
        if let ps = info.postScriptName, let details = FontMatcher.details(forPostScriptName: ps) {
            info.weight = details.cssWeight
            info.italic = details.isItalic
        }
        if let colourRef = attrs[NSAttributedString.Key("AXForegroundColor")] {
            let cf = colourRef as AnyObject
            if CFGetTypeID(cf) == CGColor.typeID {
                let cg = cf as! CGColor
                if let srgb = cg.converted(to: CGColorSpace(name: CGColorSpace.sRGB)!, intent: .defaultIntent, options: nil),
                   let c = srgb.components, c.count >= 3 {
                    info.colourHex = RGBAColour(r: Double(c[0]), g: Double(c[1]), b: Double(c[2])).hex
                }
            }
        }
        return info
    }

    // MARK: Clipboard (read only when the user asks)

    static func readClipboard() -> ClipboardContent {
        let pb = NSPasteboard.general
        if let urls = pb.readObjects(forClasses: [NSURL.self], options: [.urlReadingFileURLsOnly: true]) as? [URL], !urls.isEmpty {
            return .files(urls)
        }
        if pb.canReadObject(forClasses: [NSImage.self], options: nil), let image = NSImage(pasteboard: pb), let cg = image.cgImageValue {
            return .image(cg)
        }
        if let s = pb.string(forType: .string)?.trimmingCharacters(in: .whitespacesAndNewlines), !s.isEmpty {
            if s.count <= 40, let c = ColourMath.parse(s), s.hasPrefix("#") || s.lowercased().hasPrefix("rgb") || s.lowercased().hasPrefix("hsl") {
                return .colour(c, s)
            }
            if !s.contains(" "), let u = URL(string: s), let scheme = u.scheme?.lowercased(), scheme == "http" || scheme == "https" {
                return .url(u)
            }
            return .text(s)
        }
        return .empty
    }

    /// Lightweight check that doesn't read the contents (no privacy prompt).
    static var clipboardHasContent: Bool {
        let types = NSPasteboard.general.types ?? []
        return !types.isEmpty
    }

    /// Writes clipboard image data to HEXSHIFT's private staging folder so it can be converted like a file.
    static func stageClipboardImage(_ image: CGImage) throws -> URL {
        let dir = OutputPlanner.clipboardStagingFolder()
        let url = dir.appendingPathComponent("Clipboard Image.png")
        try ImageEncoder.write(image, format: .png, to: url)
        return url
    }
}
