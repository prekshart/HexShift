import AppKit
import HexshiftKit
import SwiftUI
import UniformTypeIdentifiers

/// Watches for the explicit activation gesture — holding Shift while dragging files —
/// and only then shows the format wheel. Ordinary drags are never touched.
@MainActor
final class DragMonitor {
    static let shared = DragMonitor()

    private var monitors: [Any] = []
    private var changeCountAtMouseDown = NSPasteboard(name: .drag).changeCount
    private var shownForThisDrag = false
    private(set) var isRunning = false

    func start() {
        guard !isRunning else { return }
        isRunning = true
        if let m = NSEvent.addGlobalMonitorForEvents(matching: .leftMouseDown, handler: { [weak self] _ in
            Task { @MainActor in self?.mouseDown() }
        }) { monitors.append(m) }
        if let m = NSEvent.addGlobalMonitorForEvents(matching: .leftMouseDragged, handler: { [weak self] _ in
            Task { @MainActor in self?.dragged() }
        }) { monitors.append(m) }
        if let m = NSEvent.addGlobalMonitorForEvents(matching: .leftMouseUp, handler: { [weak self] _ in
            Task { @MainActor in self?.mouseUp() }
        }) { monitors.append(m) }
        // Shift pressed after the drag began (flagsChanged only arrives while trusted for
        // Accessibility; the drag handler below covers the untrusted case).
        if let m = NSEvent.addGlobalMonitorForEvents(matching: .flagsChanged, handler: { [weak self] _ in
            Task { @MainActor in self?.dragged() }
        }) { monitors.append(m) }
    }

    func stop() {
        monitors.forEach { NSEvent.removeMonitor($0) }
        monitors.removeAll()
        isRunning = false
    }

    private func mouseDown() {
        changeCountAtMouseDown = NSPasteboard(name: .drag).changeCount
        shownForThisDrag = false
    }

    private func dragged() {
        guard !shownForThisDrag, AppState.shared.prefs.dragConvertEnabled else { return }
        guard NSEvent.pressedMouseButtons & 1 == 1, NSEvent.modifierFlags.contains(.shift) else { return }
        let pb = NSPasteboard(name: .drag)
        // A new drag session writes to the drag pasteboard; selection drags don't.
        guard pb.changeCount != changeCountAtMouseDown else { return }
        let types = pb.types ?? []
        let carriesFiles = types.contains(.fileURL) || types.contains(NSPasteboard.PasteboardType("NSFilenamesPboardType"))
            || types.contains(where: { $0.rawValue.contains("promise") }) || types.contains(.png) || types.contains(.tiff)
        guard carriesFiles else { return }
        shownForThisDrag = true
        DragWheelController.shared.show(at: NSEvent.mouseLocation, pasteboard: pb)
    }

    private func mouseUp() {
        shownForThisDrag = false
        // Give a drop on the wheel time to be delivered before hiding.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
            if NSEvent.pressedMouseButtons & 1 == 0 { DragWheelController.shared.hide(ifIdleOnly: true) }
        }
    }
}

// MARK: - Wheel model

@MainActor
final class FormatWheelModel: ObservableObject {
    @Published var targets: [ConversionTarget] = []
    @Published var hovered: Int?
    @Published var title = "Drop on a format"
    @Published var subtitle = ""
    @Published var icon: NSImage?
    @Published var isShown = false
    @Published var isWorking = false
    var geometry = RadialGeometry()

    // Same proportions and spacing rules as the main wheel: the ring always clears the
    // centre hexagon's corners by the same margin, and every gap is the same width.
    var hexApothem: CGFloat { 50 * geometry.scale }
    var hexCorner: CGFloat { 13 * geometry.scale }
    var hexExtent: CGFloat { hexApothem / cos(.pi / 6) - hexCorner * (1 / sin(.pi / 3) - 1) }
    var ringInner: CGFloat { (hexExtent + 10 * geometry.scale).rounded() }
    var ringOuter: CGFloat { ringInner + 82 * geometry.scale }
    var plateRadius: CGFloat { ringOuter + 9 * geometry.scale }
    var canvas: CGFloat { (2 * (plateRadius + 24 * geometry.scale)).rounded(.up) }
    var centre: CGPoint { CGPoint(x: canvas / 2, y: canvas / 2) }

    func index(at p: CGPoint) -> Int? {
        let dx = p.x - centre.x, dy = p.y - centre.y
        let r = (dx * dx + dy * dy).squareRoot()
        guard r >= ringInner - 6, r <= ringOuter + 30, !targets.isEmpty else { return nil }
        let w = 360 / CGFloat(targets.count)
        var a = atan2(dy, dx) * 180 / .pi + 90 + w / 2
        a = a.truncatingRemainder(dividingBy: 360)
        if a < 0 { a += 360 }
        let i = Int(a / w) % targets.count
        return targets[i].isAvailable ? i : nil
    }
}

// MARK: - Drop target view

final class DropTargetView: NSView {
    var onUpdate: ((NSPoint?) -> NSDragOperation)?
    var onDrop: ((NSDraggingInfo) -> Bool)?

    override init(frame: NSRect) {
        super.init(frame: frame)
        registerForDraggedTypes([.fileURL, .png, .tiff, NSPasteboard.PasteboardType("NSFilenamesPboardType")]
                                + NSFilePromiseReceiver.readableDraggedTypes.map { NSPasteboard.PasteboardType($0) })
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }

    private func flipped(_ info: NSDraggingInfo) -> NSPoint {
        let p = convert(info.draggingLocation, from: nil)
        return NSPoint(x: p.x, y: bounds.height - p.y)
    }

    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation { onUpdate?(flipped(sender)) ?? [] }
    override func draggingUpdated(_ sender: NSDraggingInfo) -> NSDragOperation { onUpdate?(flipped(sender)) ?? [] }
    override func draggingExited(_ sender: NSDraggingInfo?) { _ = onUpdate?(nil) }
    override func prepareForDragOperation(_ sender: NSDraggingInfo) -> Bool { onUpdate?(flipped(sender)) != [] }
    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool { onDrop?(sender) ?? false }
}

// MARK: - Controller

@MainActor
final class DragWheelController {
    static let shared = DragWheelController()

    let model = FormatWheelModel()
    private var panel: FloatingPanel?
    private var assets: [AssetInfo] = []
    private var dropped = false

    func show(at point: NSPoint, pasteboard: NSPasteboard) {
        let state = AppState.shared
        model.geometry = RadialGeometry(scale: state.prefs.wheelSize.scale)
        let urls = (pasteboard.readObjects(forClasses: [NSURL.self], options: [.urlReadingFileURLsOnly: true]) as? [URL]) ?? []
        assets = urls.map { AssetInspector.inspect($0) }
        configureTargets(state: state)
        guard !model.targets.isEmpty else { return }
        dropped = false
        let size = CGSize(width: model.canvas, height: model.canvas)
        let p = ensurePanel(size: size)
        p.setFrame(RadialMenuController.shared.frame(around: point, size: size), display: false)
        model.hovered = nil
        model.isShown = false
        p.orderFrontRegardless()
        DispatchQueue.main.async { self.model.isShown = true }
    }

    private func configureTargets(state: AppState) {
        let order = state.prefs.preferredFormats
        if let first = assets.first {
            var common: [ConversionTarget]? = nil
            for a in assets {
                let t = ConversionEngine.targets(for: a, preferredOrder: order).filter {
                    $0.variant == .standard || $0.variant == .animated || $0.variant == .trace
                }
                common = common.map { c in c.filter { x in t.contains { $0.id == x.id } } } ?? t
            }
            model.targets = Array((common ?? []).prefix(10))
            model.title = assets.count == 1 ? first.name : "\(assets.count) files"
            model.subtitle = assets.count == 1 ? first.summary : "Drop on a format to convert all"
            model.icon = NSWorkspace.shared.icon(forFile: first.url.path)
        } else {
            // Promised files (Photos, Mail…) or raw image data: offer image formats.
            model.targets = [Format.png, .jpeg, .webp, .heic, .pdf, .tiff].filter(ImageEncoder.canWrite).map { ConversionTarget($0) }
            model.title = "Image"
            model.subtitle = "Drop on a format"
            model.icon = NSImage(systemSymbolName: "photo", accessibilityDescription: nil)
        }
    }

    private func ensurePanel(size: CGSize) -> FloatingPanel {
        if let panel {
            panel.setContentSize(size)
            return panel
        }
        let p = FloatingPanel(size: size)
        p.level = .popUpMenu
        let drop = DropTargetView(frame: NSRect(origin: .zero, size: size))
        drop.autoresizingMask = [.width, .height]
        let host = NSHostingView(rootView: FormatWheelView(model: model).environmentObject(AppState.shared).hexAppearance(AppState.shared))
        host.frame = drop.bounds
        host.autoresizingMask = [.width, .height]
        let container = NSView(frame: NSRect(origin: .zero, size: size))
        container.autoresizingMask = [.width, .height]
        container.addSubview(host)
        container.addSubview(drop) // on top, so it receives the drag
        drop.onUpdate = { [weak self] point in
            guard let self else { return [] }
            guard let point else {
                self.model.hovered = nil
                return []
            }
            let i = self.model.index(at: point)
            if i != self.model.hovered {
                self.model.hovered = i
                if i != nil, AppState.shared.prefs.haptics {
                    NSHapticFeedbackManager.defaultPerformer.perform(.alignment, performanceTime: .now)
                }
            }
            return i == nil ? [] : .copy
        }
        drop.onDrop = { [weak self] info in self?.handleDrop(info) ?? false }
        p.contentView = container
        panel = p
        return p
    }

    func hide(ifIdleOnly: Bool = false) {
        if ifIdleOnly && model.isWorking { return }
        model.isShown = false
        model.hovered = nil
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { [weak self] in
            guard let self, !self.model.isShown else { return }
            self.panel?.orderOut(nil)
        }
    }

    private func handleDrop(_ info: NSDraggingInfo) -> Bool {
        guard let i = model.hovered, i < model.targets.count else { return false }
        let target = model.targets[i]
        let pb = info.draggingPasteboard
        dropped = true
        let urls = (pb.readObjects(forClasses: [NSURL.self], options: [.urlReadingFileURLsOnly: true]) as? [URL]) ?? []
        AppState.shared.recordAction(id: "convert:\(target.id)", title: target.label, symbol: ActionCatalog.formatSymbol(target.format))
        if !urls.isEmpty {
            convert(urls, target: target)
        } else if let receivers = pb.readObjects(forClasses: [NSFilePromiseReceiver.self], options: nil) as? [NSFilePromiseReceiver], !receivers.isEmpty {
            model.isWorking = true
            let dir = OutputPlanner.clipboardStagingFolder()
            let queue = OperationQueue()
            let group = DispatchGroup()
            let collected = URLCollector()
            for r in receivers {
                group.enter()
                r.receivePromisedFiles(atDestination: dir, options: [:], operationQueue: queue) { url, error in
                    if error == nil { collected.append(url) }
                    group.leave()
                }
            }
            group.notify(queue: .main) { [weak self] in
                self?.model.isWorking = false
                self?.convert(collected.urls, target: target)
            }
        } else if let image = NSImage(pasteboard: pb), let cg = image.cgImageValue,
                  let url = try? SelectionService.stageClipboardImage(cg) {
            convert([url], target: target)
        } else {
            return false
        }
        hide()
        return true
    }

    private func convert(_ urls: [URL], target: ConversionTarget) {
        guard !urls.isEmpty else { return }
        let assets = urls.map { AssetInspector.inspect($0) }
        let state = AppState.shared
        if state.prefs.dragAskForSettings && (target.format.isLossy || target.prefersOptions) {
            Windows.openConvertOptions(assets: assets, preselect: target)
        } else if assets.count == 1 && target.prefersOptions {
            Windows.openConvertOptions(assets: assets, preselect: target)
        } else {
            ActionRunner.shared.startConversion(assets, target: target, options: state.conversionOptions(for: target.format))
        }
    }
}

final class URLCollector: @unchecked Sendable {
    private let lock = NSLock()
    private(set) var urls: [URL] = []
    func append(_ u: URL) {
        lock.lock()
        urls.append(u)
        lock.unlock()
    }
}

// MARK: - Wheel view

@MainActor
struct FormatWheelView: View {
    @ObservedObject var model: FormatWheelModel
    @EnvironmentObject var state: AppState
    @Environment(\.colorScheme) private var scheme
    @Environment(\.colorSchemeContrast) private var contrast
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        let p = HexPalette.make(scheme: scheme, contrast: contrast, accent: state.prefs.accentRGB)
        let s = model.geometry.scale
        let n = model.targets.count
        let w = 360 / CGFloat(max(1, n))
        let plateRect = CGRect(x: model.centre.x - model.plateRadius, y: model.centre.y - model.plateRadius,
                               width: 2 * model.plateRadius, height: 2 * model.plateRadius)
        let labels = WheelLayout.formatRing(scale: s, centre: model.centre, inner: model.ringInner, outer: model.ringOuter,
                                            gap: 5 * s, corner: 10 * s, labels: model.targets.map(\.label),
                                            notes: model.targets.map { !$0.isAvailable }, pad: 5 * s)
        let hairline: CGFloat = p.highContrast ? 1.5 : 0.75
        ZStack {
            Circle()
                .fill(p.plateTint)
                .background(VisualEffectBackground(material: scheme == .dark ? .hudWindow : .popover,
                                                   maskPath: Circle().path(in: plateRect).cgPath,
                                                   size: CGSize(width: model.canvas, height: model.canvas)))
                .overlay(Circle().stroke(p.stroke, lineWidth: hairline))
                .frame(width: plateRect.width, height: plateRect.height)
                .position(model.centre)
                .shadow(color: p.shadow, radius: 22 * s, y: 10 * s)
            ForEach(Array(model.targets.enumerated()), id: \.element.id) { i, t in
                let mid = -90 + CGFloat(i) * w
                let hovered = model.hovered == i
                let shape = RingSectorShape(centre: model.centre, inner: model.ringInner, outer: model.ringOuter,
                                            startAngle: mid - w / 2, endAngle: mid + w / 2, gap: 5 * s, corner: 10 * s)
                ZStack {
                    shape.fill(hovered ? p.accent : p.surface)
                    shape.stroke(p.stroke, lineWidth: hairline)
                    VStack(spacing: 0) {
                        Text(i < labels.texts.count ? labels.texts[i] : t.label)
                            .font(.system(size: labels.fontSize, weight: .bold))
                            .multilineTextAlignment(.center)
                            .fixedSize()
                        if !t.isAvailable {
                            Text("needs tool").font(.system(size: 8.5 * s)).frame(height: 11 * s)
                        }
                    }
                    .foregroundStyle(hovered ? p.onAccent : p.text)
                    .position(x: model.centre.x + (model.ringInner + model.ringOuter) / 2 * cos(mid * .pi / 180),
                              y: model.centre.y + (model.ringInner + model.ringOuter) / 2 * sin(mid * .pi / 180))
                }
                .opacity(t.isAvailable ? 1 : 0.4)
            }
            let hex = HexagonShape(apothem: model.hexApothem, centre: model.centre, corner: model.hexCorner)
            hex.fill(p.surfaceStrong)
            hex.stroke(p.stroke, lineWidth: hairline)
            let centreLayout: CentreText = {
                if let h = model.hovered, h < model.targets.count {
                    return CentreText.layout(model.geometry, imageSize: model.icon == nil ? nil : 30 * s,
                                             title: "→ \(model.targets[h].format.displayName)", titleSize: 12 * s, titleLines: 1,
                                             subtitle: model.targets[h].note, subtitleSize: 8.5 * s, subtitleLines: 2,
                                             apothem: model.hexApothem)
                }
                return CentreText.layout(model.geometry, imageSize: model.icon == nil ? nil : 30 * s,
                                         title: model.title, titleSize: 10.5 * s, titleLines: 1, truncateTitleInMiddle: true,
                                         subtitle: model.isWorking ? "Receiving…" : "Drop on a format", subtitleSize: 9 * s,
                                         subtitleLines: 1, apothem: model.hexApothem)
            }()
            if let icon = model.icon, let y = centreLayout.imageY {
                Image(nsImage: icon).resizable().aspectRatio(contentMode: .fit)
                    .frame(width: centreLayout.imageSize, height: centreLayout.imageSize)
                    .position(x: model.centre.x, y: model.centre.y + y)
            }
            ForEach(centreLayout.lines) { line in
                Text(line.text)
                    .font(.system(size: line.size, weight: line.isTitle ? (model.hovered != nil ? .bold : .semibold) : .regular))
                    .foregroundStyle(line.isTitle ? (model.hovered != nil ? p.accent : p.text) : p.secondaryText)
                    .lineLimit(1)
                    .fixedSize()
                    .position(x: model.centre.x, y: model.centre.y + line.y)
            }
        }
        .frame(width: model.canvas, height: model.canvas)
        .scaleEffect(model.isShown || reduceMotion ? 1 : 0.8)
        .opacity(model.isShown ? 1 : 0)
        .animation(reduceMotion ? .easeOut(duration: 0.1) : .spring(response: 0.28, dampingFraction: 0.75), value: model.isShown)
        .animation(.easeOut(duration: 0.12), value: model.hovered)
        .allowsHitTesting(false)
    }
}
