import AppKit

// HEXSHIFT entry point.
// `HEXSHIFT --smoke-test [outputFolder]` renders the UI offscreen and checks wiring, then exits.

MainActor.assumeIsolated {
    if CommandLine.arguments.contains("--smoke-test") {
        let app = NSApplication.shared
        app.setActivationPolicy(.prohibited)
        SmokeTest.run(arguments: CommandLine.arguments)
        // SmokeTest exits the process when finished.
        app.run()
    } else {
        let app = NSApplication.shared
        let delegate = AppDelegate()
        app.delegate = delegate
        withExtendedLifetime(delegate) {
            app.run()
        }
    }
}
