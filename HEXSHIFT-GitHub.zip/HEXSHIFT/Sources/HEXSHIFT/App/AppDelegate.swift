import AppKit
import Combine
import CoreServices
import HexshiftKit
import ServiceManagement

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private var cancellables = Set<AnyCancellable>()
    private let services = ServiceProvider()
    static let hotKeyID: UInt32 = 1

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        buildMainMenu()
        FileWriter.cleanStaleTemporaryFiles()
        ScreenCapture.cleanOldCaptures()

        let state = AppState.shared
        if state.prefs.showMenuBarIcon { MenuBarController.shared.install() }
        registerHotKey(state.prefs)
        if state.prefs.dragConvertEnabled { DragMonitor.shared.start() }

        NSApp.servicesProvider = services
        NSUpdateDynamicServices()

        state.prefsChanged
            .receive(on: RunLoop.main)
            .sink { [weak self] old, new in self?.apply(old: old, new: new) }
            .store(in: &cancellables)

        WorkflowHotKeys.registerAll()
        state.$store
            .map(\.workflowShortcuts)
            .removeDuplicates()
            .dropFirst()
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .sink { _ in WorkflowHotKeys.registerAll() }
            .store(in: &cancellables)

        if state.prefs.clipboardSuggestions { ClipboardMonitor.shared.start() }
        if state.prefs.modifierClickEnabled { ModifierClickMonitor.shared.start(flags: state.prefs.modifierClick.flags) }
        // Accessibility can be granted while HEXSHIFT is running; pick the gesture up when it is.
        NotificationCenter.default.publisher(for: NSApplication.didBecomeActiveNotification)
            .merge(with: NSWorkspace.shared.notificationCenter.publisher(for: NSWorkspace.didActivateApplicationNotification))
            .throttle(for: .seconds(2), scheduler: RunLoop.main, latest: true)
            .sink { _ in
                let prefs = AppState.shared.prefs
                if prefs.modifierClickEnabled && !ModifierClickMonitor.shared.isRunning && Permissions.accessibilityGranted {
                    ModifierClickMonitor.shared.start(flags: prefs.modifierClick.flags)
                }
            }
            .store(in: &cancellables)

        // No welcome window on launch: HEXSHIFT starts quietly in the menu bar. (The welcome
        // screen is still in Settings › About.)
        if !state.prefs.hasCompletedOnboarding {
            state.prefs.hasCompletedOnboarding = true
        }
        if !state.prefs.showMenuBarIcon && Self.isManualLaunch(notification) {
            // No extra window on launch: HEXSHIFT lives in the menu bar and on ⌥ Space. Only when
            // the menu bar icon is turned off is the Home window the way in.
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { Windows.openHome() }
        }
    }

    /// True when the person opened HEXSHIFT themselves (not at login, and not to open a file or link).
    private static func isManualLaunch(_ notification: Notification) -> Bool {
        let isDefault = (notification.userInfo?[NSApplication.launchIsDefaultUserInfoKey] as? Bool) ?? true
        let event = NSAppleEventManager.shared().currentAppleEvent
        let atLogin = event?.eventID == kAEOpenApplication
            && event?.paramDescriptor(forKeyword: keyAEPropData)?.enumCodeValue == keyAELaunchedAsLogInItem
        return isDefault && !atLogin
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        // Opening HEXSHIFT again (Applications, Spotlight, Launchpad) opens the wheel at the
        // pointer — straight to the tool, no in-between window.
        if !flag { RadialMenuController.shared.show(context: .empty) }
        return true
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }

    /// Files opened via "Open With", the Dock, or `open -a HEXSHIFT …`, and hexshift:// links.
    func application(_ application: NSApplication, open urls: [URL]) {
        let files = urls.filter(\.isFileURL)
        if !files.isEmpty { ActionRunner.shared.showMenu(for: files) }
        for url in urls where url.scheme == "hexshift" { URLCommands.handle(url) }
    }

    // MARK: Preferences

    private func apply(old: Preferences, new: Preferences) {
        if old.hotKey != new.hotKey || old.hotKeyEnabled != new.hotKeyEnabled { registerHotKey(new) }
        if old.dragConvertEnabled != new.dragConvertEnabled {
            if new.dragConvertEnabled { DragMonitor.shared.start() } else { DragMonitor.shared.stop() }
        }
        if old.showMenuBarIcon != new.showMenuBarIcon { MenuBarController.shared.setVisible(new.showMenuBarIcon) }
        if old.clipboardSuggestions != new.clipboardSuggestions { ClipboardMonitor.shared.setEnabled(new.clipboardSuggestions) }
        if old.modifierClickEnabled != new.modifierClickEnabled || old.modifierClick != new.modifierClick {
            if new.modifierClickEnabled {
                if !ModifierClickMonitor.shared.start(flags: new.modifierClick.flags) {
                    Permissions.request(.accessibility)
                    JobCenter.shared.message("Allow Accessibility to use \(new.modifierClick.title)",
                                             detail: "The gesture starts working as soon as HEXSHIFT is allowed in System Settings › Privacy & Security › Accessibility.")
                }
            } else {
                ModifierClickMonitor.shared.stop()
            }
        }
        if old.hotKey != new.hotKey { WorkflowHotKeys.registerAll() }
    }

    @discardableResult
    func registerHotKey(_ prefs: Preferences) -> HotKeyManager.RegistrationResult {
        guard prefs.hotKeyEnabled else {
            HotKeyManager.shared.unregister(id: Self.hotKeyID)
            return .ok
        }
        let result = HotKeyManager.shared.register(id: Self.hotKeyID, combo: prefs.hotKey) {
            Task { @MainActor in HotKeyAction.invoke() }
        }
        switch result {
        case .ok: break
        case .takenByAnotherApp:
            JobCenter.shared.message("\(prefs.hotKey.display) is already used by another app",
                                     detail: "Choose a different shortcut in HEXSHIFT Settings › Activation.", kind: .error)
        case let .reservedBySystem(why):
            JobCenter.shared.message("\(prefs.hotKey.display) can't be used", detail: why + " Choose another in Settings › Activation.", kind: .error)
        case let .failed(status):
            JobCenter.shared.message("The shortcut couldn't be registered (\(status))", kind: .error)
        }
        return result
    }

    // MARK: Menu (only visible while a HEXSHIFT window is open)

    private func buildMainMenu() {
        let main = NSMenu()
        let appItem = NSMenuItem()
        main.addItem(appItem)
        let appMenu = NSMenu(title: "HEXSHIFT")
        appMenu.addItem(withTitle: "About HEXSHIFT", action: #selector(showAbout), keyEquivalent: "").target = self
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Settings…", action: #selector(showSettings), keyEquivalent: ",").target = self
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Hide HEXSHIFT", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        appMenu.addItem(withTitle: "Quit HEXSHIFT", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu

        let editItem = NSMenuItem()
        main.addItem(editItem)
        let edit = NSMenu(title: "Edit")
        edit.addItem(withTitle: "Undo", action: Selector(("undo:")), keyEquivalent: "z")
        let redo = edit.addItem(withTitle: "Redo", action: Selector(("redo:")), keyEquivalent: "z")
        redo.keyEquivalentModifierMask = [.command, .shift]
        edit.addItem(.separator())
        edit.addItem(withTitle: "Cut", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        edit.addItem(withTitle: "Copy", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        edit.addItem(withTitle: "Paste", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        edit.addItem(withTitle: "Select All", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
        editItem.submenu = edit

        let windowItem = NSMenuItem()
        main.addItem(windowItem)
        let window = NSMenu(title: "Window")
        window.addItem(withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        window.addItem(withTitle: "Close", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
        windowItem.submenu = window
        NSApp.windowsMenu = window
        NSApp.mainMenu = main
    }

    @objc private func showAbout() {
        NSApp.activate()
        NSApp.orderFrontStandardAboutPanel(options: [
            .applicationName: "HEXSHIFT",
            .credits: NSAttributedString(string: "Select Anything. Create Anything.\n\nWebP encoding by libwebp (BSD licence). All processing happens on this Mac."),
        ])
    }

    @objc private func showSettings() { Windows.openSettings() }
}

/// What the global shortcut does: read the current selection and open the wheel.
@MainActor
enum HotKeyAction {
    static func invoke() {
        if RadialMenuController.shared.isVisible {
            RadialMenuController.shared.dismiss()
            return
        }
        let front = NSWorkspace.shared.frontmostApplication
        let snapshot = SelectionService.snapshot(of: front)
        if !snapshot.files.isEmpty {
            ActionRunner.shared.showMenu(for: snapshot.files)
        } else if let text = snapshot.text {
            RadialMenuController.shared.show(context: .text(text))
        } else {
            RadialMenuController.shared.show(context: .empty)
            if snapshot.finderDenied {
                JobCenter.shared.message("Finder selection unavailable",
                                         detail: "Allow HEXSHIFT to control Finder (System Settings › Privacy & Security › Automation) to act on selected files.")
            } else if front?.bundleIdentifier != "com.apple.finder", !Permissions.accessibilityGranted, !UserDefaults.standard.bool(forKey: "hintedAccessibility") {
                UserDefaults.standard.set(true, forKey: "hintedAccessibility")
                JobCenter.shared.message("Tip: allow Accessibility to act on selected text",
                                         detail: "HEXSHIFT can read the text you select in other apps (and its font) once you allow it in Settings › Privacy.")
            }
        }
    }
}

/// Handles hexshift:// links (used by the browser extension and Shortcuts).
/// They only open HEXSHIFT's own UI — a link can never convert or modify files on its own.
@MainActor
enum URLCommands {
    static func handle(_ url: URL) {
        let comps = URLComponents(url: url, resolvingAgainstBaseURL: false)
        var q: [String: String] = [:]
        for item in comps?.queryItems ?? [] { q[item.name] = item.value ?? "" }
        switch url.host ?? "" {
        case "menu":
            HotKeyAction.invoke()
        case "pick-colour", "pick-color":
            ActionRunner.shared.pickColour()
        case "capture":
            ActionRunner.shared.captureAndShowMenu(q["mode"] == "window" ? .window : q["mode"] == "display" ? .display : .region)
        case "font":
            var info = ActualFontInfo(family: q["family"] ?? "Unknown", postScriptName: nil, displayName: q["used"],
                                      size: q["size"].flatMap(Double.init), source: "\(q["source"] ?? "Browser") (computed CSS)")
            info.weight = q["weight"].flatMap(Int.init)
            info.italic = q["style"] == "italic"
            info.colourHex = q["color"]
            info.lineHeight = q["line-height"]
            info.letterSpacing = q["letter-spacing"]
            Windows.openFontLens(.actual(info, sample: q["text"] ?? AppState.shared.prefs.fontSampleText))
        case "open":
            if let path = q["path"], FileManager.default.fileExists(atPath: path) {
                ActionRunner.shared.showMenu(for: [URL(fileURLWithPath: path)])
            }
        case "settings":
            Windows.openSettings()
        default:
            break
        }
    }
}

/// macOS Services: "Open in HEXSHIFT" for files and "HEXSHIFT: Export Selected Text".
final class ServiceProvider: NSObject {
    @objc func openInHexshift(_ pboard: NSPasteboard, userData: String?, error: AutoreleasingUnsafeMutablePointer<NSString?>) {
        let urls = (pboard.readObjects(forClasses: [NSURL.self], options: [.urlReadingFileURLsOnly: true]) as? [URL]) ?? []
        Task { @MainActor in
            if urls.isEmpty { RadialMenuController.shared.show(context: .empty) } else { ActionRunner.shared.showMenu(for: urls) }
        }
    }

    @objc func openImage(_ pboard: NSPasteboard, userData: String?, error: AutoreleasingUnsafeMutablePointer<NSString?>) {
        guard let image = NSImage(pasteboard: pboard), let cg = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else { return }
        Task { @MainActor in
            do {
                let url = try SelectionService.stageClipboardImage(cg)
                ActionRunner.shared.showMenu(for: [url])
            } catch {
                JobCenter.shared.error(error)
            }
        }
    }

    @objc func exportText(_ pboard: NSPasteboard, userData: String?, error: AutoreleasingUnsafeMutablePointer<NSString?>) {
        guard let text = pboard.string(forType: .string), !text.isEmpty else { return }
        var attributed: NSAttributedString?
        if let rtf = pboard.data(forType: .rtf) {
            attributed = NSAttributedString(rtf: rtf, documentAttributes: nil)
        }
        let a = attributed
        Task { @MainActor in
            RadialMenuController.shared.show(context: .text(SelectedText(text: text, attributed: a, font: nil, sourceApp: "Services")))
        }
    }
}

/// Launch at Login via the modern ServiceManagement API.
@MainActor
enum LoginItem {
    static var isEnabled: Bool { SMAppService.mainApp.status == .enabled }
    static var requiresApproval: Bool { SMAppService.mainApp.status == .requiresApproval }

    static func set(_ enabled: Bool) throws {
        if enabled {
            try SMAppService.mainApp.register()
        } else {
            try SMAppService.mainApp.unregister()
        }
    }
}
