import AppKit
import HexshiftKit
import SwiftUI

/// `HEXSHIFT --smoke-test [folder]` — checks UI wiring without user interaction and
/// renders the main surfaces to PNG files for visual review. Uses a separate preferences
/// domain so it never touches real settings.
@MainActor
enum SmokeTest {
    static var failures: [String] = []
    static var passes = 0

    static func check(_ ok: Bool, _ name: String) {
        if ok { passes += 1; print("PASS  \(name)") } else { failures.append(name); print("FAIL  \(name)") }
    }

    static func run(arguments: [String]) {
        let folderArg = arguments.drop { $0 != "--smoke-test" }.dropFirst().first
        let out = URL(fileURLWithPath: folderArg ?? FileManager.default.currentDirectoryPath).appendingPathComponent("ui-snapshots")
        try? FileManager.default.createDirectory(at: out, withIntermediateDirectories: true)
        print("Writing snapshots to \(out.path)")

        let defaults = UserDefaults(suiteName: "HEXSHIFT.smoketest") ?? .standard
        defaults.removePersistentDomain(forName: "HEXSHIFT.smoketest")
        let tmpStore = FileManager.default.temporaryDirectory.appendingPathComponent("hexshift-smoke-store.json")
        let state = AppState(defaults: defaults, storeURL: tmpStore)

        // Geometry hit tests
        let g = RadialGeometry(scale: 1)
        for i in 0..<6 {
            check(g.region(at: g.primaryLabelPoint(i), openSegment: nil, ringCount: 0) == .primary(i), "primary segment \(i) hit test")
        }
        check(g.region(at: g.centre, openSegment: nil, ringCount: 0) == .centre, "centre hit test")
        for n in [3, 7, 10] {
            for k in 0..<n {
                let p = g.ringItemLabelPoint(segment: 2, index: k, count: n)
                check(g.region(at: p, openSegment: 2, ringCount: n) == .ring(k), "ring item \(k)/\(n) hit test")
            }
        }

        // Fixture image
        let fixture = FileManager.default.temporaryDirectory.appendingPathComponent("smoke-photo.png")
        if let ctx = ImageOps.makeContext(width: 400, height: 300) {
            ctx.setFillColor(RGBAColour(r: 1, g: 0.5, b: 0.3).cgColor)
            ctx.fill(CGRect(x: 0, y: 0, width: 400, height: 300))
            if let img = ctx.makeImage() { try? ImageEncoder.write(img, format: .png, to: fixture) }
        }
        let asset = AssetInspector.inspect(fixture)

        // Catalog for each context
        let pdfFixture = FileManager.default.temporaryDirectory.appendingPathComponent("smoke-catalog.pdf")
        try? FileManager.default.removeItem(at: pdfFixture)
        _ = try? PDFEngine.makePDF(fromImages: [fixture], output: pdfFixture, pageSize: .a4, margin: 36)
        let pdfAsset = AssetInspector.inspect(pdfFixture)
        let contexts: [(String, RadialContext)] = [
            ("empty", .empty),
            ("image", .files([asset])),
            ("pdf", .files([pdfAsset])),
            ("multi", .files([asset, pdfAsset])),
            ("text", .text(SelectedText(text: "Hello #16A085 world", attributed: nil, font: nil, sourceApp: "Smoke"))),
        ]
        for (name, ctx) in contexts {
            let s = ActionCatalog.build(for: ctx, state: state)
            check(PrimarySegment.allCases.contains { !(s[$0] ?? []).isEmpty }, "catalog \(name) has actions")
            check(s.values.allSatisfy { $0.count <= ActionCatalog.maxRingItems }, "catalog \(name) rings fit")
        }

        // Wheel layout guarantees: nothing overlaps, every label fits inside its shape.
        check(g.ringInner - g.plateRadius >= g.ringClearance - 0.5, "ring sits clear of the plate")
        var nearestTile = CGFloat.greatestFiniteMagnitude
        for a in stride(from: CGFloat(-90), to: 270, by: 15) {
            for q in g.ringTileOutline(angle: a) { nearestTile = min(nearestTile, hypot(q.x - g.centre.x, q.y - g.centre.y)) }
        }
        check(nearestTile >= g.plateRadius + g.ringClearance - 1, "ring tiles never touch the plate (\(Int(nearestTile)) vs \(Int(g.plateRadius)))")
        // Slices: inside the plate, clear of the hub, all the same shape.
        let hubRadius = g.centreApothem / cos(.pi / 6)
        var sliceOK = true, sliceFar: CGFloat = 0, sliceNear = CGFloat.greatestFiniteMagnitude
        for i in 0..<6 {
            let pts = g.segmentOutline(i)
            if pts.count < 20 { sliceOK = false }
            for q in pts {
                let d = hypot(q.x - g.centre.x, q.y - g.centre.y)
                sliceFar = max(sliceFar, d)
                // Distance from the hub's side facing this slice.
                let ang = RadialGeometry.rad(RadialGeometry.primaryAngle(i))
                sliceNear = min(sliceNear, (q.x - g.centre.x) * cos(ang) + (q.y - g.centre.y) * sin(ang))
            }
        }
        check(sliceOK && sliceFar <= g.primaryOuter + 0.5 && sliceFar <= g.plateRadius - g.platePadding + 0.5,
              "slices stay inside the plate (\(Int(sliceFar)) ≤ \(Int(g.primaryOuter)))")
        check(sliceNear >= g.centreApothem + g.gap - 0.5 && hubRadius < g.primaryOuter, "slices keep an even gap from the hub")
        let area0 = polygonArea(g.segmentOutline(0))
        check((1..<6).allSatisfy { abs(polygonArea(g.segmentOutline($0)) - area0) < 1 }, "all six slices are the same size")
        check(g.ringOuter <= 222, "wheel is smaller than before (ring outer \(Int(g.ringOuter)) pt)")
        check(g.recentChipCentre(index: 0, count: 5).y - g.recentChipDiameter / 2 > g.centre.y + g.plateRadius,
              "recent chips sit below the plate")
        let segmentSymbols = PrimarySegment.allCases.map(\.symbol)
        check(segmentSymbols.allSatisfy { NSImage(systemSymbolName: $0, accessibilityDescription: nil) != nil },
              "segment symbols exist (\(segmentSymbols.joined(separator: ", ")))")
        let primaryLabels = WheelLayout.primary(g, titles: PrimarySegment.allCases.map(\.shortTitle))
        check(primaryLabels.fontSize >= 11.5, "segment labels fit at \(primaryLabels.fontSize) pt")
        var missingSymbols = Set<String>()
        var ringProblems: [String] = []
        for (name, ctx) in contexts {
            let segs = ActionCatalog.build(for: ctx, state: state)
            for (i, seg) in PrimarySegment.allCases.enumerated() {
                let acts = segs[seg] ?? []
                guard !acts.isEmpty else { continue }
                for a in acts where NSImage(systemSymbolName: a.symbol, accessibilityDescription: nil) == nil { missingSymbols.insert(a.symbol) }
                let layout = WheelLayout.ring(g, segment: i, actions: acts)
                for (k, item) in layout.items.enumerated() {
                    let widest = item.text.split(separator: "\n").map { TextMetrics.width(String($0), size: layout.fontSize) }.max() ?? 0
                    if widest > item.textWidth + 0.5 { ringProblems.append("\(name)/\(seg.rawValue) overflows: \(item.text)") }
                    let own = acts[k].title + (WheelLayout.ringShortTitles[acts[k].id] ?? "")
                    if item.text.contains("…") && !own.contains("…") {
                        ringProblems.append("\(name)/\(seg.rawValue) truncated: \(item.text)")
                    }
                }
                print("      ring \(name)/\(seg.rawValue) @\(layout.fontSize)pt: "
                      + layout.items.map { $0.text.replacingOccurrences(of: "\n", with: "⏎") }.joined(separator: " · "))
                if layout.fontSize < 11 * g.scale {
                    print("        at 10pt: " + WheelLayout.ringDiagnostics(g, segment: i, actions: acts, size: 12 * g.scale).joined(separator: "; "))
                }
            }
        }
        check(missingSymbols.isEmpty, "action symbols exist" + (missingSymbols.isEmpty ? "" : ": " + missingSymbols.sorted().joined(separator: ", ")))
        check(ringProblems.isEmpty, "ring labels fit their tiles" + (ringProblems.isEmpty ? "" : ": " + ringProblems.joined(separator: "; ")))

        // Snapshots
        func snapshot<V: View>(_ view: V, size: CGSize, name: String, dark: Bool = false) {
            let window = NSWindow(contentRect: NSRect(origin: .zero, size: size), styleMask: [.borderless], backing: .buffered, defer: false)
            window.appearance = NSAppearance(named: dark ? .darkAqua : .aqua)
            let host = NSHostingView(rootView: view.environmentObject(state))
            host.frame = NSRect(origin: .zero, size: size)
            window.contentView = host
            host.layoutSubtreeIfNeeded()
            RunLoop.current.run(until: Date().addingTimeInterval(0.4))
            guard let rep = host.bitmapImageRepForCachingDisplay(in: host.bounds) else {
                check(false, "snapshot \(name)")
                return
            }
            host.cacheDisplay(in: host.bounds, to: rep)
            let url = out.appendingPathComponent("\(name).png")
            if let data = rep.representation(using: .png, properties: [:]) { try? data.write(to: url) }
            check(FileManager.default.fileExists(atPath: url.path), "snapshot \(name)")
        }

        let model = RadialMenuModel()
        model.configure(context: .files([asset]), state: state)
        model.isShown = true
        model.openSegment(0)
        model.hoveredRing = 1
        let canvas = CGSize(width: model.geometry.canvas, height: model.geometry.canvas)
        let backdrop = { (v: AnyView, dark: Bool) -> AnyView in
            AnyView(ZStack { (dark ? Color(white: 0.12) : Color(red: 0.86, green: 0.6, blue: 0.45)); v })
        }
        snapshot(backdrop(AnyView(RadialMenuView(model: model)), false), size: canvas, name: "radial-image-convert")
        snapshot(backdrop(AnyView(RadialMenuView(model: model)), true), size: canvas, name: "radial-image-convert-dark", dark: true)

        let empty = RadialMenuModel()
        empty.configure(context: .empty, state: state)
        empty.isShown = true
        empty.hoveredPrimary = 4
        empty.openSegment(4)
        snapshot(backdrop(AnyView(RadialMenuView(model: empty)), false), size: canvas, name: "radial-empty-colour")

        let textModel = RadialMenuModel()
        textModel.configure(context: .text(SelectedText(text: "Design is how it works.", attributed: nil, font: nil, sourceApp: "Safari")), state: state)
        textModel.isShown = true
        snapshot(backdrop(AnyView(RadialMenuView(model: textModel)), false), size: canvas, name: "radial-text-closed")

        // Every ring for an image, plus the PDF and text rings with the longest labels.
        let ringContexts: [(String, RadialContext)] = [("image", .files([asset])), ("pdf", .files([pdfAsset])), ("text", textModel.context)]
        for (prefix, ctx) in ringContexts {
            for i in 0..<6 {
                let m = RadialMenuModel()
                m.configure(context: ctx, state: state)
                m.isShown = true
                guard m.isEnabled(i), prefix == "image" || [2, 3, 5].contains(i) else { continue }
                m.openSegment(i)
                m.hoveredRing = 0
                snapshot(backdrop(AnyView(RadialMenuView(model: m)), false), size: canvas, name: "ring-\(prefix)-\(i)-\(m.segment(i).rawValue)")
            }
        }
        let hoverModel = RadialMenuModel()
        hoverModel.configure(context: .files([asset]), state: state)
        hoverModel.isShown = true
        hoverModel.hoveredPrimary = 4
        snapshot(backdrop(AnyView(RadialMenuView(model: hoverModel)), false), size: canvas, name: "radial-hover-colour")

        // Nothing but the wheel is drawn: the corners of the window stay fully transparent.
        do {
            let m = RadialMenuModel()
            m.configure(context: .files([asset]), state: state)
            m.isShown = true
            m.openSegment(3)
            let size = CGSize(width: m.geometry.canvas, height: m.geometry.canvas)
            let window = NSWindow(contentRect: NSRect(origin: .zero, size: size), styleMask: [.borderless], backing: .buffered, defer: false)
            window.isOpaque = false
            window.backgroundColor = .clear
            window.appearance = NSAppearance(named: .darkAqua)
            let host = NSHostingView(rootView: RadialMenuView(model: m).environmentObject(state))
            host.frame = NSRect(origin: .zero, size: size)
            window.contentView = host
            host.layoutSubtreeIfNeeded()
            RunLoop.current.run(until: Date().addingTimeInterval(0.4))
            if let rep = host.bitmapImageRepForCachingDisplay(in: host.bounds) {
                host.cacheDisplay(in: host.bounds, to: rep)
                let w = rep.pixelsWide, h = rep.pixelsHigh
                let probes = [(0.04, 0.04), (0.96, 0.04), (0.04, 0.96), (0.96, 0.96), (0.9, 0.9), (0.85, 0.12)]
                let opaque = probes.filter { (fx, fy) in (rep.colorAt(x: Int(fx * Double(w)), y: Int(fy * Double(h)))?.alphaComponent ?? 0) > 0.05 }
                check(opaque.isEmpty, "area around the wheel is transparent" + (opaque.isEmpty ? "" : " (painted at \(opaque))"))
            } else {
                check(false, "area around the wheel is transparent (no render)")
            }
        }

        // Resting on a slice shows its shortcut after a moment.
        let tipModel = RadialMenuModel()
        tipModel.configure(context: .files([asset]), state: state)
        tipModel.isShown = true
        let restAt = tipModel.geometry.primaryLabelPoint(5)
        tipModel.hover(at: restAt)
        check(tipModel.tip == nil, "tip waits before appearing")
        RunLoop.current.run(until: Date().addingTimeInterval(0.8))
        check(tipModel.tip?.detail == "press 6", "resting on slice 6 shows 'press 6' (got \(tipModel.tip?.detail ?? "nothing"))")
        snapshot(backdrop(AnyView(RadialMenuView(model: tipModel)), true), size: canvas, name: "radial-tip-shortcut-dark", dark: true)
        let mid = tipModel.geometry.primaryLabelPoint(0), c0 = tipModel.geometry.centre
        check(abs(hypot(mid.x - c0.x, mid.y - c0.y) - tipModel.geometry.sliceLabelRadius) < 0.5
              && tipModel.geometry.sliceLabelRadius > tipModel.geometry.primaryInner
              && tipModel.geometry.sliceLabelRadius < tipModel.geometry.primaryOuter, "slice labels sit at the slice's middle")
        tipModel.hover(at: nil)
        check(tipModel.tip == nil, "tip hides when the pointer leaves")
        // Greyed-out actions explain themselves.
        let blocked = RadialAction(id: "x", title: "AVIF", detail: "", symbol: "photo", enabled: false, badge: "Needs tool", reason: "Needs an AVIF encoder")
        check(blocked.reason == "Needs an AVIF encoder", "unavailable actions carry a reason")

        // Favourites row under the plate.
        let pinsModel = RadialMenuModel()
        pinsModel.configure(context: .files([asset]), state: state)
        let pinCandidates = (0..<6).flatMap { pinsModel.actions(forPrimary: $0) }.filter(\.enabled)
        for a in pinCandidates.prefix(4) { _ = state.toggleFavourite(a) }
        pinsModel.configure(context: .files([asset]), state: state)
        pinsModel.isShown = true
        snapshot(backdrop(AnyView(RadialMenuView(model: pinsModel)), false), size: canvas, name: "radial-favourites")
        for a in pinCandidates.prefix(4) { _ = state.toggleFavourite(a) }

        // Presentation renders for case studies: the dark, raised wheel in the Indigo accent
        // on a fully transparent background, written to ui-snapshots/present/.
        do {
            let presentOut = out.appendingPathComponent("present")
            try? FileManager.default.createDirectory(at: presentOut, withIntermediateDirectories: true)
            let savedAccent = state.prefs.accent
            let savedCustom = state.prefs.customAccentHex
            state.prefs.customAccentHex = nil
            state.prefs.accent = .indigo
            func present(_ m: RadialMenuModel, _ name: String, dark: Bool = true) {
                let size = CGSize(width: m.geometry.canvas, height: m.geometry.canvas)
                let window = NSWindow(contentRect: NSRect(origin: .zero, size: size), styleMask: [.borderless], backing: .buffered, defer: false)
                window.isOpaque = false
                window.backgroundColor = .clear
                window.appearance = NSAppearance(named: dark ? .darkAqua : .aqua)
                let host = NSHostingView(rootView: RadialMenuView(model: m).environment(\.colorScheme, dark ? .dark : .light).environmentObject(state))
                host.frame = NSRect(origin: .zero, size: size)
                window.contentView = host
                host.layoutSubtreeIfNeeded()
                RunLoop.current.run(until: Date().addingTimeInterval(0.4))
                guard let rep = host.bitmapImageRepForCachingDisplay(in: host.bounds) else { return }
                host.cacheDisplay(in: host.bounds, to: rep)
                if let data = rep.representation(using: .png, properties: [:]) {
                    try? data.write(to: presentOut.appendingPathComponent("\(name).png"))
                }
            }
            func makeWheel(_ ctx: RadialContext) -> RadialMenuModel {
                let m = RadialMenuModel()
                m.configure(context: ctx, state: state)
                m.isShown = true
                return m
            }
            let hero = makeWheel(.files([asset]))
            hero.openSegment(0)
            hero.hoveredRing = 1
            present(hero, "hero-convert")
            present(hero, "hero-convert-light", dark: false)
            // A greyed-out action with its reason showing in the hub.
            var shownDisabled = false
            for (prefix, ctx) in ringContexts where !shownDisabled {
                for i in 0..<6 where !shownDisabled {
                    let m = makeWheel(ctx)
                    guard m.isEnabled(i) else { continue }
                    m.openSegment(i)
                    guard let k = m.openActions.firstIndex(where: { !$0.enabled }) else { continue }
                    m.hoveredRing = k
                    present(m, "disabled-\(prefix)-\(i)")
                    present(m, "disabled-\(prefix)-\(i)-light", dark: false)
                    shownDisabled = true
                }
            }
            for (prefix, ctx) in ringContexts {
                for i in 0..<6 {
                    let m = makeWheel(ctx)
                    guard m.isEnabled(i) else { continue }
                    m.openSegment(i)
                    m.hoveredRing = 0
                    present(m, "ring-\(prefix)-\(i)-\(m.segment(i).rawValue)")
                }
            }
            // Nothing selected: each slice shows its full general set of actions.
            for i in 0..<6 {
                let m = makeWheel(.empty)
                guard m.isEnabled(i) else { continue }
                m.openSegment(i)
                m.hoveredRing = 0
                present(m, "ring-empty-\(i)-\(m.segment(i).rawValue)")
            }
            let hov = makeWheel(.files([asset]))
            hov.hoveredPrimary = 4
            present(hov, "hover-colour")
            let tip = makeWheel(.files([asset]))
            tip.hover(at: tip.geometry.primaryLabelPoint(5))
            RunLoop.current.run(until: Date().addingTimeInterval(0.8))
            present(tip, "tip-capture")
            tip.hover(at: nil)
            present(makeWheel(textModel.context), "text-closed")
            let emp = makeWheel(.empty)
            emp.hoveredPrimary = 4
            emp.openSegment(4)
            present(emp, "empty-colour")
            state.prefs.accent = savedAccent
            state.prefs.customAccentHex = savedCustom
            print("Wrote presentation renders to \(presentOut.path)")
        }

        let wheel = FormatWheelModel()
        wheel.targets = ConversionEngine.targets(for: asset, preferredOrder: state.prefs.preferredFormats).filter { $0.variant == .standard }.prefix(8).map { $0 }
        wheel.title = asset.name
        wheel.icon = NSWorkspace.shared.icon(forFile: fixture.path)
        wheel.hovered = 2
        wheel.isShown = true
        snapshot(backdrop(AnyView(FormatWheelView(model: wheel)), false), size: CGSize(width: wheel.canvas, height: wheel.canvas), name: "drag-format-wheel")

        // Dark, Indigo copies of the main windows for case studies (ui-snapshots/present/).
        func presentWindow<V: View>(_ view: V, size: CGSize, name: String, dark: Bool = true) {
            let saved = state.prefs.accent, savedCustom = state.prefs.customAccentHex
            state.prefs.customAccentHex = nil
            state.prefs.accent = .indigo
            snapshot(view.background(Color(nsColor: .windowBackgroundColor)), size: size, name: "present/\(name)", dark: dark)
            state.prefs.accent = saved
            state.prefs.customAccentHex = savedCustom
        }
        snapshot(SettingsView(initialTab: .radial).frame(width: 840, height: 620), size: CGSize(width: 840, height: 620), name: "settings-radial")
        presentWindow(SettingsView(initialTab: .activation).frame(width: 840, height: 620), size: CGSize(width: 840, height: 620), name: "settings-activation-dark")
        presentWindow(SettingsView(initialTab: .radial).frame(width: 840, height: 620), size: CGSize(width: 840, height: 620), name: "settings-radial-dark")
        snapshot(OnboardingView().frame(width: 640, height: 560), size: CGSize(width: 640, height: 560), name: "onboarding")
        snapshot(MenuBarPopoverView(close: {}).frame(width: 270, height: 520), size: CGSize(width: 270, height: 520), name: "menubar-popover")
        snapshot(HomeView().frame(height: 640, alignment: .top), size: CGSize(width: 282, height: 640), name: "home-window")
        if let editorModel = try? ImageEditorModel(asset: asset, tool: .crop) {
            snapshot(ImageEditorView(model: editorModel).frame(width: 1080, height: 720), size: CGSize(width: 1080, height: 720), name: "editor-crop")
        }
        ColourLensModel.shared.handle(.colour(RGBAColour(hex: "#16A085")!, p3: nil))
        snapshot(ColourLensView(model: ColourLensModel.shared).frame(width: 760, height: 900), size: CGSize(width: 760, height: 900), name: "colour-lens")
        presentWindow(ColourLensView(model: ColourLensModel.shared).frame(width: 760, height: 900), size: CGSize(width: 760, height: 900), name: "colour-lens-dark")
        ColourLensModel.shared.handle(.contrast)
        snapshot(ColourLensView(model: ColourLensModel.shared).frame(width: 760, height: 720), size: CGSize(width: 760, height: 720), name: "colour-contrast")
        presentWindow(ColourLensView(model: ColourLensModel.shared).frame(width: 760, height: 720), size: CGSize(width: 760, height: 720), name: "colour-contrast-dark")
        // Font Lens with estimated matches for text set in a Google Font (drawn from the bundled reference).
        if FontReference.shared != nil {
            let fam = NSFontManager.shared.availableFontFamilies.contains("Poppins") ? "Montserrat" : "Poppins"
            let cand = FontCandidate(postScriptName: fam, familyName: fam, displayName: fam, styleName: "SemiBold", cssWeight: 600,
                                     isItalic: false, category: .sansSerif, similarity: 1, source: .googleFonts(slug: fam))
            if let mask = FontMatcher.referencePreview(text: "Get started for free", candidate: cand, emPixels: 44, asMask: true),
               let ctx = ImageOps.makeContext(width: mask.width + 60, height: mask.height + 40, opaque: true) {
                ctx.setFillColor(RGBAColour(r: 0.97, g: 0.95, b: 0.92).cgColor)
                ctx.fill(CGRect(x: 0, y: 0, width: mask.width + 60, height: mask.height + 40))
                let r = CGRect(x: 30, y: 20, width: mask.width, height: mask.height)
                ctx.clip(to: r, mask: mask)
                ctx.setFillColor(RGBAColour(r: 0.12, g: 0.12, b: 0.16).cgColor)
                ctx.fill(r)
                if let img = ctx.makeImage(), let report = try? FontMatcher.analyse(image: img, limit: 4) {
                    let m = FontLensModel.shared
                    m.subject = .estimate
                    m.capture = img
                    m.report = report
                    m.overrideText = report.sample.text
                    m.sampleText = report.sample.text
                    m.tab = .results
                    check(report.candidates.first?.familyName == fam, "font finder names \(fam) (got \(report.candidates.first?.familyName ?? "none"))")
                    snapshot(FontLensView(model: m).frame(width: 760, height: 1100), size: CGSize(width: 760, height: 1100), name: "font-lens-estimate")
                    presentWindow(FontLensView(model: m).frame(width: 760, height: 1100), size: CGSize(width: 760, height: 1100), name: "font-lens-dark")
                }
            }
        }
        snapshot(ConvertOptionsView(assets: [asset], preselect: nil).frame(width: 560, height: 640), size: CGSize(width: 560, height: 640), name: "convert-options")
        presentWindow(ConvertOptionsView(assets: [asset], preselect: nil).frame(width: 560, height: 640), size: CGSize(width: 560, height: 640), name: "convert-options-dark")

        // PDF toolkit in Markup mode, with a text box, a comment and a drawing on page 1.
        let pdfURL = FileManager.default.temporaryDirectory.appendingPathComponent("smoke-doc.pdf")
        try? FileManager.default.removeItem(at: pdfURL)
        if (try? PDFEngine.makePDF(fromImages: [fixture, fixture], output: pdfURL, pageSize: .a4, margin: 36)) != nil,
           let pdfModel = try? PDFToolkitModel(urls: [pdfURL], mode: .markup) {
            pdfModel.markupText = "Looks great — ship it"
            pdfModel.markupTool = .text
            pdfModel.addMarkup(page: 0, rect: CGRect(x: 80, y: 420, width: 300, height: 40), point: nil, strokes: [])
            pdfModel.markupTool = .note
            pdfModel.addMarkup(page: 0, rect: nil, point: CGPoint(x: 480, y: 480), strokes: [])
            pdfModel.markupTool = .draw
            pdfModel.addMarkup(page: 0, rect: nil, point: nil, strokes: [[CGPoint(x: 100, y: 300), CGPoint(x: 200, y: 340), CGPoint(x: 300, y: 300)]])
            check(pdfModel.document.page(at: 0)?.annotations.count ?? 0 >= 3, "PDF markup adds annotations")
            pdfModel.focusedPage = 0
            RunLoop.current.run(until: Date().addingTimeInterval(0.3))
            snapshot(PDFToolkitView(model: pdfModel).frame(width: 980, height: 700), size: CGSize(width: 980, height: 700), name: "pdf-markup")
        } else {
            check(false, "PDF toolkit opens")
        }

        // Favourites appear as quick buttons when they apply.
        let favModel = RadialMenuModel()
        favModel.configure(context: .files([asset]), state: state)
        if let first = favModel.actions(forPrimary: 1).first(where: \.enabled) {
            state.toggleFavourite(first)
            check(favModel.quickActions(state).contains { $0.action.id == first.id && $0.favourite }, "favourite shows as a quick button")
            state.toggleFavourite(first)
        }
        snapshot(DesignerToolsView().frame(width: 640, height: 560), size: CGSize(width: 640, height: 560), name: "designer-tools")
        let studio = TextStudioModel(text: "Select anything.\nCreate anything.", attributed: nil, format: .png, graphic: true, sourceName: nil)
        RunLoop.current.run(until: Date().addingTimeInterval(0.6))
        snapshot(TextStudioView(model: studio).frame(width: 1000, height: 680), size: CGSize(width: 1000, height: 680), name: "text-studio-graphic")

        print("")
        print("Smoke test: \(passes) passed, \(failures.count) failed")
        try? FileManager.default.removeItem(at: tmpStore)
        exit(failures.isEmpty ? 0 : 1)
    }
}

/// Area of a closed polygon (shoelace formula).
func polygonArea(_ pts: [CGPoint]) -> CGFloat {
    guard pts.count >= 3 else { return 0 }
    var a: CGFloat = 0
    for i in 0..<pts.count {
        let p = pts[i], q = pts[(i + 1) % pts.count]
        a += p.x * q.y - q.x * p.y
    }
    return abs(a) / 2
}
