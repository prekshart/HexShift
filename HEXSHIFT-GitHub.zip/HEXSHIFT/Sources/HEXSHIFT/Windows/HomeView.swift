import AppKit
import SwiftUI

extension Windows {
    /// The HEXSHIFT Home window: the menu bar panel as a normal window, for when the
    /// menu bar icon is hidden (e.g. behind the notch) or the app was opened from Applications.
    static func openHome() {
        WindowManager.shared.show(id: "home", title: "HEXSHIFT", size: CGSize(width: 282, height: 560),
                                  resizable: false, fitsContent: true) {
            HomeView()
        }
    }
}

@MainActor
struct HomeView: View {
    @EnvironmentObject var state: AppState

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            MenuBarPopoverView(close: { WindowManager.shared.close("home") }, wheelAtPointer: true)
                .padding(.top, 30)
            Divider().padding(.horizontal, 12)
            VStack(alignment: .leading, spacing: 8) {
                Text("Can't see the hexagon in your menu bar? On MacBooks with a notch, extra menu bar icons can hide behind it. Open HEXSHIFT from Applications or Spotlight to get this window, or press \(state.prefs.hotKey.display) for the wheel.")
                    .font(.system(size: 10.5))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
        }
        .frame(width: 282)
        .fixedSize(horizontal: false, vertical: true)
    }
}
