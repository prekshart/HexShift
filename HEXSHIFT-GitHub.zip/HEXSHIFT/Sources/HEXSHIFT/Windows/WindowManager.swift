import AppKit
import HexshiftKit
import SwiftUI

/// Opens tool windows only when needed. While any window is open HEXSHIFT shows a
/// Dock icon (so ⌘-Tab works); when the last one closes it returns to the menu bar.
@MainActor
final class WindowManager: NSObject, NSWindowDelegate {
    static let shared = WindowManager()

    private var windows: [String: NSWindow] = [:]

    func show<Content: View>(id: String, title: String, size: CGSize, minSize: CGSize? = nil,
                             resizable: Bool = true, fitsContent: Bool = false, @ViewBuilder content: () -> Content) {
        let state = AppState.shared
        let root = AnyView(content().environmentObject(state).hexAppearance(state))
        if let existing = windows[id] {
            (existing.contentViewController as? NSHostingController<AnyView>)?.rootView = root
            existing.title = title
            bringToFront(existing)
            return
        }
        var style: NSWindow.StyleMask = [.titled, .closable, .miniaturizable, .fullSizeContentView]
        if resizable { style.insert(.resizable) }
        let window = NSWindow(contentRect: NSRect(origin: .zero, size: size), styleMask: style, backing: .buffered, defer: false)
        window.title = title
        window.titlebarAppearsTransparent = true
        window.isReleasedWhenClosed = false
        let controller = NSHostingController(rootView: root)
        if fitsContent { controller.sizingOptions = [.preferredContentSize] }
        window.contentViewController = controller
        window.setContentSize(size)
        if let minSize { window.contentMinSize = minSize }
        window.delegate = self
        window.identifier = NSUserInterfaceItemIdentifier(id)
        window.setFrameAutosaveName("HEXSHIFT.\(id.components(separatedBy: ":").first ?? id)")
        if window.frame.origin == .zero { window.center() }
        windows[id] = window
        bringToFront(window)
    }

    private func bringToFront(_ window: NSWindow) {
        if NSApp.activationPolicy() != .regular {
            NSApp.setActivationPolicy(.regular)
        }
        NSApp.activate()
        window.makeKeyAndOrderFront(nil)
    }

    func close(_ id: String) {
        windows[id]?.close()
    }

    func isOpen(_ id: String) -> Bool { windows[id]?.isVisible == true }

    nonisolated func windowWillClose(_ notification: Notification) {
        Task { @MainActor in
            guard let window = notification.object as? NSWindow, let id = window.identifier?.rawValue else { return }
            self.windows.removeValue(forKey: id)
            if self.windows.values.filter(\.isVisible).isEmpty {
                NSApp.setActivationPolicy(.accessory)
            }
        }
    }
}
