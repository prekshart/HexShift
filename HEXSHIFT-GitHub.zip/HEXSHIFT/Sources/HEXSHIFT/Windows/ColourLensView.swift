import AppKit
import HexshiftKit
import SwiftUI

enum ColourImageFocus { case pick, palette, gradient }

enum ColourLensRequest {
    case colour(RGBAColour, p3: (Double, Double, Double)?)
    case image(CGImage, name: String, focus: ColourImageFocus)
    case contrast
    case history
}

extension Windows {
    static func openColourLens(_ request: ColourLensRequest) {
        let model = ColourLensModel.shared
        model.handle(request)
        WindowManager.shared.show(id: "colour-lens", title: "Colour Lens", size: CGSize(width: 760, height: 620), minSize: CGSize(width: 640, height: 520)) {
            ColourLensView(model: model)
        }
    }
}

@MainActor
final class ColourLensModel: ObservableObject {
    static let shared = ColourLensModel()

    enum Tab: String, CaseIterable, Identifiable {
        case colour = "Colour", image = "Image", contrast = "Contrast", palettes = "Palettes"
        var id: String { rawValue }
    }

    @Published var tab: Tab = .colour
    @Published var current = RGBAColour(hex: "#16A085")!
    @Published var p3: (Double, Double, Double)?
    @Published var image: CGImage?
    @Published var imageName = ""
    @Published var paletteCount = 6 { didSet { extractPalette() } }
    @Published var palette: [PaletteColour] = []
    @Published var gradient: GradientEstimate?
    @Published var gradientRegion: CGRect?
    @Published var foreground = RGBAColour(r: 0.17, g: 0.16, b: 0.16)
    @Published var background = RGBAColour(r: 1, g: 0.99, b: 0.97)
    @Published var gradientMode = false

    func handle(_ r: ColourLensRequest) {
        switch r {
        case let .colour(c, p3):
            current = c
            self.p3 = p3
            tab = .colour
        case let .image(img, name, focus):
            image = img
            imageName = name
            gradient = nil
            gradientRegion = nil
            gradientMode = focus == .gradient
            tab = .image
            extractPalette()
            if focus == .gradient { estimateGradient(nil) }
        case .contrast:
            tab = .contrast
        case .history:
            tab = .colour
        }
    }

    func extractPalette() {
        guard let img = image else { return }
        let n = paletteCount
        Task {
            let p = await Task.detached { PaletteExtractor.extract(from: img, count: n) }.value
            self.palette = p
        }
    }

    func estimateGradient(_ region: CGRect?) {
        guard let img = image else { return }
        let source = region.map { ImageOps.crop(img, to: $0) } ?? img
        gradientRegion = region
        gradient = GradientEstimator.estimate(source)
    }

    func sample(at p: CGPoint) {
        guard let img = image else { return }
        let x = Int(p.x), y = Int(p.y)
        guard x >= 0, y >= 0, x < img.width, y < img.height, let px = img.cropping(to: CGRect(x: x, y: y, width: 1, height: 1)),
              let buf = PixelBuffer(image: px) else { return }
        let c = buf.rgba(x: 0, y: 0)
        let colour = RGBAColour(r: c.r / 255, g: c.g / 255, b: c.b / 255)
        select(colour)
    }

    func select(_ c: RGBAColour) {
        current = c
        p3 = nil
        AppState.shared.addColourToHistory(c)
        if AppState.shared.prefs.autoCopyPickedColour {
            Clipboard.copy(ColourFormatting.string(c, format: AppState.shared.prefs.colourCopyFormat))
        }
    }

    enum ExportKind: String, CaseIterable {
        case css = "CSS variables", tailwind = "Tailwind config (with 50–950 scales)", json = "JSON design tokens"
        case swift = "SwiftUI Color extension", ase = "Adobe Swatch Exchange (.ase)", gpl = "GIMP / Krita palette (.gpl)"
        case svg = "SVG swatches", png = "PNG palette sheet", hex = "Plain HEX list"
    }

    func export(_ colours: [(name: String, colour: RGBAColour)], as kind: ExportKind, name: String) {
        ActionRunner.shared.withPlanner { planner, delivery in
            JobCenter.shared.runTask(title: "Exporting palette", delivery: delivery, successTitle: "Palette exported") {
                let ext: String
                switch kind {
                case .css: ext = "css"
                case .tailwind: ext = "js"
                case .json: ext = "json"
                case .swift: ext = "swift"
                case .ase: ext = "ase"
                case .gpl: ext = "gpl"
                case .svg: ext = "svg"
                case .png: ext = "png"
                case .hex: ext = "txt"
                }
                let dest = planner.url(for: nil, baseName: kind == .tailwind ? name + ".tailwind" : name, ext: ext)
                switch kind {
                case .png:
                    guard let img = PaletteExporter.pngSheet(colours) else { throw HexError.message("The palette sheet could not be drawn.") }
                    try ImageEncoder.write(img, format: .png, to: dest)
                case .ase:
                    let data = PaletteExporter.aseData(colours)
                    try FileWriter.writeAtomically(to: dest) { try data.write(to: $0) }
                default:
                    let text: String
                    switch kind {
                    case .css: text = PaletteExporter.cssVariables(colours)
                    case .tailwind: text = PaletteExporter.tailwindConfig(colours)
                    case .json: text = PaletteExporter.designTokensJSON(colours)
                    case .swift: text = PaletteExporter.swiftUIExtension(colours)
                    case .gpl: text = PaletteExporter.gimpPalette(colours, title: name)
                    case .svg: text = PaletteExporter.svgSwatches(colours)
                    default: text = PaletteExporter.hexList(colours)
                    }
                    try FileWriter.writeAtomically(to: dest) { try Data(text.utf8).write(to: $0) }
                }
                return [dest]
            }
        }
    }
}

@MainActor
struct ColourLensView: View {
    @ObservedObject var model: ColourLensModel
    @EnvironmentObject var state: AppState

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Spacer()
                Picker("", selection: $model.tab) {
                    ForEach(ColourLensModel.Tab.allCases) { Text($0.rawValue).tag($0) }
                }
                .pickerStyle(.segmented)
                .frame(width: 380)
                Spacer()
                Button {
                    ActionRunner.shared.pickColour()
                } label: { Label("Pick", systemImage: "eyedropper") }
                    .help("Pick a colour anywhere on screen")
            }
            .padding(.horizontal, 14)
            .padding(.top, 30)
            .padding(.bottom, 10)
            Divider()
            ScrollView {
                Group {
                    switch model.tab {
                    case .colour: ColourDetail(model: model)
                    case .image: ImageColours(model: model)
                    case .contrast: ContrastChecker(model: model)
                    case .palettes: PaletteLibrary(model: model)
                    }
                }
                .padding(18)
            }
        }
    }
}

@MainActor
private struct ColourDetail: View {
    @ObservedObject var model: ColourLensModel
    @EnvironmentObject var state: AppState
    @State private var hexInput = ""

    var body: some View {
        let c = model.current
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 18) {
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(c.swiftUIColor)
                    .frame(width: 150, height: 150)
                    .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(Color.primary.opacity(0.1)))
                    .shadow(color: c.swiftUIColor.opacity(0.4), radius: 14, y: 6)
                VStack(alignment: .leading, spacing: 4) {
                    Text(ColourMath.approximateName(c)).font(.system(size: 20, weight: .semibold))
                    CopyField(label: "HEX", value: c.hex)
                    CopyField(label: "RGB", value: ColourMath.rgbString(c))
                    CopyField(label: "HSL", value: ColourMath.hslString(c))
                    CopyField(label: "HSV", value: ColourMath.hsvString(c))
                    CopyField(label: "CSS", value: ColourMath.cssRGB(c))
                    CopyField(label: "CSS HSL", value: ColourMath.cssHSL(c))
                    if let p3 = model.p3 {
                        CopyField(label: "Display P3", value: ColourMath.cssDisplayP3(r: p3.0, g: p3.1, b: p3.2))
                    }
                    CopyField(label: "CMYK ≈", value: ColourMath.cmykString(c))
                    CopyField(label: "Lab", value: ColourMath.labString(c))
                    CopyField(label: "OKLCH", value: ColourMath.oklchString(c))
                }
            }
            HStack {
                TextField("Paste #hex, rgb() or hsl()", text: $hexInput)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 240)
                    .onSubmit {
                        if let parsed = ColourMath.parse(hexInput) { model.select(parsed) }
                    }
                Button("Use as Text") { model.foreground = c; model.tab = .contrast }
                Button("Use as Background") { model.background = c; model.tab = .contrast }
                Menu("Add to Palette") {
                    ForEach(state.store.palettes) { p in
                        Button(p.name) { add(to: p.id) }
                    }
                    Divider()
                    Button("New Palette") {
                        state.store.palettes.append(SavedPalette(name: "Palette \(state.store.palettes.count + 1)", colours: [NamedColour(name: ColourMath.approximateName(c), colour: c)]))
                    }
                }
                .fixedSize()
            }
            Text("Colours sampled from the screen come from the display's rendering. They can differ from the source design's values because of colour profiles, transparency, shadows and effects. CMYK is an approximation — use your printer's profile for production.")
                .font(.system(size: 10.5)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            GeneratedPalettes(model: model)
            SectionCard(title: "Recent colours") {
                if state.store.colourHistory.isEmpty {
                    Text("Colours you pick appear here.").font(.system(size: 11.5)).foregroundStyle(.secondary)
                }
                LazyVGrid(columns: Array(repeating: GridItem(.fixed(30), spacing: 8), count: 16), alignment: .leading, spacing: 8) {
                    ForEach(Array(state.store.colourHistory.enumerated()), id: \.offset) { _, h in
                        Swatch(colour: h, size: 28, selected: h.hex == c.hex)
                            .onTapGesture { model.current = h; model.p3 = nil }
                            .help(h.hex)
                    }
                }
                if !state.store.colourHistory.isEmpty {
                    Button("Clear History") { state.store.colourHistory = [] }.controlSize(.small)
                }
            }
        }
    }

    private func add(to id: UUID) {
        guard let i = state.store.palettes.firstIndex(where: { $0.id == id }) else { return }
        state.store.palettes[i].colours.append(NamedColour(name: ColourMath.approximateName(model.current), colour: model.current))
        JobCenter.shared.message("Added to \(state.store.palettes[i].name)")
    }
}

/// Harmonies, a tonal 50–950 scale and colour-vision previews for the current colour.
@MainActor
private struct GeneratedPalettes: View {
    @ObservedObject var model: ColourLensModel
    @EnvironmentObject var state: AppState
    @State private var harmony: ColourMath.Harmony = .complementary

    var body: some View {
        let c = model.current
        SectionCard(title: "Generate") {
            HStack {
                Picker("Harmony", selection: $harmony) {
                    ForEach(ColourMath.Harmony.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                .frame(width: 260)
                Spacer()
                Button("Save as Palette") { save(ColourMath.harmony(harmony, of: c), name: "\(harmony.title) \(c.hex)") }
                    .controlSize(.small)
            }
            row(ColourMath.harmony(harmony, of: c), size: 44)
            HStack {
                Text("Tonal scale").font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary)
                Spacer()
                Menu("Export Scale") {
                    ForEach(ColourLensModel.ExportKind.allCases, id: \.self) { k in
                        Button(k.rawValue) {
                            let scale = ColourMath.tonalScale(c).map { (name: "\(ColourMath.approximateName(c).lowercased())-\($0.step)", colour: $0.colour) }
                            model.export(k == .tailwind ? [(name: ColourMath.approximateName(c), colour: c)] : scale, as: k, name: "Scale \(c.hex.dropFirst())")
                        }
                    }
                }
                .fixedSize()
                .controlSize(.small)
            }
            HStack(spacing: 4) {
                ForEach(ColourMath.tonalScale(c), id: \.step) { item in
                    VStack(spacing: 3) {
                        Swatch(colour: item.colour, size: 36, selected: item.colour == c)
                            .onTapGesture { model.select(item.colour) }
                            .help(item.colour.hex)
                        Text("\(item.step)").font(.system(size: 9.5, design: .monospaced)).foregroundStyle(.secondary)
                    }
                }
            }
            Text("Colour-vision preview").font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary)
            HStack(spacing: 12) {
                ForEach(ColourMath.VisionDeficiency.allCases, id: \.self) { kind in
                    VStack(spacing: 3) {
                        Swatch(colour: ColourMath.simulate(c, kind), size: 36)
                        Text(kind.shortTitle).font(.system(size: 9.5)).foregroundStyle(.secondary)
                    }
                    .help(kind.title)
                }
            }
            Text("Harmonies rotate the hue in OKLCH, so lightness stays even; colours outside sRGB are pulled back into range.")
                .font(.system(size: 10.5)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
    }

    private func row(_ colours: [RGBAColour], size: CGFloat) -> some View {
        HStack(spacing: 8) {
            ForEach(Array(colours.enumerated()), id: \.offset) { _, col in
                VStack(spacing: 3) {
                    Swatch(colour: col, size: size, selected: col == model.current)
                        .onTapGesture { model.select(col) }
                    Text(col.hex).font(.system(size: 9.5, design: .monospaced))
                }
            }
        }
    }

    private func save(_ colours: [RGBAColour], name: String) {
        state.store.palettes.append(SavedPalette(name: name, colours: colours.map { NamedColour(name: ColourMath.approximateName($0), colour: $0) }))
        JobCenter.shared.message("Palette saved", detail: name)
    }
}

@MainActor
private struct ImageColours: View {
    @ObservedObject var model: ColourLensModel
    @EnvironmentObject var state: AppState
    @State private var dragStart: CGPoint?
    @State private var dragNow: CGPoint?

    var body: some View {
        if let img = model.image {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text(model.imageName).font(.system(size: 13, weight: .semibold)).lineLimit(1)
                    Spacer()
                    Toggle("Gradient mode", isOn: $model.gradientMode).toggleStyle(.switch).controlSize(.small)
                }
                Text(model.gradientMode ? "Drag across a region to estimate its gradient." : "Click any pixel to sample its exact colour.")
                    .font(.system(size: 11)).foregroundStyle(.secondary)
                GeometryReader { geo in
                    let s = min(geo.size.width / CGFloat(img.width), 320 / CGFloat(img.height))
                    let w = CGFloat(img.width) * s, h = CGFloat(img.height) * s
                    ZStack(alignment: .topLeading) {
                        Image(nsImage: NSImage(cg: img)).resizable().frame(width: w, height: h)
                        if let a = dragStart, let b = dragNow {
                            Rectangle().stroke(state.accentColor, style: StrokeStyle(lineWidth: 1.5, dash: [5, 3]))
                                .frame(width: abs(a.x - b.x), height: abs(a.y - b.y))
                                .offset(x: min(a.x, b.x), y: min(a.y, b.y))
                        } else if let r = model.gradientRegion {
                            Rectangle().stroke(state.accentColor, lineWidth: 1.5)
                                .frame(width: r.width * s, height: r.height * s)
                                .offset(x: r.minX * s, y: r.minY * s)
                        }
                    }
                    .frame(width: w, height: h)
                    .contentShape(Rectangle())
                    .gesture(DragGesture(minimumDistance: 0)
                        .onChanged { v in
                            if model.gradientMode { dragStart = v.startLocation; dragNow = v.location }
                        }
                        .onEnded { v in
                            let p = CGPoint(x: v.location.x / s, y: v.location.y / s)
                            if model.gradientMode, let a = dragStart {
                                let r = CGRect(x: min(a.x, v.location.x) / s, y: min(a.y, v.location.y) / s,
                                               width: abs(a.x - v.location.x) / s, height: abs(a.y - v.location.y) / s)
                                model.estimateGradient(r.width > 4 && r.height > 4 ? r : nil)
                            } else {
                                model.sample(at: p)
                            }
                            dragStart = nil
                            dragNow = nil
                        })
                }
                .frame(height: min(320, CGFloat(img.height)))
                HStack(spacing: 10) {
                    Swatch(colour: model.current, size: 34)
                    Text(model.current.hex).font(.system(size: 14, weight: .semibold, design: .monospaced))
                    Text(ColourMath.rgbString(model.current)).foregroundStyle(.secondary)
                    Spacer()
                    Button("Details") { model.tab = .colour }
                }
                SectionCard(title: "Palette") {
                    HStack {
                        Stepper("\(model.paletteCount) colours", value: $model.paletteCount, in: 3...10)
                        Spacer()
                        Menu("Export") {
                            ForEach(ColourLensModel.ExportKind.allCases, id: \.self) { k in
                                Button(k.rawValue) {
                                    model.export(model.palette.enumerated().map { (name: "colour-\($0.offset + 1)", colour: $0.element.colour) }, as: k, name: "Palette")
                                }
                            }
                        }
                        .fixedSize()
                        Button("Save") {
                            state.store.palettes.append(SavedPalette(name: model.imageName.isEmpty ? "Image palette" : model.imageName,
                                                                     colours: model.palette.map { NamedColour(name: ColourMath.approximateName($0.colour), colour: $0.colour) }))
                            JobCenter.shared.message("Palette saved")
                        }
                    }
                    HStack(spacing: 8) {
                        ForEach(model.palette, id: \.self) { p in
                            VStack(spacing: 4) {
                                Swatch(colour: p.colour, size: 54)
                                    .onTapGesture { model.select(p.colour) }
                                Text(p.colour.hex).font(.system(size: 10.5, design: .monospaced))
                                Text("\(Int((p.weight * 100).rounded()))%").font(.system(size: 9.5)).foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                if let g = model.gradient {
                    SectionCard(title: "Gradient (estimated)") {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(LinearGradient(colors: [g.start.swiftUIColor, g.end.swiftUIColor],
                                                 startPoint: UnitPoint(x: 0.5 - 0.5 * sin(g.cssAngle * .pi / 180), y: 0.5 + 0.5 * cos(g.cssAngle * .pi / 180)),
                                                 endPoint: UnitPoint(x: 0.5 + 0.5 * sin(g.cssAngle * .pi / 180), y: 0.5 - 0.5 * cos(g.cssAngle * .pi / 180))))
                            .frame(height: 50)
                        CopyField(label: "CSS", value: g.css)
                        HStack {
                            Text("Start \(g.start.hex) · End \(g.end.hex) · \(Int(g.cssAngle.rounded()))°").font(.system(size: 11))
                            Spacer()
                            Text(g.isConvincing ? "Good fit (\(Int(g.fit * 100))%)" : "Weak fit — this region may not be a simple linear gradient")
                                .font(.system(size: 10.5)).foregroundStyle(g.isConvincing ? Color.secondary : Color.orange)
                        }
                    }
                }
            }
        } else {
            VStack(spacing: 10) {
                Image(systemName: "photo").font(.system(size: 30)).foregroundStyle(.secondary)
                Text("Open an image, PDF or screenshot from the HEXSHIFT menu to sample its colours.").foregroundStyle(.secondary)
                Button("Capture a Region") { ActionRunner.shared.perform(RadialAction(id: "colour.paletteCapture", title: "Palette", detail: "", symbol: ""), context: .empty) }
            }
            .frame(maxWidth: .infinity, minHeight: 300)
        }
    }
}

@MainActor
private struct ContrastChecker: View {
    @ObservedObject var model: ColourLensModel

    var body: some View {
        let report = ColourMath.contrast(model.foreground, model.background)
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 18) {
                colourWell("Text", $model.foreground)
                Button {
                    let f = model.foreground
                    model.foreground = model.background
                    model.background = f
                } label: { Image(systemName: "arrow.left.arrow.right") }
                    .help("Swap")
                colourWell("Background", $model.background)
            }
            VStack(alignment: .leading, spacing: 8) {
                Text("The quick brown fox jumps over the lazy dog").font(.system(size: 15))
                Text("Large text, 24 pt").font(.system(size: 24, weight: .semibold))
            }
            .foregroundStyle(model.foreground.swiftUIColor)
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 14).fill(model.background.swiftUIColor))
            .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(Color.primary.opacity(0.08)))
            HStack(alignment: .firstTextBaseline, spacing: 28) {
                HStack(alignment: .firstTextBaseline) {
                    Text(report.ratioText).font(.system(size: 34, weight: .bold, design: .rounded))
                    Text("WCAG 2.2").foregroundStyle(.secondary)
                }
                let lc = ColourMath.apcaContrast(text: model.foreground, background: model.background)
                VStack(alignment: .leading, spacing: 2) {
                    HStack(alignment: .firstTextBaseline) {
                        Text(String(format: "Lc %.0f", lc)).font(.system(size: 22, weight: .semibold, design: .rounded))
                        Text("APCA").foregroundStyle(.secondary)
                    }
                    Text(ColourMath.apcaRating(lc)).font(.system(size: 11)).foregroundStyle(.secondary)
                }
            }
            Grid(alignment: .leading, horizontalSpacing: 24, verticalSpacing: 8) {
                GridRow { Text(""); Text("AA").fontWeight(.semibold); Text("AAA").fontWeight(.semibold) }
                GridRow { Text("Normal text"); badge(report.aaNormal); badge(report.aaaNormal) }
                GridRow { Text("Large text (18 pt+ or 14 pt bold)"); badge(report.aaLarge); badge(report.aaaLarge) }
                GridRow { Text("UI components & graphics"); badge(report.uiComponents); Text("—").foregroundStyle(.secondary) }
            }
            .font(.system(size: 12.5))
            Text("WCAG 2.2 uses relative luminance and is today's legal standard. APCA (from the WCAG 3 drafts) models perceived lightness contrast more accurately and is shown for guidance. Transparent colours are treated as opaque.")
                .font(.system(size: 10.5)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            SectionCard(title: "How others may see this") {
                HStack(spacing: 10) {
                    ForEach(ColourMath.VisionDeficiency.allCases, id: \.self) { kind in
                        VStack(spacing: 4) {
                            Text("Aa")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundStyle(ColourMath.simulate(model.foreground, kind).swiftUIColor)
                                .frame(width: 70, height: 46)
                                .background(RoundedRectangle(cornerRadius: 8).fill(ColourMath.simulate(model.background, kind).swiftUIColor))
                                .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(Color.primary.opacity(0.08)))
                            Text(kind.shortTitle).font(.system(size: 10.5))
                            Text(String(format: "%.1f:1", ColourMath.contrastRatio(ColourMath.simulate(model.foreground, kind), ColourMath.simulate(model.background, kind))))
                                .font(.system(size: 9.5)).foregroundStyle(.secondary)
                        }
                        .help(kind.title)
                    }
                }
            }
        }
    }

    private func colourWell(_ title: String, _ binding: Binding<RGBAColour>) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary)
            HStack {
                ColorPicker("", selection: Binding(get: { binding.wrappedValue.swiftUIColor }, set: { binding.wrappedValue = RGBAColour(color: $0) }), supportsOpacity: false)
                    .labelsHidden()
                TextField("#hex", text: Binding(get: { binding.wrappedValue.hex }, set: { if let c = ColourMath.parse($0) { binding.wrappedValue = c } }))
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 100)
                    .font(.system(size: 12, design: .monospaced))
            }
        }
    }

    private func badge(_ pass: Bool) -> some View {
        Label(pass ? "Pass" : "Fail", systemImage: pass ? "checkmark.circle.fill" : "xmark.circle.fill")
            .foregroundStyle(pass ? Color.green : Color.red)
    }
}

@MainActor
private struct PaletteLibrary: View {
    @ObservedObject var model: ColourLensModel
    @EnvironmentObject var state: AppState

    private func update(_ id: UUID, _ change: (inout SavedPalette) -> Void) {
        guard let i = state.store.palettes.firstIndex(where: { $0.id == id }) else { return }
        change(&state.store.palettes[i])
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Saved palettes are stored only on this Mac.").font(.system(size: 11.5)).foregroundStyle(.secondary)
                Spacer()
                Button("New Palette") { state.store.palettes.append(SavedPalette(name: "Palette \(state.store.palettes.count + 1)", colours: [])) }
            }
            if state.store.palettes.isEmpty {
                Text("No palettes yet. Extract one from an image or add colours from the Colour tab.").foregroundStyle(.secondary)
            }
            ForEach(state.store.palettes) { palette in
                SectionCard {
                    HStack {
                        TextField("Name", text: Binding(get: { palette.name }, set: { new in update(palette.id) { $0.name = new } }))
                            .textFieldStyle(.plain).font(.system(size: 14, weight: .semibold))
                        Spacer()
                        Menu("Export") {
                            ForEach(ColourLensModel.ExportKind.allCases, id: \.self) { k in
                                Button(k.rawValue) { model.export(palette.colours.map { (name: $0.name, colour: $0.colour) }, as: k, name: palette.name) }
                            }
                        }
                        .fixedSize()
                        Button {
                            let c = model.current
                            update(palette.id) { $0.colours.append(NamedColour(name: ColourMath.approximateName(c), colour: c)) }
                        } label: {
                            Image(systemName: "plus")
                        }
                        .help("Add the current colour")
                        Button(role: .destructive) {
                            let id = palette.id
                            DispatchQueue.main.async { state.store.palettes.removeAll { $0.id == id } }
                        } label: { Image(systemName: "trash") }
                    }
                    HStack(spacing: 8) {
                        ForEach(palette.colours) { c in
                            VStack(spacing: 3) {
                                Swatch(colour: c.colour, size: 40).onTapGesture { model.current = c.colour; model.tab = .colour }
                                Text(c.colour.hex).font(.system(size: 9.5, design: .monospaced))
                            }
                            .contextMenu {
                                Button("Remove") { update(palette.id) { p in p.colours.removeAll { $0.id == c.id } } }
                            }
                        }
                    }
                }
            }
        }
    }
}
