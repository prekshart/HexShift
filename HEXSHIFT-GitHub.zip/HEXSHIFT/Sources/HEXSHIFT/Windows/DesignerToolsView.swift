import AppKit
import HexshiftKit
import SwiftUI

extension Windows {
    static func openDesignerTools() {
        WindowManager.shared.show(id: "designer-tools", title: "Designer Tools", size: CGSize(width: 640, height: 560), minSize: CGSize(width: 560, height: 480)) {
            DesignerToolsView()
        }
    }
}

@MainActor
struct DesignerToolsView: View {
    enum Tab: String, CaseIterable, Identifiable {
        case ratio = "Aspect Ratio", units = "Units & Print", colour = "Colour", scales = "Export Scales"
        var id: String { rawValue }
    }

    @State private var tab: Tab = .ratio

    var body: some View {
        VStack(spacing: 0) {
            Picker("", selection: $tab) {
                ForEach(Tab.allCases) { Text($0.rawValue).tag($0) }
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 18)
            .padding(.top, 32)
            .padding(.bottom, 10)
            Divider()
            ScrollView {
                Group {
                    switch tab {
                    case .ratio: AspectRatioTool()
                    case .units: UnitsTool()
                    case .colour: ColourConverterTool()
                    case .scales: ScalesTool()
                    }
                }
                .padding(18)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }
}

@MainActor
private struct AspectRatioTool: View {
    @State private var width = 1920.0
    @State private var height = 1080.0
    @State private var newWidth = 1080.0
    @State private var ratioW = 4.0
    @State private var ratioH = 5.0

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionCard(title: "Simplify a size") {
                HStack {
                    TextField("Width", value: $width, format: .number).textFieldStyle(.roundedBorder)
                    Text("×")
                    TextField("Height", value: $height, format: .number).textFieldStyle(.roundedBorder)
                }
                Text("Ratio: \(AspectRatio.describe(width: Int(width), height: Int(height)))").font(.system(size: 13, weight: .semibold))
            }
            SectionCard(title: "Scale keeping the ratio") {
                HStack {
                    Text("New width")
                    TextField("", value: $newWidth, format: .number).textFieldStyle(.roundedBorder).frame(width: 100)
                    Text("→ height \(height > 0 && width > 0 ? Int((newWidth * height / width).rounded()) : 0)")
                }
            }
            SectionCard(title: "Size from a ratio") {
                HStack {
                    TextField("W", value: $ratioW, format: .number).textFieldStyle(.roundedBorder).frame(width: 60)
                    Text(":")
                    TextField("H", value: $ratioH, format: .number).textFieldStyle(.roundedBorder).frame(width: 60)
                    Text("at width \(Int(newWidth)) → \(Int(newWidth)) × \(ratioW > 0 ? Int((newWidth * ratioH / ratioW).rounded()) : 0)")
                }
                HStack(spacing: 6) {
                    ForEach(["1:1", "4:5", "9:16", "16:9", "3:2", "4:3", "21:9"], id: \.self) { r in
                        Button(r) {
                            let parts = r.split(separator: ":").compactMap { Double($0) }
                            ratioW = parts[0]
                            ratioH = parts[1]
                        }
                        .controlSize(.small)
                    }
                }
            }
        }
    }
}

@MainActor
private struct UnitsTool: View {
    @State private var value = 1080.0
    @State private var unit = 0
    @State private var dpi = 300.0
    @State private var scale = 2.0
    private let units = ["px", "pt", "in", "mm", "cm"]

    private var inches: Double {
        switch unit {
        case 0: return value / dpi
        case 1: return value / 72
        case 2: return value
        case 3: return value / 25.4
        default: return value / 2.54
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionCard(title: "Convert") {
                HStack {
                    TextField("Value", value: $value, format: .number).textFieldStyle(.roundedBorder).frame(width: 110)
                    Picker("", selection: $unit) {
                        ForEach(units.indices, id: \.self) { Text(units[$0]).tag($0) }
                    }
                    .labelsHidden()
                    .frame(width: 80)
                    Text("at")
                    TextField("DPI", value: $dpi, format: .number).textFieldStyle(.roundedBorder).frame(width: 70)
                    Text("ppi")
                }
                Grid(alignment: .leading, horizontalSpacing: 18, verticalSpacing: 6) {
                    GridRow { Text("Pixels").foregroundStyle(.secondary); Text(String(format: "%.1f px", inches * dpi)) }
                    GridRow { Text("Points").foregroundStyle(.secondary); Text(String(format: "%.2f pt", inches * 72)) }
                    GridRow { Text("Inches").foregroundStyle(.secondary); Text(String(format: "%.3f in", inches)) }
                    GridRow { Text("Millimetres").foregroundStyle(.secondary); Text(String(format: "%.2f mm", inches * 25.4)) }
                    GridRow { Text("Centimetres").foregroundStyle(.secondary); Text(String(format: "%.3f cm", inches * 2.54)) }
                }
                .font(.system(size: 13, design: .monospaced))
                .textSelection(.enabled)
            }
            SectionCard(title: "Screen pixels ↔ points") {
                HStack {
                    Text("Display scale")
                    Picker("", selection: $scale) {
                        Text("@1x").tag(1.0); Text("@2x").tag(2.0); Text("@3x").tag(3.0)
                    }
                    .pickerStyle(.segmented)
                    .frame(width: 180)
                }
                Text(String(format: "%.0f px = %.1f pt at @%.0fx", value, value / scale, scale)).font(.system(size: 13, design: .monospaced))
            }
            SectionCard(title: "Print size") {
                Text("A \(Int(value)) px side prints at \(String(format: "%.2f in (%.1f mm)", value / dpi, value / dpi * 25.4)) at \(Int(dpi)) ppi.")
                Text("For sharp print, 300 ppi is the usual target; 150 ppi is fine for large posters viewed from a distance.")
                    .font(.system(size: 11)).foregroundStyle(.secondary)
            }
        }
    }
}

@MainActor
private struct ColourConverterTool: View {
    @State private var input = "#16A085"

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionCard(title: "Any colour → every format") {
                TextField("#hex, rgb(), hsl() or r, g, b", text: $input).textFieldStyle(.roundedBorder)
                if let c = ColourMath.parse(input) {
                    HStack(alignment: .top, spacing: 14) {
                        Swatch(colour: c, size: 70)
                        VStack(alignment: .leading, spacing: 2) {
                            CopyField(label: "HEX", value: c.hex)
                            CopyField(label: "RGB", value: ColourMath.rgbString(c))
                            CopyField(label: "HSL", value: ColourMath.hslString(c))
                            CopyField(label: "HSV", value: ColourMath.hsvString(c))
                            CopyField(label: "CSS", value: ColourMath.cssRGB(c))
                            CopyField(label: "CMYK ≈", value: ColourMath.cmykString(c))
                        }
                    }
                    let white = ColourMath.contrast(c, .white), black = ColourMath.contrast(c, .black)
                    Text("Contrast on white \(white.ratioText) · on black \(black.ratioText)").font(.system(size: 11.5)).foregroundStyle(.secondary)
                    Button("Open in Colour Lens") { Windows.openColourLens(.colour(c, p3: nil)) }
                } else {
                    Text("Not a recognised colour.").foregroundStyle(.secondary)
                }
            }
        }
    }
}

@MainActor
private struct ScalesTool: View {
    @State private var file: URL?
    @State private var sourceScale = 3.0
    @State private var scales: Set<Double> = [1, 2, 3]
    @State private var customScales = ""
    @State private var format: Format? = nil
    @State private var matte = Color.white

    private var allScales: [Double] { Array(scales.union(QuickImageEdits.parseScales(customScales))).sorted() }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionCard(title: "Export scale variants") {
                HStack {
                    Button(file == nil ? "Choose Image or SVG…" : file!.lastPathComponent) {
                        let panel = NSOpenPanel()
                        panel.allowedContentTypes = [.image, .svg]
                        panel.level = .modalPanel   // stay above other apps, so it can't hide behind them
                        if panel.runModal() == .OK { file = panel.url }
                    }
                    Spacer()
                }
                if let f = file, Format.detect(f) != .svg {
                    Picker("This image is", selection: $sourceScale) {
                        Text("@1x").tag(1.0); Text("@2x").tag(2.0); Text("@3x").tag(3.0); Text("@4x").tag(4.0)
                    }
                    .pickerStyle(.segmented)
                    Text("Only smaller scales can be made from a raster image without losing sharpness.").font(.system(size: 11)).foregroundStyle(.secondary)
                }
                HStack {
                    ForEach([1.0, 1.5, 2, 3, 4], id: \.self) { s in
                        Toggle("@\(QuickImageEdits.scaleLabel(s))x", isOn: Binding(get: { scales.contains(s) }, set: { on in if on { scales.insert(s) } else { scales.remove(s) } }))
                            .toggleStyle(.checkbox)
                    }
                }
                TextField("Other scales, e.g. 0.5, 0.75, 6", text: $customScales).textFieldStyle(.roundedBorder)
                Picker("Format", selection: $format) {
                    Text("Same as source").tag(Format?.none)
                    ForEach([Format.png, .jpeg, .webp, .heic, .tiff].filter(ImageEncoder.canWrite), id: \.self) { Text($0.displayName).tag(Format?.some($0)) }
                }
                if let f = format, !f.supportsAlpha {
                    ColorPicker("Background (matte) colour", selection: $matte, supportsOpacity: false)
                }
                Text(allScales.isEmpty ? "Choose at least one scale." : "Will export: " + allScales.map { "@\(QuickImageEdits.scaleLabel($0))x" }.joined(separator: ", "))
                    .font(.system(size: 11)).foregroundStyle(.secondary)
                Button("Export") { export() }.buttonStyle(AccentButtonStyle()).disabled(file == nil || allScales.isEmpty)
            }
        }
    }

    private func export() {
        guard let f = file else { return }
        let asset = AssetInspector.inspect(f)
        let isSVG = asset.format == .svg
        let chosen = allScales.filter { isSVG || $0 <= sourceScale }
        let src = isSVG ? 1 : sourceScale
        let fmt = format, m = RGBAColour(color: matte)
        guard !chosen.isEmpty else {
            JobCenter.shared.message("Nothing to export", detail: "Choose scales at or below the source scale.", kind: .error)
            return
        }
        ActionRunner.shared.withPlanner { planner, delivery in
            JobCenter.shared.runTask(title: "Exporting scales", delivery: delivery, successTitle: "Scale variants saved") {
                try await QuickImageEdits.exportScales(asset, scales: chosen, sourceScale: src, planner: planner, format: fmt, matte: m)
            }
        }
    }
}
