import AppKit
import AVFoundation
import AVKit
import HexshiftKit
import SwiftUI

enum MediaToolMode: String { case trim, gif, frame }

extension Windows {
    static func openMediaTools(asset: AssetInfo, mode: MediaToolMode) {
        let model = MediaToolsModel(asset: asset, mode: mode)
        WindowManager.shared.show(id: "media:\(asset.url.path)", title: asset.name, size: CGSize(width: 900, height: 620), minSize: CGSize(width: 700, height: 480)) {
            MediaToolsView(model: model)
        }
    }
}

@MainActor
final class MediaToolsModel: ObservableObject {
    let asset: AssetInfo
    let player: AVPlayer
    @Published var mode: MediaToolMode
    @Published var duration: Double = 0
    @Published var start: Double = 0
    @Published var end: Double = 0
    @Published var format: Format
    @Published var quality: VideoQuality = .high
    @Published var fps = 12.0
    @Published var width = 640
    @Published var frameFormat: Format = .png

    init(asset: AssetInfo, mode: MediaToolMode) {
        self.asset = asset
        self.mode = mode
        player = AVPlayer(url: asset.url)
        format = asset.kind == .audio ? (asset.format == .m4a ? .wav : .m4a) : (asset.format == .mov ? .mov : .mp4)
        Task {
            let d = await MediaConverter.duration(asset.url) ?? 0
            duration = d
            end = mode == .gif ? min(d, 6) : d
        }
    }

    var currentTime: Double { player.currentTime().seconds.isFinite ? player.currentTime().seconds : 0 }

    func setStartToPlayhead() { start = min(currentTime, end) }
    func setEndToPlayhead() { end = max(currentTime, start) }

    func export() {
        var o = VideoOptions()
        o.quality = quality
        o.start = start > 0.01 ? start : nil
        o.end = end < duration - 0.01 ? end : nil
        o.gifFPS = fps
        o.gifMaxWidth = width
        let a = asset
        let target: Format
        switch mode {
        case .trim: target = format
        case .gif: target = format == .webp ? .webp : .gif
        case .frame:
            o.frameTime = currentTime
            target = frameFormat
        }
        if mode == .gif && (end - start) > 20 {
            JobCenter.shared.message("Long GIFs get very large", detail: "Consider a shorter range or a smaller width.")
        }
        let opts = o
        let suffix: String
        switch mode {
        case .trim: suffix = "-trimmed"
        case .gif: suffix = ""
        case .frame: suffix = "-frame"
        }
        ActionRunner.shared.withPlanner { planner, delivery in
            JobCenter.shared.runTask(title: "Exporting \(target.displayName)", delivery: delivery) {
                let dest = planner.url(for: a.url, baseName: a.baseName + suffix, ext: target.fileExtension)
                try await MediaConverter.convert(a.url, from: a.format ?? .mp4, to: target, output: dest, options: opts)
                return [dest]
            }
        }
    }
}

struct PlayerView: NSViewRepresentable {
    let player: AVPlayer
    func makeNSView(context: Context) -> AVPlayerView {
        let v = AVPlayerView()
        v.player = player
        v.controlsStyle = .inline
        v.showsFrameSteppingButtons = true
        return v
    }
    func updateNSView(_ nsView: AVPlayerView, context: Context) {}
}

@MainActor
struct MediaToolsView: View {
    @ObservedObject var model: MediaToolsModel
    @EnvironmentObject var state: AppState

    var body: some View {
        HStack(spacing: 0) {
            VStack {
                if model.asset.kind == .video {
                    PlayerView(player: model.player)
                } else {
                    VStack {
                        Image(systemName: "waveform").font(.system(size: 60)).foregroundStyle(state.accentColor)
                        PlayerView(player: model.player).frame(height: 60)
                    }
                }
            }
            .padding(.top, 28)
            Divider()
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Picker("", selection: $model.mode) {
                        Text("Trim").tag(MediaToolMode.trim)
                        if model.asset.kind == .video {
                            Text("GIF").tag(MediaToolMode.gif)
                            Text("Frame").tag(MediaToolMode.frame)
                        }
                    }
                    .pickerStyle(.segmented)
                    if model.mode != .frame {
                        SectionCard(title: "Range") {
                            HStack {
                                Text(String(format: "Start %.2fs", model.start)).monospacedDigit()
                                Spacer()
                                Button("Set to Playhead") { model.setStartToPlayhead() }.controlSize(.small)
                            }
                            Slider(value: $model.start, in: 0...max(0.01, model.duration))
                            HStack {
                                Text(String(format: "End %.2fs", model.end)).monospacedDigit()
                                Spacer()
                                Button("Set to Playhead") { model.setEndToPlayhead() }.controlSize(.small)
                            }
                            Slider(value: $model.end, in: 0...max(0.01, model.duration))
                            Text(String(format: "Duration %.1fs of %.1fs", max(0, model.end - model.start), model.duration))
                                .font(.system(size: 11)).foregroundStyle(.secondary)
                        }
                    }
                    switch model.mode {
                    case .trim:
                        SectionCard(title: "Output") {
                            Picker("Format", selection: $model.format) {
                                if model.asset.kind == .video {
                                    Text("MP4").tag(Format.mp4); Text("MOV").tag(Format.mov); Text("M4V").tag(Format.m4v)
                                }
                                Text("M4A (audio)").tag(Format.m4a); Text("WAV (audio)").tag(Format.wav)
                            }
                            if model.asset.kind == .video && [.mp4, .mov, .m4v].contains(model.format) {
                                Picker("Quality", selection: $model.quality) {
                                    ForEach(VideoQuality.allCases, id: \.self) { Text($0.title).tag($0) }
                                }
                                Text("“Same quality” only cuts on keyframes, so the trim may be slightly wider.").font(.system(size: 10.5)).foregroundStyle(.secondary)
                            }
                        }
                    case .gif:
                        SectionCard(title: "Animation") {
                            Picker("Format", selection: $model.format) {
                                Text("GIF").tag(Format.gif); Text("Animated WebP").tag(Format.webp)
                            }
                            .pickerStyle(.segmented)
                            Stepper("Frame rate: \(Int(model.fps)) fps", value: $model.fps, in: 4...30)
                            Stepper("Width: \(model.width) px", value: $model.width, in: 120...1600, step: 40)
                        }
                    case .frame:
                        SectionCard(title: "Frame") {
                            Text("Pause the video on the frame you want, then export.").font(.system(size: 11.5)).foregroundStyle(.secondary)
                            Picker("Format", selection: $model.frameFormat) {
                                Text("PNG").tag(Format.png); Text("JPEG").tag(Format.jpeg); Text("HEIC").tag(Format.heic)
                            }
                            .pickerStyle(.segmented)
                        }
                    }
                    HStack {
                        Spacer()
                        Button("Export") { model.export() }.buttonStyle(AccentButtonStyle())
                    }
                }
                .padding(16)
                .padding(.top, 20)
            }
            .frame(width: 300)
        }
        .onChange(of: model.mode) { _, mode in
            if mode == .gif && model.format != .webp { model.format = .gif }
            if mode == .trim && (model.format == .gif || model.format == .webp) { model.format = model.asset.format == .mov ? .mov : .mp4 }
        }
    }
}
