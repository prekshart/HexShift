import AppKit
import HexshiftKit
import SwiftUI

extension Windows {
    static func openConvertOptions(assets: [AssetInfo], preselect: ConversionTarget?) {
        let title = assets.count == 1 ? "Convert \(assets[0].name)" : "Convert \(assets.count) files"
        WindowManager.shared.show(id: "convert", title: title, size: CGSize(width: 560, height: 600), minSize: CGSize(width: 480, height: 460)) {
            ConvertOptionsView(assets: assets, preselect: preselect)
        }
    }
}

@MainActor
struct ConvertOptionsView: View {
    let assets: [AssetInfo]
    let preselect: ConversionTarget?
    @EnvironmentObject var state: AppState

    @State private var targets: [ConversionTarget] = []
    @State private var selected: ConversionTarget?
    @State private var quality = 0.85
    @State private var maxSizeChoice = 0
    @State private var customMax = 2048
    @State private var metadata: MetadataPolicy = .stripGPS
    @State private var pagesText = "All"
    @State private var dpi = 150.0
    @State private var transparentPages = false
    @State private var svgScale = 2.0
    @State private var videoQuality: VideoQuality = .high
    @State private var start = ""
    @State private var end = ""
    @State private var fps = 12.0
    @State private var gifWidth = 640
    @State private var pageSize: PDFPageSize = .a4
    @State private var lossless = false
    @State private var destination: OutputDestination = .sameFolder
    @State private var matte = Color.white
    @State private var traceColours = 6
    @State private var colourProfile: ColourProfileChoice = .keep

    private var first: AssetInfo { assets[0] }
    private let maxSizes = [0, 4096, 2560, 2048, 1600, 1080, 800, -1]

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            header
            Divider()
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    formatGrid
                    if let t = selected {
                        if let note = t.note {
                            Label(note, systemImage: t.isAvailable ? "info.circle" : "exclamationmark.triangle")
                                .font(.system(size: 11.5))
                                .foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        options(for: t)
                    }
                    SectionCard(title: "Save to") {
                        Picker("Destination", selection: $destination) {
                            Text("Same folder as original").tag(OutputDestination.sameFolder)
                            Text("Desktop").tag(OutputDestination.desktop)
                            Text("Downloads").tag(OutputDestination.downloads)
                            Text("Clipboard only").tag(OutputDestination.clipboardOnly)
                            Text("Ask where to save").tag(OutputDestination.askEveryTime)
                            if case let .custom(path) = state.prefs.output.destination {
                                Text((path as NSString).lastPathComponent).tag(OutputDestination.custom(path: path))
                            }
                        }
                        .labelsHidden()
                        Text("Originals are never changed. Names follow your rule: \(state.prefs.output.naming.title).")
                            .font(.system(size: 11)).foregroundStyle(.secondary)
                    }
                }
                .padding(18)
            }
            Divider()
            HStack {
                Text(assets.count > 1 ? "\(assets.count) files will be converted in the background." : "")
                    .font(.system(size: 11)).foregroundStyle(.secondary)
                Spacer()
                Button("Cancel") { WindowManager.shared.close("convert") }
                    .keyboardShortcut(.cancelAction)
                Button("Convert") { run() }
                    .buttonStyle(AccentButtonStyle())
                    .keyboardShortcut(.defaultAction)
                    .disabled(selected?.isAvailable != true)
            }
            .padding(14)
        }
        .onAppear(perform: setup)
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image(nsImage: NSWorkspace.shared.icon(forFile: first.url.path))
                .resizable().frame(width: 40, height: 40)
            VStack(alignment: .leading, spacing: 2) {
                Text(assets.count == 1 ? first.name : "\(assets.count) files").font(.system(size: 14, weight: .semibold)).lineLimit(1)
                Text(assets.count == 1 ? first.summary : Set(assets.compactMap { $0.format?.displayName }).sorted().joined(separator: ", "))
                    .font(.system(size: 11.5)).foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(.horizontal, 18)
        .padding(.top, 34)
        .padding(.bottom, 14)
    }

    private var formatGrid: some View {
        SectionCard(title: "Convert to") {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 92), spacing: 8)], spacing: 8) {
                ForEach(targets) { t in
                    let isSel = selected?.id == t.id
                    Button {
                        selected = t
                        quality = state.prefs.quality(for: t.format)
                    } label: {
                        VStack(spacing: 3) {
                            Image(systemName: ActionCatalog.formatSymbol(t.format)).font(.system(size: 14))
                            Text(t.label).font(.system(size: 11.5, weight: .semibold)).lineLimit(1)
                        }
                        .frame(maxWidth: .infinity, minHeight: 50)
                        .foregroundStyle(isSel ? Color.white : Color.primary)
                        .background(RoundedRectangle(cornerRadius: 9, style: .continuous).fill(isSel ? state.accentColor : Color.primary.opacity(0.05)))
                        .opacity(t.isAvailable ? 1 : 0.45)
                    }
                    .buttonStyle(.plain)
                    .help(t.note ?? t.format.displayName)
                }
            }
        }
    }

    @ViewBuilder
    private func options(for t: ConversionTarget) -> some View {
        let source = first.kind
        if t.format.isLossy || t.format == .avif {
            SectionCard(title: "Quality") {
                HStack {
                    Slider(value: $quality, in: 0.1...1)
                    Text("\(Int(quality * 100))").monospacedDigit().frame(width: 34)
                }
                if t.format == .webp { Toggle("Lossless WebP", isOn: $lossless) }
            }
        }
        if (source == .image || source == .rawImage) && t.format.category == .raster {
            SectionCard(title: "Size & metadata") {
                Picker("Maximum size", selection: $maxSizeChoice) {
                    ForEach(maxSizes.indices, id: \.self) { i in
                        Text(maxSizes[i] == 0 ? "Original size" : maxSizes[i] < 0 ? "Custom…" : "\(maxSizes[i]) px longest side").tag(i)
                    }
                }
                if maxSizes[maxSizeChoice] < 0 {
                    Stepper("Longest side: \(customMax) px", value: $customMax, in: 16...16000, step: 16)
                }
                Picker("Metadata", selection: $metadata) {
                    ForEach(MetadataPolicy.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                Picker("Colour profile", selection: $colourProfile) {
                    ForEach(ColourProfileChoice.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                if !t.format.supportsAlpha && assets.contains(where: { $0.hasAlpha == true }) {
                    ColorPicker("Background for transparent areas", selection: $matte, supportsOpacity: false)
                }
            }
        }
        if (source == .pdf || source == .document || source == .presentation || first.format == .ai) && t.format.category == .raster {
            SectionCard(title: "Pages") {
                TextField("Pages, e.g. 1-3, 5 (or All)", text: $pagesText)
                    .textFieldStyle(.roundedBorder)
                if let n = first.pageCount, n > 0 {
                    Text(PDFEngine.parsePageList(pagesText, pageCount: n) == nil ? "Enter pages between 1 and \(n)." : "\(PDFEngine.parsePageList(pagesText, pageCount: n)?.count ?? 0) of \(n) pages")
                        .font(.system(size: 11)).foregroundStyle(PDFEngine.parsePageList(pagesText, pageCount: n) == nil ? .red : .secondary)
                }
                Picker("Resolution", selection: $dpi) {
                    Text("72 dpi (screen)").tag(72.0)
                    Text("150 dpi").tag(150.0)
                    Text("300 dpi (print)").tag(300.0)
                    Text("600 dpi").tag(600.0)
                }
                if t.format.supportsAlpha { Toggle("Transparent background", isOn: $transparentPages) }
            }
        }
        if t.variant == .trace {
            SectionCard(title: "Tracing") {
                Stepper("Colours: \(traceColours)", value: $traceColours, in: 2...16)
                Text(traceColours <= 2
                     ? (ExternalTools.path(.potrace) != nil ? "Two colours: traced with Potrace for smooth curves — ideal for logos and line art." : "Two colours suits logos and line art. Install Potrace for smoother curves.")
                     : "More colours keep more detail but make larger, busier files. Tracing is an approximation.")
                    .font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
        if first.format == .svg && t.format.category == .raster {
            SectionCard(title: "Render scale") {
                Picker("Scale", selection: $svgScale) {
                    Text("1×").tag(1.0); Text("2×").tag(2.0); Text("3×").tag(3.0); Text("4×").tag(4.0)
                }
                .pickerStyle(.segmented)
            }
        }
        if source == .video {
            if [.mp4, .mov, .m4v].contains(t.format) {
                SectionCard(title: "Video") {
                    Picker("Encoding", selection: $videoQuality) {
                        ForEach(VideoQuality.allCases, id: \.self) { Text($0.title).tag($0) }
                    }
                }
            }
            SectionCard(title: "Time range (seconds, optional)") {
                HStack {
                    TextField("Start", text: $start).textFieldStyle(.roundedBorder)
                    TextField("End", text: $end).textFieldStyle(.roundedBorder)
                }
                if t.format == .gif || t.format == .webp {
                    Stepper("Frame rate: \(Int(fps)) fps", value: $fps, in: 4...30)
                    Stepper("Width: \(gifWidth) px", value: $gifWidth, in: 120...1600, step: 40)
                    Text("Without an end time the first 10 seconds are used.").font(.system(size: 11)).foregroundStyle(.secondary)
                }
            }
        }
        if source == .document && t.format == .pdf {
            SectionCard(title: "Page") {
                Picker("Page size", selection: $pageSize) {
                    ForEach(PDFPageSize.allCases.filter { $0 != .fitImage }, id: \.self) { Text($0.title).tag($0) }
                }
            }
        }
    }

    private func setup() {
        targets = ConversionEngine.targets(for: first, preferredOrder: state.prefs.preferredFormats)
        if assets.count > 1 {
            let others = assets.dropFirst().map { Set(ConversionEngine.targets(for: $0).map(\.id)) }
            targets = targets.filter { t in others.allSatisfy { $0.contains(t.id) } }
        }
        selected = preselect.flatMap { p in targets.first { $0.id == p.id } } ?? targets.first { $0.isAvailable }
        if let s = selected { quality = state.prefs.quality(for: s.format) }
        metadata = state.prefs.metadataPolicy
        dpi = state.prefs.pdfDPI
        svgScale = state.prefs.svgRenderScale
        destination = state.prefs.output.destination
    }

    private func run() {
        guard let t = selected else { return }
        var o = state.conversionOptions(for: t.format)
        o.image.quality = quality
        o.image.lossless = lossless
        o.image.metadata = metadata
        o.image.matte = RGBAColour(color: matte)
        o.image.colourProfile = colourProfile
        o.image.traceColours = traceColours
        let m = maxSizes[maxSizeChoice]
        o.image.maxPixelSize = m == 0 ? nil : (m < 0 ? customMax : m)
        if let n = first.pageCount { o.pdfPages = PDFEngine.parsePageList(pagesText, pageCount: n) }
        o.pdfDPI = dpi
        o.pdfTransparentBackground = transparentPages
        o.svgScale = svgScale
        o.video.quality = videoQuality
        o.video.start = Double(start.trimmingCharacters(in: .whitespaces))
        o.video.end = Double(end.trimmingCharacters(in: .whitespaces))
        o.video.gifFPS = fps
        o.video.gifMaxWidth = gifWidth
        o.document.pageSize = pageSize
        // The per-run destination doesn't change the saved preference.
        WindowManager.shared.close("convert")
        ActionRunner.shared.startConversion(assets, target: t, options: o, destination: destination)
    }
}

// MARK: - Batch resize / compress

enum BatchOptionsMode { case resize, compress }

extension Windows {
    static func openBatchOptions(assets: [AssetInfo], mode: BatchOptionsMode) {
        WindowManager.shared.show(id: "batch", title: mode == .resize ? "Resize \(assets.count) images" : "Compress \(assets.count) images",
                                  size: CGSize(width: 460, height: 380), resizable: false) {
            BatchOptionsView(assets: assets, mode: mode)
        }
    }
}

@MainActor
struct BatchOptionsView: View {
    let assets: [AssetInfo]
    let mode: BatchOptionsMode
    @EnvironmentObject var state: AppState
    @State private var maxWidth = 1600
    @State private var maxHeight = 1600
    @State private var format: Format = .jpeg
    @State private var quality = 0.8
    @State private var targetKB = 0

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(mode == .resize ? "Fit every image within a box (never upscales)" : "Re-encode every image to save space")
                .font(.system(size: 13, weight: .semibold))
                .padding(.top, 24)
            if mode == .resize {
                SectionCard(title: "Maximum size") {
                    Stepper("Width: \(maxWidth) px", value: $maxWidth, in: 16...16000, step: 16)
                    Stepper("Height: \(maxHeight) px", value: $maxHeight, in: 16...16000, step: 16)
                }
            }
            SectionCard(title: "Format") {
                Picker("Format", selection: $format) {
                    ForEach([Format.jpeg, .webp, .heic, .png, .avif].filter(ImageEncoder.canWrite), id: \.self) { Text($0.displayName).tag($0) }
                }
                if format.isLossy || format == .avif {
                    HStack { Slider(value: $quality, in: 0.1...1); Text("\(Int(quality * 100))").monospacedDigit().frame(width: 30) }
                }
                if mode == .compress {
                    Picker("Target size", selection: $targetKB) {
                        Text("Quality slider").tag(0)
                        Text("≤ 200 KB").tag(200)
                        Text("≤ 500 KB").tag(500)
                        Text("≤ 1 MB").tag(1024)
                    }
                }
            }
            Spacer()
            HStack {
                Spacer()
                Button("Cancel") { WindowManager.shared.close("batch") }
                Button(mode == .resize ? "Resize" : "Compress") { run() }.buttonStyle(AccentButtonStyle()).keyboardShortcut(.defaultAction)
            }
        }
        .padding(18)
    }

    private func run() {
        let fmt = format, q = quality, kb = targetKB, mw = maxWidth, mh = maxHeight, isResize = mode == .resize
        let metadata = state.prefs.metadataPolicy
        ActionRunner.shared.withPlanner { planner, delivery in
            JobCenter.shared.run(title: isResize ? "Resizing" : "Compressing", items: assets.map(\.url), delivery: delivery) { url in
                let asset = AssetInspector.inspect(url)
                if isResize {
                    let loaded = try ImageLoader.load(url)
                    let size = ImageOps.fittedSize(width: loaded.image.width, height: loaded.image.height, maxWidth: mw, maxHeight: mh)
                    let resized = ImageOps.resize(loaded.image, to: size)
                    var o = ImageExportOptions()
                    o.quality = q
                    o.metadata = metadata
                    let dest = planner.url(for: url, ext: fmt.fileExtension, format: fmt.displayName, pixelSize: (resized.width, resized.height))
                    try ImageEncoder.write(resized, sourceProperties: loaded.properties, format: fmt, to: dest, options: o)
                    return [dest]
                }
                let r = try ImageCompressor.compress(asset, format: fmt, quality: q, targetBytes: kb > 0 ? kb * 1024 : nil, metadata: metadata, planner: planner)
                return [r.url]
            }
        }
        WindowManager.shared.close("batch")
    }
}
