import AppKit
import HexshiftKit
import PDFKit
import SwiftUI

extension Windows {
    static func openTextStudio(text: String, attributed: NSAttributedString?, format: Format, graphic: Bool = false, sourceName: String? = nil) {
        let model = TextStudioModel(text: text, attributed: attributed, format: format, graphic: graphic, sourceName: sourceName)
        WindowManager.shared.show(id: "text-studio", title: graphic ? "Create Graphic from Text" : "Text Studio",
                                  size: CGSize(width: 1000, height: 680), minSize: CGSize(width: 820, height: 540)) {
            TextStudioView(model: model)
        }
    }
}

@MainActor
final class TextStudioModel: ObservableObject {
    @Published var text: String { didSet { if text != oldValue { attributed = nil; schedulePreview() } } }
    @Published var attributed: NSAttributedString?
    @Published var graphicMode: Bool { didSet { schedulePreview() } }
    @Published var format: Format { didSet { schedulePreview() } }
    @Published var treatAsMarkdown = false { didSet { schedulePreview() } }
    // Document settings
    @Published var pageSize: PDFPageSize = .a4 { didSet { schedulePreview() } }
    @Published var landscape = false { didSet { schedulePreview() } }
    @Published var fontName = "" { didSet { schedulePreview() } }
    @Published var fontSize = 12.0 { didSet { schedulePreview() } }
    @Published var margin = 54.0 { didSet { schedulePreview() } }
    @Published var lineSpacing = 1.25 { didSet { schedulePreview() } }
    // Image settings
    @Published var canvasWidth = 1080 { didSet { schedulePreview() } }
    @Published var fixedHeight = false { didSet { schedulePreview() } }
    @Published var canvasHeight = 1080 { didSet { schedulePreview() } }
    @Published var imageFontSize = 48.0 { didSet { schedulePreview() } }
    @Published var bold = false { didSet { schedulePreview() } }
    @Published var textColour = Color(red: 0.17, green: 0.16, blue: 0.16) { didSet { schedulePreview() } }
    @Published var bgColour = Color.white { didSet { schedulePreview() } }
    @Published var transparent = false { didSet { schedulePreview() } }
    @Published var alignment: TextAlign = .left { didSet { schedulePreview() } }
    @Published var padding = 72.0 { didSet { schedulePreview() } }
    // Graphic settings
    @Published var preset: GraphicPreset = .instagramQuote { didSet { schedulePreview() } }
    @Published var accent: Color { didSet { schedulePreview() } }
    @Published var graphicBackground = Color(red: 0.98, green: 0.96, blue: 0.93) { didSet { schedulePreview() } }
    @Published var graphicText = Color(red: 0.15, green: 0.14, blue: 0.13) { didSet { schedulePreview() } }
    @Published var headlineFont = "" { didSet { schedulePreview() } }
    @Published var label = "ANNOUNCEMENT" { didSet { schedulePreview() } }

    @Published private(set) var preview: NSImage?
    @Published private(set) var previewNote = ""
    let sourceName: String?
    private var task: Task<Void, Never>?

    init(text: String, attributed: NSAttributedString?, format: Format, graphic: Bool, sourceName: String?) {
        self.text = text
        self.attributed = attributed
        self.format = format
        graphicMode = graphic
        self.sourceName = sourceName
        accent = AppState.shared.accentColor
        treatAsMarkdown = text.contains("# ") || text.contains("**") || text.contains("\n- ")
        schedulePreview()
    }

    var documentOptions: DocumentOptions {
        var o = DocumentOptions()
        o.pageSize = pageSize
        o.landscape = landscape
        o.margin = margin
        o.fontName = fontName.isEmpty ? nil : fontName
        o.fontSize = fontSize
        o.lineSpacing = lineSpacing
        o.useExternalEngines = false
        return o
    }

    var imageOptions: TextImageOptions {
        var o = TextImageOptions()
        o.width = canvasWidth
        o.height = fixedHeight ? canvasHeight : nil
        o.fontName = fontName.isEmpty ? nil : fontName
        o.fontSize = imageFontSize
        o.bold = bold
        o.textColour = RGBAColour(color: textColour)
        o.background = transparent ? .clear : RGBAColour(color: bgColour)
        o.alignment = alignment
        o.padding = padding
        o.lineSpacing = lineSpacing
        return o
    }

    var graphicStyle: GraphicStyle {
        var s = GraphicStyle()
        s.accent = RGBAColour(color: accent)
        s.background = RGBAColour(color: graphicBackground)
        s.text = RGBAColour(color: graphicText)
        s.headlineFont = headlineFont.isEmpty ? nil : headlineFont
        s.alignment = alignment
        s.label = label
        return s
    }

    var isImageFormat: Bool { graphicMode || [.png, .jpeg, .svg].contains(format) }

    func schedulePreview() {
        task?.cancel()
        task = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 180_000_000)
            guard let self, !Task.isCancelled else { return }
            await self.renderPreview()
        }
    }

    private func renderPreview() async {
        let t = text.isEmpty ? "Type or paste text on the left." : text
        if graphicMode {
            let preset = self.preset, style = graphicStyle
            let img = await Task.detached { TextGraphics.graphic(preset, text: t, style: style) }.value
            preview = img.map { NSImage(cg: $0) }
            previewNote = "\(Int(preset.size.width)) × \(Int(preset.size.height)) px"
        } else if [.png, .jpeg, .svg].contains(format) {
            let o = imageOptions
            let img = await Task.detached { TextGraphics.render(t, options: o) }.value
            preview = img.map { NSImage(cg: $0) }
            previewNote = img.map { "\($0.width) × \($0.height) px" + (format == .svg ? " · SVG keeps real, editable text" : "") } ?? ""
        } else {
            // Render the first page of the real PDF output.
            do {
                let tmp = try FileWriter.makeTemporaryDirectory().appendingPathComponent("preview.pdf")
                defer { try? FileManager.default.removeItem(at: tmp.deletingLastPathComponent()) }
                let attr = try currentAttributed()
                try DocumentConverter.exportPDF(attr, to: tmp, options: documentOptions)
                if let doc = PDFDocument(url: tmp), let page = doc.page(at: 0), let img = PDFEngine.render(page, dpi: 110) {
                    preview = NSImage(cg: img)
                    previewNote = "\(doc.pageCount) page\(doc.pageCount == 1 ? "" : "s") · \(pageSize.title)\(landscape ? " landscape" : "")"
                }
            } catch {
                previewNote = (error as? LocalizedError)?.errorDescription ?? "Preview unavailable"
            }
        }
    }

    func currentAttributed() throws -> NSAttributedString {
        if let a = attributed, fontName.isEmpty { return a }
        if treatAsMarkdown { return try DocumentConverter.attributedString(fromHTML: MarkdownRenderer.html(from: text, title: sourceName)) }
        return DocumentConverter.styledFromPlain(text, options: documentOptions)
    }

    func export() {
        let fmt = graphicMode ? (format == .jpeg ? Format.jpeg : .png) : format
        let base = sourceName ?? (graphicMode ? preset.title : "Text")
        let snapshotText = text
        let docOptions = documentOptions
        let imgOptions = imageOptions
        let style = graphicStyle
        let p = preset
        let graphic = graphicMode
        let attr: NSAttributedString?
        do { attr = [.png, .jpeg, .svg].contains(fmt) || graphic ? nil : try currentAttributed() } catch { JobCenter.shared.error(error); return }
        let markdown = treatAsMarkdown
        ActionRunner.shared.withPlanner { planner, delivery in
            JobCenter.shared.runTask(title: "Exporting \(fmt.displayName)", delivery: delivery, successTitle: "\(fmt.displayName) saved") {
                let dest = planner.url(for: nil, baseName: base, ext: fmt.fileExtension)
                if graphic {
                    guard let img = TextGraphics.graphic(p, text: snapshotText, style: style) else { throw HexError.message("The graphic could not be drawn.") }
                    try ImageEncoder.write(img, format: fmt, to: dest)
                } else {
                    switch fmt {
                    case .png, .jpeg:
                        guard let img = TextGraphics.render(snapshotText, options: imgOptions) else { throw HexError.message("The image could not be drawn.") }
                        try ImageEncoder.write(img, format: fmt, to: dest)
                    case .svg:
                        try FileWriter.writeAtomically(to: dest) { try Data(TextGraphics.svg(snapshotText, options: imgOptions).utf8).write(to: $0) }
                    case .md where !markdown, .txt:
                        try FileWriter.writeAtomically(to: dest) { try Data(snapshotText.utf8).write(to: $0) }
                    case .html where markdown, .md:
                        try await MainActor.run { try DocumentConverter.export(text: snapshotText, as: fmt, to: dest, options: docOptions, treatAsMarkdown: true, title: base) }
                    default:
                        let a = attr ?? NSAttributedString(string: snapshotText)
                        try await MainActor.run { try DocumentConverter.write(a, as: fmt, to: dest, options: docOptions, title: base) }
                    }
                }
                return [dest]
            }
        }
    }

    func copyRichText() {
        guard let attr = try? currentAttributed() else { return }
        let pb = NSPasteboard.general
        pb.clearContents()
        pb.writeObjects([attr])
        JobCenter.shared.message("Copied as rich text")
    }
}

@MainActor
struct TextStudioView: View {
    @ObservedObject var model: TextStudioModel
    @EnvironmentObject var state: AppState

    private let documentFormats: [Format] = [.pdf, .docx, .rtf, .odt, .md, .html, .txt]
    private let imageFormats: [Format] = [.png, .jpeg, .svg]

    var body: some View {
        HStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 8) {
                Picker("", selection: $model.graphicMode) {
                    Text("Export").tag(false)
                    Text("Create Graphic").tag(true)
                }
                .pickerStyle(.segmented)
                .frame(width: 240)
                .padding(.top, 30)
                TextEditor(text: $model.text)
                    .font(.system(size: 13))
                    .scrollContentBackground(.hidden)
                    .padding(8)
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color.primary.opacity(0.04)))
                let s = DocumentConverter.statistics(model.text)
                HStack {
                    Text("\(s.words) words").font(.system(size: 11)).foregroundStyle(.secondary)
                    Spacer()
                    if !model.graphicMode { Toggle("Markdown", isOn: $model.treatAsMarkdown).toggleStyle(.checkbox).font(.system(size: 11.5)) }
                    Button("Copy Rich Text") { model.copyRichText() }.controlSize(.small)
                }
            }
            .padding(14)
            .frame(width: 320)
            Divider()
            VStack(spacing: 8) {
                ZStack {
                    if model.transparent && model.isImageFormat && !model.graphicMode { Checkerboard() }
                    if let p = model.preview {
                        Image(nsImage: p).resizable().aspectRatio(contentMode: .fit)
                            .shadow(color: .black.opacity(0.15), radius: 8, y: 3)
                            .padding(20)
                    } else {
                        ProgressView()
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.primary.opacity(0.03))
                Text(model.previewNote).font(.system(size: 11)).foregroundStyle(.secondary).padding(.bottom, 8)
            }
            Divider()
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    if model.graphicMode { graphicSettings } else { exportSettings }
                    HStack {
                        Spacer()
                        Button(model.graphicMode ? "Export Graphic" : "Export \(model.format.displayName)") { model.export() }
                            .buttonStyle(AccentButtonStyle())
                            .keyboardShortcut("s", modifiers: .command)
                    }
                }
                .padding(14)
                .padding(.top, 20)
            }
            .frame(width: 290)
        }
    }

    private var fontPicker: some View {
        Picker("Font", selection: $model.fontName) {
            Text("System").tag("")
            ForEach(["Helvetica Neue", "Avenir Next", "Georgia", "New York", "Times New Roman", "Futura", "Gill Sans", "Baskerville", "Menlo", "Charter", "Optima"]
                        .filter { NSFont(name: $0, size: 12) != nil || NSFontManager.shared.availableFontFamilies.contains($0) }, id: \.self) { f in
                Text(f).tag(f)
            }
        }
    }

    @ViewBuilder
    private var exportSettings: some View {
        SectionCard(title: "Format") {
            Picker("Document", selection: $model.format) {
                ForEach(documentFormats + imageFormats, id: \.self) { Text($0.displayName).tag($0) }
            }
            .labelsHidden()
        }
        if model.isImageFormat {
            SectionCard(title: "Canvas") {
                Stepper("Width: \(model.canvasWidth) px", value: $model.canvasWidth, in: 200...4000, step: 20)
                Toggle("Fixed height", isOn: $model.fixedHeight)
                if model.fixedHeight { Stepper("Height: \(model.canvasHeight) px", value: $model.canvasHeight, in: 100...4000, step: 20) }
                Stepper("Padding: \(Int(model.padding)) px", value: $model.padding, in: 0...300, step: 4)
            }
            SectionCard(title: "Type") {
                fontPicker
                Stepper("Size: \(Int(model.imageFontSize)) px", value: $model.imageFontSize, in: 8...300)
                Toggle("Bold", isOn: $model.bold)
                Picker("Alignment", selection: $model.alignment) {
                    Image(systemName: "text.alignleft").tag(TextAlign.left)
                    Image(systemName: "text.aligncenter").tag(TextAlign.center)
                    Image(systemName: "text.alignright").tag(TextAlign.right)
                }
                .pickerStyle(.segmented)
                ColorPicker("Text colour", selection: $model.textColour, supportsOpacity: false)
                Toggle("Transparent background", isOn: $model.transparent).disabled(model.format == .jpeg)
                if !model.transparent || model.format == .jpeg { ColorPicker("Background", selection: $model.bgColour, supportsOpacity: false) }
            }
        } else {
            SectionCard(title: "Page") {
                Picker("Page size", selection: $model.pageSize) {
                    ForEach(PDFPageSize.allCases.filter { $0 != .fitImage }, id: \.self) { Text($0.title).tag($0) }
                }
                Toggle("Landscape", isOn: $model.landscape)
                Stepper("Margins: \(Int(model.margin)) pt", value: $model.margin, in: 18...144, step: 6)
            }
            SectionCard(title: "Type") {
                fontPicker
                Stepper("Size: \(Int(model.fontSize)) pt", value: $model.fontSize, in: 6...48)
                Stepper(String(format: "Line spacing: %.2f", model.lineSpacing), value: $model.lineSpacing, in: 0.9...2.5, step: 0.05)
                if model.attributed != nil && model.fontName.isEmpty {
                    Text("Keeping the original document's formatting. Choose a font to restyle.").font(.system(size: 10.5)).foregroundStyle(.secondary)
                }
            }
        }
    }

    @ViewBuilder
    private var graphicSettings: some View {
        SectionCard(title: "Preset") {
            Picker("Preset", selection: $model.preset) {
                ForEach(GraphicPreset.allCases) { Text($0.title).tag($0) }
            }
            .labelsHidden()
            Text("The first line becomes the headline; following lines are supporting text.").font(.system(size: 10.5)).foregroundStyle(.secondary)
            Picker("Save as", selection: $model.format) {
                Text("PNG").tag(Format.png)
                Text("JPEG").tag(Format.jpeg)
            }
            .pickerStyle(.segmented)
        }
        SectionCard(title: "Style") {
            ColorPicker("Accent", selection: $model.accent, supportsOpacity: false)
            ColorPicker("Background", selection: $model.graphicBackground, supportsOpacity: false)
            ColorPicker("Text", selection: $model.graphicText, supportsOpacity: false)
            Picker("Headline font", selection: $model.headlineFont) {
                Text("System").tag("")
                ForEach(["Georgia", "New York", "Avenir Next", "Futura", "Helvetica Neue", "Didot", "Baskerville", "Gill Sans", "American Typewriter"]
                            .filter { NSFontManager.shared.availableFontFamilies.contains($0) }, id: \.self) { Text($0).tag($0) }
            }
            Picker("Alignment", selection: $model.alignment) {
                Text("Left").tag(TextAlign.left)
                Text("Centre").tag(TextAlign.center)
                Text("Right").tag(TextAlign.right)
            }
            .pickerStyle(.segmented)
            if model.preset == .announcement { TextField("Label", text: $model.label).textFieldStyle(.roundedBorder) }
        }
    }
}
