import AppKit
import HexshiftKit
import SwiftUI
#if canImport(Translation) && compiler(>=6.0)
import Translation
#endif

/// On-device translation with Apple's Translation framework (macOS 15+). On older systems the
/// action isn't offered at all — HEXSHIFT never shows placeholder features.
enum TranslateSupport {
    static var isAvailable: Bool {
        #if canImport(Translation) && compiler(>=6.0)
        if #available(macOS 15.0, *) { return true }
        #endif
        return false
    }
}

extension Windows {
    static func openTranslate(text: String) {
        #if canImport(Translation) && compiler(>=6.0)
        if #available(macOS 15.0, *) {
            WindowManager.shared.show(id: "translate", title: "Translate", size: CGSize(width: 680, height: 460),
                                      minSize: CGSize(width: 520, height: 360)) {
                TranslateView(source: text)
            }
            return
        }
        #endif
        JobCenter.shared.message("Translation needs macOS 15 or later", kind: .error)
    }
}

#if canImport(Translation) && compiler(>=6.0)
@available(macOS 15.0, *)
@MainActor
struct TranslateView: View {
    let source: String
    @AppStorage("translateTarget") private var target = "en"
    @State private var configuration: TranslationSession.Configuration?
    @State private var result = ""
    @State private var problem: String?
    @State private var working = false

    static let languages: [(code: String, name: String)] = [
        ("en", "English"), ("hi", "Hindi"), ("es", "Spanish"), ("fr", "French"), ("de", "German"),
        ("it", "Italian"), ("pt", "Portuguese"), ("nl", "Dutch"), ("pl", "Polish"), ("tr", "Turkish"),
        ("ru", "Russian"), ("uk", "Ukrainian"), ("ar", "Arabic"), ("ja", "Japanese"), ("ko", "Korean"),
        ("zh-Hans", "Chinese (Simplified)"), ("zh-Hant", "Chinese (Traditional)"), ("id", "Indonesian"),
        ("th", "Thai"), ("vi", "Vietnamese"),
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Text("Translate to").font(.system(size: 12))
                Picker("", selection: $target) {
                    ForEach(Self.languages, id: \.code) { Text($0.name).tag($0.code) }
                }
                .labelsHidden()
                .frame(width: 220)
                .onChange(of: target) { _, _ in start() }
                Spacer()
                Button(working ? "Translating…" : "Translate Again") { start() }
                    .buttonStyle(AccentButtonStyle())
                    .disabled(working)
            }
            HStack(alignment: .top, spacing: 12) {
                pane(title: "Original", text: source)
                pane(title: "Translation", text: result.isEmpty ? (problem ?? (working ? "…" : "")) : result)
            }
            HStack(alignment: .top) {
                Text("Translated on this Mac by Apple's Translation framework. The first time you choose a language, macOS may ask to download it.")
                    .font(.system(size: 10.5)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                Spacer()
                Button("Copy Translation") { Clipboard.copy(result) }.disabled(result.isEmpty)
            }
        }
        .padding(18)
        .translationTask(configuration) { session in
            do {
                let response = try await session.translate(source)
                await MainActor.run {
                    result = response.targetText
                    problem = nil
                    working = false
                }
            } catch {
                let message = "Couldn't translate: \(error.localizedDescription)"
                await MainActor.run {
                    problem = message
                    working = false
                }
            }
        }
        .onAppear { start() }
    }

    private func pane(title: String, text: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary)
            ScrollView {
                Text(text)
                    .font(.system(size: 13))
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(10)
            }
            .background(RoundedRectangle(cornerRadius: 10).fill(Color.primary.opacity(0.04)))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func start() {
        working = true
        result = ""
        problem = nil
        let language = Locale.Language(identifier: target)
        if configuration?.target == language {
            configuration?.invalidate()
        } else {
            configuration = TranslationSession.Configuration(source: nil, target: language)
        }
    }
}
#endif
