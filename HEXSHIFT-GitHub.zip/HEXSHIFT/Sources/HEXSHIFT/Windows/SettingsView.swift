import AppKit
import Carbon.HIToolbox
import HexshiftKit
import SwiftUI
import UniformTypeIdentifiers

extension Windows {
    static func openSettings(tab: SettingsView.Tab = .general) {
        WindowManager.shared.show(id: "settings", title: "HEXSHIFT Settings", size: CGSize(width: 840, height: 620), minSize: CGSize(width: 720, height: 500)) {
            SettingsView(initialTab: tab)
        }
    }
}

@MainActor
struct SettingsView: View {
    enum Tab: String, CaseIterable, Identifiable {
        case general = "General", activation = "Activation", radial = "Radial Menu", conversion = "Conversion"
        case typography = "Typography", privacy = "Privacy", workflows = "Workflows", about = "About"
        var id: String { rawValue }
        var symbol: String {
            switch self {
            case .general: return "gearshape"
            case .activation: return "keyboard"
            case .radial: return "hexagon"
            case .conversion: return "arrow.triangle.2.circlepath"
            case .typography: return "textformat"
            case .privacy: return "hand.raised"
            case .workflows: return "bolt"
            case .about: return "info.circle"
            }
        }
    }

    @State var tab: Tab
    @EnvironmentObject var state: AppState
    init(initialTab: Tab) { _tab = State(initialValue: initialTab) }

    var body: some View {
        HStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 2) {
                ForEach(Tab.allCases) { t in
                    Button { tab = t } label: {
                        Label(t.rawValue, systemImage: t.symbol)
                            .font(.system(size: 13, weight: tab == t ? .semibold : .regular))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(RoundedRectangle(cornerRadius: 7, style: .continuous)
                                .fill(tab == t ? state.accentColor.opacity(0.16) : Color.clear))
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(tab == t ? state.accentColor : Color.primary)
                    .accessibilityAddTraits(tab == t ? .isSelected : [])
                }
                Spacer()
            }
            .padding(.horizontal, 10)
            .padding(.top, 40)
            .frame(width: 180)
            .frame(maxHeight: .infinity)
            .background(Color.primary.opacity(0.035))
            Divider()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text(tab.rawValue).font(.system(size: 20, weight: .semibold))
                    switch tab {
                    case .general: GeneralSettings()
                    case .activation: ActivationSettings()
                    case .radial: RadialSettings()
                    case .conversion: ConversionSettings()
                    case .typography: TypographySettings()
                    case .privacy: PrivacySettings()
                    case .workflows: WorkflowSettings()
                    case .about: AboutSettings()
                    }
                }
                .padding(24)
                .padding(.top, 12)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }
}

/// A fixed-width label next to a control, so rows line up.
@MainActor
struct LabeledRow<Content: View>: View {
    let title: String
    @ViewBuilder var content: Content
    init(_ title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    var body: some View {
        HStack(spacing: 10) {
            Text(title).frame(width: 84, alignment: .leading)
            content
        }
    }
}

// MARK: - General

@MainActor
private struct GeneralSettings: View {
    @EnvironmentObject var state: AppState
    @State private var loginEnabled = LoginItem.isEnabled
    @State private var loginError: String?
    @State private var customPattern = "{name}-{format}"

    var body: some View {
        SectionCard(title: "Startup") {
            Toggle("Launch HEXSHIFT at login", isOn: Binding(get: { loginEnabled }, set: { on in
                do {
                    try LoginItem.set(on)
                    loginEnabled = LoginItem.isEnabled
                    loginError = LoginItem.requiresApproval ? "Approve HEXSHIFT in System Settings › General › Login Items." : nil
                } catch {
                    loginError = "macOS refused: \(error.localizedDescription). Launch at login works once HEXSHIFT is in /Applications."
                }
            }))
            if let e = loginError { Text(e).font(.system(size: 11)).foregroundStyle(.orange) }
            Toggle("Show icon in the menu bar", isOn: $state.prefs.showMenuBarIcon)
            if !state.prefs.showMenuBarIcon {
                Text("Open HEXSHIFT again from Applications or Spotlight to get back to Settings.").font(.system(size: 11)).foregroundStyle(.secondary)
            }
        }
        SectionCard(title: "Where results are saved") {
            Picker("Destination", selection: $state.prefs.output.destination) {
                Text("Same folder as original").tag(OutputDestination.sameFolder)
                Text("Desktop").tag(OutputDestination.desktop)
                Text("Downloads").tag(OutputDestination.downloads)
                Text("Clipboard only").tag(OutputDestination.clipboardOnly)
                Text("Ask every time").tag(OutputDestination.askEveryTime)
                if case let .custom(path) = state.prefs.output.destination {
                    Text("Custom: \((path as NSString).lastPathComponent)").tag(OutputDestination.custom(path: path))
                }
            }
            Button("Choose Custom Folder…") {
                let panel = NSOpenPanel()
                panel.canChooseDirectories = true
                panel.canChooseFiles = false
                panel.canCreateDirectories = true
                panel.level = .modalPanel   // stay above other apps, so it can't hide behind them
                if panel.runModal() == .OK, let url = panel.url { state.prefs.output.destination = .custom(path: url.path) }
            }
            Text("Originals are never overwritten or deleted.").font(.system(size: 11)).foregroundStyle(.secondary)
        }
        SectionCard(title: "File names") {
            Picker("Naming", selection: Binding(get: { namingKey }, set: { setNaming($0) })) {
                Text("photo-converted.png (default)").tag("suffix")
                Text("photo.png (original name, new extension)").tag("original")
                Text("photo-1.png (numbered)").tag("numbered")
                Text("photo-20261024-013200.png (timestamp)").tag("timestamp")
                Text("Custom pattern").tag("custom")
            }
            if namingKey == "custom" {
                TextField("Pattern", text: $customPattern)
                    .textFieldStyle(.roundedBorder)
                    .onSubmit { state.prefs.output.naming = .custom(customPattern) }
                Text("Tokens: {name} {format} {ext} {date} {time} {w} {h} {n}. Press Return to apply.")
                    .font(.system(size: 11)).foregroundStyle(.secondary)
            }
            Text("If a file with that name exists, a number is added (“photo-converted 2.png”).").font(.system(size: 11)).foregroundStyle(.secondary)
        }
        .onAppear { if case let .custom(p) = state.prefs.output.naming { customPattern = p } }
    }

    private var namingKey: String {
        switch state.prefs.output.naming {
        case .suffix: return "suffix"
        case .originalName: return "original"
        case .numbered: return "numbered"
        case .timestamp: return "timestamp"
        case .custom: return "custom"
        }
    }

    private func setNaming(_ key: String) {
        switch key {
        case "original": state.prefs.output.naming = .originalName
        case "numbered": state.prefs.output.naming = .numbered
        case "timestamp": state.prefs.output.naming = .timestamp
        case "custom": state.prefs.output.naming = .custom(customPattern)
        default: state.prefs.output.naming = .suffix("-converted")
        }
    }
}

// MARK: - Activation

@MainActor
private struct ActivationSettings: View {
    @EnvironmentObject var state: AppState
    @State private var recording = false
    @State private var monitor: Any?
    @State private var message: String?
    @State private var quickActionInstalled = false
    @State private var finderMessage: String?

    var body: some View {
        SectionCard(title: "Keyboard shortcut") {
            Toggle("Open the radial menu with a shortcut", isOn: $state.prefs.hotKeyEnabled)
            HStack {
                Text(recording ? "Press the new shortcut…" : state.prefs.hotKey.display)
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .frame(minWidth: 140)
                    .padding(.vertical, 6)
                    .background(RoundedRectangle(cornerRadius: 8).strokeBorder(recording ? state.accentColor : Color.primary.opacity(0.15), lineWidth: recording ? 2 : 1))
                Button(recording ? "Cancel" : "Record Shortcut") { recording ? stopRecording() : startRecording() }
                Button("Reset to ⌥ Space") { state.prefs.hotKey = .optionSpace }
            }
            if let message { Text(message).font(.system(size: 11)).foregroundStyle(.orange) }
            Text("The shortcut opens the wheel at the pointer. Selected Finder files or selected text are used automatically when HEXSHIFT is allowed to read them (Privacy tab).")
                .font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
        SectionCard(title: "Modifier-click") {
            Toggle("Open the wheel with a modifier + right-click", isOn: $state.prefs.modifierClickEnabled)
            Picker("Gesture", selection: $state.prefs.modifierClick) {
                ForEach(ModifierClickChoice.allCases) { Text($0.title).tag($0) }
            }
            .disabled(!state.prefs.modifierClickEnabled)
            Text(Permissions.accessibilityGranted || !state.prefs.modifierClickEnabled
                 ? "The wheel opens where you click. Only that exact combination is intercepted; normal right-clicks are untouched."
                 : "Needs Accessibility permission (System Settings › Privacy & Security › Accessibility). It starts working as soon as it's allowed.")
                .font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
        SectionCard(title: "Drag to convert") {
            Toggle("Hold Shift while dragging files to show the format wheel", isOn: $state.prefs.dragConvertEnabled)
            Toggle("Ask for settings (quality, pages) after dropping", isOn: $state.prefs.dragAskForSettings)
            Text("Ordinary drags are never affected — the wheel only appears while Shift is held during a file drag. You can also drop files on the menu-bar icon.")
                .font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
        SectionCard(title: "Finder") {
            Text("Right-click any file → Quick Actions (or Services) → **Open in HEXSHIFT**. You can also use **Open With → HEXSHIFT**.")
                .font(.system(size: 12))
            Text("If the item is missing, enable “Open in HEXSHIFT” in System Settings › Keyboard › Keyboard Shortcuts › Services (Files and Folders). HEXSHIFT must be in your Applications folder.")
                .font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            HStack {
                if QuickActionInstaller.bundledURL != nil {
                    if quickActionInstalled {
                        Button("Remove Quick Action") {
                            do { try QuickActionInstaller.uninstall(); finderMessage = "Quick Action removed (moved to the Trash)." }
                            catch { finderMessage = "Couldn't remove the Quick Action: \(error.localizedDescription)" }
                            quickActionInstalled = QuickActionInstaller.isInstalled
                        }
                    } else {
                        Button("Install Finder Quick Action") {
                            do { try QuickActionInstaller.install(); finderMessage = "Installed. Right-click a file › Quick Actions › Open in HEXSHIFT." }
                            catch { finderMessage = "Couldn't install the Quick Action: \(error.localizedDescription)" }
                            quickActionInstalled = QuickActionInstaller.isInstalled
                        }
                    }
                }
                Button("Open Keyboard Settings") {
                    NSWorkspace.shared.open(URL(string: "x-apple.systempreferences:com.apple.Keyboard-Settings.extension")!)
                }
                Button("Refresh Services") {
                    QuickActionInstaller.refreshServices()
                    finderMessage = "Services refreshed. It can take a few seconds to appear in Finder."
                }
            }
            .onAppear { quickActionInstalled = QuickActionInstaller.isInstalled }
            if let finderMessage { Text(finderMessage).font(.system(size: 11)).foregroundStyle(.secondary) }
        }
        SectionCard(title: "Menu bar & links") {
            Text("Menu bar: click the hexagon for quick actions. Links: hexshift://menu, hexshift://pick-colour and hexshift://capture can be used from Shortcuts or a browser.")
                .font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
    }

    private func startRecording() {
        recording = true
        message = nil
        HotKeyManager.shared.unregister(id: AppDelegate.hotKeyID)
        monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { event in
            let mods = HotKeyManager.carbonModifiers(from: event.modifierFlags)
            let isFunctionKey = (96...122).contains(Int(event.keyCode)) && ![kVK_ANSI_KeypadDecimal].contains(Int(event.keyCode))
            if event.keyCode == UInt16(kVK_Escape) && mods == 0 {
                stopRecording()
                return nil
            }
            guard mods & UInt32(cmdKey | optionKey | controlKey) != 0 || isFunctionKey else {
                message = "Use at least one of ⌘, ⌥ or ⌃ (or a function key)."
                return nil
            }
            let combo = HotKeyCombo(keyCode: UInt32(event.keyCode), modifiers: mods,
                                    display: HotKeyManager.displayString(modifiers: mods, keyName: HotKeyManager.keyName(for: event)))
            if let conflict = HotKeyManager.systemConflict(combo) {
                message = "\(combo.display): \(conflict)"
                return nil
            }
            state.prefs.hotKey = combo
            stopRecording()
            return nil
        }
    }

    private func stopRecording() {
        recording = false
        if let m = monitor { NSEvent.removeMonitor(m) }
        monitor = nil
        (NSApp.delegate as? AppDelegate)?.registerHotKey(state.prefs)
    }
}

// MARK: - Radial menu

@MainActor
private struct RadialSettings: View {
    @EnvironmentObject var state: AppState
    @StateObject private var preview = RadialMenuModel()

    var body: some View {
        HStack(alignment: .top, spacing: 20) {
            VStack(alignment: .leading, spacing: 16) {
                SectionCard(title: "Look") {
                    LabeledRow("Size") {
                        Picker("Size", selection: $state.prefs.wheelSize) {
                            ForEach(WheelSize.allCases) { Text($0.title).tag($0) }
                        }
                        .pickerStyle(.segmented).labelsHidden()
                    }
                    LabeledRow("Appearance") {
                        Picker("Appearance", selection: $state.prefs.appearance) {
                            ForEach(AppearanceChoice.allCases) { Text($0.title).tag($0) }
                        }
                        .pickerStyle(.segmented).labelsHidden()
                    }
                    LabeledRow("Animation") {
                        Picker("Animation", selection: $state.prefs.animationSpeed) {
                            ForEach(AnimationSpeed.allCases) { Text($0.title).tag($0) }
                        }
                        .pickerStyle(.segmented).labelsHidden()
                    }
                    Text("Reduce Motion in Accessibility settings is always respected.").font(.system(size: 10.5)).foregroundStyle(.secondary)
                }
                SectionCard(title: "Accent colour") {
                    HStack(spacing: 8) {
                        ForEach(AccentChoice.allCases) { a in
                            Circle().fill(a.rgb.swiftUIColor).frame(width: 22, height: 22)
                                .overlay(Circle().strokeBorder(Color.primary.opacity(state.prefs.accent == a && state.prefs.customAccentHex == nil ? 0.9 : 0), lineWidth: 2))
                                .onTapGesture { state.prefs.accent = a; state.prefs.customAccentHex = nil }
                                .help(a.title)
                                .accessibilityLabel("\(a.title) accent")
                        }
                    }
                    ColorPicker("Custom", selection: Binding(get: { state.accentColor }, set: { state.prefs.customAccentHex = RGBAColour(color: $0).hex }), supportsOpacity: false)
                }
                SectionCard(title: "Behaviour") {
                    Toggle("Show favourites and the most-used actions under the wheel", isOn: $state.prefs.showRecentActions)
                    Toggle("Haptic feedback on Force Touch trackpads", isOn: $state.prefs.haptics)
                }
                SectionCard(title: "Favourite tools") {
                    Text("Pin tools to the wheel: hover an action in the wheel and press F, or right-click it. Favourites appear as quick buttons whenever they apply to what you selected.")
                        .font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    if state.store.favouriteActions.isEmpty {
                        Text("No favourites yet.").font(.system(size: 11.5)).foregroundStyle(.secondary)
                    }
                    ForEach(state.store.favouriteActions) { fav in
                        HStack {
                            Image(systemName: fav.symbol).frame(width: 20)
                            Text(fav.title).font(.system(size: 12))
                            Spacer()
                            Button {
                                let id = fav.id
                                DispatchQueue.main.async { state.store.favouriteActions.removeAll { $0.id == id } }
                            } label: { Image(systemName: "minus.circle") }
                                .buttonStyle(.borderless)
                                .help("Remove from favourites")
                        }
                    }
                }
                SectionCard(title: "Segment order") {
                    ForEach(Array(state.prefs.segmentOrder.enumerated()), id: \.element) { i, seg in
                        HStack {
                            Image(systemName: seg.symbol).frame(width: 20)
                            Text(seg.title)
                            Spacer()
                            Button { move(i, -1) } label: { Image(systemName: "chevron.up") }.buttonStyle(.borderless).disabled(i == 0)
                            Button { move(i, 1) } label: { Image(systemName: "chevron.down") }.buttonStyle(.borderless).disabled(i == 5)
                        }
                    }
                    Button("Reset Order") { state.prefs.segmentOrder = PrimarySegment.allCases }.controlSize(.small)
                }
            }
            .frame(maxWidth: 340)
            RadialMenuView(model: preview)
                .scaleEffect(0.5)
                .frame(width: preview.geometry.canvas * 0.5, height: preview.geometry.canvas * 0.5)
                .allowsHitTesting(false)
                .onAppear(perform: refreshPreview)
                .onChange(of: state.prefs) { _, _ in refreshPreview() }
        }
    }

    private func move(_ i: Int, _ d: Int) {
        var order = state.prefs.segmentOrder
        let j = i + d
        guard j >= 0, j < order.count else { return }
        order.swapAt(i, j)
        state.prefs.segmentOrder = order
    }

    private func refreshPreview() {
        preview.isPreview = true
        preview.configure(context: .empty, state: state)
        preview.isShown = true
        preview.hoveredPrimary = 0
        preview.openSegment(0)
    }
}

// MARK: - Conversion

@MainActor
private struct ConversionSettings: View {
    @EnvironmentObject var state: AppState
    @State private var tools: [(ExternalTool, String?)] = ExternalTools.installedSummary

    var body: some View {
        SectionCard(title: "Quality") {
            qualityRow("JPEG", $state.prefs.jpegQuality)
            qualityRow("HEIC", $state.prefs.heicQuality)
            qualityRow("WebP", $state.prefs.webpQuality)
            qualityRow("AVIF", $state.prefs.avifQuality)
        }
        SectionCard(title: "Metadata") {
            Picker("When exporting images", selection: $state.prefs.metadataPolicy) {
                ForEach(MetadataPolicy.allCases, id: \.self) { Text($0.title).tag($0) }
            }
        }
        SectionCard(title: "Rendering") {
            Picker("PDF pages to images", selection: $state.prefs.pdfDPI) {
                Text("72 dpi").tag(72.0); Text("150 dpi").tag(150.0); Text("300 dpi").tag(300.0)
            }
            Picker("SVG to images", selection: $state.prefs.svgRenderScale) {
                Text("1×").tag(1.0); Text("2×").tag(2.0); Text("3×").tag(3.0); Text("4×").tag(4.0)
            }
            Picker("Batch jobs at once", selection: $state.prefs.batchConcurrency) {
                Text("Automatic").tag(0); Text("1").tag(1); Text("2").tag(2); Text("4").tag(4); Text("8").tag(8)
            }
        }
        SectionCard(title: "Preferred formats (shown first)") {
            ForEach(Array(state.prefs.preferredFormats.enumerated()), id: \.element) { i, f in
                HStack {
                    Text(f.displayName)
                    if !ImageEncoder.canWrite(f) && f.category == .raster { Text("not available").font(.system(size: 10.5)).foregroundStyle(.secondary) }
                    Spacer()
                    Button { swapFormats(i, i - 1) } label: { Image(systemName: "chevron.up") }.buttonStyle(.borderless).disabled(i == 0)
                    Button { swapFormats(i, i + 1) } label: { Image(systemName: "chevron.down") }.buttonStyle(.borderless).disabled(i == state.prefs.preferredFormats.count - 1)
                }
            }
        }
        SectionCard(title: "Optional helper tools") {
            Toggle("Use LibreOffice, Pandoc, Pages and Keynote when installed (higher fidelity)", isOn: $state.prefs.useExternalEngines)
            ForEach(tools, id: \.0.rawValue) { tool, path in
                HStack(alignment: .top) {
                    Image(systemName: path == nil ? "circle.dashed" : "checkmark.circle.fill").foregroundStyle(path == nil ? Color.secondary : Color.green)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(tool.displayName).font(.system(size: 12, weight: .medium))
                        Text(path == nil ? "\(tool.purpose). \(tool.installHint)" : "\(tool.purpose) — \(path!)")
                            .font(.system(size: 10.5)).foregroundStyle(.secondary).textSelection(.enabled)
                    }
                }
            }
            HStack {
                Text("Pages: \(OfficeAdapters.hasPages ? "yes" : "no") · Keynote: \(OfficeAdapters.hasKeynote ? "yes" : "no") · Numbers: \(OfficeAdapters.hasNumbers ? "yes" : "no")")
                    .font(.system(size: 11)).foregroundStyle(.secondary)
                Spacer()
                Button("Check Again") { ExternalTools.refresh(); tools = ExternalTools.installedSummary }.controlSize(.small)
            }
            Text("Nothing is downloaded or bundled automatically. Built-in: PNG, JPEG, HEIC, TIFF, GIF, BMP, ICO, ICNS, JPEG 2000, PDF, WebP (libwebp), SVG, documents, MP4/MOV, M4A/WAV.")
                .font(.system(size: 10.5)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
        }
    }

    private func qualityRow(_ name: String, _ value: Binding<Double>) -> some View {
        HStack {
            Text(name).frame(width: 50, alignment: .leading)
            Slider(value: value, in: 0.3...1)
            Text("\(Int(value.wrappedValue * 100))").monospacedDigit().frame(width: 30)
        }
    }

    private func swapFormats(_ a: Int, _ b: Int) {
        var list = state.prefs.preferredFormats
        guard a >= 0, b >= 0, a < list.count, b < list.count else { return }
        list.swapAt(a, b)
        state.prefs.preferredFormats = list
    }
}

// MARK: - Typography

@MainActor
private struct TypographySettings: View {
    @EnvironmentObject var state: AppState

    var body: some View {
        SectionCard(title: "Font matching") {
            Toggle("Compare every weight and style of the closest families (slower, more accurate)", isOn: $state.prefs.fontMatchAllWeights)
            Text("Matching uses the \(NSFontManager.shared.availableFontFamilies.filter { !$0.hasPrefix(".") }.count) font families installed on this Mac. Install more fonts with Font Book to widen the search. Results are always labelled as estimates.")
                .font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            TextField("Default sample text", text: $state.prefs.fontSampleText).textFieldStyle(.roundedBorder)
        }
        SectionCard(title: "Actual fonts from apps") {
            Text("With Accessibility allowed, HEXSHIFT reads the real font of selected text in apps that report it (TextEdit, Pages, Mail, Notes, Safari and others).")
                .font(.system(size: 11.5)).fixedSize(horizontal: false, vertical: true)
        }
        SectionCard(title: "Browser extension (Chrome, Edge, Brave, Arc)") {
            Text("The optional extension reads the computed CSS of the text you select on a web page (family, weight, size, line height, letter spacing, colour) and sends it to Font Lens.")
                .font(.system(size: 11.5)).fixedSize(horizontal: false, vertical: true)
            Text("Install: click Show Extension Folder, open chrome://extensions, turn on Developer mode, then drag the “Browser Extension” folder onto that page (or use “Load unpacked”).")
                .font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            if Bundle.main.url(forResource: "Browser Extension", withExtension: nil) != nil {
                Button("Show Extension Folder") {
                    if let folder = BrowserExtensionInstaller.prepare() { NSWorkspace.shared.activateFileViewerSelecting([folder]) }
                }
            }
        }
    }
}

// MARK: - Privacy

@MainActor
private struct PrivacySettings: View {
    @EnvironmentObject var state: AppState
    @State private var refresh = 0

    private func appName(_ bundleID: String) -> String {
        guard let url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: bundleID) else { return bundleID.components(separatedBy: ".").last ?? bundleID }
        return FileManager.default.displayName(atPath: url.path).replacingOccurrences(of: ".app", with: "")
    }

    var body: some View {
        SectionCard(title: "Your data stays on this Mac") {
            Text("HEXSHIFT processes everything locally. It never uploads files, screenshots or text, never records the screen continuously, and never monitors typing. There are no accounts and no analytics.")
                .font(.system(size: 12)).fixedSize(horizontal: false, vertical: true)
        }
        SectionCard(title: "Permissions (asked only when a feature needs them)") {
            ForEach(Permission.allCases) { p in
                HStack(alignment: .top) {
                    Image(systemName: Permissions.isGranted(p) ? "checkmark.circle.fill" : "circle").foregroundStyle(Permissions.isGranted(p) ? Color.green : Color.secondary)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(p.title).font(.system(size: 12.5, weight: .medium))
                        Text(p.reason).font(.system(size: 10.5)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer()
                    Button(Permissions.isGranted(p) ? "Settings" : "Allow…") {
                        if Permissions.isGranted(p) { Permissions.openSettings(p) } else { Permissions.request(p) }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { refresh += 1 }
                    }
                    .controlSize(.small)
                }
                .id("\(p.rawValue)-\(refresh)")
            }
            Text("Colour picking uses the system loupe and needs no permission.").font(.system(size: 10.5)).foregroundStyle(.secondary)
        }
        SectionCard(title: "Clipboard") {
            Text("By default the clipboard is read only when you choose “Convert Clipboard”. HEXSHIFT keeps no clipboard history.")
                .font(.system(size: 11.5)).fixedSize(horizontal: false, vertical: true)
            Toggle("Suggest actions when I copy an image, a file or a link", isOn: $state.prefs.clipboardSuggestions)
            Text("When on, HEXSHIFT checks only what *kind* of item was copied and shows a small suggestion. The contents are read only if you click it. Plain text, password managers and items marked as concealed are always ignored.")
                .font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            if state.prefs.clipboardSuggestions {
                Text("Never look at copies from:").font(.system(size: 11.5, weight: .medium))
                ForEach(state.prefs.clipboardExcludedApps, id: \.self) { id in
                    HStack {
                        Text(appName(id)).font(.system(size: 11.5))
                        Text(id).font(.system(size: 10)).foregroundStyle(.secondary)
                        Spacer()
                        Button {
                            DispatchQueue.main.async { state.prefs.clipboardExcludedApps.removeAll { $0 == id } }
                        } label: { Image(systemName: "minus.circle") }.buttonStyle(.borderless)
                    }
                }
                HStack {
                    Button("Add App…") {
                        let panel = NSOpenPanel()
                        panel.allowedContentTypes = [.application]
                        panel.directoryURL = URL(fileURLWithPath: "/Applications")
                        panel.level = .modalPanel   // stay above other apps, so it can't hide behind them
                        if panel.runModal() == .OK, let url = panel.url, let id = Bundle(url: url)?.bundleIdentifier,
                           !state.prefs.clipboardExcludedApps.contains(id) {
                            state.prefs.clipboardExcludedApps.append(id)
                        }
                    }
                    Button("Restore Defaults") { state.prefs.clipboardExcludedApps = ClipboardDefaults.exclusions }
                }
                .controlSize(.small)
            }
        }
        SectionCard(title: "History") {
            Toggle("Remember recent actions and files", isOn: $state.prefs.rememberRecents)
            HStack {
                Button("Clear History") { state.clearHistory(); JobCenter.shared.message("History cleared") }
                Button("Show Local Data") { NSWorkspace.shared.activateFileViewerSelecting([state.storeURL]) }
            }
            Text("Recent actions, colours, palettes, favourite fonts and workflows are stored in \(state.storeURL.deletingLastPathComponent().path).")
                .font(.system(size: 10.5)).foregroundStyle(.secondary).textSelection(.enabled)
        }
    }
}

// MARK: - Workflows

@MainActor
private struct WorkflowSettings: View {
    @EnvironmentObject var state: AppState
    @State private var selection: UUID?

    var body: some View {
        Text("Workflows chain steps together. They appear under Capture & More in the radial menu for matching files.")
            .font(.system(size: 11.5)).foregroundStyle(.secondary)
        ForEach(state.allWorkflows) { wf in
            SectionCard {
                HStack {
                    Image(systemName: wf.symbol).foregroundStyle(state.accentColor)
                    if wf.isBuiltIn {
                        Text(wf.name).font(.system(size: 13, weight: .semibold))
                        Text("Built-in").font(.system(size: 10)).foregroundStyle(.secondary)
                    } else {
                        TextField("Name", text: Binding(get: { wf.name }, set: { n in update(wf.id) { $0.name = n } }))
                            .textFieldStyle(.plain).font(.system(size: 13, weight: .semibold))
                    }
                    Spacer()
                    Button {
                        state.toggleFavourite(RadialAction(id: "workflow:\(wf.id.uuidString)", title: wf.name, detail: wf.summary, symbol: wf.symbol))
                    } label: {
                        Image(systemName: state.isFavourite("workflow:\(wf.id.uuidString)") ? "star.fill" : "star")
                    }
                    .buttonStyle(.borderless)
                    .help("Favourite: pin to the wheel")
                    Button("Duplicate") {
                        var copy = wf
                        copy.id = UUID()
                        copy.name = wf.name + " copy"
                        copy.isBuiltIn = false
                        state.store.workflows.append(copy)
                    }
                    .controlSize(.small)
                    if !wf.isBuiltIn {
                        Button(role: .destructive) {
                            let id = wf.id
                            DispatchQueue.main.async { state.store.workflows.removeAll { $0.id == id } }
                        } label: { Image(systemName: "trash") }.buttonStyle(.borderless)
                    }
                }
                HStack {
                    Text("Shortcut").font(.system(size: 11.5)).foregroundStyle(.secondary)
                    ShortcutRecorder(combo: Binding(get: { state.store.workflowShortcuts[wf.id.uuidString] },
                                                    set: { state.store.workflowShortcuts[wf.id.uuidString] = $0 }))
                    Text("Runs on the files selected in Finder").font(.system(size: 10.5)).foregroundStyle(.secondary)
                }
                ForEach(Array(wf.steps.enumerated()), id: \.offset) { i, step in
                    HStack {
                        Text("\(i + 1).").foregroundStyle(.secondary).frame(width: 20)
                        if wf.isBuiltIn {
                            Text(step.title).font(.system(size: 12))
                        } else {
                            WorkflowStepEditor(step: Binding(get: { step }, set: { new in update(wf.id) { w in if i < w.steps.count { w.steps[i] = new } } }))
                        }
                        Spacer()
                        if !wf.isBuiltIn {
                            Button { update(wf.id) { w in if i > 0 { w.steps.swapAt(i, i - 1) } } } label: { Image(systemName: "chevron.up") }.buttonStyle(.borderless)
                            Button { update(wf.id) { w in if i < w.steps.count { w.steps.remove(at: i) } } } label: { Image(systemName: "minus.circle") }.buttonStyle(.borderless)
                        }
                    }
                }
                if !wf.isBuiltIn {
                    Menu("Add Step") {
                        ForEach(stepTemplates, id: \.0) { title, step in
                            Button(title) { update(wf.id) { $0.steps.append(step) } }
                        }
                    }
                    .fixedSize()
                }
            }
        }
        Button("New Workflow") {
            state.store.workflows.append(Workflow(name: "My Workflow", symbol: "bolt", steps: [.resize(maxWidth: 2000, maxHeight: nil), .convert(format: .jpeg, quality: 0.85)]))
        }
        .buttonStyle(AccentButtonStyle())
    }

    private var stepTemplates: [(String, WorkflowStep)] {
        [
            ("Resize width to 1600 px", .resize(maxWidth: 1600, maxHeight: nil)),
            ("Resize width to 1080 px", .resize(maxWidth: 1080, maxHeight: nil)),
            ("Fit within 2048 × 2048", .resize(maxWidth: 2048, maxHeight: 2048)),
            ("Crop to 1:1", .cropAspect(width: 1, height: 1)),
            ("Crop to 4:5", .cropAspect(width: 4, height: 5)),
            ("Crop to 16:9", .cropAspect(width: 16, height: 9)),
            ("Exactly 1080 × 1350", .resizeExact(width: 1080, height: 1350)),
            ("Exactly 1080 × 1920", .resizeExact(width: 1080, height: 1920)),
            ("Export WebP", .convert(format: .webp, quality: 0.8)),
            ("Export JPEG", .convert(format: .jpeg, quality: 0.85)),
            ("Export PNG", .convert(format: .png, quality: 1)),
            ("Export HEIC", .convert(format: .heic, quality: 0.8)),
            ("Compress to ≤ 500 KB JPEG", .compressTo(kilobytes: 500, format: .jpeg)),
            ("Remove background", .removeBackground),
            ("Auto enhance", .autoEnhance),
            ("Black & white", .grayscale),
            ("Remove location data", .stripMetadata(gpsOnly: true)),
            ("Remove all metadata", .stripMetadata(gpsOnly: false)),
            ("Extract text (TXT)", .extractText),
            ("Copy result to clipboard", .copyToClipboard),
            ("PDF: compress", .pdfCompress),
            ("PDF: remove metadata", .pdfStripMetadata),
            ("PDF: make searchable", .pdfSearchable),
        ]
    }

    private func update(_ id: UUID, _ change: (inout Workflow) -> Void) {
        guard let i = state.store.workflows.firstIndex(where: { $0.id == id }) else { return }
        change(&state.store.workflows[i])
    }
}

/// Inline editor for a workflow step's values (sizes, ratios, formats, quality).
@MainActor
private struct WorkflowStepEditor: View {
    @Binding var step: WorkflowStep

    private let formats: [Format] = [.jpeg, .png, .webp, .heic, .avif, .tiff, .gif, .pdf].filter(ImageEncoder.canWrite)

    var body: some View {
        HStack(spacing: 6) {
            switch step {
            case let .resize(w, h):
                Text("Fit within").font(.system(size: 12))
                optionalInt(w) { step = .resize(maxWidth: $0, maxHeight: h) }
                Text("×")
                optionalInt(h) { step = .resize(maxWidth: w, maxHeight: $0) }
                Text("px").font(.system(size: 12))
            case let .resizeExact(w, h):
                Text("Exactly").font(.system(size: 12))
                int(w) { step = .resizeExact(width: $0, height: h) }
                Text("×")
                int(h) { step = .resizeExact(width: w, height: $0) }
                Text("px").font(.system(size: 12))
            case let .cropAspect(w, h):
                Text("Crop to").font(.system(size: 12))
                double(w) { step = .cropAspect(width: $0, height: h) }
                Text(":")
                double(h) { step = .cropAspect(width: w, height: $0) }
            case let .convert(f, q):
                Text("Export").font(.system(size: 12))
                formatPicker(f) { step = .convert(format: $0, quality: q) }
                if f.isLossy || f == .avif {
                    Slider(value: Binding(get: { q }, set: { step = .convert(format: f, quality: $0) }), in: 0.3...1).frame(width: 90)
                    Text("\(Int(q * 100))").monospacedDigit().font(.system(size: 11)).frame(width: 26)
                }
            case let .compressTo(kb, f):
                Text("Compress to ≤").font(.system(size: 12))
                int(kb) { step = .compressTo(kilobytes: $0, format: f) }
                Text("KB as").font(.system(size: 12))
                formatPicker(f, lossyOnly: true) { step = .compressTo(kilobytes: kb, format: $0) }
            default:
                Text(step.title).font(.system(size: 12))
            }
        }
    }

    private func int(_ value: Int, _ set: @escaping (Int) -> Void) -> some View {
        TextField("", value: Binding(get: { value }, set: { set(max(1, $0)) }), format: .number)
            .textFieldStyle(.roundedBorder).frame(width: 62)
    }

    private func optionalInt(_ value: Int?, _ set: @escaping (Int?) -> Void) -> some View {
        TextField("any", text: Binding(get: { value.map(String.init) ?? "" }, set: { set(Int($0).map { max(1, $0) }) }))
            .textFieldStyle(.roundedBorder).frame(width: 62)
    }

    private func double(_ value: Double, _ set: @escaping (Double) -> Void) -> some View {
        TextField("", value: Binding(get: { value }, set: { set(max(0.01, $0)) }), format: .number)
            .textFieldStyle(.roundedBorder).frame(width: 48)
    }

    private func formatPicker(_ value: Format, lossyOnly: Bool = false, _ set: @escaping (Format) -> Void) -> some View {
        Picker("", selection: Binding(get: { value }, set: set)) {
            ForEach(formats.filter { !lossyOnly || $0.isLossy || $0 == .avif }, id: \.self) { Text($0.displayName).tag($0) }
        }
        .labelsHidden()
        .frame(width: 96)
    }
}

// MARK: - About

@MainActor
private struct AboutSettings: View {
    @EnvironmentObject var state: AppState

    var body: some View {
        HStack(spacing: 14) {
            Image(nsImage: NSApp.applicationIconImage).resizable().frame(width: 64, height: 64)
            VStack(alignment: .leading, spacing: 3) {
                Text("HEXSHIFT").font(.system(size: 22, weight: .bold))
                Text("Select Anything. Create Anything.").foregroundStyle(.secondary)
                Text("Version \(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "dev") (\(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "0"))")
                    .font(.system(size: 11)).foregroundStyle(.secondary)
            }
        }
        SectionCard(title: "Built with") {
            Text("Swift, SwiftUI and AppKit · ImageIO, Core Image, PDFKit, Vision, AVFoundation, Core Text · libwebp \(ImageEncoder.webpEncoderVersion) (BSD-3-Clause, © Google).")
                .font(.system(size: 11.5)).fixedSize(horizontal: false, vertical: true)
        }
        SectionCard(title: "Open again") {
            Button("Show Welcome") { Windows.openOnboarding() }
            Button("Run Conversion Self-Test") {
                JobCenter.shared.runTask(title: "Running self-test", successTitle: "Self-test finished") {
                    let report = await SelfTest.run(log: { _ in })
                    if report.failed > 0 { throw HexError.message("\(report.failed) check(s) failed: \(report.failures.prefix(3).joined(separator: "; "))") }
                    await MainActor.run { JobCenter.shared.message("\(report.passed) checks passed", detail: report.warnings > 0 ? "\(report.warnings) with warnings" : nil, kind: .success) }
                    return []
                }
            }
        }
    }
}
