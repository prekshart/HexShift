import AppKit
import HexshiftKit
import SwiftUI

extension Windows {
    static func openOnboarding() {
        WindowManager.shared.show(id: "welcome", title: "Welcome to HEXSHIFT", size: CGSize(width: 640, height: 560), resizable: false) {
            OnboardingView()
        }
    }
}

@MainActor
struct OnboardingView: View {
    @EnvironmentObject var state: AppState
    @StateObject private var preview = RadialMenuModel()

    var body: some View {
        VStack(spacing: 18) {
            HStack(alignment: .center, spacing: 22) {
                RadialMenuView(model: preview)
                    .scaleEffect(0.42)
                    .frame(width: preview.geometry.canvas * 0.42, height: preview.geometry.canvas * 0.42)
                    .allowsHitTesting(false)
                VStack(alignment: .leading, spacing: 6) {
                    Text("HEXSHIFT").font(.system(size: 30, weight: .bold))
                    Text("Select anything. Create anything.").font(.system(size: 15)).foregroundStyle(.secondary)
                    Text("Convert, edit, inspect and capture without opening a big app. Everything runs on this Mac.")
                        .font(.system(size: 12)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(.top, 24)
            VStack(alignment: .leading, spacing: 12) {
                tip("keyboard", "Press \(state.prefs.hotKey.display)", "Opens the wheel at your pointer. Select files in Finder or text in any app first and HEXSHIFT acts on them.")
                tip("hand.draw", "Hold Shift while dragging files", "A format wheel appears — drop onto PNG, JPEG, WebP, PDF… to convert instantly.")
                tip("cursorarrow.click.2", "Right-click → Open in HEXSHIFT", "From Finder's Quick Actions or Services menu, or use Open With.")
                tip("menubar.rectangle", "Menu bar or Applications", "Click the hexagon in the menu bar — or open HEXSHIFT from Applications — for Capture, Pick Colour, Find Font and recent actions.")
            }
            .padding(16)
            .background(RoundedRectangle(cornerRadius: 14).fill(Color.primary.opacity(0.04)))
            Text("HEXSHIFT asks for permissions only when a feature needs them, and explains why first.")
                .font(.system(size: 11)).foregroundStyle(.secondary)
            HStack {
                Button("Settings…") { Windows.openSettings() }
                Spacer()
                Button("Start Using HEXSHIFT") {
                    state.prefs.hasCompletedOnboarding = true
                    WindowManager.shared.close("welcome")
                }
                .buttonStyle(AccentButtonStyle())
                .keyboardShortcut(.defaultAction)
            }
        }
        .padding(24)
        .onAppear {
            preview.isPreview = true
            preview.configure(context: .empty, state: state)
            preview.isShown = true
            preview.hoveredPrimary = 0
            preview.openSegment(0)
        }
    }

    private func tip(_ symbol: String, _ title: String, _ detail: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: symbol).font(.system(size: 18)).foregroundStyle(state.accentColor).frame(width: 26)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 13, weight: .semibold))
                Text(detail).font(.system(size: 11.5)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}
