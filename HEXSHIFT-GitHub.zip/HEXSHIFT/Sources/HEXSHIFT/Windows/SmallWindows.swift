import AppKit
import HexshiftKit
import PDFKit
import SwiftUI

// MARK: - Text result (OCR / extracted text)

extension Windows {
    static func openTextResult(title: String, text: String, source: AssetInfo?, note: String?) {
        WindowManager.shared.show(id: "text-result", title: title, size: CGSize(width: 560, height: 520), minSize: CGSize(width: 420, height: 320)) {
            TextResultView(title: title, text: text, source: source, note: note)
        }
    }
}

@MainActor
struct TextResultView: View {
    let title: String
    @State var text: String
    let source: AssetInfo?
    let note: String?
    @EnvironmentObject var state: AppState

    init(title: String, text: String, source: AssetInfo?, note: String?) {
        self.title = title
        _text = State(initialValue: text)
        self.source = source
        self.note = note
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.system(size: 15, weight: .semibold)).padding(.top, 26)
            if let note {
                Label(note, systemImage: "exclamationmark.bubble").font(.system(size: 11.5)).foregroundStyle(.secondary)
            }
            TextEditor(text: $text)
                .font(.system(size: 13))
                .scrollContentBackground(.hidden)
                .padding(8)
                .background(RoundedRectangle(cornerRadius: 10).fill(Color.primary.opacity(0.04)))
            let stats = DocumentConverter.statistics(text)
            HStack {
                Text("\(stats.words) words · \(stats.characters) characters").font(.system(size: 11)).foregroundStyle(.secondary)
                Spacer()
                Button("Copy") { Clipboard.copy(text); JobCenter.shared.message("Text copied") }
                Menu("Save As") {
                    Button("Plain Text (.txt)") { save(.txt) }
                    Button("Word (.docx)") { save(.docx) }
                    Button("Markdown (.md)") { save(.md) }
                    Button("PDF") { save(.pdf) }
                }
                .fixedSize()
                Button("Open in Text Studio") { Windows.openTextStudio(text: text, attributed: nil, format: .pdf) }
                    .buttonStyle(AccentButtonStyle())
            }
        }
        .padding(18)
    }

    private func save(_ format: Format) {
        let content = text
        let base = source?.baseName ?? "Extracted text"
        let src = source?.url
        ActionRunner.shared.withPlanner { planner, delivery in
            JobCenter.shared.runTask(title: "Saving text", delivery: delivery, successTitle: "Text saved") {
                let dest = planner.url(for: src, baseName: base + "-text", ext: format.fileExtension)
                try await MainActor.run { try DocumentConverter.export(text: content, as: format, to: dest, title: base) }
                return [dest]
            }
        }
    }
}

// MARK: - Inspector

extension Windows {
    static func openInspector(asset: AssetInfo) {
        WindowManager.shared.show(id: "inspect:\(asset.url.path)", title: "Inspect \(asset.name)", size: CGSize(width: 520, height: 560)) {
            InspectorView(asset: asset)
        }
    }
}

@MainActor
struct InspectorView: View {
    let asset: AssetInfo
    @State private var rows: [(String, String)] = []
    @State private var thumb: NSImage?
    @EnvironmentObject var state: AppState

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 14) {
                Image(nsImage: thumb ?? NSWorkspace.shared.icon(forFile: asset.url.path))
                    .resizable().aspectRatio(contentMode: .fit).frame(width: 72, height: 72)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                VStack(alignment: .leading, spacing: 3) {
                    Text(asset.name).font(.system(size: 15, weight: .semibold)).lineLimit(2)
                    Text(asset.summary).font(.system(size: 12)).foregroundStyle(.secondary)
                }
            }
            .padding(.top, 26)
            ScrollView {
                Grid(alignment: .leading, horizontalSpacing: 14, verticalSpacing: 7) {
                    ForEach(Array(rows.enumerated()), id: \.offset) { _, row in
                        GridRow {
                            Text(row.0).font(.system(size: 11.5, weight: .medium)).foregroundStyle(.secondary).gridColumnAlignment(.trailing)
                            Text(row.1).font(.system(size: 12)).textSelection(.enabled).fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(14)
                .background(RoundedRectangle(cornerRadius: 12).fill(Color.primary.opacity(0.04)))
            }
            HStack {
                Button("Copy All") {
                    Clipboard.copy(rows.map { "\($0.0): \($0.1)" }.joined(separator: "\n"))
                    JobCenter.shared.message("Details copied")
                }
                if asset.hasGPS {
                    Button("Remove Location Data") {
                        ActionRunner.shared.perform(RadialAction(id: "batch.stripGPS", title: "Remove GPS", detail: "", symbol: "location.slash"), context: .files([asset]))
                    }
                }
                Spacer()
                Button("Reveal in Finder") { NSWorkspace.shared.activateFileViewerSelecting([asset.url]) }
            }
        }
        .padding(18)
        .task {
            let url = asset.url
            rows = await Task.detached { AssetInspector.detailedProperties(url) }.value
            if let img = ImageLoader.thumbnail(url, maxPixelSize: 160) { thumb = NSImage(cg: img) }
        }
    }
}

// MARK: - PDF quick tasks (page numbers, stamp, highlight, split, extract, compress)

enum PDFTask: String {
    case pageNumbers, stamp, highlight, split, extract, compress, password, pageSize

    init(actionID: String) {
        switch actionID {
        case "pdf.stamp": self = .stamp
        case "pdf.highlight": self = .highlight
        case "pdf.split": self = .split
        case "pdf.extract": self = .extract
        case "pdf.compress": self = .compress
        case "pdf.password": self = .password
        case "pdf.pageSize": self = .pageSize
        default: self = .pageNumbers
        }
    }

    var title: String {
        switch self {
        case .pageNumbers: return "Insert Page Numbers"
        case .stamp: return "Add a Stamp"
        case .highlight: return "Highlight Text"
        case .split: return "Split PDF"
        case .extract: return "Extract Pages"
        case .compress: return "Compress PDF"
        case .password: return "Password"
        case .pageSize: return "Page Size & Margins"
        }
    }
}

extension Windows {
    static func openPDFTask(asset: AssetInfo, task: PDFTask) {
        WindowManager.shared.show(id: "pdftask", title: "\(task.title) — \(asset.name)", size: CGSize(width: 460, height: 400), resizable: false) {
            PDFTaskView(asset: asset, task: task)
        }
    }
}

@MainActor
struct PDFTaskView: View {
    let asset: AssetInfo
    let task: PDFTask
    @EnvironmentObject var state: AppState
    @State private var format = "Page {n} of {total}"
    @State private var position: PageNumberPosition = .bottomCenter
    @State private var fontSize = 10.0
    @State private var skipFirst = false
    @State private var stampText = "CONFIDENTIAL"
    @State private var terms = ""
    @State private var underline = false
    @State private var splitMode = 0
    @State private var chunk = 2
    @State private var ranges = "1-2, 3-"
    @State private var pages = "1"
    @State private var level: PDFCompressionLevel = .balanced
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var ownerPassword = ""
    @State private var newPageSize: PDFPageSize = .a4
    @State private var orientation: PDFEngine.PageOrientation = .matchEachPage
    @State private var marginMM = 10.0
    @State private var allowEnlarge = false
    private var isEncrypted: Bool { task == .password && (PDFDocument(url: asset.url)?.isEncrypted ?? false) }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(task == .password ? (isEncrypted ? "Remove Password" : "Protect with a Password") : task.title)
                .font(.system(size: 15, weight: .semibold)).padding(.top, 24)
            Text("\(asset.name) · \(asset.pageCount ?? 0) pages. A new file is saved; the original stays as it is.")
                .font(.system(size: 11.5)).foregroundStyle(.secondary)
            form
            Spacer()
            HStack {
                Spacer()
                Button("Cancel") { WindowManager.shared.close("pdftask") }
                Button("Apply") { run() }.buttonStyle(AccentButtonStyle()).keyboardShortcut(.defaultAction)
            }
        }
        .padding(18)
    }

    @ViewBuilder private var form: some View {
        switch task {
        case .pageNumbers:
            SectionCard {
                TextField("Format", text: $format).textFieldStyle(.roundedBorder)
                Text("{n} = page number, {total} = page count").font(.system(size: 10.5)).foregroundStyle(.secondary)
                Picker("Position", selection: $position) {
                    ForEach(PageNumberPosition.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                Stepper("Size: \(Int(fontSize)) pt", value: $fontSize, in: 6...24)
                Toggle("Skip the first page (cover)", isOn: $skipFirst)
            }
        case .stamp:
            SectionCard {
                TextField("Stamp text", text: $stampText).textFieldStyle(.roundedBorder)
                Text("Drawn diagonally across every page and flattened into the page.").font(.system(size: 10.5)).foregroundStyle(.secondary)
            }
        case .highlight:
            SectionCard {
                TextField("Words or phrases (comma-separated)", text: $terms).textFieldStyle(.roundedBorder)
                Toggle("Underline instead of highlight", isOn: $underline)
            }
        case .split:
            SectionCard {
                Picker("Split", selection: $splitMode) {
                    Text("Every page").tag(0)
                    Text("Every N pages").tag(1)
                    Text("By ranges").tag(2)
                }
                .pickerStyle(.radioGroup)
                if splitMode == 1 { Stepper("N = \(chunk)", value: $chunk, in: 1...500) }
                if splitMode == 2 { TextField("Ranges, e.g. 1-3, 4-6, 7-", text: $ranges).textFieldStyle(.roundedBorder) }
            }
        case .extract:
            SectionCard {
                TextField("Pages, e.g. 1, 3-5", text: $pages).textFieldStyle(.roundedBorder)
            }
        case .compress:
            SectionCard {
                Picker("Level", selection: $level) {
                    ForEach(PDFCompressionLevel.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                .pickerStyle(.radioGroup)
                Text(ExternalTools.path(.gs) != nil ? "Strong uses Ghostscript (installed)." : "Strong uses macOS's Reduce File Size filter; install Ghostscript for better results.")
                    .font(.system(size: 10.5)).foregroundStyle(.secondary)
            }
        case .pageSize:
            SectionCard {
                Picker("Page size", selection: $newPageSize) {
                    Text("Keep each page's size").tag(PDFPageSize.fitImage)
                    ForEach(PDFPageSize.allCases.filter { $0 != .fitImage }, id: \.self) { Text($0.title).tag($0) }
                }
                if newPageSize != .fitImage {
                    Picker("Orientation", selection: $orientation) {
                        ForEach(PDFEngine.PageOrientation.allCases, id: \.self) { Text($0.title).tag($0) }
                    }
                }
                HStack {
                    Text("Margin")
                    Slider(value: $marginMM, in: 0...40, step: 1)
                    Text("\(Int(marginMM)) mm").monospacedDigit().frame(width: 52, alignment: .trailing)
                }
                Toggle("Enlarge small pages to fill", isOn: $allowEnlarge)
                Text(newPageSize == .fitImage ? "Adds the margin around every page." : "Content is scaled to fit inside the margins and centred. Text stays selectable.")
                    .font(.system(size: 10.5)).foregroundStyle(.secondary)
            }
        case .password:
            SectionCard {
                if isEncrypted {
                    SecureField("Current password", text: $password).textFieldStyle(.roundedBorder)
                    Text("Saves an unprotected copy. The protected original is kept.").font(.system(size: 10.5)).foregroundStyle(.secondary)
                } else {
                    SecureField("Password to open", text: $password).textFieldStyle(.roundedBorder)
                    SecureField("Repeat password", text: $confirmPassword).textFieldStyle(.roundedBorder)
                    SecureField("Owner password (optional)", text: $ownerPassword).textFieldStyle(.roundedBorder)
                    Text("Saves an encrypted copy. HEXSHIFT doesn't keep the password — if it's lost, the copy can't be opened.")
                        .font(.system(size: 10.5)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                }
            }
        }
    }

    private func run() {
        let a = asset
        let n = a.pageCount ?? 1
        let t = task
        let fmt = format, pos = position, size = CGFloat(fontSize), skip = skipFirst, stamp = stampText
        let termList = terms.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
        let under = underline, mode = splitMode, chunkSize = chunk, rangeText = ranges, pageText = pages, lvl = level
        if t == .extract && PDFEngine.parsePageList(pageText, pageCount: n) == nil {
            JobCenter.shared.message("Those pages aren't valid", detail: "Use numbers between 1 and \(n).", kind: .error)
            return
        }
        if t == .highlight && termList.isEmpty { return }
        let encrypted = isEncrypted, pw = password, owner = ownerPassword
        let sizeChoice = newPageSize, orient = orientation, margin = CGFloat(marginMM / 25.4 * 72), enlarge = allowEnlarge
        if t == .password {
            if pw.isEmpty { return }
            if !encrypted && pw != confirmPassword {
                JobCenter.shared.message("The passwords don't match", kind: .error)
                return
            }
        }
        WindowManager.shared.close("pdftask")
        ActionRunner.shared.withPlanner { planner, delivery in
            JobCenter.shared.runTask(title: t.title, delivery: delivery) {
                switch t {
                case .pageNumbers:
                    let dest = planner.url(for: a.url, baseName: a.baseName + "-numbered", ext: "pdf")
                    try PDFEngine.addPageNumbers(a.url, output: dest, format: fmt, position: pos, fontSize: size, skipFirstPage: skip)
                    return [dest]
                case .stamp:
                    let dest = planner.url(for: a.url, baseName: a.baseName + "-stamped", ext: "pdf")
                    try PDFEngine.stampText(stamp, on: a.url, output: dest)
                    return [dest]
                case .highlight:
                    let dest = planner.url(for: a.url, baseName: a.baseName + "-highlighted", ext: "pdf")
                    try PDFEngine.markText(a.url, terms: termList, output: dest, underline: under)
                    return [dest]
                case .split:
                    let m: PDFSplitMode = mode == 0 ? .everyPage : mode == 1 ? .chunks(chunkSize) : .ranges(rangeText)
                    return try PDFEngine.split(a.url, mode: m, planner: planner)
                case .extract:
                    let dest = planner.url(for: a.url, baseName: a.baseName + "-pages", ext: "pdf")
                    try PDFEngine.extractPages(a.url, pages: PDFEngine.parsePageList(pageText, pageCount: n) ?? [], output: dest)
                    return [dest]
                case .compress:
                    let dest = planner.url(for: a.url, baseName: a.baseName + "-compressed", ext: "pdf")
                    let r = try PDFEngine.compress(a.url, output: dest, level: lvl)
                    await MainActor.run {
                        JobCenter.shared.message("Saved \(Int((r.saving * 100).rounded()))%",
                                                 detail: "\(ByteCountFormatter.string(fromByteCount: r.before, countStyle: .file)) → \(ByteCountFormatter.string(fromByteCount: r.after, countStyle: .file))")
                    }
                    return [dest]
                case .pageSize:
                    let dest = planner.url(for: a.url, baseName: a.baseName + "-resized", ext: "pdf")
                    try PDFEngine.resizePages(a.url, output: dest, size: sizeChoice, orientation: orient, margin: margin, allowEnlarge: enlarge)
                    return [dest]
                case .password:
                    if encrypted {
                        let dest = planner.url(for: a.url, baseName: a.baseName + "-unlocked", ext: "pdf")
                        try PDFEngine.removePassword(a.url, password: pw, output: dest)
                        return [dest]
                    } else {
                        let dest = planner.url(for: a.url, baseName: a.baseName + "-protected", ext: "pdf")
                        try PDFEngine.protect(a.url, output: dest, password: pw, ownerPassword: owner)
                        return [dest]
                    }
                }
            }
        }
    }
}
