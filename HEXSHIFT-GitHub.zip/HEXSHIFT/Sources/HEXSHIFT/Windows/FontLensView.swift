import AppKit
import CoreText
import HexshiftKit
import SwiftUI

enum FontLensRequest {
    case actual(ActualFontInfo, sample: String)
    case estimate(image: CGImage, text: String?)
    case compare(sample: String)
    case browse
    case fontsInFile(AssetInfo)
    case fontFile(URL)
}

extension Windows {
    static func openFontLens(_ request: FontLensRequest) {
        let model = FontLensModel.shared
        model.handle(request)
        WindowManager.shared.show(id: "font-lens", title: "Font Lens", size: CGSize(width: 860, height: 660), minSize: CGSize(width: 700, height: 520)) {
            FontLensView(model: model)
        }
    }
}

struct FileFont: Identifiable, Hashable {
    var id: String { name }
    let name: String
    let detail: String
    let installed: FontDetails?
}

@MainActor
final class FontLensModel: ObservableObject {
    static let shared = FontLensModel()

    enum Tab: String, CaseIterable, Identifiable {
        case results = "Results", compare = "Compare", installed = "Installed Fonts", favourites = "Favourites"
        var id: String { rawValue }
    }

    enum Subject { case none, actual, estimate, fileFonts, fontFile }

    @Published var tab: Tab = .results
    @Published var subject: Subject = .none
    @Published var actual: ActualFontInfo?
    @Published var actualDetails: FontDetails?
    @Published var capture: CGImage?
    @Published var report: FontMatchReport?
    @Published var analysing = false
    @Published var progress = 0.0
    @Published var error: String?
    @Published var overrideText = ""
    @Published var sampleText: String = AppState.shared.prefs.fontSampleText
    @Published var fileFonts: [FileFont] = []
    @Published var fileName = ""
    @Published var fontFileFamily: String?
    @Published var compare: [String] = []
    @Published var search = ""
    private var task: Task<Void, Never>?
    private var registeredFontFile: URL?

    func handle(_ r: FontLensRequest) {
        error = nil
        switch r {
        case let .actual(info, sample):
            subject = .actual
            actual = info
            sampleText = sample.isEmpty ? AppState.shared.prefs.fontSampleText : String(sample.prefix(120))
            actualDetails = info.postScriptName.flatMap { FontMatcher.details(forPostScriptName: $0) } ?? FontMatcher.details(forFamily: info.family)
            tab = .results
        case let .estimate(image, text):
            subject = .estimate
            capture = image
            overrideText = text ?? ""
            report = nil
            tab = .results
            analyse()
        case let .compare(sample):
            sampleText = sample
            tab = .compare
            if compare.isEmpty { compare = ["Helvetica", "Georgia", "Menlo-Regular"].filter { FontMatcher.details(forPostScriptName: $0) != nil } }
        case .browse:
            tab = .installed
        case let .fontsInFile(asset):
            subject = .fileFonts
            fileName = asset.name
            tab = .results
            loadFileFonts(asset)
        case let .fontFile(url):
            subject = .fontFile
            fileName = url.lastPathComponent
            tab = .results
            registerFontFile(url)
        }
    }

    func analyse() {
        guard let image = capture else { return }
        task?.cancel()
        analysing = true
        progress = 0
        error = nil
        let override = overrideText.isEmpty ? nil : overrideText
        let allFaces = AppState.shared.prefs.fontMatchAllWeights
        task = Task {
            do {
                let r = try await Task.detached {
                    try FontMatcher.analyse(image: image, overrideText: override, limit: 8, allFaces: allFaces) { p in
                        Task { @MainActor in FontLensModel.shared.progress = p }
                    }
                }.value
                report = r
                if overrideText.isEmpty { overrideText = r.sample.text }
                if sampleText == AppState.shared.prefs.fontSampleText { sampleText = r.sample.text }
            } catch {
                self.error = (error as? LocalizedError)?.errorDescription ?? "Font matching failed."
            }
            analysing = false
        }
    }

    private func loadFileFonts(_ asset: AssetInfo) {
        fileFonts = []
        if asset.kind == .pdf || asset.format == .ai {
            fileFonts = PDFEngine.fontsUsed(asset.url).map { f in
                FileFont(name: f.name, detail: "\(f.type) · \(f.embedded ? (f.subset ? "embedded (subset)" : "embedded") : "not embedded")",
                         installed: FontMatcher.details(forPostScriptName: f.name) ?? FontMatcher.details(forFamily: f.name))
            }
        } else if let fmt = asset.format {
            fileFonts = DocumentConverter.fontsUsed(asset.url, format: fmt).map { f in
                FileFont(name: f.face, detail: "\(f.family) · " + f.sizes.map { "\(Int($0)) pt" }.joined(separator: ", "),
                         installed: FontMatcher.details(forFamily: f.family))
            }
        }
        if fileFonts.isEmpty { error = "No font information was found in this file." }
    }

    private func registerFontFile(_ url: URL) {
        if let old = registeredFontFile { CTFontManagerUnregisterFontsForURL(old as CFURL, .process, nil) }
        var err: Unmanaged<CFError>?
        if CTFontManagerRegisterFontsForURL(url as CFURL, .process, &err) { registeredFontFile = url }
        if let desc = (CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as? [CTFontDescriptor])?.first {
            fontFileFamily = CTFontCopyFamilyName(CTFontCreateWithFontDescriptor(desc, 24, nil)) as String
        } else {
            error = "This font file couldn't be read."
        }
    }

    func saveSpecimen(family: String) {
        ActionRunner.shared.withPlanner { planner, delivery in
            JobCenter.shared.runTask(title: "Creating typography card", delivery: delivery, successTitle: "Typography card saved") {
                guard let img = TextGraphics.specimen(family: family) else { throw HexError.message("The card could not be drawn.") }
                let dest = planner.url(for: nil, baseName: "\(family) specimen", ext: "png")
                try ImageEncoder.write(img, format: .png, to: dest)
                return [dest]
            }
        }
    }

    func addToCompare(_ postScriptName: String) {
        if !compare.contains(postScriptName) { compare.append(postScriptName) }
        tab = .compare
    }
}

@MainActor
struct FontLensView: View {
    @ObservedObject var model: FontLensModel
    @EnvironmentObject var state: AppState

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Picker("", selection: $model.tab) {
                    ForEach(FontLensModel.Tab.allCases) { Text($0.rawValue).tag($0) }
                }
                .pickerStyle(.segmented)
                .frame(width: 460)
                Spacer()
                Button {
                    ActionRunner.shared.perform(RadialAction(id: "type.findFont", title: "Find Font", detail: "", symbol: ""), context: .empty)
                } label: { Label("Capture Text", systemImage: "text.viewfinder") }
            }
            .padding(.horizontal, 16)
            .padding(.top, 30)
            .padding(.bottom, 10)
            Divider()
            ScrollView {
                Group {
                    switch model.tab {
                    case .results: results
                    case .compare: CompareFonts(model: model)
                    case .installed: InstalledFonts(model: model)
                    case .favourites: Favourites(model: model)
                    }
                }
                .padding(18)
            }
        }
    }

    @ViewBuilder
    private var results: some View {
        switch model.subject {
        case .actual: ActualFontCard(model: model)
        case .estimate: EstimateResults(model: model)
        case .fileFonts: FileFontsList(model: model)
        case .fontFile:
            if let family = model.fontFileFamily {
                FontFamilyPreview(family: family, model: model, note: "Previewing \(model.fileName). It isn't installed — open it in Font Book to install it.")
            }
        case .none:
            VStack(spacing: 12) {
                Image(systemName: "textformat.size").font(.system(size: 34)).foregroundStyle(state.accentColor)
                Text("Font Lens").font(.system(size: 18, weight: .semibold))
                Text("Select text in an app and press \(state.prefs.hotKey.display) → Typography → Inspect Font, or capture text from the screen.")
                    .multilineTextAlignment(.center).foregroundStyle(.secondary).frame(maxWidth: 420)
            }
            .frame(maxWidth: .infinity, minHeight: 360)
        }
        if let e = model.error {
            Label(e, systemImage: "exclamationmark.triangle").foregroundStyle(.orange).padding(.top, 8)
        }
    }
}

@MainActor
private struct Badge: View {
    let text: String
    var colour: Color = .secondary
    var body: some View {
        Text(text).font(.system(size: 10, weight: .semibold))
            .padding(.horizontal, 7).padding(.vertical, 2)
            .background(Capsule().fill(colour.opacity(0.15)))
            .foregroundStyle(colour)
    }
}

@MainActor
private struct ActualFontCard: View {
    @ObservedObject var model: FontLensModel
    @EnvironmentObject var state: AppState

    var body: some View {
        if let info = model.actual {
            let details = model.actualDetails
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Badge(text: "CONFIRMED", colour: .green)
                    Text(info.source).font(.system(size: 11.5)).foregroundStyle(.secondary)
                }
                Text(model.sampleText)
                    .font(.custom(info.postScriptName ?? info.family, size: 34))
                    .lineLimit(3)
                    .textSelection(.enabled)
                SectionCard(title: "Typography") {
                    CopyField(label: "Family", value: info.family)
                    if let ps = info.postScriptName { CopyField(label: "Font", value: ps) }
                    if let s = info.size { CopyField(label: "Size", value: String(format: "%g pt / px", s)) }
                    CopyField(label: "Weight", value: info.weight.map { "\($0)" } ?? details.map { "\($0.cssWeight)" } ?? "Not reported")
                    CopyField(label: "Style", value: info.italic ? "Italic" : (details?.styleName ?? "Regular"))
                    CopyField(label: "Line height", value: info.lineHeight ?? "Not reported by the app")
                    CopyField(label: "Letter sp.", value: info.letterSpacing ?? "Not reported by the app")
                    if let c = info.colourHex { CopyField(label: "Colour", value: c) }
                }
                HStack {
                    Button("Copy CSS") {
                        Clipboard.copy(FontMatcher.cssDeclaration(family: info.family, weight: info.weight ?? details?.cssWeight ?? 400, italic: info.italic,
                                                                  category: details?.category ?? .sansSerif, sizePx: info.size, colour: info.colourHex))
                        JobCenter.shared.message("CSS copied")
                    }
                    .buttonStyle(AccentButtonStyle())
                    Button("Copy SwiftUI") {
                        Clipboard.copy(FontMatcher.swiftUIDeclaration(family: info.family, postScriptName: info.postScriptName ?? details?.postScriptName,
                                                                      weight: info.weight ?? details?.cssWeight ?? 400, italic: info.italic, size: info.size))
                        JobCenter.shared.message("SwiftUI code copied")
                    }
                    if let d = details {
                        Button(state.store.favouriteFonts.contains(d.postScriptName) ? "★ Favourite" : "☆ Add to Favourites") { state.toggleFavouriteFont(d.postScriptName) }
                        Button("Compare") { model.addToCompare(d.postScriptName) }
                        Button("Typography Card") { model.saveSpecimen(family: d.familyName) }
                    }
                }
                FontDetailsCard(details: details, familyName: info.family)
            }
        }
    }
}

@MainActor
private struct FontDetailsCard: View {
    let details: FontDetails?
    let familyName: String

    var body: some View {
        SectionCard(title: "About this font") {
            if let d = details {
                HStack(spacing: 6) {
                    Badge(text: "INSTALLED", colour: .green)
                    Badge(text: d.category.title.uppercased())
                    Badge(text: "\(d.availableStyles.count) STYLES")
                }
                Text(d.availableStyles.joined(separator: " · ")).font(.system(size: 11)).foregroundStyle(.secondary)
                if let designer = d.designer { Text("Designer: \(designer)").font(.system(size: 11.5)) }
                if let m = d.manufacturer { Text("Foundry: \(m)").font(.system(size: 11.5)) }
                Text("Licence: \(d.licenceSummary)").font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                HStack {
                    if let url = d.sourceURL { Link("Official source", destination: url) }
                    if let l = d.licenceURL, let u = URL(string: l.hasPrefix("http") ? l : "https://" + l) { Link("Licence", destination: u) }
                    if let f = d.fileURL { Button("Show Font File") { NSWorkspace.shared.activateFileViewerSelecting([f]) }.buttonStyle(.link) }
                }
            } else {
                Badge(text: "NOT INSTALLED", colour: .orange)
                Text("“\(familyName)” isn't installed on this Mac. HEXSHIFT never downloads or installs fonts for you.")
                    .font(.system(size: 11.5)).foregroundStyle(.secondary)
                if let q = familyName.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
                    HStack {
                        Link("Search Google Fonts", destination: URL(string: "https://fonts.google.com/?query=\(q)")!)
                        Link("Search Adobe Fonts", destination: URL(string: "https://fonts.adobe.com/search?query=\(q)")!)
                    }
                    .font(.system(size: 11.5))
                }
            }
        }
    }
}

@MainActor
private struct EstimateResults: View {
    @ObservedObject var model: FontLensModel
    @EnvironmentObject var state: AppState

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Badge(text: "ESTIMATED", colour: .orange)
                Text("No exact font information was found. Showing visually similar fonts — installed ones and popular Google Fonts.")
                    .font(.system(size: 11.5)).foregroundStyle(.secondary)
            }
            if let img = model.capture {
                Image(nsImage: NSImage(cg: img)).resizable().aspectRatio(contentMode: .fit)
                    .frame(maxHeight: 120)
                    .background(Checkerboard(size: 6))
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            }
            HStack {
                TextField("Recognised text (correct it for better matches)", text: $model.overrideText)
                    .textFieldStyle(.roundedBorder)
                    .onSubmit { model.analyse() }
                Button("Match Again") { model.analyse() }.disabled(model.analysing)
            }
            if model.analysing {
                ProgressView(value: model.progress) { Text("Comparing letter shapes with every font…").font(.system(size: 11.5)) }
                    .tint(state.accentColor)
            }
            if let r = model.report {
                HStack(spacing: 14) {
                    if let a = r.alignment { Label(a, systemImage: "text.alignleft").font(.system(size: 11.5)) }
                    if let lh = r.lineHeightRatio { Label("Line spacing ≈ \(String(format: "%.2f", lh))× text height (estimate)", systemImage: "arrow.up.and.down.text.horizontal").font(.system(size: 11.5)) }
                    Label("Text height ≈ \(Int(r.approxTextHeightPx)) px", systemImage: "textformat.size").font(.system(size: 11.5))
                }
                .foregroundStyle(.secondary)
                TextField("Sample text", text: $model.sampleText).textFieldStyle(.roundedBorder)
                ForEach(r.candidates) { c in
                    CandidateRow(candidate: c, sample: model.sampleText, model: model)
                }
                Text("Similarity is estimated from letter shapes and is never a guarantee. Fonts are matched against those installed on this Mac and \(FontReference.shared?.faces.count ?? 0) styles of popular Google Fonts. Correct the recognised text above for better matches.")
                    .font(.system(size: 10.5)).foregroundStyle(.secondary)
            }
        }
    }
}

@MainActor
private struct CandidateRow: View {
    let candidate: FontCandidate
    let sample: String
    @ObservedObject var model: FontLensModel
    @EnvironmentObject var state: AppState
    @State private var expanded = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("\(candidate.familyName) \(candidate.styleName)").font(.system(size: 13, weight: .semibold))
                    HStack(spacing: 6) {
                        Badge(text: candidate.category.title.uppercased())
                        if candidate.isInstalled {
                            Badge(text: "INSTALLED", colour: .green)
                        } else {
                            Badge(text: "GOOGLE FONTS · NOT INSTALLED", colour: .blue)
                        }
                        Text("weight \(candidate.cssWeight)\(candidate.isItalic ? " · italic" : "")").font(.system(size: 10.5)).foregroundStyle(.secondary)
                    }
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 3) {
                    Text("≈ \(Int((candidate.similarity * 100).rounded()))%").font(.system(size: 15, weight: .bold, design: .rounded))
                    ProgressView(value: candidate.similarity).frame(width: 90).tint(state.accentColor)
                }
            }
            if candidate.isInstalled {
                Text(sample.isEmpty ? "Sphinx of black quartz" : sample)
                    .font(.custom(candidate.postScriptName, size: 30))
                    .lineLimit(2)
            } else if let preview = FontMatcher.referencePreview(text: sample.isEmpty ? "Sphinx of black quartz" : sample,
                                                                 candidate: candidate, emPixels: 60) {
                Image(decorative: preview, scale: 2)
                    .renderingMode(.template)
                    .foregroundStyle(.primary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .clipped()
            }
            HStack {
                Button("Copy Name") { Clipboard.copy(candidate.familyName) }
                Button("Copy CSS") {
                    let size = model.report.map { $0.approxTextHeightPx / 1.2 }
                    Clipboard.copy(candidate.isInstalled
                        ? FontMatcher.cssDeclaration(family: candidate.familyName, weight: candidate.cssWeight, italic: candidate.isItalic,
                                                     category: candidate.category, sizePx: size)
                        : FontMatcher.googleFontsCSS(candidate, sizePx: size))
                    JobCenter.shared.message("CSS copied")
                }
                if let url = candidate.googleFontsURL {
                    Button("Get Font") { NSWorkspace.shared.open(url) }
                        .help("Opens the font's page on Google Fonts (free to download)")
                }
                if candidate.isInstalled {
                Button("SwiftUI") {
                    Clipboard.copy(FontMatcher.swiftUIDeclaration(family: candidate.familyName, postScriptName: candidate.postScriptName,
                                                                  weight: candidate.cssWeight, italic: candidate.isItalic, size: model.report.map { $0.approxTextHeightPx / 1.2 }))
                    JobCenter.shared.message("SwiftUI code copied")
                }
                .help("Copy SwiftUI code")
                Button(state.store.favouriteFonts.contains(candidate.postScriptName) ? "★" : "☆") { state.toggleFavouriteFont(candidate.postScriptName) }
                    .help("Favourite")
                Button("Compare") { model.addToCompare(candidate.postScriptName) }
                }
                Spacer()
                if candidate.isInstalled {
                    Button(expanded ? "Less" : "Details") { expanded.toggle() }.buttonStyle(.link)
                }
            }
            .controlSize(.small)
            if expanded && candidate.isInstalled {
                FontDetailsCard(details: FontMatcher.details(forPostScriptName: candidate.postScriptName), familyName: candidate.familyName)
            }
            if !candidate.isInstalled {
                Text("Free under the SIL Open Font License or Apache License. Install it from Google Fonts to use it in your apps.")
                    .font(.system(size: 10.5)).foregroundStyle(.secondary)
            }
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.primary.opacity(0.04)))
    }
}

@MainActor
private struct FileFontsList: View {
    @ObservedObject var model: FontLensModel

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Badge(text: "ACTUAL METADATA", colour: .green)
                Text("Fonts referenced inside \(model.fileName)").font(.system(size: 12)).foregroundStyle(.secondary)
            }
            ForEach(model.fileFonts) { f in
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(f.name).font(.system(size: 13, weight: .semibold))
                        Text(f.detail).font(.system(size: 11)).foregroundStyle(.secondary)
                        if let d = f.installed {
                            Text(model.sampleText).font(.custom(d.postScriptName, size: 22)).lineLimit(1)
                        }
                    }
                    Spacer()
                    if f.installed != nil { Badge(text: "INSTALLED", colour: .green) } else { Badge(text: "NOT INSTALLED", colour: .orange) }
                    Button("Copy") { Clipboard.copy(f.name) }.controlSize(.small)
                }
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 10).fill(Color.primary.opacity(0.04)))
            }
        }
    }
}

@MainActor
private struct FontFamilyPreview: View {
    let family: String
    @ObservedObject var model: FontLensModel
    var note: String?

    var body: some View {
        let members = NSFontManager.shared.availableMembers(ofFontFamily: family) ?? []
        VStack(alignment: .leading, spacing: 12) {
            Text(family).font(.custom(family, size: 40))
            if let note { Text(note).font(.system(size: 11.5)).foregroundStyle(.secondary) }
            TextField("Sample text", text: $model.sampleText).textFieldStyle(.roundedBorder)
            ForEach(Array(members.enumerated()), id: \.offset) { _, m in
                if let ps = m.first as? String {
                    VStack(alignment: .leading, spacing: 2) {
                        Text((m.count > 1 ? m[1] as? String : nil) ?? ps).font(.system(size: 10.5)).foregroundStyle(.secondary)
                        Text(model.sampleText).font(.custom(ps, size: 26)).lineLimit(2)
                    }
                }
            }
            FontDetailsCard(details: FontMatcher.details(forFamily: family), familyName: family)
            Button("Create Typography Card") { model.saveSpecimen(family: family) }.buttonStyle(AccentButtonStyle())
        }
    }
}

@MainActor
private struct CompareFonts: View {
    @ObservedObject var model: FontLensModel
    @State private var adding = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            TextField("Sample text", text: $model.sampleText).textFieldStyle(.roundedBorder)
            HStack {
                TextField("Add a font by name (e.g. Avenir Next, Futura)", text: $adding)
                    .textFieldStyle(.roundedBorder)
                    .onSubmit(add)
                Button("Add", action: add)
            }
            if model.compare.isEmpty {
                Text("Add fonts from results, the installed list, or by name.").foregroundStyle(.secondary)
            }
            ForEach(model.compare, id: \.self) { ps in
                let d = FontMatcher.details(forPostScriptName: ps)
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text(d.map { "\($0.familyName) \($0.styleName)" } ?? ps).font(.system(size: 11.5, weight: .semibold))
                        if let d { Text("\(d.category.title) · \(d.cssWeight)").font(.system(size: 10.5)).foregroundStyle(.secondary) }
                        Spacer()
                        Button { model.compare.removeAll { $0 == ps } } label: { Image(systemName: "xmark") }.buttonStyle(.borderless)
                    }
                    Text(model.sampleText).font(.custom(ps, size: 30)).lineLimit(2)
                }
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 10).fill(Color.primary.opacity(0.04)))
            }
        }
    }

    private func add() {
        let name = adding.trimmingCharacters(in: .whitespaces)
        guard !name.isEmpty else { return }
        if let d = FontMatcher.details(forPostScriptName: name) ?? FontMatcher.details(forFamily: name)
            ?? NSFontManager.shared.availableFontFamilies.first(where: { $0.localizedCaseInsensitiveCompare(name) == .orderedSame }).flatMap({ FontMatcher.details(forFamily: $0) }) {
            model.addToCompare(d.postScriptName)
            adding = ""
        } else {
            JobCenter.shared.message("“\(name)” isn't installed")
        }
    }
}

@MainActor
private struct InstalledFonts: View {
    @ObservedObject var model: FontLensModel
    @EnvironmentObject var state: AppState
    @State private var families: [String] = []

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                TextField("Search \(families.count) installed families", text: $model.search).textFieldStyle(.roundedBorder)
                TextField("Sample", text: $model.sampleText).textFieldStyle(.roundedBorder).frame(width: 260)
            }
            LazyVStack(alignment: .leading, spacing: 10) {
                ForEach(families.filter { model.search.isEmpty || $0.localizedCaseInsensitiveContains(model.search) }, id: \.self) { fam in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(fam).font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary)
                            Text(model.sampleText).font(.custom(fam, size: 22)).lineLimit(1)
                        }
                        Spacer()
                        Button("Compare") {
                            if let d = FontMatcher.details(forFamily: fam) { model.addToCompare(d.postScriptName) }
                        }
                        .controlSize(.small)
                        Button("Card") { model.saveSpecimen(family: fam) }.controlSize(.small)
                    }
                    Divider()
                }
            }
        }
        .onAppear { families = NSFontManager.shared.availableFontFamilies.filter { !$0.hasPrefix(".") }.sorted() }
    }
}

@MainActor
private struct Favourites: View {
    @ObservedObject var model: FontLensModel
    @EnvironmentObject var state: AppState

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if state.store.favouriteFonts.isEmpty {
                Text("Star fonts in results to keep them here.").foregroundStyle(.secondary)
            }
            ForEach(state.store.favouriteFonts, id: \.self) { ps in
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(FontMatcher.details(forPostScriptName: ps).map { "\($0.familyName) \($0.styleName)" } ?? ps)
                            .font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary)
                        Text(model.sampleText).font(.custom(ps, size: 24)).lineLimit(1)
                    }
                    Spacer()
                    Button("Copy CSS") {
                        if let d = FontMatcher.details(forPostScriptName: ps) {
                            Clipboard.copy(FontMatcher.cssDeclaration(family: d.familyName, weight: d.cssWeight, italic: d.isItalic, category: d.category))
                        }
                    }
                    .controlSize(.small)
                    Button { state.toggleFavouriteFont(ps) } label: { Image(systemName: "star.slash") }.buttonStyle(.borderless)
                }
                Divider()
            }
        }
    }
}
