import AppKit
import HexshiftKit
import PDFKit
import SwiftUI
import UniformTypeIdentifiers

enum PDFToolkitMode: String { case organize, markup, redact, sign }

enum MarkupTool: String, CaseIterable, Identifiable {
    case text, note, draw, highlight, rectangle
    var id: String { rawValue }
    var title: String {
        switch self {
        case .text: return "Text"
        case .note: return "Comment"
        case .draw: return "Draw"
        case .highlight: return "Highlight"
        case .rectangle: return "Box"
        }
    }
    var symbol: String {
        switch self {
        case .text: return "textformat"
        case .note: return "text.bubble"
        case .draw: return "scribble"
        case .highlight: return "highlighter"
        case .rectangle: return "rectangle"
        }
    }
    var hint: String {
        switch self {
        case .text: return "Drag a box on the page where the text should go."
        case .note: return "Click where the comment should be pinned."
        case .draw: return "Draw on the page with the mouse or trackpad."
        case .highlight: return "Drag over the area to highlight."
        case .rectangle: return "Drag to draw an outlined box."
        }
    }
}

extension Windows {
    static func openPDFToolkit(urls: [URL], mode: PDFToolkitMode, promptInsert: Bool = false) {
        do {
            let model = try PDFToolkitModel(urls: urls, mode: mode)
            WindowManager.shared.show(id: "pdf:\(urls.first?.path ?? "")", title: urls.first?.lastPathComponent ?? "PDF",
                                      size: CGSize(width: 980, height: 700), minSize: CGSize(width: 760, height: 520)) {
                PDFToolkitView(model: model)
            }
            if promptInsert {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { model.insertFiles() }
            }
        } catch {
            JobCenter.shared.error(error, title: "Couldn't open the PDF")
        }
    }
}

@MainActor
final class PDFToolkitModel: ObservableObject {
    let sourceURL: URL
    @Published private(set) var document: PDFDocument
    @Published var thumbnails: [Int: NSImage] = [:]
    @Published var selection: Set<Int> = []
    @Published var mode: PDFToolkitMode
    @Published var isDirty = false
    @Published var redactions: [RedactionArea] = []
    @Published var redactTerms = ""
    @Published var focusedPage: Int?
    @Published var signatureImage: CGImage?
    @Published var signatureRect: (page: Int, rect: CGRect)?
    @Published var busy = false
    @Published var revision = 0
    @Published var markupTool: MarkupTool = .text
    @Published var markupText = ""
    @Published var markupFontSize = 14.0
    @Published var markupColour = RGBAColour(r: 0.86, g: 0.18, b: 0.15)
    private var markupHistory: [(page: Int, annotation: PDFAnnotation)] = []
    private var detailCache: [Int: CGImage] = [:]
    private var lastClicked: Int?

    init(urls: [URL], mode: PDFToolkitMode) throws {
        sourceURL = urls[0]
        self.mode = mode
        if urls.count == 1 {
            document = try PDFEngine.open(urls[0])
        } else {
            let tmp = try FileWriter.makeTemporaryDirectory().appendingPathComponent("merged.pdf")
            try PDFEngine.merge(urls, output: tmp)
            document = try PDFEngine.open(tmp)
            isDirty = true
        }
        renderThumbnails()
    }

    var pageCount: Int { document.pageCount }
    var baseName: String { sourceURL.deletingPathExtension().lastPathComponent }

    private var thumbnailTask: Task<Void, Never>?

    /// Renders page thumbnails a few at a time, letting the run loop breathe between pages so a
    /// 300-page PDF opens instantly and fills in as you look at it.
    func renderThumbnails() {
        thumbnailTask?.cancel()
        thumbnails = [:]
        revision += 1
        let rev = revision
        thumbnailTask = Task { @MainActor [weak self] in
            var i = 0
            while let self, i < self.document.pageCount, !Task.isCancelled, rev == self.revision {
                if let page = self.document.page(at: i) {
                    self.thumbnails[i] = page.thumbnail(of: NSSize(width: 220, height: 280), for: .cropBox)
                }
                i += 1
                try? await Task.sleep(nanoseconds: 2_000_000)
            }
        }
    }

    // MARK: Selection

    func click(_ i: Int) {
        let flags = NSEvent.modifierFlags
        if flags.contains(.command) {
            if selection.contains(i) { selection.remove(i) } else { selection.insert(i) }
        } else if flags.contains(.shift), let last = lastClicked {
            for k in min(last, i)...max(last, i) { selection.insert(k) }
        } else {
            selection = [i]
        }
        lastClicked = i
    }

    var sortedSelection: [Int] { selection.sorted() }

    // MARK: Page operations (in memory until saved)

    private func changed() {
        isDirty = true
        detailCache = [:]
        renderThumbnails()
    }

    /// The large page image for the detail view, rendered once per change.
    func detailImage(for page: Int) -> CGImage? {
        if let cached = detailCache[page] { return cached }
        guard let p = document.page(at: page), let img = PDFEngine.render(p, dpi: 144) else { return nil }
        detailCache[page] = img
        return img
    }

    // MARK: Markup

    var canUndoMarkup: Bool { !markupHistory.isEmpty }

    /// Adds a markup annotation. Geometry is in the page's visual space (points, bottom-left origin).
    func addMarkup(page index: Int, rect: CGRect?, point: CGPoint?, strokes: [[CGPoint]]) {
        guard let page = document.page(at: index) else { return }
        let text = markupText.trimmingCharacters(in: .whitespacesAndNewlines)
        var added: PDFAnnotation?
        switch markupTool {
        case .text:
            guard let rect else { return }
            added = PDFEngine.addTextBox(text.isEmpty ? "Text" : text, to: page, visualRect: rect,
                                         fontSize: CGFloat(markupFontSize), colour: markupColour)
        case .note:
            guard let point else { return }
            added = PDFEngine.addNote(text.isEmpty ? "Comment" : text, to: page, visualPoint: point)
        case .draw:
            added = PDFEngine.addInk(strokes, to: page, colour: markupColour, lineWidth: 2.5)
        case .highlight:
            guard let rect else { return }
            added = PDFEngine.addBox(to: page, visualRect: rect, colour: RGBAColour(r: 1, g: 0.85, b: 0.1), filled: true)
        case .rectangle:
            guard let rect else { return }
            added = PDFEngine.addBox(to: page, visualRect: rect, colour: markupColour, filled: false)
        }
        if let added { markupHistory.append((index, added)) }
        changed()
    }

    func undoMarkup() {
        guard let last = markupHistory.popLast(), let page = document.page(at: last.page) else { return }
        page.removeAnnotation(last.annotation)
        changed()
    }

    func rotateSelected(_ degrees: Int) {
        PDFEngine.rotate(document, pages: sortedSelection, by: degrees)
        changed()
    }

    func deleteSelected() {
        guard selection.count < pageCount else {
            JobCenter.shared.message("A PDF needs at least one page")
            return
        }
        for i in sortedSelection.reversed() { document.removePage(at: i) }
        selection = []
        changed()
    }

    func duplicateSelected() {
        var offset = 0
        for i in sortedSelection {
            if let copy = document.page(at: i + offset)?.copy() as? PDFPage {
                document.insert(copy, at: i + offset + 1)
                offset += 1
            }
        }
        changed()
    }

    func moveSelected(by delta: Int) {
        let sel = sortedSelection
        guard !sel.isEmpty else { return }
        if delta < 0, sel.first! == 0 { return }
        if delta > 0, sel.last! == pageCount - 1 { return }
        let order = delta < 0 ? sel : sel.reversed()
        for i in order {
            document.exchangePage(at: i, withPageAt: i + delta)
        }
        selection = Set(sel.map { $0 + delta })
        changed()
    }

    func insertFiles() {
        NSApp.activate()
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = true
        panel.allowedContentTypes = [.pdf, .image]
        panel.message = "Choose PDFs or images to insert"
        panel.level = .modalPanel   // stay above other apps, so it can't hide behind them
        guard panel.runModal() == .OK else { return }
        do {
            let tmp = try FileWriter.makeTemporaryDirectory().appendingPathComponent("insert.pdf")
            try PDFEngine.merge(panel.urls, output: tmp)
            let insert = try PDFEngine.open(tmp)
            var at = (sortedSelection.last.map { $0 + 1 }) ?? pageCount
            for i in 0..<insert.pageCount {
                if let p = insert.page(at: i)?.copy() as? PDFPage {
                    document.insert(p, at: at)
                    at += 1
                }
            }
            changed()
        } catch {
            JobCenter.shared.error(error)
        }
    }

    // MARK: Saving & exporting

    func workingCopy() throws -> URL {
        let tmp = try FileWriter.makeTemporaryDirectory().appendingPathComponent("working.pdf")
        guard document.write(to: tmp) else { throw HexError.writeFailed("PDFKit could not write the working copy.") }
        return tmp
    }

    func save() {
        let doc = document
        let name = baseName
        let src = sourceURL
        ActionRunner.shared.withPlanner { planner, delivery in
            let dest = planner.url(for: src, baseName: name + "-edited", ext: "pdf")
            do {
                try PDFEngine.save(doc, to: dest)
                self.isDirty = false
                JobCenter.shared.show(Toast(kind: .success, title: "PDF saved", detail: dest.lastPathComponent, outputs: [dest], canUndo: true))
                if delivery == .clipboard { JobCenter.shared.copyOutputsToClipboard([dest]) }
            } catch {
                JobCenter.shared.error(error)
            }
        }
    }

    func extractSelected() {
        guard !selection.isEmpty, let working = try? workingCopy() else { return }
        let pages = sortedSelection, name = baseName, src = sourceURL
        ActionRunner.shared.withPlanner { planner, delivery in
            JobCenter.shared.runTask(title: "Extracting pages", delivery: delivery) {
                let dest = planner.url(for: src, baseName: name + "-extract", ext: "pdf")
                try PDFEngine.extractPages(working, pages: pages, output: dest)
                return [dest]
            }
        }
    }

    func exportSelected(as format: Format, dpi: Double) {
        guard let working = try? workingCopy() else { return }
        let pages = selection.isEmpty ? nil : sortedSelection, src = sourceURL
        var o = AppState.shared.conversionOptions(for: format).image
        o.quality = AppState.shared.prefs.quality(for: format)
        let opts = o
        ActionRunner.shared.withPlanner { planner, delivery in
            JobCenter.shared.runTask(title: "Exporting pages", delivery: delivery) {
                try PDFEngine.exportPages(working, pages: pages, dpi: dpi, format: format, options: opts, planner: planner, namingSource: src)
            }
        }
    }

    /// Runs an engine operation on the current document and loads the result back in.
    func transform(_ title: String, _ op: @escaping @Sendable (URL, URL) throws -> Void) {
        guard let working = try? workingCopy() else { return }
        busy = true
        Task {
            do {
                let out = working.deletingLastPathComponent().appendingPathComponent("result-\(UUID().uuidString.prefix(6)).pdf")
                try await Task.detached { try op(working, out) }.value
                document = try PDFEngine.open(out)
                changed()
                JobCenter.shared.message(title, detail: "Not saved yet — choose Save Copy when you're done.")
            } catch {
                JobCenter.shared.error(error)
            }
            busy = false
        }
    }

    // MARK: Redaction

    func findRedactions() {
        let terms = redactTerms.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
        guard !terms.isEmpty, let working = try? workingCopy() else { return }
        do {
            let found = try PDFEngine.redactionAreas(matching: terms, in: working)
            redactions.append(contentsOf: found)
            JobCenter.shared.message(found.isEmpty ? "No matches found" : "\(found.count) area(s) marked for redaction")
        } catch {
            JobCenter.shared.error(error)
        }
    }

    func applyRedactions() {
        let areas = redactions
        guard !areas.isEmpty else { return }
        transform("Redaction applied") { input, output in
            try PDFEngine.redact(input, areas: areas, output: output)
        }
        redactions = []
    }

    // MARK: Signature

    func chooseSignature() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.png, .image]
        panel.message = "Choose a signature image (a PNG with a transparent background works best)"
        panel.level = .modalPanel   // stay above other apps, so it can't hide behind them
        guard panel.runModal() == .OK, let url = panel.url, let img = try? ImageLoader.load(url).image else { return }
        signatureImage = img
    }

    func applySignature() {
        guard let img = signatureImage, let placement = signatureRect else { return }
        transform("Signature placed") { input, output in
            try PDFEngine.placeImage(img, on: input, pageIndex: placement.page, visualRect: placement.rect, output: output)
        }
        signatureRect = nil
    }

    func visualSize(of page: Int) -> CGSize {
        guard let ref = document.page(at: page)?.pageRef else { return CGSize(width: 612, height: 792) }
        return PDFEngine.visualSize(ref)
    }
}

@MainActor
struct PDFToolkitView: View {
    @ObservedObject var model: PDFToolkitModel
    @EnvironmentObject var state: AppState
    @State private var exportFormat: Format = .png
    @State private var exportDPI = 150.0

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            Divider()
            HStack(spacing: 0) {
                if let page = model.focusedPage {
                    PageDetailView(model: model, page: page)
                } else {
                    pageGrid
                }
                Divider()
                sidebar.frame(width: 270)
            }
        }
    }

    private var toolbar: some View {
        HStack(spacing: 8) {
            Spacer().frame(width: 70)
            Picker("", selection: $model.mode) {
                Text("Pages").tag(PDFToolkitMode.organize)
                Text("Markup").tag(PDFToolkitMode.markup)
                Text("Redact").tag(PDFToolkitMode.redact)
                Text("Sign").tag(PDFToolkitMode.sign)
            }
            .pickerStyle(.segmented)
            .frame(width: 320)
            Spacer()
            if model.busy { ProgressView().controlSize(.small) }
            Text("\(model.pageCount) pages\(model.isDirty ? " · edited" : "")").font(.system(size: 11.5)).foregroundStyle(.secondary)
            Button("Save Copy") { model.save() }
                .buttonStyle(AccentButtonStyle())
                .keyboardShortcut("s", modifiers: .command)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
    }

    private var pageGrid: some View {
        ScrollView {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 150, maximum: 190), spacing: 16)], spacing: 18) {
                ForEach(0..<model.pageCount, id: \.self) { i in
                    VStack(spacing: 6) {
                        ZStack {
                            if let t = model.thumbnails[i] {
                                Image(nsImage: t).resizable().aspectRatio(contentMode: .fit)
                            } else {
                                Rectangle().fill(Color.primary.opacity(0.05))
                            }
                        }
                        .frame(height: 190)
                        .padding(6)
                        .background(RoundedRectangle(cornerRadius: 8).fill(Color.white).shadow(color: .black.opacity(0.12), radius: 4, y: 1))
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(model.selection.contains(i) ? state.accentColor : Color.clear, lineWidth: 3))
                        HStack(spacing: 4) {
                            Text("\(i + 1)").font(.system(size: 11.5, weight: .medium))
                            let marks = model.redactions.filter { $0.pageIndex == i }.count
                            if marks > 0 { Image(systemName: "eye.slash.fill").font(.system(size: 9)).foregroundStyle(.red) }
                        }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture(count: 2) { model.focusedPage = i }
                    .onTapGesture { model.click(i) }
                    .accessibilityLabel("Page \(i + 1)")
                    .accessibilityAddTraits(model.selection.contains(i) ? .isSelected : [])
                }
            }
            .padding(20)
        }
    }

    @ViewBuilder
    private var sidebar: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                switch model.mode {
                case .organize: organizePanel
                case .markup: markupPanel
                case .redact: redactPanel
                case .sign: signPanel
                }
            }
            .padding(16)
        }
    }

    private var organizePanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(model.selection.isEmpty ? "Select pages (⌘-click / ⇧-click for several). Double-click to view a page." : "\(model.selection.count) page(s) selected")
                .font(.system(size: 11.5)).foregroundStyle(.secondary)
            SectionCard(title: "Arrange") {
                HStack {
                    Button { model.rotateSelected(-90) } label: { Image(systemName: "rotate.left") }.help("Rotate left")
                    Button { model.rotateSelected(90) } label: { Image(systemName: "rotate.right") }.help("Rotate right")
                    Button { model.moveSelected(by: -1) } label: { Image(systemName: "arrow.left") }.help("Move earlier")
                    Button { model.moveSelected(by: 1) } label: { Image(systemName: "arrow.right") }.help("Move later")
                }
                .disabled(model.selection.isEmpty)
                HStack {
                    Button("Duplicate") { model.duplicateSelected() }.disabled(model.selection.isEmpty)
                    Button("Delete") { model.deleteSelected() }.disabled(model.selection.isEmpty)
                }
                Button("Insert PDFs or Images…") { model.insertFiles() }
            }
            SectionCard(title: "Export") {
                Button("Extract Selected to New PDF") { model.extractSelected() }.disabled(model.selection.isEmpty)
                Picker("Format", selection: $exportFormat) {
                    ForEach([Format.png, .jpeg, .tiff, .webp, .heic].filter(ImageEncoder.canWrite), id: \.self) { Text($0.displayName).tag($0) }
                }
                Picker("Resolution", selection: $exportDPI) {
                    Text("72 dpi").tag(72.0); Text("150 dpi").tag(150.0); Text("300 dpi").tag(300.0)
                }
                Button(model.selection.isEmpty ? "Export All Pages as Images" : "Export Selected as Images") {
                    model.exportSelected(as: exportFormat, dpi: exportDPI)
                }
            }
            SectionCard(title: "Whole document") {
                Button("Make Searchable (OCR)") {
                    model.transform("Text layer added") { i, o in _ = try PDFEngine.makeSearchable(i, output: o) }
                }
                Button("Compress") {
                    model.transform("Compressed") { i, o in _ = try PDFEngine.compress(i, output: o) }
                }
                Button("Remove Metadata") {
                    model.transform("Metadata removed") { i, o in try PDFEngine.stripMetadata(i, output: o) }
                }
                Button("Add Page Numbers") {
                    model.transform("Page numbers added") { i, o in try PDFEngine.addPageNumbers(i, output: o, format: "{n}") }
                }
            }
        }
    }

    private var markupPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Markup is added as real PDF annotations — they stay editable in Preview, Acrobat and other apps.")
                .font(.system(size: 11.5)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            SectionCard(title: "Tool") {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 70), spacing: 6)], spacing: 6) {
                    ForEach(MarkupTool.allCases) { tool in
                        Button { model.markupTool = tool } label: {
                            VStack(spacing: 3) {
                                Image(systemName: tool.symbol).font(.system(size: 15))
                                Text(tool.title).font(.system(size: 10.5))
                            }
                            .frame(maxWidth: .infinity, minHeight: 42)
                            .background(RoundedRectangle(cornerRadius: 8).fill(model.markupTool == tool ? state.accentColor.opacity(0.18) : Color.primary.opacity(0.04)))
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(tool.title)
                        .accessibilityAddTraits(model.markupTool == tool ? .isSelected : [])
                    }
                }
                Text(model.focusedPage == nil ? "Double-click a page to open it, then: " + model.markupTool.hint.lowercased() : model.markupTool.hint)
                    .font(.system(size: 11)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            if model.markupTool == .text || model.markupTool == .note {
                SectionCard(title: model.markupTool == .text ? "Text" : "Comment") {
                    TextField(model.markupTool == .text ? "Type the text to place" : "Type the comment", text: $model.markupText, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .lineLimit(2...5)
                    if model.markupTool == .text {
                        Stepper("Size: \(Int(model.markupFontSize)) pt", value: $model.markupFontSize, in: 6...72)
                    }
                }
            }
            if [.text, .draw, .rectangle].contains(model.markupTool) {
                SectionCard(title: "Colour") {
                    HStack(spacing: 8) {
                        ForEach(Self.markupColours, id: \.self) { c in
                            Circle().fill(c.swiftUIColor).frame(width: 22, height: 22)
                                .overlay(Circle().stroke(model.markupColour == c ? state.accentColor : Color.primary.opacity(0.2), lineWidth: model.markupColour == c ? 3 : 1))
                                .onTapGesture { model.markupColour = c }
                                .accessibilityLabel(ColourMath.approximateName(c))
                        }
                    }
                }
            }
            HStack {
                Button("Undo Last") { model.undoMarkup() }.disabled(!model.canUndoMarkup)
                Spacer()
            }
            Text("Choose Save Copy when you're done. The original PDF isn't changed.").font(.system(size: 10.5)).foregroundStyle(.secondary)
        }
    }

    static let markupColours: [RGBAColour] = [
        RGBAColour(r: 0.86, g: 0.18, b: 0.15), RGBAColour(r: 0.1, g: 0.1, b: 0.1), RGBAColour(r: 0.12, g: 0.4, b: 0.85),
        RGBAColour(r: 0.1, g: 0.6, b: 0.35), RGBAColour(r: 0.95, g: 0.55, b: 0.1),
    ]

    private var redactPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Redaction permanently removes content. Marked pages are flattened into images with black boxes, so hidden text can't be copied or recovered. The rest of the text stays searchable.")
                .font(.system(size: 11.5)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            SectionCard(title: "Find text to redact") {
                TextField("Names, numbers… (comma-separated)", text: $model.redactTerms)
                    .textFieldStyle(.roundedBorder)
                    .onSubmit { model.findRedactions() }
                Button("Mark All Matches") { model.findRedactions() }
            }
            SectionCard(title: "Draw areas") {
                Text("Double-click a page, then drag rectangles over anything to remove.").font(.system(size: 11)).foregroundStyle(.secondary)
            }
            Text("\(model.redactions.count) area(s) marked").font(.system(size: 12, weight: .medium))
            HStack {
                Button("Clear") { model.redactions = [] }.disabled(model.redactions.isEmpty)
                Spacer()
                Button("Apply Redaction") { model.applyRedactions() }
                    .buttonStyle(AccentButtonStyle())
                    .disabled(model.redactions.isEmpty)
            }
        }
    }

    private var signPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionCard(title: "Signature") {
                if let img = model.signatureImage {
                    Image(nsImage: NSImage(cg: img)).resizable().aspectRatio(contentMode: .fit).frame(height: 70)
                        .background(Checkerboard(size: 6))
                }
                Button(model.signatureImage == nil ? "Choose Signature Image…" : "Change Image…") { model.chooseSignature() }
            }
            Text("Double-click a page, then drag where the signature should go.").font(.system(size: 11)).foregroundStyle(.secondary)
            Text("This places a visible signature image. It is not a cryptographic digital signature.").font(.system(size: 10.5)).foregroundStyle(.secondary)
            HStack {
                Spacer()
                Button("Place Signature") { model.applySignature() }
                    .buttonStyle(AccentButtonStyle())
                    .disabled(model.signatureImage == nil || model.signatureRect == nil)
            }
        }
    }
}

/// Large single-page view used for markup, drawing redaction areas and placing signatures.
@MainActor
struct PageDetailView: View {
    @ObservedObject var model: PDFToolkitModel
    let page: Int
    @State private var dragStart: CGPoint?
    @State private var dragCurrent: CGPoint?
    @State private var inkPoints: [CGPoint] = []
    @EnvironmentObject var state: AppState

    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Button { model.focusedPage = nil } label: { Label("All Pages", systemImage: "square.grid.2x2") }
                Spacer()
                Button { if page > 0 { model.focusedPage = page - 1 } } label: { Image(systemName: "chevron.left") }.disabled(page == 0)
                Text("Page \(page + 1) of \(model.pageCount)").font(.system(size: 12))
                Button { if page < model.pageCount - 1 { model.focusedPage = page + 1 } } label: { Image(systemName: "chevron.right") }.disabled(page >= model.pageCount - 1)
            }
            .padding(.horizontal, 14)
            .padding(.top, 10)
            GeometryReader { geo in
                let pageSize = model.visualSize(of: page)
                let scale = min((geo.size.width - 30) / pageSize.width, (geo.size.height - 30) / pageSize.height)
                let fit = CGRect(x: (geo.size.width - pageSize.width * scale) / 2, y: (geo.size.height - pageSize.height * scale) / 2,
                                 width: pageSize.width * scale, height: pageSize.height * scale)
                ZStack(alignment: .topLeading) {
                    if let img = model.detailImage(for: page) {
                        Image(nsImage: NSImage(cg: img)).resizable()
                            .frame(width: fit.width, height: fit.height)
                            .position(x: fit.midX, y: fit.midY)
                            .shadow(color: .black.opacity(0.15), radius: 6, y: 2)
                    }
                    Canvas { ctx, _ in
                        for area in model.redactions where area.pageIndex == page {
                            ctx.fill(Path(viewRect(area.rect, fit: fit, scale: scale, pageHeight: pageSize.height)), with: .color(.black.opacity(0.75)))
                        }
                        if let sig = model.signatureRect, sig.page == page {
                            ctx.stroke(Path(viewRect(sig.rect, fit: fit, scale: scale, pageHeight: pageSize.height)), with: .color(state.accentColor), lineWidth: 2)
                        }
                        if inkPoints.count > 1 {
                            var path = Path()
                            path.addLines(inkPoints)
                            ctx.stroke(path, with: .color(model.markupColour.swiftUIColor), style: StrokeStyle(lineWidth: 2.5 * scale, lineCap: .round, lineJoin: .round))
                        }
                        if let a = dragStart, let b = dragCurrent {
                            let r = CGRect(x: min(a.x, b.x), y: min(a.y, b.y), width: abs(a.x - b.x), height: abs(a.y - b.y))
                            ctx.stroke(Path(r), with: .color(state.accentColor), style: StrokeStyle(lineWidth: 1.5, dash: [5, 3]))
                        }
                    }
                    .allowsHitTesting(false)
                }
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0)
                    .onChanged { v in
                        if model.mode == .markup && model.markupTool == .draw {
                            if fit.contains(v.location) { inkPoints.append(v.location) }
                            return
                        }
                        guard hypot(v.translation.width, v.translation.height) >= 3 else { return }
                        dragStart = v.startLocation
                        dragCurrent = v.location
                    }
                    .onEnded { v in
                        defer { dragStart = nil; dragCurrent = nil; inkPoints = [] }
                        let toPage = { (p: CGPoint) -> CGPoint in
                            CGPoint(x: (p.x - fit.minX) / scale, y: pageSize.height - (p.y - fit.minY) / scale)
                        }
                        if model.mode == .markup && model.markupTool == .draw {
                            let stroke = inkPoints.map(toPage)
                            if stroke.count > 1 { model.addMarkup(page: page, rect: nil, point: nil, strokes: [stroke]) }
                            return
                        }
                        if model.mode == .markup && model.markupTool == .note {
                            guard fit.contains(v.location) else { return }
                            model.addMarkup(page: page, rect: nil, point: toPage(v.location), strokes: [])
                            return
                        }
                        let a = v.startLocation, b = v.location
                        let r = CGRect(x: min(a.x, b.x), y: min(a.y, b.y), width: abs(a.x - b.x), height: abs(a.y - b.y)).intersection(fit)
                        guard r.width > 4, r.height > 4 else { return }
                        // View (top-left) → page visual space (bottom-left, points)
                        let pr = CGRect(x: (r.minX - fit.minX) / scale, y: pageSize.height - (r.maxY - fit.minY) / scale,
                                        width: r.width / scale, height: r.height / scale)
                        switch model.mode {
                        case .sign:
                            model.signatureRect = (page, pr)
                        case .markup:
                            model.addMarkup(page: page, rect: pr, point: nil, strokes: [])
                        case .redact, .organize:
                            model.mode = .redact
                            model.redactions.append(RedactionArea(pageIndex: page, rect: pr))
                        }
                    })
            }
        }
    }

    private func viewRect(_ r: CGRect, fit: CGRect, scale: CGFloat, pageHeight: CGFloat) -> CGRect {
        CGRect(x: fit.minX + r.minX * scale, y: fit.minY + (pageHeight - r.maxY) * scale, width: r.width * scale, height: r.height * scale)
    }
}
