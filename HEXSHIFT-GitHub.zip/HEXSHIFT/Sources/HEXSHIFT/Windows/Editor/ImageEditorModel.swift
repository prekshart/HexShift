import AppKit
import HexshiftKit
import SwiftUI

enum EditorTool: String, CaseIterable, Identifiable {
    case crop, resize, adjust, background, annotate, measure, eyedropper, export

    var id: String { rawValue }

    init(actionID: String) {
        switch actionID {
        case "edit.crop": self = .crop
        case "edit.resize": self = .resize
        case "edit.removebg": self = .background
        case "edit.annotate": self = .annotate
        case "edit.compress", "edit.metadata": self = .export
        case "edit.measure": self = .measure
        default: self = .adjust
        }
    }

    var title: String {
        switch self {
        case .crop: return "Crop"
        case .resize: return "Resize"
        case .adjust: return "Enhance"
        case .background: return "Background"
        case .annotate: return "Annotate"
        case .measure: return "Measure"
        case .eyedropper: return "Pick Colour"
        case .export: return "Export"
        }
    }

    var symbol: String {
        switch self {
        case .crop: return "crop"
        case .resize: return "arrow.up.left.and.arrow.down.right"
        case .adjust: return "wand.and.stars"
        case .background: return "person.crop.rectangle"
        case .annotate: return "pencil.tip.crop.circle"
        case .measure: return "ruler"
        case .eyedropper: return "eyedropper"
        case .export: return "square.and.arrow.up"
        }
    }
}

struct AspectPreset: Hashable, Identifiable {
    let id: String
    let label: String
    let ratio: CGSize?
    /// Exact output size (Instagram etc.) — the crop is resized to this after applying.
    let size: CGSize?

    // Identity is the id (CGSize isn't Hashable before the macOS 15 SDK).
    static func == (a: AspectPreset, b: AspectPreset) -> Bool { a.id == b.id }
    func hash(into hasher: inout Hasher) { hasher.combine(id) }

    static let free = AspectPreset(id: "free", label: "Free", ratio: nil, size: nil)
    static func custom(_ w: Double, _ h: Double) -> AspectPreset {
        let label = "\(QuickImageEdits.scaleLabel(w)):\(QuickImageEdits.scaleLabel(h))"
        return AspectPreset(id: "custom-\(label)", label: "Custom \(label)", ratio: CGSize(width: w, height: h), size: nil)
    }
    static func r(_ w: CGFloat, _ h: CGFloat) -> AspectPreset { AspectPreset(id: "\(w):\(h)", label: "\(Int(w)):\(Int(h))", ratio: CGSize(width: w, height: h), size: nil) }
    static func s(_ label: String, _ w: CGFloat, _ h: CGFloat) -> AspectPreset {
        AspectPreset(id: label, label: "\(label) · \(Int(w))×\(Int(h))", ratio: CGSize(width: w, height: h), size: CGSize(width: w, height: h))
    }

    static let all: [AspectPreset] = [
        .free, .r(1, 1), .r(4, 5), .r(9, 16), .r(16, 9), .r(3, 2), .r(4, 3),
        .s("Instagram Post", 1080, 1350), .s("Instagram Story", 1080, 1920), .s("Square Post", 1080, 1080),
        .s("LinkedIn Post", 1200, 627), .s("LinkedIn Banner", 1584, 396), .s("Web Banner", 1600, 500), .s("YouTube Thumbnail", 1280, 720),
    ]
}

struct Annotation: Identifiable, Equatable {
    enum Kind: String, CaseIterable, Identifiable {
        case arrow, rectangle, ellipse, pen, highlighter, text, callout, blur, pixelate
        var id: String { rawValue }
        var title: String {
            switch self {
            case .arrow: return "Arrow"
            case .rectangle: return "Rectangle"
            case .ellipse: return "Circle"
            case .pen: return "Pen"
            case .highlighter: return "Highlighter"
            case .text: return "Text"
            case .callout: return "Numbered callout"
            case .blur: return "Blur"
            case .pixelate: return "Pixelate"
            }
        }
        var symbol: String {
            switch self {
            case .arrow: return "arrow.up.right"
            case .rectangle: return "rectangle"
            case .ellipse: return "circle"
            case .pen: return "scribble"
            case .highlighter: return "highlighter"
            case .text: return "textformat"
            case .callout: return "1.circle"
            case .blur: return "drop"
            case .pixelate: return "square.grid.3x3"
            }
        }
    }

    let id = UUID()
    var kind: Kind
    /// Image pixel coordinates, top-left origin.
    var points: [CGPoint]
    var text = ""
    var colour: RGBAColour
    var width: CGFloat
    var number = 0

    var rect: CGRect {
        guard let a = points.first, let b = points.last else { return .zero }
        return CGRect(x: min(a.x, b.x), y: min(a.y, b.y), width: abs(a.x - b.x), height: abs(a.y - b.y))
    }
}

@MainActor
final class ImageEditorModel: ObservableObject {
    let asset: AssetInfo
    let properties: [CFString: Any]
    let original: CGImage

    @Published private(set) var base: CGImage
    @Published private(set) var preview: CGImage
    @Published var tool: EditorTool { didSet { toolChanged(from: oldValue) } }
    @Published var showOriginal = false
    @Published private(set) var canUndo = false
    @Published private(set) var canRedo = false
    @Published var isBusy = false
    @Published var status: String?

    // Crop
    @Published var cropRect: CGRect = .zero
    @Published var aspect: AspectPreset = .free { didSet { constrainCropToAspect() } }
    private var cropDragMode: CropDrag?
    private var cropAtDragStart: CGRect = .zero

    // Resize
    @Published var targetWidth = 0
    @Published var targetHeight = 0
    @Published var lockAspect = true
    @Published var resampling: Resampling = .lanczos
    @Published var dpi: Double

    // Adjust
    @Published var adjustments = Adjustments() { didSet { scheduleRender() } }

    // Background
    @Published private(set) var mask: CGImage?
    @Published var bgChoice = 0 { didSet { scheduleRender() } }
    @Published var bgColour: Color = .white { didSet { scheduleRender() } }
    @Published var bgColour2: Color = Color(red: 1, green: 0.42, blue: 0.3) { didSet { scheduleRender() } }
    @Published var bgImagePath: String? { didSet { scheduleRender() } }
    @Published var blurRadius = 24.0 { didSet { scheduleRender() } }
    @Published var feather = 1.0 { didSet { scheduleRender() } }
    @Published var edgeShift = 0.0 { didSet { scheduleRender() } }

    // Annotate
    @Published var annotations: [Annotation] = []
    @Published var annotationKind: Annotation.Kind = .arrow
    @Published var annotationColour: Color = Color(red: 1, green: 0.27, blue: 0.2)
    @Published var annotationWidth: CGFloat = 6
    @Published var pendingText: CGPoint?
    @Published var draft: Annotation?
    private(set) var effectCache: (blur: CGImage, pixel: CGImage)?

    // Measure & eyedropper
    @Published var measureFrom: CGPoint?
    @Published var measureTo: CGPoint?
    @Published var pickedColour: RGBAColour?

    // Export
    @Published var exportFormat: Format { didSet { scheduleEstimate() } }
    @Published var exportQuality: Double { didSet { scheduleEstimate() } }
    @Published var targetKB = 0 { didSet { scheduleEstimate() } }
    @Published var metadata: MetadataPolicy
    @Published private(set) var estimatedBytes: Int?

    private var undoStack: [CGImage] = []
    private var redoStack: [CGImage] = []
    private var previewSource: CGImage
    private var renderTask: Task<Void, Never>?
    private var estimateTask: Task<Void, Never>?

    init(asset: AssetInfo, tool: EditorTool) throws {
        self.asset = asset
        let loaded = try ImageLoader.load(asset.url)
        properties = loaded.properties
        original = loaded.image
        base = loaded.image
        preview = loaded.image
        previewSource = ImageOps.limit(loaded.image, maxPixelSize: 1800)
        self.tool = tool
        dpi = asset.dpi ?? 72
        let state = AppState.shared
        let fmt: Format = (asset.format.map { ImageEncoder.canWrite($0) && $0.category == .raster ? $0 : .png }) ?? .png
        exportFormat = fmt
        exportQuality = state.prefs.quality(for: fmt)
        metadata = state.prefs.metadataPolicy
        resetToolState()
        scheduleEstimate()
    }

    var displayImage: CGImage {
        if showOriginal { return original }
        switch tool {
        case .adjust, .background: return preview
        default: return base
        }
    }

    var imageSize: CGSize { CGSize(width: base.width, height: base.height) }

    // MARK: Undo

    private func pushUndo() {
        undoStack.append(base)
        if undoStack.count > 12 { undoStack.removeFirst() }
        redoStack.removeAll()
        updateUndoFlags()
    }

    private func updateUndoFlags() {
        canUndo = !undoStack.isEmpty
        canRedo = !redoStack.isEmpty
    }

    func undo() {
        if tool == .annotate, !annotations.isEmpty {
            annotations.removeLast()
            return
        }
        guard let previous = undoStack.popLast() else { return }
        redoStack.append(base)
        setBase(previous)
        updateUndoFlags()
    }

    func redo() {
        guard let next = redoStack.popLast() else { return }
        undoStack.append(base)
        setBase(next)
        updateUndoFlags()
    }

    private func setBase(_ image: CGImage) {
        base = image
        previewSource = ImageOps.limit(image, maxPixelSize: 1800)
        effectCache = nil
        resetToolState()
        scheduleRender()
        scheduleEstimate()
    }

    private func commit(_ work: @escaping @Sendable (CGImage) throws -> CGImage, message: String) {
        let current = base
        isBusy = true
        Task {
            do {
                let result = try await Task.detached { try work(current) }.value
                pushUndo()
                setBase(result)
                status = message
            } catch {
                JobCenter.shared.error(error)
            }
            isBusy = false
        }
    }

    // MARK: Tool state

    private func toolChanged(from old: EditorTool) {
        if old == .background && tool != .background && mask != nil {
            // Leaving with an unapplied background keeps it pending; preview resets.
        }
        status = nil
        scheduleRender()
        if tool == .export { scheduleEstimate() }
    }

    func resetToolState() {
        cropRect = CGRect(origin: .zero, size: imageSize)
        constrainCropToAspect()
        targetWidth = base.width
        targetHeight = base.height
        measureFrom = nil
        measureTo = nil
    }

    var hasPendingChanges: Bool {
        switch tool {
        case .crop: return cropRect.integral != CGRect(origin: .zero, size: imageSize)
        case .resize: return targetWidth != base.width || targetHeight != base.height
        case .adjust: return !adjustments.isIdentity
        case .background: return mask != nil
        case .annotate: return !annotations.isEmpty
        default: return false
        }
    }

    func applyCurrentTool() {
        switch tool {
        case .crop: applyCrop()
        case .resize: applyResize()
        case .adjust: applyAdjustments()
        case .background: applyBackground()
        case .annotate: applyAnnotations()
        default: break
        }
    }

    // MARK: Crop

    enum CropDrag { case move, new, resize(anchorX: CGFloat?, anchorY: CGFloat?) }

    private func constrainCropToAspect() {
        guard let ratio = aspect.ratio else { return }
        let target = ratio.width / ratio.height
        let full = CGRect(origin: .zero, size: imageSize)
        var r = full
        if full.width / full.height > target {
            r.size.width = full.height * target
            r.origin.x = (full.width - r.width) / 2
        } else {
            r.size.height = full.width / target
            r.origin.y = (full.height - r.height) / 2
        }
        cropRect = r
    }

    func cropDrag(start: CGPoint, current: CGPoint, handleTolerance: CGFloat) {
        let bounds = CGRect(origin: .zero, size: imageSize)
        if cropDragMode == nil {
            cropAtDragStart = cropRect
            let r = cropRect
            let nearL = abs(start.x - r.minX) < handleTolerance, nearR = abs(start.x - r.maxX) < handleTolerance
            let nearT = abs(start.y - r.minY) < handleTolerance, nearB = abs(start.y - r.maxY) < handleTolerance
            let inY = start.y > r.minY - handleTolerance && start.y < r.maxY + handleTolerance
            let inX = start.x > r.minX - handleTolerance && start.x < r.maxX + handleTolerance
            if (nearL || nearR) && inY || (nearT || nearB) && inX {
                let ax: CGFloat? = nearL ? r.maxX : nearR ? r.minX : nil
                let ay: CGFloat? = nearT ? r.maxY : nearB ? r.minY : nil
                cropDragMode = .resize(anchorX: ax, anchorY: ay)
            } else if r.contains(start) {
                cropDragMode = .move
            } else {
                cropDragMode = .new
            }
        }
        let p = CGPoint(x: min(max(current.x, 0), bounds.maxX), y: min(max(current.y, 0), bounds.maxY))
        var r = cropAtDragStart
        switch cropDragMode! {
        case .move:
            r.origin.x = min(max(0, r.origin.x + current.x - start.x), bounds.width - r.width)
            r.origin.y = min(max(0, r.origin.y + current.y - start.y), bounds.height - r.height)
        case .new:
            let s = CGPoint(x: min(max(start.x, 0), bounds.maxX), y: min(max(start.y, 0), bounds.maxY))
            r = rectFrom(anchor: s, to: p)
        case let .resize(ax, ay):
            let anchor = CGPoint(x: ax ?? cropAtDragStart.minX, y: ay ?? cropAtDragStart.minY)
            var moving = p
            if ax == nil { moving.x = cropAtDragStart.maxX }
            if ay == nil { moving.y = cropAtDragStart.maxY }
            if ax == nil {
                r = rectFrom(anchor: CGPoint(x: cropAtDragStart.minX, y: anchor.y), to: CGPoint(x: cropAtDragStart.maxX, y: moving.y), lockWidth: true)
            } else if ay == nil {
                r = rectFrom(anchor: CGPoint(x: anchor.x, y: cropAtDragStart.minY), to: CGPoint(x: moving.x, y: cropAtDragStart.maxY), lockHeight: true)
            } else {
                r = rectFrom(anchor: anchor, to: moving)
            }
        }
        cropRect = r.intersection(bounds)
    }

    private func rectFrom(anchor a: CGPoint, to b: CGPoint, lockWidth: Bool = false, lockHeight: Bool = false) -> CGRect {
        var w = b.x - a.x, h = b.y - a.y
        if let ratio = aspect.ratio {
            let t = ratio.width / ratio.height
            if lockWidth { w = (abs(h) * t) * (w < 0 ? -1 : 1) }
            else if lockHeight { h = (abs(w) / t) * (h < 0 ? -1 : 1) }
            else if abs(w) / max(1, abs(h)) > t { w = abs(h) * t * (w < 0 ? -1 : 1) } else { h = abs(w) / t * (h < 0 ? -1 : 1) }
        }
        return CGRect(x: min(a.x, a.x + w), y: min(a.y, a.y + h), width: max(1, abs(w)), height: max(1, abs(h)))
    }

    func endCropDrag() { cropDragMode = nil }

    func applyCrop() {
        let rect = cropRect.integral
        let size = aspect.size
        commit({ img in
            let c = ImageOps.crop(img, to: rect)
            return size.map { ImageOps.resize(c, to: $0) } ?? c
        }, message: size != nil ? "Cropped and resized to \(Int(size!.width)) × \(Int(size!.height))" : "Cropped")
    }

    func rotate(clockwise: Bool) { commit({ ImageOps.rotate90($0, clockwise: clockwise) }, message: "Rotated") }
    func flip(horizontal: Bool) { commit({ ImageOps.flip($0, horizontal: horizontal) }, message: "Flipped") }

    // MARK: Resize

    func setWidth(_ w: Int) {
        targetWidth = max(1, w)
        if lockAspect { targetHeight = max(1, Int((Double(w) * Double(base.height) / Double(base.width)).rounded())) }
    }

    func setHeight(_ h: Int) {
        targetHeight = max(1, h)
        if lockAspect { targetWidth = max(1, Int((Double(h) * Double(base.width) / Double(base.height)).rounded())) }
    }

    func setPercent(_ p: Double) {
        setWidth(Int((Double(base.width) * p / 100).rounded()))
        if !lockAspect { targetHeight = Int((Double(base.height) * p / 100).rounded()) }
    }

    var isUpscaling: Bool { targetWidth > base.width || targetHeight > base.height }

    func applyResize() {
        let size = CGSize(width: targetWidth, height: targetHeight)
        let method = resampling
        commit({ ImageOps.resize($0, to: size, method: method) }, message: "Resized to \(targetWidth) × \(targetHeight)")
    }

    // MARK: Adjust

    func autoEnhance() {
        commit({ ImageEffects.autoEnhance($0) }, message: "Auto enhanced")
    }

    func applyAdjustments() {
        let adj = adjustments
        commit({ ImageEffects.apply(adj, to: $0) }, message: "Adjustments applied")
        adjustments = Adjustments()
    }

    // MARK: Background

    func detectSubject() {
        let img = base
        isBusy = true
        status = "Finding the subject…"
        Task {
            do {
                let m = try await Task.detached { try BackgroundRemoval.subjectMask(for: img) }.value
                mask = m
                status = "Subject found. Choose a background, then Apply."
                if !exportFormat.supportsAlpha { exportFormat = .png }
                scheduleRender()
            } catch {
                status = (error as? LocalizedError)?.errorDescription ?? "Background removal failed."
            }
            isBusy = false
        }
    }

    var backgroundMode: BackgroundMode {
        switch bgChoice {
        case 1: return .solid(RGBAColour(color: bgColour))
        case 2: return .gradient(RGBAColour(color: bgColour), RGBAColour(color: bgColour2), angle: 180)
        case 3: return .blur(radius: blurRadius)
        case 4: return bgImagePath.map { .image(path: $0) } ?? .transparent
        default: return .transparent
        }
    }

    func applyBackground() {
        guard let m = mask else { return }
        let mode = backgroundMode, f = feather, e = edgeShift
        commit({ img in
            guard let out = BackgroundRemoval.composite(img, mask: m, mode: mode, feather: f, edgeShift: e) else {
                throw HexError.message("The background could not be replaced.")
            }
            return out
        }, message: "Background replaced")
        mask = nil
    }

    // MARK: Annotate

    var annotationRGBA: RGBAColour { RGBAColour(color: annotationColour) }

    func annotationDrag(start: CGPoint, current: CGPoint) {
        switch annotationKind {
        case .text, .callout:
            return
        case .pen, .highlighter:
            if draft == nil { draft = Annotation(kind: annotationKind, points: [start], colour: annotationRGBA, width: annotationWidth) }
            draft?.points.append(current)
        default:
            if draft == nil { draft = Annotation(kind: annotationKind, points: [start, current], colour: annotationRGBA, width: annotationWidth) }
            draft?.points = [start, current]
        }
        if annotationKind == .blur || annotationKind == .pixelate { ensureEffects() }
    }

    func annotationEnd(at point: CGPoint, moved: Bool) {
        switch annotationKind {
        case .text:
            pendingText = point
        case .callout:
            let n = (annotations.filter { $0.kind == .callout }.map(\.number).max() ?? 0) + 1
            annotations.append(Annotation(kind: .callout, points: [point], colour: annotationRGBA, width: annotationWidth, number: n))
        default:
            if let d = draft, moved, d.rect.width + d.rect.height > 4 || d.kind == .pen || d.kind == .highlighter { annotations.append(d) }
        }
        draft = nil
    }

    func addText(_ text: String) {
        guard let p = pendingText, !text.isEmpty else { pendingText = nil; return }
        annotations.append(Annotation(kind: .text, points: [p], text: text, colour: annotationRGBA, width: annotationWidth))
        pendingText = nil
    }

    func ensureEffects() {
        guard effectCache == nil else { return }
        let side = Double(min(base.width, base.height))
        effectCache = (ImageEffects.gaussianBlur(base, radius: max(8, side / 50)), ImageEffects.pixellate(base, scale: max(8, side / 45)))
    }

    func applyAnnotations() {
        let list = annotations
        if list.contains(where: { $0.kind == .blur || $0.kind == .pixelate }) { ensureEffects() }
        let effects = effectCache
        commit({ AnnotationRenderer.render(list, onto: $0, effects: effects) }, message: "Annotations applied")
        annotations = []
    }

    // MARK: Measure / eyedropper

    var measureSummary: String? {
        guard let a = measureFrom, let b = measureTo else { return nil }
        let dx = abs(b.x - a.x), dy = abs(b.y - a.y)
        let len = (dx * dx + dy * dy).squareRoot()
        let scale = max(1, (asset.dpi ?? 72) / 72)
        var s = "\(Int(len.rounded())) px  (Δx \(Int(dx.rounded())), Δy \(Int(dy.rounded())))"
        if scale > 1 { s += " · ≈ \(Int((len / scale).rounded())) pt at @\(Int(scale))x" }
        return s + " — estimated from pixels"
    }

    func pickColour(at p: CGPoint) {
        let x = Int(p.x), y = Int(p.y)
        guard x >= 0, y >= 0, x < base.width, y < base.height,
              let pixel = base.cropping(to: CGRect(x: x, y: y, width: 1, height: 1)),
              let buf = PixelBuffer(image: pixel) else { return }
        let c = buf.rgba(x: 0, y: 0)
        let colour = RGBAColour(r: c.r / 255, g: c.g / 255, b: c.b / 255, a: c.a / 255)
        pickedColour = colour
        AppState.shared.addColourToHistory(colour)
        Clipboard.copy(ColourFormatting.string(colour, format: AppState.shared.prefs.colourCopyFormat))
        status = "\(colour.hex) copied"
    }

    // MARK: Preview rendering

    func scheduleRender() {
        renderTask?.cancel()
        let source = previewSource
        let tool = self.tool
        let adj = adjustments
        let m = mask
        let mode = backgroundMode
        let scale = Double(source.width) / Double(max(1, base.width))
        let f = feather * scale, e = edgeShift * scale
        renderTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 25_000_000)
            guard !Task.isCancelled else { return }
            let image: CGImage = await Task.detached {
                switch tool {
                case .adjust: return ImageEffects.apply(adj, to: source)
                case .background:
                    if let m, let out = BackgroundRemoval.composite(source, mask: m, mode: mode, feather: f, edgeShift: e) { return out }
                    return source
                default: return source
                }
            }.value
            guard !Task.isCancelled else { return }
            self?.preview = image
        }
    }

    func scheduleEstimate() {
        estimateTask?.cancel()
        let img = base, fmt = exportFormat, q = exportQuality, kb = targetKB
        estimateTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 150_000_000)
            guard !Task.isCancelled else { return }
            let bytes: Int? = await Task.detached {
                if kb > 0 { return kb * 1024 }
                guard fmt.category == .raster, ImageEncoder.canWrite(fmt), fmt != .ico, fmt != .icns else { return nil }
                return ImageCompressor.estimate(img, format: fmt, quality: q)
            }.value
            guard !Task.isCancelled else { return }
            self?.estimatedBytes = bytes
        }
    }

    // MARK: Export

    /// Applies any pending edit for the current tool, then saves a new file.
    func export(toClipboard: Bool = false) {
        if hasPendingChanges && tool != .export {
            applyCurrentTool()
        }
        let fmt = exportFormat, q = exportQuality, kb = targetKB, meta = metadata, d = dpi
        let props = properties
        let a = asset
        Task {
            // Wait for an in-flight apply to finish.
            while isBusy { try? await Task.sleep(nanoseconds: 50_000_000) }
            let image = base
            if toClipboard {
                Clipboard.copy(image: image)
                JobCenter.shared.message("Image copied to the clipboard")
                return
            }
            ActionRunner.shared.withPlanner { planner, delivery in
                JobCenter.shared.runTask(title: "Saving image", delivery: delivery, successTitle: "Image saved") {
                    var o = ImageExportOptions()
                    o.quality = q
                    o.metadata = meta
                    o.dpi = d
                    var img = image
                    if kb > 0 {
                        if !fmt.supportsAlpha { img = ImageOps.flatten(img) }
                        o.quality = try ImageCompressor.findQuality(img, format: fmt, targetBytes: kb * 1024).quality
                    }
                    let dest = planner.url(for: a.url, baseName: a.baseName + "-edited", ext: fmt.fileExtension, format: fmt.displayName,
                                           pixelSize: (img.width, img.height))
                    try ImageEncoder.write(img, sourceProperties: props, format: fmt, to: dest, options: o)
                    return [dest]
                }
            }
        }
    }
}

/// Draws annotations into the image's pixels.
enum AnnotationRenderer {
    static func render(_ annotations: [Annotation], onto image: CGImage, effects: (blur: CGImage, pixel: CGImage)?) -> CGImage {
        let w = image.width, h = image.height
        guard let ctx = ImageOps.makeContext(width: w, height: h) else { return image }
        let full = CGRect(x: 0, y: 0, width: w, height: h)
        ctx.draw(image, in: full)
        // Region effects first (drawn in bottom-left coordinates).
        for a in annotations where a.kind == .blur || a.kind == .pixelate {
            guard let fx = a.kind == .blur ? effects?.blur : effects?.pixel else { continue }
            let r = a.rect
            ctx.saveGState()
            ctx.clip(to: CGRect(x: r.minX, y: CGFloat(h) - r.maxY, width: r.width, height: r.height))
            ctx.draw(fx, in: full)
            ctx.restoreGState()
        }
        // Vector marks in a flipped (top-left) space.
        ctx.saveGState()
        ctx.translateBy(x: 0, y: CGFloat(h))
        ctx.scaleBy(x: 1, y: -1)
        let ns = NSGraphicsContext(cgContext: ctx, flipped: true)
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = ns
        for a in annotations where a.kind != .blur && a.kind != .pixelate {
            draw(a)
        }
        NSGraphicsContext.restoreGraphicsState()
        ctx.restoreGState()
        return ctx.makeImage() ?? image
    }

    static func draw(_ a: Annotation) {
        let colour = a.colour.nsColor
        switch a.kind {
        case .pen, .highlighter:
            guard let first = a.points.first else { return }
            let path = NSBezierPath()
            path.move(to: first)
            for p in a.points.dropFirst() { path.line(to: p) }
            path.lineCapStyle = .round
            path.lineJoinStyle = .round
            if a.kind == .highlighter {
                path.lineWidth = a.width * 3.2
                NSGraphicsContext.current?.compositingOperation = .multiply
                colour.withAlphaComponent(0.38).setStroke()
            } else {
                path.lineWidth = a.width
                colour.setStroke()
            }
            path.stroke()
            NSGraphicsContext.current?.compositingOperation = .sourceOver
        case .arrow:
            guard let s = a.points.first, let e = a.points.last else { return }
            let angle = atan2(e.y - s.y, e.x - s.x)
            let head = max(14, a.width * 3.6)
            let base = CGPoint(x: e.x - head * 0.8 * cos(angle), y: e.y - head * 0.8 * sin(angle))
            let line = NSBezierPath()
            line.move(to: s)
            line.line(to: base)
            line.lineWidth = a.width
            line.lineCapStyle = .round
            colour.setStroke()
            line.stroke()
            let tip = NSBezierPath()
            tip.move(to: e)
            tip.line(to: CGPoint(x: e.x - head * cos(angle - 0.45), y: e.y - head * sin(angle - 0.45)))
            tip.line(to: CGPoint(x: e.x - head * cos(angle + 0.45), y: e.y - head * sin(angle + 0.45)))
            tip.close()
            colour.setFill()
            tip.fill()
        case .rectangle:
            let path = NSBezierPath(roundedRect: a.rect, xRadius: a.width, yRadius: a.width)
            path.lineWidth = a.width
            colour.setStroke()
            path.stroke()
        case .ellipse:
            let path = NSBezierPath(ovalIn: a.rect)
            path.lineWidth = a.width
            colour.setStroke()
            path.stroke()
        case .text:
            guard let p = a.points.first else { return }
            let font = NSFont.systemFont(ofSize: max(14, a.width * 5), weight: .bold)
            let shadow = NSShadow()
            shadow.shadowColor = NSColor.black.withAlphaComponent(0.25)
            shadow.shadowBlurRadius = 3
            shadow.shadowOffset = NSSize(width: 0, height: -1)
            NSAttributedString(string: a.text, attributes: [.font: font, .foregroundColor: colour, .shadow: shadow])
                .draw(at: CGPoint(x: p.x, y: p.y - font.pointSize * 0.6))
        case .callout:
            guard let p = a.points.first else { return }
            let r = max(14, a.width * 2.6 + 8)
            let circle = NSBezierPath(ovalIn: CGRect(x: p.x - r, y: p.y - r, width: r * 2, height: r * 2))
            colour.setFill()
            circle.fill()
            NSColor.white.setStroke()
            circle.lineWidth = max(2, r * 0.12)
            circle.stroke()
            let font = NSFont.systemFont(ofSize: r * 1.05, weight: .bold)
            let s = NSAttributedString(string: "\(a.number)", attributes: [.font: font, .foregroundColor: NSColor.white])
            let size = s.size()
            s.draw(at: CGPoint(x: p.x - size.width / 2, y: p.y - size.height / 2))
        case .blur, .pixelate:
            break
        }
    }
}
