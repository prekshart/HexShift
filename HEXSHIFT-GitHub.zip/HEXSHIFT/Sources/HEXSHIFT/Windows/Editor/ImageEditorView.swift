import AppKit
import HexshiftKit
import SwiftUI
import UniformTypeIdentifiers

extension Windows {
    static func openEditor(asset: AssetInfo, tool: EditorTool) {
        do {
            let model = try ImageEditorModel(asset: asset, tool: tool)
            WindowManager.shared.show(id: "editor:\(asset.url.path)", title: asset.name, size: CGSize(width: 1080, height: 720),
                                      minSize: CGSize(width: 820, height: 520)) {
                ImageEditorView(model: model)
            }
        } catch {
            JobCenter.shared.error(error, title: "Couldn't open the image")
        }
    }
}

@MainActor
struct ImageEditorView: View {
    @ObservedObject var model: ImageEditorModel
    @EnvironmentObject var state: AppState
    @State private var customRatioW = 4.0
    @State private var customRatioH = 5.0
    @State private var customPercent = 100.0
    @State private var customKB = 300

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            Divider()
            HStack(spacing: 0) {
                EditorCanvas(model: model)
                    .background(Color(nsColor: .windowBackgroundColor).opacity(0.6))
                Divider()
                ScrollView {
                    inspector
                        .padding(16)
                        .frame(width: 290, alignment: .topLeading)
                }
                .frame(width: 290)
            }
            Divider()
            footer
        }
    }

    // MARK: Toolbar

    private var toolbar: some View {
        HStack(spacing: 10) {
            Spacer().frame(width: 70)
            HStack(spacing: 2) {
                ForEach(EditorTool.allCases) { t in
                    Button {
                        model.tool = t
                    } label: {
                        Label(t.title, systemImage: t.symbol)
                            .labelStyle(.iconOnly)
                            .font(.system(size: 14))
                            .frame(width: 34, height: 28)
                            .foregroundStyle(model.tool == t ? Color.white : Color.primary)
                            .background(RoundedRectangle(cornerRadius: 7).fill(model.tool == t ? state.accentColor : Color.clear))
                    }
                    .buttonStyle(.plain)
                    .help(t.title)
                    .accessibilityLabel(t.title)
                }
            }
            .padding(3)
            .background(RoundedRectangle(cornerRadius: 9).fill(Color.primary.opacity(0.05)))
            Spacer()
            Button { model.undo() } label: { Image(systemName: "arrow.uturn.backward") }
                .keyboardShortcut("z", modifiers: .command)
                .disabled(!model.canUndo && model.annotations.isEmpty)
                .help("Undo")
            Button { model.redo() } label: { Image(systemName: "arrow.uturn.forward") }
                .keyboardShortcut("z", modifiers: [.command, .shift])
                .disabled(!model.canRedo)
                .help("Redo")
            Toggle(isOn: $model.showOriginal) { Text("Before") }
                .toggleStyle(.button)
                .help("Compare with the original")
            Button("Copy") { model.export(toClipboard: true) }
            Button("Save Copy") { model.export() }
                .buttonStyle(AccentButtonStyle())
                .keyboardShortcut("s", modifiers: .command)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
    }

    private var footer: some View {
        HStack(spacing: 14) {
            Text("\(model.base.width) × \(model.base.height) px").monospacedDigit()
            if let s = model.status { Text(s).foregroundStyle(.secondary) }
            if model.isBusy { ProgressView().controlSize(.small) }
            Spacer()
            Text("Original: \(ByteCountFormatter.string(fromByteCount: model.asset.fileSize, countStyle: .file))")
            if let e = model.estimatedBytes {
                Text("→ \(model.exportFormat.displayName) ≈ \(ByteCountFormatter.string(fromByteCount: Int64(e), countStyle: .file))")
                    .foregroundStyle(state.accentColor)
            }
        }
        .font(.system(size: 11.5))
        .padding(.horizontal, 14)
        .padding(.vertical, 7)
    }

    // MARK: Inspector

    @ViewBuilder
    private var inspector: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(model.tool.title).font(.system(size: 16, weight: .semibold))
            switch model.tool {
            case .crop: cropPanel
            case .resize: resizePanel
            case .adjust: adjustPanel
            case .background: backgroundPanel
            case .annotate: annotatePanel
            case .measure: measurePanel
            case .eyedropper: eyedropperPanel
            case .export: exportPanel
            }
        }
    }

    private func applyButton(_ title: String = "Apply") -> some View {
        Button(title) { model.applyCurrentTool() }
            .buttonStyle(AccentButtonStyle())
            .disabled(!model.hasPendingChanges || model.isBusy)
            .keyboardShortcut(.return, modifiers: .command)
    }

    private var cropPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionCard(title: "Aspect & size presets") {
                Picker("Preset", selection: $model.aspect) {
                    ForEach(AspectPreset.all) { Text($0.label).tag($0) }
                    if !AspectPreset.all.contains(model.aspect) { Text(model.aspect.label).tag(model.aspect) }
                }
                .labelsHidden()
                Text("\(Int(model.cropRect.width)) × \(Int(model.cropRect.height)) px selected").font(.system(size: 11)).foregroundStyle(.secondary)
                if let s = model.aspect.size {
                    Text("After cropping, the image is resized to exactly \(Int(s.width)) × \(Int(s.height)) px.")
                        .font(.system(size: 11)).foregroundStyle(.secondary)
                }
                HStack(spacing: 6) {
                    Text("Custom ratio").font(.system(size: 11.5))
                    TextField("W", value: $customRatioW, format: .number).textFieldStyle(.roundedBorder).frame(width: 52)
                    Text(":")
                    TextField("H", value: $customRatioH, format: .number).textFieldStyle(.roundedBorder).frame(width: 52)
                    Button("Use") {
                        guard customRatioW > 0, customRatioH > 0 else { return }
                        model.aspect = AspectPreset.custom(customRatioW, customRatioH)
                    }
                    .controlSize(.small)
                }
            }
            SectionCard(title: "Rotate & flip") {
                HStack {
                    Button { model.rotate(clockwise: false) } label: { Image(systemName: "rotate.left") }.help("Rotate left")
                    Button { model.rotate(clockwise: true) } label: { Image(systemName: "rotate.right") }.help("Rotate right")
                    Button { model.flip(horizontal: true) } label: { Image(systemName: "arrow.left.and.right.righttriangle.left.righttriangle.right") }.help("Flip horizontally")
                    Button { model.flip(horizontal: false) } label: { Image(systemName: "arrow.up.and.down.righttriangle.up.righttriangle.down") }.help("Flip vertically")
                }
            }
            Text("Drag on the image to draw a crop; drag inside to move it, or drag the edges and corners.")
                .font(.system(size: 11)).foregroundStyle(.secondary)
            HStack { Button("Reset") { model.resetToolState() }; Spacer(); applyButton("Crop") }
        }
    }

    private var resizePanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionCard(title: "Pixel dimensions") {
                HStack {
                    Text("Width").frame(width: 50, alignment: .leading)
                    TextField("Width", value: Binding(get: { model.targetWidth }, set: { model.setWidth($0) }), format: .number)
                        .textFieldStyle(.roundedBorder)
                    Text("px")
                }
                HStack {
                    Text("Height").frame(width: 50, alignment: .leading)
                    TextField("Height", value: Binding(get: { model.targetHeight }, set: { model.setHeight($0) }), format: .number)
                        .textFieldStyle(.roundedBorder)
                    Text("px")
                }
                Toggle("Keep aspect ratio", isOn: $model.lockAspect)
                HStack {
                    ForEach([25.0, 50, 75, 150, 200], id: \.self) { p in
                        Button("\(Int(p))%") { model.setPercent(p) }.controlSize(.small)
                    }
                }
                HStack(spacing: 6) {
                    Text("Scale").font(.system(size: 11.5))
                    TextField("%", value: $customPercent, format: .number).textFieldStyle(.roundedBorder).frame(width: 64)
                    Text("%")
                    Button("Apply") { if customPercent > 0 { model.setPercent(min(customPercent, 1600)) } }.controlSize(.small)
                }
            }
            SectionCard(title: "Quality & resolution") {
                Picker("Resampling", selection: $model.resampling) {
                    ForEach(Resampling.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                HStack {
                    Text("Resolution")
                    TextField("DPI", value: $model.dpi, format: .number).textFieldStyle(.roundedBorder).frame(width: 70)
                    Text("ppi")
                }
                Text(String(format: "Prints at %.2f × %.2f in (%.0f × %.0f mm)", Double(model.targetWidth) / model.dpi, Double(model.targetHeight) / model.dpi,
                            Double(model.targetWidth) / model.dpi * 25.4, Double(model.targetHeight) / model.dpi * 25.4))
                    .font(.system(size: 11)).foregroundStyle(.secondary)
                Text("Changing PPI only changes print size metadata; pixels stay the same.").font(.system(size: 10.5)).foregroundStyle(.secondary)
            }
            if model.isUpscaling {
                Label("Enlarging adds pixels but can't recover detail that isn't in the original.", systemImage: "exclamationmark.triangle")
                    .font(.system(size: 11)).foregroundStyle(.orange)
            }
            HStack { Spacer(); applyButton("Resize") }
        }
    }

    private func slider(_ title: String, _ value: Binding<Double>, _ range: ClosedRange<Double>, neutral: Double) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(title).font(.system(size: 11.5))
                Spacer()
                Text(String(format: "%+.2f", value.wrappedValue - neutral)).font(.system(size: 10.5, design: .monospaced)).foregroundStyle(.secondary)
            }
            Slider(value: value, in: range)
                .onTapGesture(count: 2) { value.wrappedValue = neutral }
        }
    }

    private var adjustPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            Button { model.autoEnhance() } label: { Label("Auto Enhance", systemImage: "wand.and.stars") }
            SectionCard(title: "Light") {
                slider("Exposure", $model.adjustments.exposure, -2...2, neutral: 0)
                slider("Brightness", $model.adjustments.brightness, -0.5...0.5, neutral: 0)
                slider("Contrast", $model.adjustments.contrast, 0.5...1.5, neutral: 1)
                slider("Highlights", $model.adjustments.highlights, -1...1, neutral: 0)
                slider("Shadows", $model.adjustments.shadows, -1...1, neutral: 0)
            }
            SectionCard(title: "Colour") {
                slider("Saturation", $model.adjustments.saturation, 0...2, neutral: 1)
                slider("Vibrance", $model.adjustments.vibrance, -1...1, neutral: 0)
                slider("Temperature", $model.adjustments.warmth, -1...1, neutral: 0)
                slider("Tint", $model.adjustments.tint, -1...1, neutral: 0)
                Toggle("Black & white", isOn: $model.adjustments.grayscale)
            }
            SectionCard(title: "Detail") {
                slider("Sharpness", $model.adjustments.sharpness, 0...2, neutral: 0)
            }
            Text("Double-click a slider to reset it. Changes preview live and are applied when you press Apply or save.")
                .font(.system(size: 10.5)).foregroundStyle(.secondary)
            HStack { Button("Reset All") { model.adjustments = Adjustments() }; Spacer(); applyButton() }
        }
    }

    private var backgroundPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            if model.mask == nil {
                Text("HEXSHIFT finds the main subject on this Mac using Apple's Vision framework.").font(.system(size: 11.5)).foregroundStyle(.secondary)
                Button { model.detectSubject() } label: { Label("Remove Background", systemImage: "person.crop.rectangle") }
                    .buttonStyle(AccentButtonStyle())
                    .disabled(model.isBusy)
            } else {
                SectionCard(title: "New background") {
                    Picker("Background", selection: $model.bgChoice) {
                        Text("Transparent").tag(0)
                        Text("Solid colour").tag(1)
                        Text("Gradient").tag(2)
                        Text("Blurred original").tag(3)
                        Text("Image…").tag(4)
                    }
                    .pickerStyle(.radioGroup)
                    if model.bgChoice == 1 || model.bgChoice == 2 { ColorPicker("Colour", selection: $model.bgColour, supportsOpacity: false) }
                    if model.bgChoice == 2 { ColorPicker("Second colour", selection: $model.bgColour2, supportsOpacity: false) }
                    if model.bgChoice == 3 { slider("Blur", $model.blurRadius, 4...80, neutral: 24) }
                    if model.bgChoice == 4 {
                        Button(model.bgImagePath == nil ? "Choose Image…" : (model.bgImagePath! as NSString).lastPathComponent) {
                            let panel = NSOpenPanel()
                            panel.allowedContentTypes = [.image]
                            panel.level = .modalPanel   // stay above other apps, so it can't hide behind them
                            if panel.runModal() == .OK { model.bgImagePath = panel.url?.path }
                        }
                    }
                }
                SectionCard(title: "Edges") {
                    slider("Softness", $model.feather, 0...8, neutral: 1)
                    slider("Shrink / grow", $model.edgeShift, -6...6, neutral: 0)
                    Text("Shrink a little to remove halos around hair and fur.").font(.system(size: 10.5)).foregroundStyle(.secondary)
                }
                HStack { Button("Discard") { model.detectSubject() }.hidden(); Spacer(); applyButton() }
                if model.bgChoice == 0 && !model.exportFormat.supportsAlpha {
                    Text("Tip: export as PNG, WebP or HEIC to keep transparency.").font(.system(size: 11)).foregroundStyle(.orange)
                }
            }
        }
    }

    private var annotatePanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionCard(title: "Tool") {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 6), count: 3), spacing: 6) {
                    ForEach(Annotation.Kind.allCases) { k in
                        Button {
                            model.annotationKind = k
                        } label: {
                            VStack(spacing: 2) {
                                Image(systemName: k.symbol).font(.system(size: 14))
                                Text(k.title).font(.system(size: 9.5)).lineLimit(1)
                            }
                            .frame(maxWidth: .infinity, minHeight: 42)
                            .foregroundStyle(model.annotationKind == k ? Color.white : Color.primary)
                            .background(RoundedRectangle(cornerRadius: 8).fill(model.annotationKind == k ? state.accentColor : Color.primary.opacity(0.05)))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            SectionCard(title: "Style") {
                ColorPicker("Colour", selection: $model.annotationColour, supportsOpacity: false)
                HStack {
                    Text("Size")
                    Slider(value: $model.annotationWidth, in: 2...24)
                }
            }
            Text("\(model.annotations.count) annotation\(model.annotations.count == 1 ? "" : "s"). Click to place text or numbered callouts; drag for shapes.")
                .font(.system(size: 11)).foregroundStyle(.secondary)
            HStack { Button("Clear") { model.annotations.removeAll() }; Spacer(); applyButton() }
        }
    }

    private var measurePanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Drag across the image to measure a distance.").font(.system(size: 11.5)).foregroundStyle(.secondary)
            if let s = model.measureSummary {
                Text(s).font(.system(size: 13, weight: .medium)).textSelection(.enabled)
                Button("Copy") { Clipboard.copy(s) }
            }
            Text("Screenshots from Retina displays have 2 pixels per point; values are estimates unless they come from the source design file.")
                .font(.system(size: 10.5)).foregroundStyle(.secondary)
        }
    }

    private var eyedropperPanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Click a pixel to sample its exact colour from the image data.").font(.system(size: 11.5)).foregroundStyle(.secondary)
            if let c = model.pickedColour {
                HStack { Swatch(colour: c, size: 44); Text(ColourMath.approximateName(c)).font(.system(size: 13, weight: .medium)) }
                CopyField(label: "HEX", value: c.hex)
                CopyField(label: "RGB", value: ColourMath.rgbString(c))
                CopyField(label: "HSL", value: ColourMath.hslString(c))
                Button("Open in Colour Lens") { Windows.openColourLens(.colour(c, p3: nil)) }
            }
        }
    }

    private var exportPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionCard(title: "Format") {
                Picker("Format", selection: $model.exportFormat) {
                    ForEach([Format.png, .jpeg, .webp, .heic, .avif, .tiff, .gif, .bmp, .jp2, .pdf].filter(ImageEncoder.canWrite), id: \.self) {
                        Text($0.displayName).tag($0)
                    }
                }
                .labelsHidden()
                if model.exportFormat.isLossy || model.exportFormat == .avif {
                    HStack {
                        Slider(value: $model.exportQuality, in: 0.1...1)
                        Text("\(Int(model.exportQuality * 100))").monospacedDigit().frame(width: 30)
                    }
                    .disabled(model.targetKB > 0)
                    Picker("Target size", selection: $model.targetKB) {
                        Text("Use quality").tag(0)
                        Text("≤ 200 KB").tag(200)
                        Text("≤ 500 KB").tag(500)
                        Text("≤ 1 MB").tag(1024)
                        Text("≤ 2 MB").tag(2048)
                        if ![0, 200, 500, 1024, 2048].contains(model.targetKB) {
                            Text("≤ \(model.targetKB) KB").tag(model.targetKB)
                        }
                    }
                    HStack(spacing: 6) {
                        Text("Custom").font(.system(size: 11.5))
                        TextField("KB", value: $customKB, format: .number).textFieldStyle(.roundedBorder).frame(width: 70)
                        Text("KB")
                        Button("Set") { if customKB >= 5 { model.targetKB = customKB } }.controlSize(.small)
                    }
                }
                Text("Original \(ByteCountFormatter.string(fromByteCount: model.asset.fileSize, countStyle: .file)) → ≈ \(model.estimatedBytes.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .file) } ?? "…")")
                    .font(.system(size: 11.5, weight: .medium))
            }
            SectionCard(title: "Metadata") {
                Picker("Metadata", selection: $model.metadata) {
                    ForEach(MetadataPolicy.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                .labelsHidden()
                Text(model.asset.hasGPS ? "This photo contains location data." : "No location data found.")
                    .font(.system(size: 11)).foregroundStyle(model.asset.hasGPS ? .orange : .secondary)
            }
            Text("A new file is saved next to the original (or where your settings say). The original is never changed.")
                .font(.system(size: 10.5)).foregroundStyle(.secondary)
            HStack { Spacer(); Button("Save Copy") { model.export() }.buttonStyle(AccentButtonStyle()) }
        }
    }
}

// MARK: - Canvas

@MainActor
struct EditorCanvas: View {
    @ObservedObject var model: ImageEditorModel
    @EnvironmentObject var state: AppState
    @State private var textEntry = ""
    @State private var dragMoved = false

    var body: some View {
        GeometryReader { geo in
            let img = model.displayImage
            let size = model.imageSize
            let avail = CGSize(width: max(10, geo.size.width - 40), height: max(10, geo.size.height - 40))
            let scale = min(avail.width / size.width, avail.height / size.height, 4)
            let fit = CGRect(x: (geo.size.width - size.width * scale) / 2, y: (geo.size.height - size.height * scale) / 2,
                             width: size.width * scale, height: size.height * scale)
            ZStack(alignment: .topLeading) {
                if ImageOps.hasAlpha(img) {
                    Checkerboard().frame(width: fit.width, height: fit.height).position(x: fit.midX, y: fit.midY)
                }
                Image(nsImage: NSImage(cg: img))
                    .resizable()
                    .interpolation(scale > 2 ? .none : .high)
                    .frame(width: fit.width, height: fit.height)
                    .position(x: fit.midX, y: fit.midY)
                    .shadow(color: .black.opacity(0.12), radius: 8, y: 2)
                overlay(fit: fit, scale: scale)
                if let p = model.pendingText {
                    TextField("Type, then press Return", text: $textEntry)
                        .textFieldStyle(.roundedBorder)
                        .frame(width: 220)
                        .position(x: fit.minX + p.x * scale + 110, y: fit.minY + p.y * scale)
                        .onSubmit {
                            model.addText(textEntry)
                            textEntry = ""
                        }
                }
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { v in
                        let start = toImage(v.startLocation, fit: fit, scale: scale)
                        let cur = toImage(v.location, fit: fit, scale: scale)
                        if abs(v.translation.width) + abs(v.translation.height) > 3 { dragMoved = true }
                        switch model.tool {
                        case .crop: model.cropDrag(start: start, current: cur, handleTolerance: 14 / scale)
                        case .annotate: if dragMoved || model.annotationKind == .pen { model.annotationDrag(start: start, current: cur) }
                        case .measure:
                            model.measureFrom = start
                            model.measureTo = cur
                        default: break
                        }
                    }
                    .onEnded { v in
                        let end = toImage(v.location, fit: fit, scale: scale)
                        switch model.tool {
                        case .crop: model.endCropDrag()
                        case .annotate: model.annotationEnd(at: end, moved: dragMoved)
                        case .eyedropper: model.pickColour(at: end)
                        default: break
                        }
                        dragMoved = false
                    }
            )
        }
    }

    private func toImage(_ p: CGPoint, fit: CGRect, scale: CGFloat) -> CGPoint {
        CGPoint(x: (p.x - fit.minX) / scale, y: (p.y - fit.minY) / scale)
    }

    private func toView(_ p: CGPoint, fit: CGRect, scale: CGFloat) -> CGPoint {
        CGPoint(x: fit.minX + p.x * scale, y: fit.minY + p.y * scale)
    }

    @ViewBuilder
    private func overlay(fit: CGRect, scale: CGFloat) -> some View {
        switch model.tool {
        case .crop:
            let r = model.cropRect
            let vr = CGRect(x: fit.minX + r.minX * scale, y: fit.minY + r.minY * scale, width: r.width * scale, height: r.height * scale)
            Canvas { ctx, _ in
                var dim = Path(fit)
                dim.addRect(vr)
                ctx.fill(dim, with: .color(.black.opacity(0.45)), style: FillStyle(eoFill: true))
                ctx.stroke(Path(vr), with: .color(.white), lineWidth: 1.5)
                for i in 1...2 {
                    let x = vr.minX + vr.width * CGFloat(i) / 3
                    let y = vr.minY + vr.height * CGFloat(i) / 3
                    ctx.stroke(Path { $0.move(to: CGPoint(x: x, y: vr.minY)); $0.addLine(to: CGPoint(x: x, y: vr.maxY)) }, with: .color(.white.opacity(0.4)), lineWidth: 0.7)
                    ctx.stroke(Path { $0.move(to: CGPoint(x: vr.minX, y: y)); $0.addLine(to: CGPoint(x: vr.maxX, y: y)) }, with: .color(.white.opacity(0.4)), lineWidth: 0.7)
                }
                for corner in [CGPoint(x: vr.minX, y: vr.minY), CGPoint(x: vr.maxX, y: vr.minY), CGPoint(x: vr.minX, y: vr.maxY), CGPoint(x: vr.maxX, y: vr.maxY),
                               CGPoint(x: vr.midX, y: vr.minY), CGPoint(x: vr.midX, y: vr.maxY), CGPoint(x: vr.minX, y: vr.midY), CGPoint(x: vr.maxX, y: vr.midY)] {
                    ctx.fill(Path(ellipseIn: CGRect(x: corner.x - 5, y: corner.y - 5, width: 10, height: 10)), with: .color(.white))
                }
            }
            .allowsHitTesting(false)
        case .annotate:
            Canvas { ctx, _ in
                var list = model.annotations
                if let d = model.draft { list.append(d) }
                for a in list { draw(a, in: &ctx, fit: fit, scale: scale) }
            }
            .allowsHitTesting(false)
        case .measure:
            if let a = model.measureFrom, let b = model.measureTo {
                let va = toView(a, fit: fit, scale: scale), vb = toView(b, fit: fit, scale: scale)
                Canvas { ctx, _ in
                    ctx.stroke(Path { $0.move(to: va); $0.addLine(to: vb) }, with: .color(state.accentColor), style: StrokeStyle(lineWidth: 2, dash: [6, 3]))
                    for p in [va, vb] { ctx.fill(Path(ellipseIn: CGRect(x: p.x - 4, y: p.y - 4, width: 8, height: 8)), with: .color(state.accentColor)) }
                }
                .allowsHitTesting(false)
                if let s = model.measureSummary {
                    Text(s.components(separatedBy: " — ").first ?? s)
                        .font(.system(size: 11, weight: .semibold))
                        .padding(.horizontal, 6).padding(.vertical, 3)
                        .background(Capsule().fill(.regularMaterial))
                        .position(x: (va.x + vb.x) / 2, y: (va.y + vb.y) / 2 - 16)
                }
            }
        default:
            EmptyView()
        }
    }

    private func draw(_ a: Annotation, in ctx: inout GraphicsContext, fit: CGRect, scale: CGFloat) {
        let colour = a.colour.swiftUIColor
        let pts = a.points.map { toView($0, fit: fit, scale: scale) }
        let w = a.width * scale
        switch a.kind {
        case .pen, .highlighter:
            guard let f = pts.first else { return }
            var path = Path()
            path.move(to: f)
            for p in pts.dropFirst() { path.addLine(to: p) }
            if a.kind == .highlighter {
                ctx.stroke(path, with: .color(colour.opacity(0.38)), style: StrokeStyle(lineWidth: w * 3.2, lineCap: .round, lineJoin: .round))
            } else {
                ctx.stroke(path, with: .color(colour), style: StrokeStyle(lineWidth: w, lineCap: .round, lineJoin: .round))
            }
        case .arrow:
            guard let s = pts.first, let e = pts.last else { return }
            let angle = atan2(e.y - s.y, e.x - s.x)
            let head = max(14 * scale, w * 3.6)
            let baseP = CGPoint(x: e.x - head * 0.8 * cos(angle), y: e.y - head * 0.8 * sin(angle))
            ctx.stroke(Path { $0.move(to: s); $0.addLine(to: baseP) }, with: .color(colour), style: StrokeStyle(lineWidth: w, lineCap: .round))
            var tip = Path()
            tip.move(to: e)
            tip.addLine(to: CGPoint(x: e.x - head * cos(angle - 0.45), y: e.y - head * sin(angle - 0.45)))
            tip.addLine(to: CGPoint(x: e.x - head * cos(angle + 0.45), y: e.y - head * sin(angle + 0.45)))
            tip.closeSubpath()
            ctx.fill(tip, with: .color(colour))
        case .rectangle, .ellipse, .blur, .pixelate:
            let r = a.rect
            let vr = CGRect(x: fit.minX + r.minX * scale, y: fit.minY + r.minY * scale, width: r.width * scale, height: r.height * scale)
            if a.kind == .rectangle {
                ctx.stroke(Path(roundedRect: vr, cornerRadius: w), with: .color(colour), lineWidth: w)
            } else if a.kind == .ellipse {
                ctx.stroke(Path(ellipseIn: vr), with: .color(colour), lineWidth: w)
            } else if let fx = a.kind == .blur ? model.effectCache?.blur : model.effectCache?.pixel {
                var c = ctx
                c.clip(to: Path(vr))
                c.draw(Image(nsImage: NSImage(cg: fx)).resizable(), in: fit)
                ctx.stroke(Path(vr), with: .color(.white.opacity(0.6)), style: StrokeStyle(lineWidth: 1, dash: [4, 3]))
            }
        case .text:
            guard let p = pts.first else { return }
            let size = max(14, a.width * 5) * scale
            ctx.draw(Text(a.text).font(.system(size: size, weight: .bold)).foregroundColor(colour), at: CGPoint(x: p.x, y: p.y), anchor: .leading)
        case .callout:
            guard let p = pts.first else { return }
            let r = max(14, a.width * 2.6 + 8) * scale
            ctx.fill(Path(ellipseIn: CGRect(x: p.x - r, y: p.y - r, width: r * 2, height: r * 2)), with: .color(colour))
            ctx.stroke(Path(ellipseIn: CGRect(x: p.x - r, y: p.y - r, width: r * 2, height: r * 2)), with: .color(.white), lineWidth: max(2, r * 0.12))
            ctx.draw(Text("\(a.number)").font(.system(size: r * 1.05, weight: .bold)).foregroundColor(.white), at: p, anchor: .center)
        }
    }
}
