// HEXSHIFT – thin C shim over the vendored libwebp encoder.
// Only these functions are visible to Swift; libwebp's own headers stay private.
#ifndef HEXSHIFT_HEXWEBP_H
#define HEXSHIFT_HEXWEBP_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/// Returns libwebp's encoder version as 0xMMmmrr (e.g. 0x010500 for 1.5.0).
int hex_webp_encoder_version(void);

/// Encodes a straight (non-premultiplied) RGBA8888 buffer to WebP.
/// quality: 0...100. lossless: 0/1. method: 0 (fast) ... 6 (slow, smallest).
/// On success returns the byte count and sets *output (free with hex_webp_free).
/// Returns 0 on failure.
size_t hex_webp_encode_rgba(const uint8_t *rgba, int width, int height, int stride,
                            float quality, int lossless, int method,
                            uint8_t **output);

void hex_webp_free(void *ptr);

/// Animated WebP encoder.
typedef struct HexWebPAnim HexWebPAnim;

HexWebPAnim *hex_webp_anim_new(int width, int height, int loop_count,
                               float quality, int lossless);
/// Adds one RGBA frame that starts at timestamp_ms. Returns 1 on success.
int hex_webp_anim_add(HexWebPAnim *anim, const uint8_t *rgba, int stride,
                      int timestamp_ms);
/// Finishes the animation (end_timestamp_ms = end of last frame) and returns
/// the encoded size, setting *output (free with hex_webp_free). 0 on failure.
size_t hex_webp_anim_finish(HexWebPAnim *anim, int end_timestamp_ms,
                            uint8_t **output);
void hex_webp_anim_free(HexWebPAnim *anim);

#ifdef __cplusplus
}
#endif

#endif
