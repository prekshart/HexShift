// HEXSHIFT – thin C shim over the vendored libwebp encoder (see include/hexwebp.h).
#include "include/hexwebp.h"

#include <stdlib.h>
#include <string.h>

#include "src/webp/encode.h"
#include "src/webp/mux.h"

int hex_webp_encoder_version(void) { return WebPGetEncoderVersion(); }

void hex_webp_free(void *ptr) { WebPFree(ptr); }

static int hex_clamp_method(int method) {
  if (method < 0) return 0;
  if (method > 6) return 6;
  return method;
}

static float hex_clamp_quality(float q) {
  if (q < 0.f) return 0.f;
  if (q > 100.f) return 100.f;
  return q;
}

size_t hex_webp_encode_rgba(const uint8_t *rgba, int width, int height, int stride,
                            float quality, int lossless, int method,
                            uint8_t **output) {
  if (output == NULL) return 0;
  *output = NULL;
  if (rgba == NULL || width <= 0 || height <= 0 || stride < width * 4) return 0;
  if (width > WEBP_MAX_DIMENSION || height > WEBP_MAX_DIMENSION) return 0;

  WebPConfig config;
  if (!WebPConfigInit(&config)) return 0;
  config.quality = hex_clamp_quality(quality);
  config.method = hex_clamp_method(method);
  if (lossless) {
    // Preset 6 is a good speed/size balance for lossless.
    if (!WebPConfigLosslessPreset(&config, 6)) return 0;
    config.exact = 1;  // keep RGB under fully transparent pixels
  } else {
    config.use_sharp_yuv = 1;  // better colour edges for UI screenshots
  }
  if (!WebPValidateConfig(&config)) return 0;

  WebPPicture picture;
  if (!WebPPictureInit(&picture)) return 0;
  picture.use_argb = lossless ? 1 : 0;
  picture.width = width;
  picture.height = height;
  if (!WebPPictureImportRGBA(&picture, rgba, stride)) {
    WebPPictureFree(&picture);
    return 0;
  }

  WebPMemoryWriter writer;
  WebPMemoryWriterInit(&writer);
  picture.writer = WebPMemoryWrite;
  picture.custom_ptr = &writer;

  const int ok = WebPEncode(&config, &picture);
  WebPPictureFree(&picture);
  if (!ok) {
    WebPMemoryWriterClear(&writer);
    return 0;
  }
  *output = writer.mem;  // ownership transferred to caller (hex_webp_free)
  return writer.size;
}

struct HexWebPAnim {
  WebPAnimEncoder *enc;
  WebPConfig config;
  int width;
  int height;
};

HexWebPAnim *hex_webp_anim_new(int width, int height, int loop_count,
                               float quality, int lossless) {
  if (width <= 0 || height <= 0) return NULL;
  HexWebPAnim *anim = (HexWebPAnim *)calloc(1, sizeof(HexWebPAnim));
  if (anim == NULL) return NULL;
  anim->width = width;
  anim->height = height;

  WebPAnimEncoderOptions opts;
  if (!WebPAnimEncoderOptionsInit(&opts)) { free(anim); return NULL; }
  opts.anim_params.loop_count = loop_count < 0 ? 0 : loop_count;
  opts.allow_mixed = 0;

  if (!WebPConfigInit(&anim->config)) { free(anim); return NULL; }
  anim->config.quality = hex_clamp_quality(quality);
  anim->config.method = 4;
  if (lossless) {
    WebPConfigLosslessPreset(&anim->config, 4);
  }
  if (!WebPValidateConfig(&anim->config)) { free(anim); return NULL; }

  anim->enc = WebPAnimEncoderNew(width, height, &opts);
  if (anim->enc == NULL) { free(anim); return NULL; }
  return anim;
}

int hex_webp_anim_add(HexWebPAnim *anim, const uint8_t *rgba, int stride,
                      int timestamp_ms) {
  if (anim == NULL || anim->enc == NULL || rgba == NULL) return 0;
  WebPPicture picture;
  if (!WebPPictureInit(&picture)) return 0;
  picture.use_argb = 1;
  picture.width = anim->width;
  picture.height = anim->height;
  if (!WebPPictureImportRGBA(&picture, rgba, stride)) {
    WebPPictureFree(&picture);
    return 0;
  }
  const int ok = WebPAnimEncoderAdd(anim->enc, &picture, timestamp_ms, &anim->config);
  WebPPictureFree(&picture);
  return ok;
}

size_t hex_webp_anim_finish(HexWebPAnim *anim, int end_timestamp_ms,
                            uint8_t **output) {
  if (output == NULL) return 0;
  *output = NULL;
  if (anim == NULL || anim->enc == NULL) return 0;
  // A NULL frame marks the end of the animation.
  if (!WebPAnimEncoderAdd(anim->enc, NULL, end_timestamp_ms, NULL)) return 0;
  WebPData data;
  WebPDataInit(&data);
  if (!WebPAnimEncoderAssemble(anim->enc, &data)) {
    WebPDataClear(&data);
    return 0;
  }
  *output = (uint8_t *)data.bytes;  // allocated with WebPMalloc -> hex_webp_free
  return data.size;
}

void hex_webp_anim_free(HexWebPAnim *anim) {
  if (anim == NULL) return;
  if (anim->enc != NULL) WebPAnimEncoderDelete(anim->enc);
  free(anim);
}
