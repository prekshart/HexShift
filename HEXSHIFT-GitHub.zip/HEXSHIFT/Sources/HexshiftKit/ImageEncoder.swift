import Accelerate
import CWebP
import CoreGraphics
import Foundation
import ImageIO
import UniformTypeIdentifiers

public enum MetadataPolicy: String, Codable, CaseIterable, Sendable {
    case preserve, stripGPS, stripAll

    public var title: String {
        switch self {
        case .preserve: return "Preserve all metadata"
        case .stripGPS: return "Remove location (GPS) only"
        case .stripAll: return "Remove all metadata"
        }
    }
}

public enum SVGMode: String, Codable, CaseIterable, Sendable {
    /// Wraps the pixels in an SVG container. Not editable vector artwork.
    case embed
    /// Traces shapes into real vector paths (posterised, approximate).
    case trace
}

/// What to do with the image's colour profile on export.
public enum ColourProfileChoice: String, Codable, CaseIterable, Sendable {
    case keep, sRGB, displayP3
    public var title: String {
        switch self {
        case .keep: return "Keep the original profile"
        case .sRGB: return "Convert to sRGB (web, most compatible)"
        case .displayP3: return "Convert to Display P3 (wide colour)"
        }
    }
}

public struct ImageExportOptions: Codable, Hashable, Sendable {
    /// 0...1 for lossy formats.
    public var quality: Double = 0.85
    /// WebP lossless mode.
    public var lossless: Bool = false
    public var metadata: MetadataPolicy = .stripGPS
    /// Background used when a format cannot store transparency.
    public var matte: RGBAColour = .white
    /// Optional downscale (longest side).
    public var maxPixelSize: Int?
    public var keepAnimation: Bool = true
    /// Overrides stored DPI/PPI metadata.
    public var dpi: Double?
    public var svgMode: SVGMode = .embed
    public var traceColours: Int = 6
    public var colourProfile: ColourProfileChoice = .keep

    public init() {}
}

/// Writes CGImages to every supported output format and validates the result.
public enum ImageEncoder {
    // MARK: Capabilities

    public static let imageIOWritableTypes: Set<String> = {
        Set((CGImageDestinationCopyTypeIdentifiers() as? [String]) ?? [])
    }()

    public static let imageIOReadableTypes: Set<String> = {
        Set((CGImageSourceCopyTypeIdentifiers() as? [String]) ?? [])
    }()

    /// Whether this Mac can produce the format as an image output.
    public static func canWrite(_ format: Format) -> Bool {
        switch format {
        case .webp, .svg, .pdf, .ico: return true
        case .avif:
            return imageIOWritableTypes.contains("public.avif") || ExternalTools.path(.avifenc) != nil
        case .psd, .raw, .tga: return false
        default:
            guard let t = format.imageIOType else { return false }
            return imageIOWritableTypes.contains(t)
        }
    }

    public static var webpEncoderVersion: String {
        let v = Int(hex_webp_encoder_version())
        return "\(v >> 16).\((v >> 8) & 0xFF).\(v & 0xFF)"
    }

    // MARK: Still images

    public static func write(_ input: CGImage, sourceProperties: [CFString: Any] = [:], format: Format,
                             to url: URL, options: ImageExportOptions = ImageExportOptions()) throws {
        var image = ImageOps.limit(input, maxPixelSize: options.maxPixelSize)
        switch options.colourProfile {
        case .keep: break
        case .sRGB: image = ImageOps.toSRGB(image)
        case .displayP3: image = ImageOps.toDisplayP3(image)
        }
        if !format.supportsAlpha { image = ImageOps.flatten(image, matte: options.matte) }
        switch format {
        case .jpeg, .tiff, .pdf, .psd:
            break // CMYK is fine here
        default:
            image = ImageOps.ensureRGB(image)
        }

        try FileWriter.writeAtomically(to: url) { tmp in
            switch format {
            case .webp:
                let data = try encodeWebP(image, quality: options.quality, lossless: options.lossless)
                try data.write(to: tmp)
            case .svg:
                let data: Data
                if options.svgMode == .trace {
                    if options.traceColours <= 2, let smooth = VectorTracer.potraceSVG(image) {
                        data = Data(smooth.utf8)
                    } else {
                        data = Data(VectorTracer.trace(image, colours: options.traceColours).utf8)
                    }
                } else {
                    data = try svgEmbedding(image)
                }
                try data.write(to: tmp)
            case .pdf:
                try pdfData(image, dpi: options.dpi ?? dpi(from: sourceProperties) ?? 72).write(to: tmp)
            case .ico:
                let sizes = [16, 24, 32, 48, 64, 128, 256].filter { $0 <= max(16, max(image.width, image.height)) }
                try icoData(sizes.map { ImageOps.squareFit(image, size: $0) }).write(to: tmp)
            case .icns:
                let sizes = [16, 32, 64, 128, 256, 512, 1024]
                try writeImageIO(sizes.map { (ImageOps.squareFit(image, size: $0), [CFString: Any]()) },
                                 type: "com.apple.icns", to: tmp)
            case .avif where !imageIOWritableTypes.contains("public.avif"):
                try encodeAVIFExternally(image, quality: options.quality, to: tmp)
            default:
                guard let type = format.imageIOType, imageIOWritableTypes.contains(type) else {
                    throw HexError.unsupportedConversion(from: "This image", to: format.displayName)
                }
                var props = destinationProperties(source: sourceProperties, format: format, options: options)
                if format == .tiff {
                    // LZW keeps TIFFs lossless but much smaller than uncompressed.
                    var tiff = (props[kCGImagePropertyTIFFDictionary] as? [CFString: Any]) ?? [:]
                    tiff[kCGImagePropertyTIFFCompression] = 5
                    props[kCGImagePropertyTIFFDictionary] = tiff
                }
                try writeImageIO([(image, props)], type: type, to: tmp)
            }
            try validate(tmp, format: format)
        }
    }

    /// Encodes to memory (used for size estimates and the clipboard).
    public static func encodedData(_ image: CGImage, format: Format, quality: Double, lossless: Bool = false) throws -> Data {
        switch format {
        case .webp:
            return try encodeWebP(image, quality: quality, lossless: lossless)
        default:
            guard let type = format.imageIOType, imageIOWritableTypes.contains(type) else {
                throw HexError.unsupportedConversion(from: "This image", to: format.displayName)
            }
            var img = image
            if !format.supportsAlpha { img = ImageOps.flatten(img) }
            let data = NSMutableData()
            guard let dest = CGImageDestinationCreateWithData(data as CFMutableData, type as CFString, 1, nil) else {
                throw HexError.writeFailed("ImageIO refused \(format.displayName).")
            }
            var props: [CFString: Any] = [:]
            if format.isLossy { props[kCGImageDestinationLossyCompressionQuality] = quality }
            CGImageDestinationAddImage(dest, img, props as CFDictionary)
            guard CGImageDestinationFinalize(dest) else { throw HexError.writeFailed("Encoding failed.") }
            return data as Data
        }
    }

    static func dpi(from props: [CFString: Any]) -> Double? {
        (props[kCGImagePropertyDPIWidth] as? NSNumber)?.doubleValue
    }

    static func destinationProperties(source: [CFString: Any], format: Format, options: ImageExportOptions) -> [CFString: Any] {
        var props: [CFString: Any] = [:]
        if format.isLossy { props[kCGImageDestinationLossyCompressionQuality] = options.quality }
        if options.metadata != .stripAll {
            let keys: [CFString] = [kCGImagePropertyExifDictionary, kCGImagePropertyTIFFDictionary,
                                    kCGImagePropertyIPTCDictionary, kCGImagePropertyGPSDictionary,
                                    kCGImagePropertyExifAuxDictionary]
            for key in keys {
                if let d = source[key] { props[key] = d }
            }
            if options.metadata == .stripGPS { props.removeValue(forKey: kCGImagePropertyGPSDictionary) }
            if var exif = props[kCGImagePropertyExifDictionary] as? [CFString: Any] {
                // Pixel dimensions are recomputed by ImageIO; stale values would be misleading.
                exif.removeValue(forKey: kCGImagePropertyExifPixelXDimension)
                exif.removeValue(forKey: kCGImagePropertyExifPixelYDimension)
                props[kCGImagePropertyExifDictionary] = exif
            }
            if var tiff = props[kCGImagePropertyTIFFDictionary] as? [CFString: Any] {
                tiff[kCGImagePropertyTIFFOrientation] = 1
                props[kCGImagePropertyTIFFDictionary] = tiff
            }
        }
        // Pixels are already upright.
        props[kCGImagePropertyOrientation] = 1
        if let dpi = options.dpi ?? dpi(from: source) {
            props[kCGImagePropertyDPIWidth] = dpi
            props[kCGImagePropertyDPIHeight] = dpi
        }
        return props
    }

    /// A Windows .ico with PNG-compressed entries (supported by Windows Vista+, macOS and browsers).
    static func icoData(_ images: [CGImage]) throws -> Data {
        var entries: [(width: Int, height: Int, png: Data)] = []
        for img in images {
            let d = NSMutableData()
            guard let dest = CGImageDestinationCreateWithData(d as CFMutableData, "public.png" as CFString, 1, nil) else {
                throw HexError.writeFailed("Could not encode an icon image.")
            }
            CGImageDestinationAddImage(dest, img, nil)
            guard CGImageDestinationFinalize(dest) else { throw HexError.writeFailed("Could not encode an icon image.") }
            entries.append((img.width, img.height, d as Data))
        }
        var out = Data()
        func u16(_ v: UInt16) { out.append(UInt8(v & 0xFF)); out.append(UInt8(v >> 8)) }
        func u32(_ v: UInt32) { for shift in stride(from: 0, to: 32, by: 8) { out.append(UInt8((v >> UInt32(shift)) & 0xFF)) } }
        u16(0); u16(1); u16(UInt16(entries.count))
        var offset = 6 + 16 * entries.count
        for e in entries {
            out.append(UInt8(e.width >= 256 ? 0 : e.width))
            out.append(UInt8(e.height >= 256 ? 0 : e.height))
            out.append(0); out.append(0)       // palette size, reserved
            u16(1); u16(32)                    // colour planes, bits per pixel
            u32(UInt32(e.png.count)); u32(UInt32(offset))
            offset += e.png.count
        }
        for e in entries { out.append(e.png) }
        return out
    }

    static func writeImageIO(_ images: [(CGImage, [CFString: Any])], type: String, to url: URL,
                             global: [CFString: Any]? = nil) throws {
        guard let dest = CGImageDestinationCreateWithURL(url as CFURL, type as CFString, images.count, nil) else {
            throw HexError.writeFailed("ImageIO could not create a \(type) file.")
        }
        if let global { CGImageDestinationSetProperties(dest, global as CFDictionary) }
        for (img, props) in images {
            CGImageDestinationAddImage(dest, img, props.isEmpty ? nil : props as CFDictionary)
        }
        guard CGImageDestinationFinalize(dest) else {
            throw HexError.writeFailed("ImageIO could not finish writing the file.")
        }
    }

    // MARK: WebP (vendored libwebp)

    /// Straight RGBA8 sRGB pixels, as libwebp expects.
    static func straightRGBA(_ image: CGImage) throws -> (bytes: [UInt8], width: Int, height: Int, stride: Int) {
        let w = image.width, h = image.height
        let stride = w * 4
        var bytes = [UInt8](repeating: 0, count: stride * h)
        let ok: Bool = bytes.withUnsafeMutableBytes { ptr -> Bool in
            guard let ctx = CGContext(data: ptr.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: stride,
                                      space: ImageOps.sRGB, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.draw(image, in: CGRect(x: 0, y: 0, width: w, height: h))
            let buffer = vImage_Buffer(data: ptr.baseAddress, height: vImagePixelCount(h), width: vImagePixelCount(w), rowBytes: stride)
            var src = buffer
            var dst = buffer
            vImageUnpremultiplyData_RGBA8888(&src, &dst, vImage_Flags(kvImageNoFlags))
            return true
        }
        guard ok else { throw HexError.writeFailed("Could not prepare pixels for WebP.") }
        return (bytes, w, h, stride)
    }

    public static func encodeWebP(_ image: CGImage, quality: Double, lossless: Bool) throws -> Data {
        guard image.width <= 16383, image.height <= 16383 else {
            throw HexError.message("WebP supports images up to 16383 × 16383 pixels.")
        }
        let px = try straightRGBA(image)
        var output: UnsafeMutablePointer<UInt8>?
        let size = px.bytes.withUnsafeBufferPointer { buf in
            hex_webp_encode_rgba(buf.baseAddress, Int32(px.width), Int32(px.height), Int32(px.stride),
                                 Float(min(1, max(0, quality)) * 100), lossless ? 1 : 0, 4, &output)
        }
        guard size > 0, let out = output else { throw HexError.writeFailed("The WebP encoder failed.") }
        defer { hex_webp_free(out) }
        return Data(bytes: out, count: Int(size))
    }

    public static func encodeAnimatedWebP(_ frames: [AnimationFrame], loopCount: Int, quality: Double, lossless: Bool) throws -> Data {
        guard let first = frames.first else { throw HexError.message("No frames to encode.") }
        let w = first.image.width, h = first.image.height
        guard let anim = hex_webp_anim_new(Int32(w), Int32(h), Int32(loopCount), Float(quality * 100), lossless ? 1 : 0) else {
            throw HexError.writeFailed("The animated WebP encoder could not start.")
        }
        defer { hex_webp_anim_free(anim) }
        var timestamp = 0
        for frame in frames {
            var img = frame.image
            if img.width != w || img.height != h { img = ImageOps.resize(img, to: CGSize(width: w, height: h)) }
            let px = try straightRGBA(img)
            let ok = px.bytes.withUnsafeBufferPointer { buf in
                hex_webp_anim_add(anim, buf.baseAddress, Int32(px.stride), Int32(timestamp))
            }
            guard ok == 1 else { throw HexError.writeFailed("A frame could not be added to the WebP animation.") }
            timestamp += max(20, Int((frame.delay * 1000).rounded()))
        }
        var output: UnsafeMutablePointer<UInt8>?
        let size = hex_webp_anim_finish(anim, Int32(timestamp), &output)
        guard size > 0, let out = output else { throw HexError.writeFailed("The animated WebP could not be assembled.") }
        defer { hex_webp_free(out) }
        return Data(bytes: out, count: Int(size))
    }

    // MARK: AVIF via avifenc (when ImageIO cannot encode AVIF)

    static func encodeAVIFExternally(_ image: CGImage, quality: Double, to url: URL) throws {
        guard let tool = ExternalTools.path(.avifenc) else {
            throw HexError.missingTool(name: "an AVIF encoder", hint: ExternalTool.avifenc.installHint)
        }
        let tmpDir = try FileWriter.makeTemporaryDirectory()
        defer { try? FileManager.default.removeItem(at: tmpDir) }
        let png = tmpDir.appendingPathComponent("in.png")
        try writeImageIO([(image, [:])], type: "public.png", to: png)
        let q = Int((quality * 100).rounded())
        let result = try ExternalTools.run(tool, ["-q", "\(q)", "--speed", "6", png.path, url.path], timeout: 300)
        guard result.status == 0 else { throw HexError.writeFailed("avifenc failed: \(result.stderr.prefix(200))") }
    }

    // MARK: SVG

    static func svgEmbedding(_ image: CGImage) throws -> Data {
        let png = try encodedData(image, format: .png, quality: 1)
        let w = image.width, h = image.height
        let svg = """
        <?xml version="1.0" encoding="UTF-8"?>
        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="\(w)" height="\(h)" viewBox="0 0 \(w) \(h)">
          <!-- Raster image embedded by HEXSHIFT. This is pixel data inside an SVG, not editable vector artwork. -->
          <image width="\(w)" height="\(h)" xlink:href="data:image/png;base64,\(png.base64EncodedString())"/>
        </svg>

        """
        return Data(svg.utf8)
    }

    // MARK: PDF

    static func pdfData(_ image: CGImage, dpi: Double) throws -> Data {
        let d = dpi > 0 ? dpi : 72
        var box = CGRect(x: 0, y: 0, width: Double(image.width) * 72 / d, height: Double(image.height) * 72 / d)
        let data = NSMutableData()
        guard let consumer = CGDataConsumer(data: data as CFMutableData),
              let ctx = CGContext(consumer: consumer, mediaBox: &box, [kCGPDFContextCreator: "HEXSHIFT"] as CFDictionary) else {
            throw HexError.writeFailed("Could not create a PDF context.")
        }
        ctx.beginPDFPage(nil)
        ctx.interpolationQuality = .high
        ctx.draw(image, in: box)
        ctx.endPDFPage()
        ctx.closePDF()
        return data as Data
    }

    // MARK: Animation

    public static func writeAnimation(_ frames: [AnimationFrame], loopCount: Int, format: Format, to url: URL,
                                      options: ImageExportOptions = ImageExportOptions()) throws {
        guard !frames.isEmpty else { throw HexError.message("No frames to write.") }
        let limited = frames.map { AnimationFrame(image: ImageOps.ensureRGB(ImageOps.limit($0.image, maxPixelSize: options.maxPixelSize)), delay: $0.delay) }
        try FileWriter.writeAtomically(to: url) { tmp in
            switch format {
            case .gif:
                let global: [CFString: Any] = [kCGImagePropertyGIFDictionary: [kCGImagePropertyGIFLoopCount: loopCount]]
                let items = limited.map { f -> (CGImage, [CFString: Any]) in
                    (f.image, [kCGImagePropertyGIFDictionary: [kCGImagePropertyGIFDelayTime: f.delay,
                                                               kCGImagePropertyGIFUnclampedDelayTime: f.delay]])
                }
                try writeImageIO(items, type: "com.compuserve.gif", to: tmp, global: global)
            case .png:
                let global: [CFString: Any] = [kCGImagePropertyPNGDictionary: [kCGImagePropertyAPNGLoopCount: loopCount]]
                let items = limited.map { f -> (CGImage, [CFString: Any]) in
                    (f.image, [kCGImagePropertyPNGDictionary: [kCGImagePropertyAPNGDelayTime: f.delay,
                                                               kCGImagePropertyAPNGUnclampedDelayTime: f.delay]])
                }
                try writeImageIO(items, type: "public.png", to: tmp, global: global)
            case .webp:
                let data = try encodeAnimatedWebP(limited, loopCount: loopCount, quality: options.quality, lossless: options.lossless)
                try data.write(to: tmp)
            default:
                throw HexError.unsupportedConversion(from: "An animation", to: format.displayName)
            }
            try validate(tmp, format: format, minimumFrames: limited.count > 1 ? 2 : 1)
        }
    }

    // MARK: Validation — never report success for a broken file

    public static func validate(_ url: URL, format: Format, minimumFrames: Int = 1) throws {
        let attrs = try? FileManager.default.attributesOfItem(atPath: url.path)
        let size = (attrs?[.size] as? NSNumber)?.intValue ?? 0
        guard size > 0 else { throw HexError.invalidOutput("The file is empty.") }
        switch format {
        case .svg:
            guard let data = try? Data(contentsOf: url), XMLValidator.isWellFormed(data) else {
                throw HexError.invalidOutput("The SVG is not well-formed XML.")
            }
        case .pdf:
            guard let doc = CGPDFDocument(url as CFURL), doc.numberOfPages > 0 else {
                throw HexError.invalidOutput("The PDF has no readable pages.")
            }
        case .avif where !imageIOReadableTypes.contains("public.avif"):
            // Cannot decode AVIF on this macOS version; check the container signature instead.
            guard Format.sniff(url) == .avif else { throw HexError.invalidOutput("The AVIF container is invalid.") }
        default:
            guard let src = CGImageSourceCreateWithURL(url as CFURL, nil),
                  CGImageSourceGetStatus(src) == .statusComplete,
                  CGImageSourceGetCount(src) >= minimumFrames,
                  CGImageSourceCreateImageAtIndex(src, 0, nil) != nil else {
                throw HexError.invalidOutput("The written \(format.displayName) could not be decoded again.")
            }
        }
    }
}

/// Minimal XML well-formedness check.
enum XMLValidator {
    final class Delegate: NSObject, XMLParserDelegate {
        var failed = false
        func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) { failed = true }
    }

    static func isWellFormed(_ data: Data) -> Bool {
        let parser = XMLParser(data: data)
        let delegate = Delegate()
        parser.delegate = delegate
        return parser.parse() && !delegate.failed
    }
}
