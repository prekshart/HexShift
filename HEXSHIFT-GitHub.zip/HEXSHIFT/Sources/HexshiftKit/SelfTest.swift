import AppKit
import AVFoundation
import CoreGraphics
import CoreText
import Foundation
import ImageIO
import PDFKit

/// End-to-end checks of the conversion engine against real files.
/// Run with `hexshift-cli selftest` or `swift test`.
public enum SelfTest {
    public struct Report: Sendable {
        public var passed = 0
        public var failed = 0
        public var skipped = 0
        public var warnings = 0
        public var lines: [String] = []
        public var failures: [String] = []
    }

    final class Context {
        let dir: URL
        var report = Report()
        let log: (String) -> Void
        init(dir: URL, log: @escaping (String) -> Void) {
            self.dir = dir
            self.log = log
        }
        func file(_ name: String) -> URL { dir.appendingPathComponent(name) }
        var planner: OutputPlanner {
            OutputPlanner(settings: OutputSettings(destination: .custom(path: dir.appendingPathComponent("out").path), naming: .suffix("-converted")))
        }
    }

    struct Skip: Error { let reason: String }
    struct Warn: Error { let reason: String }
    struct Failure: Error, CustomStringConvertible {
        let description: String
        init(_ d: String) { description = d }
    }

    static func expect(_ condition: Bool, _ message: @autoclosure () -> String) throws {
        if !condition { throw Failure(message()) }
    }

    public static func run(keepFiles: Bool = false, filter: String? = nil, log: @escaping (String) -> Void = { print($0) }) async -> Report {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("HEXSHIFT-selftest-\(UUID().uuidString.prefix(6))")
        try? FileManager.default.createDirectory(at: dir.appendingPathComponent("out"), withIntermediateDirectories: true)
        let ctx = Context(dir: dir, log: log)
        log("HEXSHIFT self-test — \(ProcessInfo.processInfo.operatingSystemVersionString)")
        log("Working folder: \(dir.path)")
        log("ImageIO can write: \(ImageEncoder.imageIOWritableTypes.sorted().joined(separator: ", "))")
        log("libwebp encoder: \(ImageEncoder.webpEncoderVersion)")
        log("Optional tools: " + ExternalTools.installedSummary.map { "\($0.0.rawValue)=\($0.1 == nil ? "no" : "yes")" }.joined(separator: " "))
        log("")

        do {
            try makeFixtures(ctx)
        } catch {
            log("FAIL  fixtures: \(error)")
            ctx.report.failed += 1
            return ctx.report
        }

        let tests: [(String, (Context) async throws -> String?)] = [
            ("format detection", testDetection),
            ("image → every writable format", testImageFormats),
            ("WebP (libwebp) still + lossless", testWebP),
            ("EXIF orientation applied", testOrientation),
            ("metadata preserve / strip GPS / strip all", testMetadata),
            ("animation: GIF → WebP / APNG / MP4", testAnimation),
            ("PDF → PNG pages (all + selected)", testPDFToImages),
            ("images → PDF, merge, split, extract", testPDFAssembly),
            ("PDF text extraction", testPDFText),
            ("OCR on scanned PDF", testOCR),
            ("searchable PDF (invisible OCR layer)", testSearchable),
            ("true redaction removes text", testRedaction),
            ("page numbers, metadata strip, compression", testPDFUtilities),
            ("PDF password protect + remove", testPDFPassword),
            ("PDF markup (ink, text box, note, box) + page size & margins", testPDFMarkup),
            ("fonts used in PDF", testPDFFonts),
            ("documents: MD / HTML / DOCX / RTF / ODT / PDF", testDocuments),
            ("tables: CSV ⇄ XLSX / JSON / PDF", testTables),
            ("SVG → PNG / PDF", testSVG),
            ("vector trace → SVG paths", testTrace),
            ("ICO / ICNS multi-size", testIcons),
            ("colour maths (HEX/RGB/HSL/OKLCH, WCAG + APCA, harmonies, CVD, ASE)", testColour),
            ("palette extraction + gradient estimate", testPalette),
            ("adjustments (warmth direction, grayscale)", testAdjustments),
            ("background removal (Vision)", testBackground),
            ("font matching from pixels", testFontMatch),
            ("font finder accuracy (macOS + Google Fonts)", testFontBenchmark),
            ("output naming never overwrites", testOutputNaming),
            ("batch queue + cancellation", testBatch),
            ("corrupted input fails cleanly", testCorrupted),
            ("unreadable file / read-only folder fail cleanly", testPermissions),
            ("video: MP4 ⇄ MOV / GIF / frame", testVideo),
            ("text graphics + specimen", testTextGraphics),
            ("workflows", testWorkflows),
            ("compress to target size", testCompression),
            ("conversion engine routing", testEngineRouting),
        ]

        for (name, test) in tests {
            if let filter, !name.localizedCaseInsensitiveContains(filter) { continue }
            let start = Date()
            do {
                let detail = try await test(ctx)
                let ms = Int(Date().timeIntervalSince(start) * 1000)
                ctx.report.passed += 1
                log("PASS  \(name) (\(ms) ms)" + (detail.map { " — \($0)" } ?? ""))
            } catch let s as Skip {
                ctx.report.skipped += 1
                log("SKIP  \(name) — \(s.reason)")
            } catch let w as Warn {
                ctx.report.warnings += 1
                ctx.report.passed += 1
                log("WARN  \(name) — \(w.reason)")
            } catch {
                ctx.report.failed += 1
                let message = (error as? LocalizedError)?.errorDescription ?? "\(error)"
                ctx.report.failures.append("\(name): \(message)")
                log("FAIL  \(name) — \(message)")
            }
        }
        log("")
        log("Result: \(ctx.report.passed) passed (\(ctx.report.warnings) with warnings), \(ctx.report.failed) failed, \(ctx.report.skipped) skipped")
        if !keepFiles { try? FileManager.default.removeItem(at: dir) }
        return ctx.report
    }

    // MARK: Fixtures

    static func makeFixtures(_ c: Context) throws {
        // RGBA test image with transparency and text.
        let img = testImage(width: 640, height: 480, text: "HEXSHIFT Test 123")
        try ImageEncoder.writeImageIO([(img, [:])], type: "public.png", to: c.file("sample.png"))

        // Opaque photo-like JPEG with GPS + orientation 6 (rotated 90° CW for display).
        let photo = ImageOps.flatten(testImage(width: 640, height: 480, text: "Photo"))
        let props: [CFString: Any] = [
            kCGImagePropertyOrientation: 6,
            kCGImagePropertyGPSDictionary: [kCGImagePropertyGPSLatitude: 19.07, kCGImagePropertyGPSLatitudeRef: "N",
                                            kCGImagePropertyGPSLongitude: 72.87, kCGImagePropertyGPSLongitudeRef: "E"],
            kCGImagePropertyExifDictionary: [kCGImagePropertyExifDateTimeOriginal: "2026:10:24 01:00:00"],
            kCGImageDestinationLossyCompressionQuality: 0.9,
        ]
        try ImageEncoder.writeImageIO([(photo, props)], type: "public.jpeg", to: c.file("photo.jpg"))

        // A PNG with the wrong extension.
        try FileManager.default.copyItem(at: c.file("sample.png"), to: c.file("mislabelled.jpg"))

        // Animated GIF, 5 frames.
        var frames: [AnimationFrame] = []
        for i in 0..<5 {
            guard let ctx = ImageOps.makeContext(width: 120, height: 90) else { continue }
            ctx.setFillColor(RGBAColour(r: Double(i) / 4, g: 0.4, b: 1 - Double(i) / 4).cgColor)
            ctx.fill(CGRect(x: 0, y: 0, width: 120, height: 90))
            ctx.setFillColor(RGBAColour.white.cgColor)
            ctx.fill(CGRect(x: 10 + i * 18, y: 30, width: 20, height: 20))
            if let f = ctx.makeImage() { frames.append(AnimationFrame(image: f, delay: 0.1)) }
        }
        try ImageEncoder.writeAnimation(frames, loopCount: 0, format: .gif, to: c.file("anim.gif"))

        // 3-page text PDF.
        try textPDF(pages: ["Page one confidential report", "Second page with SECRET-CODE 4711 inside", "Third page closing notes"],
                    to: c.file("doc.pdf"))

        // Image-only ("scanned") PDF.
        let scan = testImage(width: 1240, height: 1754, text: "Scanned invoice number 98765", background: .white, fontSize: 64)
        try ImageEncoder.writeImageIO([(scan, [kCGImagePropertyDPIWidth: 150, kCGImagePropertyDPIHeight: 150])], type: "public.png", to: c.file("scan.png"))
        try PDFEngine.makePDF(fromImages: [c.file("scan.png")], output: c.file("scan.pdf"))

        try Data("""
        # Quarterly Update

        Revenue grew **12%** this quarter, led by *design tools*.

        ## Highlights

        - Launched HEXSHIFT
        - Shipped `WebP` export
        1. First ordered
        2. Second ordered

        > Quote block

        | Name | Value |
        | --- | --- |
        | Alpha | 1 |
        | Beta | 2 |

        Visit [Example](https://example.com).
        """.utf8).write(to: c.file("notes.md"))

        try Data("name,city,amount\n\"Smith, Jo\",Mumbai,1200\nAsha,\"Pune \"\"East\"\"\",88.5\nRavi,Delhi,0042\n".utf8).write(to: c.file("table.csv"))

        try Data("""
        <svg xmlns="http://www.w3.org/2000/svg" width="200" height="120" viewBox="0 0 200 120">
          <rect width="200" height="120" fill="#F6F1EA"/>
          <circle cx="60" cy="60" r="40" fill="#FF6A4D"/>
          <rect x="120" y="30" width="60" height="60" rx="8" fill="#2B2A28"/>
        </svg>
        """.utf8).write(to: c.file("shapes.svg"))

        // Flat shapes for tracing / palette.
        guard let ctx = ImageOps.makeContext(width: 300, height: 200, opaque: true) else { throw Failure("context") }
        ctx.setFillColor(RGBAColour(r: 0.9, g: 0.1, b: 0.1).cgColor)
        ctx.fill(CGRect(x: 0, y: 0, width: 100, height: 200))
        ctx.setFillColor(RGBAColour(r: 0.1, g: 0.7, b: 0.2).cgColor)
        ctx.fill(CGRect(x: 100, y: 0, width: 100, height: 200))
        ctx.setFillColor(RGBAColour(r: 0.1, g: 0.2, b: 0.9).cgColor)
        ctx.fill(CGRect(x: 200, y: 0, width: 100, height: 200))
        ctx.setFillColor(RGBAColour.white.cgColor)
        ctx.fillEllipse(in: CGRect(x: 120, y: 60, width: 60, height: 60))
        if let shapes = ctx.makeImage() {
            try ImageEncoder.writeImageIO([(shapes, [:])], type: "public.png", to: c.file("shapes.png"))
        }
    }

    static func testImage(width: Int, height: Int, text: String, background: RGBAColour? = nil, fontSize: CGFloat = 48) -> CGImage {
        let ctx = ImageOps.makeContext(width: width, height: height)!
        if let bg = background {
            ctx.setFillColor(bg.cgColor)
            ctx.fill(CGRect(x: 0, y: 0, width: width, height: height))
        } else {
            // Gradient with a transparent left strip.
            for x in stride(from: width / 4, to: width, by: 4) {
                let t = Double(x) / Double(width)
                ctx.setFillColor(RGBAColour(r: 1 - t, g: 0.5, b: t).cgColor)
                ctx.fill(CGRect(x: x, y: 0, width: 4, height: height))
            }
        }
        TextDrawing.draw(text, in: ctx, at: CGPoint(x: CGFloat(width) * 0.1, y: CGFloat(height) * 0.55),
                         fontSize: fontSize, colour: .black, bold: true, fontName: "Helvetica-Bold")
        return ctx.makeImage()!
    }

    static func textPDF(pages: [String], to url: URL) throws {
        var box = CGRect(x: 0, y: 0, width: 612, height: 792)
        guard let ctx = CGContext(url as CFURL, mediaBox: &box, [kCGPDFContextTitle: "Self-test", kCGPDFContextAuthor: "HEXSHIFT"] as CFDictionary) else {
            throw Failure("pdf context")
        }
        for text in pages {
            ctx.beginPDFPage(nil)
            TextDrawing.draw(text, in: ctx, at: CGPoint(x: 72, y: 700), fontSize: 20, colour: .black, bold: false, fontName: "Helvetica")
            TextDrawing.draw("Body text for testing extraction.", in: ctx, at: CGPoint(x: 72, y: 660), fontSize: 12, colour: .black, bold: false, fontName: "Helvetica")
            ctx.endPDFPage()
        }
        ctx.closePDF()
    }

    static func decode(_ url: URL) throws -> (width: Int, height: Int, frames: Int, props: [CFString: Any]) {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil), CGImageSourceGetCount(src) > 0,
              let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any] else {
            throw Failure("cannot decode \(url.lastPathComponent)")
        }
        return ((props[kCGImagePropertyPixelWidth] as? Int) ?? 0, (props[kCGImagePropertyPixelHeight] as? Int) ?? 0,
                CGImageSourceGetCount(src), props)
    }

    // MARK: Tests

    static func testDetection(_ c: Context) async throws -> String? {
        try expect(Format.detect(c.file("sample.png")) == .png, "png")
        try expect(Format.detect(c.file("photo.jpg")) == .jpeg, "jpeg")
        try expect(Format.detect(c.file("mislabelled.jpg")) == .png, "PNG saved as .jpg should be detected as PNG")
        try expect(Format.detect(c.file("anim.gif")) == .gif, "gif")
        try expect(Format.detect(c.file("doc.pdf")) == .pdf, "pdf")
        try expect(Format.detect(c.file("shapes.svg")) == .svg, "svg")
        try expect(Format.detect(c.file("notes.md")) == .md, "md")
        let anim = AssetInspector.inspect(c.file("anim.gif"))
        try expect(anim.kind == .animatedImage && anim.frameCount == 5, "animated GIF kind/frames: \(anim.kind) \(anim.frameCount)")
        let photo = AssetInspector.inspect(c.file("photo.jpg"))
        try expect(photo.pixelWidth == 480 && photo.pixelHeight == 640, "display size should account for orientation")
        try expect(photo.hasGPS, "GPS should be detected")
        return nil
    }

    static func testImageFormats(_ c: Context) async throws -> String? {
        let asset = AssetInspector.inspect(c.file("sample.png"))
        var done: [String] = []
        for target in ConversionEngine.targets(for: asset) where target.isAvailable && target.format.category == .raster && target.variant == .standard {
            let outs = try await ConversionEngine.convert(asset, to: target, options: ConversionOptions(), planner: c.planner)
            try expect(outs.count == 1, "\(target.label): one output")
            let d = try decode(outs[0])
            if target.format != .ico && target.format != .icns {
                try expect(d.width == 640 && d.height == 480, "\(target.label) dimensions \(d.width)×\(d.height)")
            }
            if target.format == .jpeg {
                // Transparent strip must be flattened onto white.
                let img = try ImageLoader.load(outs[0]).image
                let buf = PixelBuffer(image: img)!
                let p = buf.rgba(x: 5, y: 5)
                try expect(p.r > 240 && p.g > 240 && p.b > 240, "JPEG alpha should flatten to white, got \(p)")
            }
            done.append(target.label)
        }
        // PDF and SVG wrappers
        for target in ConversionEngine.targets(for: asset) where target.format == .pdf || (target.format == .svg && target.variant == .standard) {
            let outs = try await ConversionEngine.convert(asset, to: target, options: ConversionOptions(), planner: c.planner)
            try ImageEncoder.validate(outs[0], format: target.format)
            done.append(target.label)
        }
        return done.joined(separator: " ")
    }

    static func testWebP(_ c: Context) async throws -> String? {
        let img = try ImageLoader.load(c.file("sample.png")).image
        let lossy = try ImageEncoder.encodeWebP(img, quality: 0.8, lossless: false)
        let lossless = try ImageEncoder.encodeWebP(img, quality: 1, lossless: true)
        for (name, data) in [("lossy", lossy), ("lossless", lossless)] {
            let url = c.file("t-\(name).webp")
            try data.write(to: url)
            let d = try decode(url)
            try expect(d.width == 640 && d.height == 480, "\(name) WebP decodes at the right size")
        }
        // Transparent pixels survive.
        let decoded = try ImageLoader.load(c.file("t-lossless.webp")).image
        let buf = PixelBuffer(image: decoded)!
        try expect(buf.alpha(x: 5, y: 5) < 10, "lossless WebP keeps transparency")
        return "lossy \(lossy.count / 1024) KB, lossless \(lossless.count / 1024) KB"
    }

    static func testOrientation(_ c: Context) async throws -> String? {
        let asset = AssetInspector.inspect(c.file("photo.jpg"))
        let outs = try await ConversionEngine.convert(asset, to: ConversionTarget(.png), options: ConversionOptions(), planner: c.planner)
        let d = try decode(outs[0])
        try expect(d.width == 480 && d.height == 640, "rotated output should be 480×640, got \(d.width)×\(d.height)")
        let o = (d.props[kCGImagePropertyOrientation] as? Int) ?? 1
        try expect(o == 1, "orientation tag should be reset to 1")
        return nil
    }

    static func testMetadata(_ c: Context) async throws -> String? {
        let asset = AssetInspector.inspect(c.file("photo.jpg"))
        func run(_ policy: MetadataPolicy) async throws -> [CFString: Any] {
            var o = ConversionOptions()
            o.image.metadata = policy
            let outs = try await ConversionEngine.convert(asset, to: ConversionTarget(.heic), options: o, planner: c.planner)
            return try decode(outs[0]).props
        }
        let keep = try await run(.preserve)
        try expect(keep[kCGImagePropertyGPSDictionary] != nil, "preserve keeps GPS")
        let noGPS = try await run(.stripGPS)
        try expect(noGPS[kCGImagePropertyGPSDictionary] == nil, "stripGPS removes GPS")
        try expect(noGPS[kCGImagePropertyExifDictionary] != nil, "stripGPS keeps EXIF")
        let none = try await run(.stripAll)
        try expect(none[kCGImagePropertyGPSDictionary] == nil, "stripAll removes GPS")
        let lossless = try QuickImageEdits.stripMetadata(asset, gpsOnly: true, planner: c.planner)
        try expect(try decode(lossless).props[kCGImagePropertyGPSDictionary] == nil, "lossless strip removes GPS")
        let all = try QuickImageEdits.stripMetadata(asset, gpsOnly: false, planner: c.planner)
        let allProps = try decode(all).props
        try expect(allProps[kCGImagePropertyGPSDictionary] == nil, "strip-all removes GPS")
        return nil
    }

    static func testAnimation(_ c: Context) async throws -> String? {
        let asset = AssetInspector.inspect(c.file("anim.gif"))
        let targets = ConversionEngine.targets(for: asset)
        var results: [String] = []
        for t in targets where t.variant == .animated {
            let outs = try await ConversionEngine.convert(asset, to: t, options: ConversionOptions(), planner: c.planner)
            if t.format == .mp4 || t.format == .mov {
                let tracks = try await AVURLAsset(url: outs[0]).loadTracks(withMediaType: .video)
                try expect(!tracks.isEmpty, "\(t.label) has a video track")
                results.append("\(t.label)✓")
            } else {
                let d = try decode(outs[0])
                try expect(d.frames == 5, "\(t.label) should keep 5 frames, has \(d.frames)")
                results.append("\(t.label)×\(d.frames)")
            }
        }
        let first = targets.first { $0.variant == .firstFrame && $0.format == .png }!
        let outs = try await ConversionEngine.convert(asset, to: first, options: ConversionOptions(), planner: c.planner)
        try expect(try decode(outs[0]).frames == 1, "first-frame export is a still")
        return results.joined(separator: " ")
    }

    static func testPDFToImages(_ c: Context) async throws -> String? {
        let asset = AssetInspector.inspect(c.file("doc.pdf"))
        try expect(asset.pageCount == 3, "3 pages")
        var o = ConversionOptions()
        o.pdfDPI = 100
        let all = try await ConversionEngine.convert(asset, to: ConversionTarget(.png), options: o, planner: c.planner)
        try expect(all.count == 3, "3 PNGs, got \(all.count)")
        for u in all {
            let d = try decode(u)
            try expect(abs(d.width - 850) <= 2 && abs(d.height - 1100) <= 2, "100 dpi letter page ≈ 850×1100, got \(d.width)×\(d.height)")
        }
        o.pdfPages = PDFEngine.parsePageList("2", pageCount: 3)
        let one = try await ConversionEngine.convert(asset, to: ConversionTarget(.jpeg), options: o, planner: c.planner)
        try expect(one.count == 1 && one[0].lastPathComponent.contains("-02"), "only page 2 exported: \(one.map(\.lastPathComponent))")
        try expect(PDFEngine.parsePageList("1-2, 3", pageCount: 3) == [0, 1, 2], "page list parsing")
        try expect(PDFEngine.parsePageList("4", pageCount: 3) == nil, "out-of-range pages rejected")
        return all.map(\.lastPathComponent).joined(separator: ", ")
    }

    static func testPDFAssembly(_ c: Context) async throws -> String? {
        let made = c.file("out/images.pdf")
        try PDFEngine.makePDF(fromImages: [c.file("sample.png"), c.file("shapes.png")], output: made, pageSize: .a4, margin: 36)
        try expect(PDFEngine.pageCount(made) == 2, "2 image pages")
        let merged = c.file("out/merged.pdf")
        try PDFEngine.merge([c.file("doc.pdf"), c.file("sample.png")], output: merged)
        try expect(PDFEngine.pageCount(merged) == 4, "merged has 4 pages")
        let parts = try PDFEngine.split(c.file("doc.pdf"), mode: .everyPage, planner: c.planner)
        try expect(parts.count == 3 && parts.allSatisfy { PDFEngine.pageCount($0) == 1 }, "split into 3 single pages")
        let ranges = try PDFEngine.split(c.file("doc.pdf"), mode: .ranges("1-2, 3"), planner: c.planner)
        try expect(ranges.map { PDFEngine.pageCount($0) } == [2, 1], "split by ranges")
        let extracted = c.file("out/extract.pdf")
        try PDFEngine.extractPages(c.file("doc.pdf"), pages: [0, 2], output: extracted)
        try expect(PDFEngine.pageCount(extracted) == 2, "extracted 2 pages")
        let text = try PDFEngine.extractText(extracted, ocrIfNeeded: false).text
        try expect(text.contains("Third") && !text.contains("SECRET"), "correct pages extracted")
        return nil
    }

    static func testPDFText(_ c: Context) async throws -> String? {
        let r = try PDFEngine.extractText(c.file("doc.pdf"), ocrIfNeeded: false)
        try expect(r.text.contains("confidential") && r.text.contains("SECRET-CODE"), "text found")
        try expect(!r.usedOCR, "no OCR needed for a text PDF")
        let asset = AssetInspector.inspect(c.file("doc.pdf"))
        let docx = try await ConversionEngine.convert(asset, to: ConversionTarget(.docx), options: ConversionOptions(), planner: c.planner)
        try expect(Format.sniffZip(docx[0]), "DOCX is a valid container")
        let back = try await MainActor.run { try DocumentConverter.attributedString(from: docx[0], format: .docx).string }
        try expect(back.contains("confidential"), "PDF → DOCX keeps the text")
        return nil
    }

    static func testOCR(_ c: Context) async throws -> String? {
        let r = try PDFEngine.extractText(c.file("scan.pdf"), ocrIfNeeded: true)
        try expect(r.usedOCR, "scanned PDF should use OCR")
        try expect(r.text.localizedCaseInsensitiveContains("invoice"), "OCR text: \(r.text.prefix(80))")
        return "“\(r.text.prefix(40))”"
    }

    static func testSearchable(_ c: Context) async throws -> String? {
        let out = c.file("out/searchable.pdf")
        let pages = try PDFEngine.makeSearchable(c.file("scan.pdf"), output: out)
        try expect(pages == 1, "one page recognised")
        let text = PDFDocument(url: out)?.string ?? ""
        try expect(text.localizedCaseInsensitiveContains("invoice"), "searchable text layer present: \(text.prefix(60))")
        return nil
    }

    static func testRedaction(_ c: Context) async throws -> String? {
        let areas = try PDFEngine.redactionAreas(matching: ["SECRET-CODE"], in: c.file("doc.pdf"))
        try expect(!areas.isEmpty && areas.allSatisfy { $0.pageIndex == 1 }, "found the term on page 2")
        let out = c.file("out/redacted.pdf")
        try PDFEngine.redact(c.file("doc.pdf"), areas: areas, output: out)
        let text = PDFDocument(url: out)?.string ?? ""
        try expect(!text.contains("SECRET"), "redacted text must be gone from the output")
        try expect(text.contains("confidential"), "other pages keep their text")
        // The pixels under the box are black.
        let page = PDFDocument(url: out)!.page(at: 1)!
        let img = PDFEngine.render(page, dpi: 72)!
        let buf = PixelBuffer(image: img)!
        let r = areas[0].rect
        let p = buf.rgba(x: Int(r.midX), y: buf.height - Int(r.midY))
        try expect(p.r < 30 && p.g < 30 && p.b < 30, "redaction box is opaque black")
        return "\(areas.count) area(s)"
    }

    static func testPDFUtilities(_ c: Context) async throws -> String? {
        let numbered = c.file("out/numbered.pdf")
        try PDFEngine.addPageNumbers(c.file("doc.pdf"), output: numbered, format: "Page {n} of {total}")
        let doc = PDFDocument(url: numbered)!
        let contents = (0..<doc.pageCount).compactMap { doc.page(at: $0)?.annotations.first?.contents }
        try expect(contents == ["Page 1 of 3", "Page 2 of 3", "Page 3 of 3"], "page number annotations: \(contents)")
        let stripped = c.file("out/stripped.pdf")
        try PDFEngine.stripMetadata(c.file("doc.pdf"), output: stripped)
        let attrs = PDFDocument(url: stripped)?.documentAttributes ?? [:]
        try expect(attrs[PDFDocumentAttribute.authorAttribute] == nil, "author removed")
        let stamped = c.file("out/stamped.pdf")
        try PDFEngine.stampText("DRAFT", on: c.file("doc.pdf"), output: stamped)
        try expect(PDFEngine.pageCount(stamped) == 3, "stamp keeps pages")
        var note = "compression: "
        do {
            let r = try PDFEngine.compress(c.file("scan.pdf"), output: c.file("out/compressed.pdf"))
            note += "\(r.before / 1024) KB → \(r.after / 1024) KB"
        } catch {
            note += (error as? LocalizedError)?.errorDescription ?? "\(error)"
        }
        return note
    }

    static func testPDFPassword(_ c: Context) async throws -> String? {
        let locked = c.file("out/locked.pdf")
        try PDFEngine.protect(c.file("doc.pdf"), output: locked, password: "hex-42")
        let reopened = PDFDocument(url: locked)!
        try expect(reopened.isEncrypted && reopened.isLocked, "protected copy is locked")
        try expect(!reopened.unlock(withPassword: "wrong"), "wrong password rejected")
        var rejected = false
        do { try PDFEngine.removePassword(locked, password: "nope", output: c.file("out/should-not-exist.pdf")) } catch { rejected = true }
        try expect(rejected, "removing with a wrong password must fail")
        try expect(!FileManager.default.fileExists(atPath: c.file("out/should-not-exist.pdf").path), "no file left after failure")
        let unlocked = c.file("out/unlocked.pdf")
        try PDFEngine.removePassword(locked, password: "hex-42", output: unlocked)
        let open = PDFDocument(url: unlocked)!
        try expect(!open.isEncrypted && !open.isLocked, "unprotected copy opens without a password")
        try expect((open.string ?? "").contains("SECRET-CODE"), "text survives the round trip")
        return "\(open.pageCount) pages round-tripped"
    }

    static func testPDFMarkup(_ c: Context) async throws -> String? {
        let doc = try PDFEngine.open(c.file("doc.pdf"))
        let page = doc.page(at: 0)!
        let before = page.annotations.count
        PDFEngine.addInk([[CGPoint(x: 100, y: 120), CGPoint(x: 300, y: 120)]], to: page, colour: .black, lineWidth: 6)
        PDFEngine.addTextBox("HELLO-BOX", to: page, visualRect: CGRect(x: 100, y: 420, width: 320, height: 60), fontSize: 28)
        PDFEngine.addNote("Check this", to: page, visualPoint: CGPoint(x: 500, y: 700))
        PDFEngine.addBox(to: page, visualRect: CGRect(x: 100, y: 250, width: 200, height: 60), colour: RGBAColour(r: 1, g: 0.8, b: 0), filled: true)
        let marked = c.file("out/marked.pdf")
        try PDFEngine.save(doc, to: marked)
        let reopened = PDFDocument(url: marked)!.page(at: 0)!
        try expect(reopened.annotations.count >= before + 4, "annotations kept as annotations (\(reopened.annotations.count))")
        let img = PDFEngine.render(reopened, dpi: 72)!
        let buf = PixelBuffer(image: img)!
        let ink = buf.rgba(x: 200, y: buf.height - 120)
        try expect(ink.r < 90 && ink.g < 90 && ink.b < 90, "ink stroke drawn where it was placed (got \(ink))")
        let box = buf.rgba(x: 200, y: buf.height - 280)
        try expect(box.b < box.r - 40, "highlight box tints the page yellow (got \(box))")
        var textPixels = 0
        for x in stride(from: 100, to: 420, by: 2) {
            for y in stride(from: 420, to: 480, by: 2) {
                let p = buf.rgba(x: x, y: buf.height - y)
                if p.r < 100 && p.g < 100 && p.b < 100 { textPixels += 1 }
            }
        }
        try expect(textPixels > 20, "text box text is visible (\(textPixels) dark samples)")

        let resized = c.file("out/a4-margins.pdf")
        try PDFEngine.resizePages(c.file("doc.pdf"), output: resized, size: .a4, orientation: .portrait, margin: 36)
        let r = PDFDocument(url: resized)!
        let bounds = r.page(at: 0)!.bounds(for: .mediaBox)
        try expect(abs(bounds.width - 595.28) < 1 && abs(bounds.height - 841.89) < 1, "pages are A4 (\(bounds.size))")
        try expect((r.string ?? "").contains("SECRET-CODE"), "text stays selectable after resizing")
        return "\(reopened.annotations.count) annotations; A4 with 0.5 in margins"
    }

    static func testPermissions(_ c: Context) async throws -> String? {
        if getuid() == 0 { throw Skip(reason: "running as root, so file permissions aren't enforced") }
        let fm = FileManager.default
        // 1. A file HEXSHIFT isn't allowed to read.
        let locked = c.file("locked.png")
        try fm.copyItem(at: c.file("sample.png"), to: locked)
        try fm.setAttributes([.posixPermissions: 0o000], ofItemAtPath: locked.path)
        defer { try? fm.setAttributes([.posixPermissions: 0o644], ofItemAtPath: locked.path) }
        let lockedAsset = AssetInspector.inspect(locked)
        var refused = true
        if let target = ConversionEngine.targets(for: lockedAsset).first(where: { $0.format == .jpeg }) {
            refused = false
            do { _ = try await ConversionEngine.convert(lockedAsset, to: target, options: ConversionOptions(), planner: c.planner) } catch { refused = true }
        }
        try expect(refused, "an unreadable file is refused with an error")

        // 2. A destination folder that can't be written to.
        let readOnly = c.file("read-only")
        try fm.createDirectory(at: readOnly, withIntermediateDirectories: true)
        try fm.setAttributes([.posixPermissions: 0o555], ofItemAtPath: readOnly.path)
        defer { try? fm.setAttributes([.posixPermissions: 0o755], ofItemAtPath: readOnly.path) }
        let planner = OutputPlanner(settings: OutputSettings(destination: .custom(path: readOnly.path), naming: .suffix("-converted")))
        let source = AssetInspector.inspect(c.file("sample.png"))
        guard let jpeg = ConversionEngine.targets(for: source).first(where: { $0.format == .jpeg }) else { throw Failure("no JPEG target") }
        var writeFailed = false
        do { _ = try await ConversionEngine.convert(source, to: jpeg, options: ConversionOptions(), planner: planner) } catch { writeFailed = true }
        try expect(writeFailed, "writing into a read-only folder reports an error")
        let leftovers = (try? fm.contentsOfDirectory(atPath: readOnly.path)) ?? []
        try expect(leftovers.isEmpty, "nothing (not even a temp file) is left in the read-only folder: \(leftovers)")
        try expect(fm.fileExists(atPath: c.file("sample.png").path), "the original is untouched")
        return "both fail cleanly"
    }

    static func testPDFFonts(_ c: Context) async throws -> String? {
        let fonts = PDFEngine.fontsUsed(c.file("doc.pdf"))
        try expect(fonts.contains { $0.name.contains("Helvetica") }, "Helvetica listed: \(fonts.map(\.name))")
        return fonts.map { "\($0.name)\($0.embedded ? " (embedded)" : "")" }.joined(separator: ", ")
    }

    static func testDocuments(_ c: Context) async throws -> String? {
        let md = AssetInspector.inspect(c.file("notes.md"))
        var opts = ConversionOptions()
        opts.document.useExternalEngines = false
        var produced: [String] = []
        for f in [Format.html, .docx, .rtf, .odt, .pdf, .txt] {
            let outs = try await ConversionEngine.convert(md, to: ConversionTarget(f), options: opts, planner: c.planner)
            produced.append(f.shortName)
            if f == .docx {
                let back = try await MainActor.run { try DocumentConverter.attributedString(from: outs[0], format: .docx) }
                try expect(back.string.contains("Quarterly Update") && back.string.contains("Launched HEXSHIFT"), "DOCX content")
                let mdBack = MarkdownWriter.markdown(from: back)
                try expect(mdBack.contains("# Quarterly Update") || mdBack.contains("## Quarterly Update"), "DOCX → Markdown keeps the heading: \(mdBack.prefix(80))")
                try expect(mdBack.contains("**12%**"), "bold survives the round trip")
                // DOCX → PDF with the built-in engine
                let docxAsset = AssetInspector.inspect(outs[0])
                let pdf = try await ConversionEngine.convert(docxAsset, to: ConversionTarget(.pdf), options: opts, planner: c.planner)
                let text = PDFDocument(url: pdf[0])?.string ?? ""
                try expect(text.contains("Quarterly Update"), "DOCX → PDF keeps the text")
            }
            if f == .pdf {
                let doc = PDFDocument(url: outs[0])!
                let size = doc.page(at: 0)!.bounds(for: .mediaBox).size
                try expect(abs(size.width - 595.28) < 2 && abs(size.height - 841.89) < 2, "A4 page, got \(size)")
                try expect((doc.string ?? "").contains("Revenue grew"), "PDF has the text")
            }
        }
        // Plain text → PDF with a chosen font and size (Journey 5).
        let out = c.file("out/selected-text.pdf")
        var docOpts = DocumentOptions()
        docOpts.pageSize = .letter
        docOpts.fontName = "Georgia"
        docOpts.fontSize = 14
        try await MainActor.run { [docOpts] in
            try DocumentConverter.export(text: "A paragraph highlighted in another app.\n\nSecond paragraph.", as: .pdf, to: out, options: docOpts)
        }
        try expect((PDFDocument(url: out)?.string ?? "").contains("highlighted"), "text → PDF")
        return produced.joined(separator: " ")
    }

    static func testTables(_ c: Context) async throws -> String? {
        let rows = try TableConverter.read(c.file("table.csv"), format: .csv)
        try expect(rows.count == 4 && rows[1][0] == "Smith, Jo" && rows[2][1] == "Pune \"East\"", "CSV parsing with quotes: \(rows)")
        let xlsx = c.file("out/table.xlsx")
        try TableConverter.writeXLSX(rows, to: xlsx)
        let back = try TableConverter.readXLSX(xlsx)
        try expect(back == rows, "XLSX round trip: \(back)")
        let json = TableConverter.json(rows)
        let parsed = try JSONSerialization.jsonObject(with: Data(json.utf8)) as? [[String: Any]]
        try expect(parsed?.count == 3, "JSON rows")
        try expect((parsed?[2]["amount"] as? String) == "0042", "leading zeros kept as text")
        let asset = AssetInspector.inspect(c.file("table.csv"))
        let pdf = try await ConversionEngine.convert(asset, to: ConversionTarget(.pdf), options: ConversionOptions(), planner: c.planner)
        try expect((PDFDocument(url: pdf[0])?.string ?? "").contains("Mumbai"), "table PDF")
        return nil
    }

    static func testSVG(_ c: Context) async throws -> String? {
        try expect(SVGSupport.intrinsicSize(of: c.file("shapes.svg")) == CGSize(width: 200, height: 120), "intrinsic size")
        let asset = AssetInspector.inspect(c.file("shapes.svg"))
        let png = try await ConversionEngine.convert(asset, to: ConversionTarget(.png), options: ConversionOptions(), planner: c.planner)
        let d = try decode(png[0])
        try expect(d.width == 400 && d.height == 240, "rendered at 2×: \(d.width)×\(d.height)")
        let img = try ImageLoader.load(png[0]).image
        let p = PixelBuffer(image: img)!.rgba(x: 120, y: 120)
        try expect(p.r > 200 && p.g < 160, "circle colour rendered: \(p)")
        let pdf = try await ConversionEngine.convert(asset, to: ConversionTarget(.pdf), options: ConversionOptions(), planner: c.planner)
        try ImageEncoder.validate(pdf[0], format: .pdf)
        return SVGSupport.renderNative(c.file("shapes.svg")) != nil ? "native AppKit renderer" : "WebKit fallback renderer"
    }

    static func testTrace(_ c: Context) async throws -> String? {
        let img = try ImageLoader.load(c.file("shapes.png")).image
        let svg = VectorTracer.trace(img, colours: 4)
        try expect(XMLValidator.isWellFormed(Data(svg.utf8)), "well-formed SVG")
        let paths = svg.components(separatedBy: "<path").count - 1
        try expect(paths >= 3, "at least 3 colour layers, got \(paths)")
        let url = c.file("out/trace.svg")
        try Data(svg.utf8).write(to: url)
        if let rendered = SVGSupport.renderNative(url) {
            let p = PixelBuffer(image: rendered)!.rgba(x: 50, y: 100)
            try expect(p.r > 180 && p.b < 90, "traced red region renders red: \(p)")
        }
        return "\(paths) paths, \(svg.count / 1024) KB"
    }

    static func testIcons(_ c: Context) async throws -> String? {
        let img = try ImageLoader.load(c.file("sample.png")).image
        var notes: [String] = []
        for f in [Format.ico, .icns] where ImageEncoder.canWrite(f) {
            let url = c.file("out/icon.\(f.fileExtension)")
            try ImageEncoder.write(img, format: f, to: url)
            let d = try decode(url)
            try expect(d.frames >= 4, "\(f.displayName) should contain several sizes, has \(d.frames)")
            notes.append("\(f.displayName)×\(d.frames)")
        }
        if notes.isEmpty { throw Skip(reason: "ImageIO can't write ICO/ICNS on this macOS") }
        return notes.joined(separator: " ")
    }

    static func testColour(_ c: Context) async throws -> String? {
        let teal = ColourMath.parse("#16A085")!
        try expect(ColourMath.rgbString(teal) == "22, 160, 133", "RGB \(ColourMath.rgbString(teal))")
        let hsl = ColourMath.hsl(teal)
        try expect(Int(hsl.h.rounded()) == 168 && Int(hsl.s.rounded()) == 76 && Int(hsl.l.rounded()) == 36, "HSL \(ColourMath.hslString(teal))")
        try expect(ColourMath.parse("rgb(22, 160, 133)")?.hex == "#16A085", "rgb() parsing")
        try expect(ColourMath.parse("hsl(168, 76%, 36%)").map { ColourMath.deltaE(ColourMath.lab($0), ColourMath.lab(teal)) < 2 } == true, "hsl() parsing")
        try expect(abs(ColourMath.contrastRatio(.black, .white) - 21) < 0.01, "black/white contrast is 21:1")
        try expect(ColourMath.contrast(ColourMath.parse("#767676")!, .white).aaNormal, "#767676 on white passes AA")
        let lab = ColourMath.lab(teal)
        try expect(ColourMath.fromLab(lab).hex == "#16A085", "Lab round trip")
        let red = ColourMath.oklch(RGBAColour(r: 1, g: 0, b: 0))
        try expect(abs(red.l - 0.628) < 0.002 && abs(red.c - 0.2577) < 0.002 && abs(red.h - 29.23) < 0.3, "OKLCH of red: \(ColourMath.oklchString(RGBAColour(r: 1, g: 0, b: 0)))")
        try expect(ColourMath.fromOKLCH(ColourMath.oklch(teal)).hex == "#16A085", "OKLCH round trip")
        try expect(abs(ColourMath.apcaContrast(text: .black, background: .white) - 106.04) < 0.2, "APCA black on white ≈ Lc 106")
        try expect(abs(ColourMath.apcaContrast(text: .white, background: .black) + 107.88) < 0.2, "APCA white on black ≈ Lc −108")
        let tri = ColourMath.harmony(.triadic, of: teal)
        try expect(tri.count == 3 && tri[0] == teal, "triadic harmony keeps the base colour first")
        let hues = tri.map { ColourMath.oklch($0).h }
        try expect(abs(((hues[1] - hues[0]) + 360).truncatingRemainder(dividingBy: 360) - 120) < 4, "triadic hues are 120° apart: \(hues)")
        let scale = ColourMath.tonalScale(teal)
        try expect(scale.count == 11 && scale.contains { $0.colour == teal }, "tonal scale contains the base colour")
        let ls = scale.map { ColourMath.oklch($0.colour).l }
        try expect(zip(ls, ls.dropFirst()).allSatisfy { $0 > $1 }, "tonal scale goes from light to dark")
        let grey = RGBAColour(r: 0.5, g: 0.5, b: 0.5)
        try expect(ColourMath.VisionDeficiency.allCases.allSatisfy { ColourMath.deltaE(ColourMath.lab(ColourMath.simulate(grey, $0)), ColourMath.lab(grey)) < 3 }, "neutral grey looks the same to everyone")
        let protanRed = ColourMath.simulate(RGBAColour(r: 1, g: 0, b: 0), .protanopia)
        try expect(protanRed.r < 0.7, "protanopia darkens red")
        let ase = PaletteExporter.aseData([(name: "Teal", colour: teal)])
        try expect(ase.prefix(4) == Data("ASEF".utf8) && ase.count == 12 + 6 + 2 + 10 + 4 + 12 + 2, "ASE layout (\(ase.count) bytes)")
        try expect(PaletteExporter.tailwindConfig([(name: "Brand", colour: teal)]).contains("500:"), "Tailwind scale exported")
        return "\(teal.hex) · \(ColourMath.rgbString(teal)) · \(ColourMath.hslString(teal)) · \(ColourMath.cmykString(teal))"
    }

    static func testPalette(_ c: Context) async throws -> String? {
        let img = try ImageLoader.load(c.file("shapes.png")).image
        let palette = PaletteExtractor.extract(from: img, count: 5)
        let names = palette.map { $0.colour.hex }
        func has(_ r: Double, _ g: Double, _ b: Double) -> Bool {
            palette.contains { ColourMath.deltaE(ColourMath.lab($0.colour), ColourMath.lab(RGBAColour(r: r, g: g, b: b))) < 8 }
        }
        try expect(has(0.9, 0.1, 0.1) && has(0.1, 0.7, 0.2) && has(0.1, 0.2, 0.9), "palette finds red, green and blue: \(names)")
        // Horizontal red → blue gradient
        let ctx = ImageOps.makeContext(width: 200, height: 60, opaque: true)!
        for x in 0..<200 {
            let t = Double(x) / 199
            ctx.setFillColor(RGBAColour(r: 1 - t, g: 0, b: t).cgColor)
            ctx.fill(CGRect(x: x, y: 0, width: 1, height: 60))
        }
        let g = GradientEstimator.estimate(ctx.makeImage()!)!
        try expect(abs(g.cssAngle - 90) < 5, "gradient angle ≈ 90°, got \(g.cssAngle)")
        try expect(g.start.r > 0.8 && g.end.b > 0.8, "gradient ends: \(g.css)")
        return names.joined(separator: " ") + " · " + g.css
    }

    static func testAdjustments(_ c: Context) async throws -> String? {
        let ctx = ImageOps.makeContext(width: 40, height: 40, opaque: true)!
        ctx.setFillColor(RGBAColour(r: 0.5, g: 0.5, b: 0.5).cgColor)
        ctx.fill(CGRect(x: 0, y: 0, width: 40, height: 40))
        let grey = ctx.makeImage()!
        var warm = Adjustments()
        warm.warmth = 1
        let w = PixelBuffer(image: ImageEffects.apply(warm, to: grey))!.rgba(x: 20, y: 20)
        try expect(w.r > w.b + 5, "warmth +1 should make the image warmer (R>B): \(w)")
        var mono = Adjustments()
        mono.grayscale = true
        let colourful = try ImageLoader.load(c.file("shapes.png")).image
        let m = PixelBuffer(image: ImageEffects.apply(mono, to: colourful))!.rgba(x: 50, y: 100)
        try expect(abs(m.r - m.g) < 6 && abs(m.g - m.b) < 6, "grayscale: \(m)")
        return nil
    }

    static func testBackground(_ c: Context) async throws -> String? {
        // A simple subject: a dark rounded shape on a light background.
        let ctx = ImageOps.makeContext(width: 400, height: 400, opaque: true)!
        ctx.setFillColor(RGBAColour(r: 0.92, g: 0.92, b: 0.9).cgColor)
        ctx.fill(CGRect(x: 0, y: 0, width: 400, height: 400))
        ctx.setFillColor(RGBAColour(r: 0.8, g: 0.2, b: 0.1).cgColor)
        ctx.fillEllipse(in: CGRect(x: 100, y: 60, width: 200, height: 280))
        do {
            let out = try BackgroundRemoval.removeBackground(ctx.makeImage()!)
            let buf = PixelBuffer(image: out)!
            let corner = buf.alpha(x: 5, y: 5)
            let centre = buf.alpha(x: 200, y: 200)
            try expect(centre > 200, "subject kept")
            if corner > 40 { throw Warn(reason: "subject found but background not fully transparent (corner alpha \(corner))") }
            return "subject isolated"
        } catch HexError.noSubjectFound {
            throw Warn(reason: "Vision found no subject in the synthetic test image (real photos work better)")
        }
    }

    static func testFontMatch(_ c: Context) async throws -> String? {
        let family = NSFontManager.shared.availableFontFamilies.contains("Georgia") ? "Georgia" : "Times New Roman"
        let ps = family == "Georgia" ? "Georgia-Bold" : "TimesNewRomanPS-BoldMT"
        let ctx = ImageOps.makeContext(width: 900, height: 160, opaque: true)!
        ctx.setFillColor(RGBAColour.white.cgColor)
        ctx.fill(CGRect(x: 0, y: 0, width: 900, height: 160))
        TextDrawing.draw("Sphinx of black quartz", in: ctx, at: CGPoint(x: 30, y: 60), fontSize: 64, colour: .black, bold: false, fontName: ps)
        let report = try FontMatcher.analyse(image: ctx.makeImage()!, limit: 8)
        try expect(!report.candidates.isEmpty, "candidates returned")
        let rank = report.candidates.firstIndex { $0.familyName == family }
        let top = report.candidates.prefix(3).map { "\($0.familyName) \($0.styleName) \(Int($0.similarity * 100))%" }.joined(separator: ", ")
        guard let r = rank else { throw Warn(reason: "\(family) not in the top 8 (top: \(top))") }
        if r > 2 { throw Warn(reason: "\(family) ranked #\(r + 1) (top: \(top))") }
        return "\(family) ranked #\(r + 1) · \(top)"
    }

    /// End-to-end accuracy check: real text images (OCR included) in common macOS fonts at
    /// screenshot sizes, plus a few Google Fonts drawn from the bundled reference.
    static func testFontBenchmark(_ c: Context) async throws -> String? {
        let texts = ["Design is how it works", "Get started for free", "Pricing plans for teams", "Book your table tonight",
                     "Summer Collection", "Find your next home", "Typography matters", "Join the waitlist"]
        let mac: [(String, CGFloat, CGFloat)] = [
            ("Helvetica", 15, 2), ("ArialMT", 22, 1), ("TimesNewRomanPSMT", 28, 1), ("Georgia", 18, 2), ("Verdana", 14, 2),
            ("Futura-Medium", 36, 1), ("AvenirNext-Regular", 24, 1), ("GillSans", 30, 1), ("Optima-Regular", 26, 1),
            ("Baskerville", 32, 1), ("Didot", 40, 1), ("Palatino-Roman", 20, 2), ("Menlo-Regular", 16, 2),
            ("TrebuchetMS", 22, 1), ("HoeflerText-Regular", 28, 1), ("AmericanTypewriter", 24, 1),
        ]
        var cases: [(image: CGImage, family: String)] = []
        for (i, (ps, size, scale)) in mac.enumerated() {
            let font = CTFontCreateWithName(ps as CFString, size * scale, nil)
            guard (CTFontCopyPostScriptName(font) as String) == ps else { continue }
            let family = CTFontCopyFamilyName(font) as String
            let text = texts[i % texts.count]
            let w = Int(size * scale * CGFloat(text.count) * 0.75) + 40, h = Int(size * scale * 2.2)
            guard let ctx = ImageOps.makeContext(width: w, height: h, opaque: true) else { continue }
            ctx.setFillColor(RGBAColour.white.cgColor)
            ctx.fill(CGRect(x: 0, y: 0, width: w, height: h))
            TextDrawing.draw(text, in: ctx, at: CGPoint(x: 20, y: CGFloat(h) * 0.35), fontSize: size * scale, colour: RGBAColour(r: 0.1, g: 0.1, b: 0.1),
                             bold: false, fontName: ps)
            if let img = ctx.makeImage() { cases.append((img, family)) }
        }
        // Google Fonts that aren't installed: drawn from the reference itself (checks the whole pipeline).
        if FontReference.shared != nil {
            for (i, fam) in ["Poppins", "Montserrat", "Inter", "Playfair Display", "Roboto"].enumerated()
            where !NSFontManager.shared.availableFontFamilies.contains(fam) {
                let cand = FontCandidate(postScriptName: fam, familyName: fam, displayName: fam, styleName: "Regular", cssWeight: 400,
                                         isItalic: false, category: .sansSerif, similarity: 1, source: .googleFonts(slug: fam))
                guard let mask = FontMatcher.referencePreview(text: texts[(i + 3) % texts.count], candidate: cand, emPixels: 40, asMask: true),
                      let ctx = ImageOps.makeContext(width: mask.width + 40, height: mask.height + 40, opaque: true) else { continue }
                ctx.setFillColor(RGBAColour.white.cgColor)
                ctx.fill(CGRect(x: 0, y: 0, width: mask.width + 40, height: mask.height + 40))
                let r = CGRect(x: 20, y: 20, width: mask.width, height: mask.height)
                ctx.clip(to: r, mask: mask)
                ctx.setFillColor(RGBAColour(r: 0.1, g: 0.1, b: 0.1).cgColor)
                ctx.fill(r)
                if let img = ctx.makeImage() { cases.append((img, fam)) }
            }
        }
        guard !cases.isEmpty else { throw Skip(reason: "no test fonts available") }
        var top1 = 0, top3 = 0
        var misses: [String] = []
        for (img, family) in cases {
            guard let report = try? FontMatcher.analyse(image: img, limit: 40) else { misses.append("\(family): no text"); continue }
            let names = report.candidates.map(\.familyName)
            if names.first == family { top1 += 1 } else {
                let top = report.candidates.prefix(3).map { "\($0.familyName) \($0.styleName) \(Int(($0.similarity * 1000).rounded()))" }.joined(separator: "/")
                let truth = report.candidates.firstIndex { $0.familyName == family }
                    .map { "#\($0 + 1) \(report.candidates[$0].styleName) \(Int((report.candidates[$0].similarity * 1000).rounded()))" } ?? "not in 40"
                misses.append("\(family) '\(report.sample.text)' →[\(top)] truth \(truth)")
            }
            if names.prefix(3).contains(family) { top3 += 1 }
        }
        let n = cases.count
        let summary = "top-1 \(top1)/\(n), top-3 \(top3)/\(n)" + (misses.isEmpty ? "" : " · missed: " + misses.joined(separator: ", "))
        if Double(top3) / Double(n) < 0.8 { throw Warn(reason: summary) }
        return summary
    }

    static func testOutputNaming(_ c: Context) async throws -> String? {
        let src = c.file("sample.png")
        let same = OutputPlanner(settings: OutputSettings(destination: .sameFolder, naming: .originalName))
        let u = same.url(for: src, ext: "png")
        try expect(u.path != src.path, "never returns the source path: \(u.lastPathComponent)")
        try expect(u.lastPathComponent == "sample 2.png", "Finder-style unique name, got \(u.lastPathComponent)")
        let suffix = OutputPlanner(settings: OutputSettings(destination: .sameFolder, naming: .suffix("-converted")))
        try expect(suffix.url(for: src, ext: "jpg").lastPathComponent == "sample-converted.jpg", "default naming")
        let custom = OutputPlanner(settings: OutputSettings(destination: .sameFolder, naming: .custom("{name}_{format}_{w}x{h}")))
        try expect(custom.url(for: src, ext: "webp", format: "WebP", pixelSize: (640, 480)).lastPathComponent == "sample_webp_640x480.webp", "custom pattern")
        // Converting twice never overwrites.
        let asset = AssetInspector.inspect(src)
        let a = try await ConversionEngine.convert(asset, to: ConversionTarget(.jpeg), options: ConversionOptions(), planner: c.planner)
        let b = try await ConversionEngine.convert(asset, to: ConversionTarget(.jpeg), options: ConversionOptions(), planner: c.planner)
        try expect(a[0] != b[0] && FileManager.default.fileExists(atPath: a[0].path), "second conversion gets a new name: \(b[0].lastPathComponent)")
        return b[0].lastPathComponent
    }

    @MainActor
    static func testBatch(_ c: Context) async throws -> String? {
        let dir = c.file("batch")
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        var items: [URL] = []
        let img = try ImageLoader.load(c.file("shapes.png")).image
        for i in 0..<8 {
            let u = dir.appendingPathComponent("img\(i).png")
            try ImageEncoder.writeImageIO([(img, [:])], type: "public.png", to: u)
            items.append(u)
        }
        // One deliberately broken file: the batch must report it and carry on.
        let corrupt = dir.appendingPathComponent("broken.png")
        try Data([0x89, 0x50, 0x4E, 0x47, 0, 1, 2, 3]).write(to: corrupt)
        items.append(corrupt)
        let planner = c.planner
        let job = BatchJob(title: "Batch", items: items, concurrency: 3) { url in
            let asset = AssetInspector.inspect(url)
            return try await ConversionEngine.convert(asset, to: ConversionTarget(.webp), options: ConversionOptions(), planner: planner)
        }
        await job.wait()
        try expect(job.isFinished && job.completed == 9, "all items processed")
        try expect(job.outputs.count == 8 && job.failures.count == 1, "8 outputs + 1 reported failure, got \(job.outputs.count)/\(job.failures.count)")
        try expect(job.failures[0].item.lastPathComponent == "broken.png", "failure names the file")
        // Cancellation
        let slow = BatchJob(title: "Slow", items: Array(repeating: c.file("sample.png"), count: 30), concurrency: 2) { _ in
            try await Task.sleep(nanoseconds: 50_000_000)
            return []
        }
        try await Task.sleep(nanoseconds: 120_000_000)
        slow.cancel()
        await slow.wait()
        try expect(slow.isCancelled && slow.completed < 30, "cancelled early (\(slow.completed)/30)")
        return job.summary + " · cancelled after \(slow.completed)"
    }

    static func testCorrupted(_ c: Context) async throws -> String? {
        let bad = c.file("garbage.png")
        try Data((0..<2048).map { _ in UInt8.random(in: 0...255) }).write(to: bad)
        let outDir = c.file("out-corrupt")
        let planner = OutputPlanner(settings: OutputSettings(destination: .custom(path: outDir.path), naming: .suffix("-converted")))
        let asset = AssetInspector.inspect(bad)
        do {
            _ = try await ConversionEngine.convert(asset, to: ConversionTarget(.jpeg), options: ConversionOptions(), planner: planner)
            throw Failure("a corrupted file should not convert")
        } catch is Failure {
            throw Failure("a corrupted file should not convert")
        } catch {
            let leftovers = (try? FileManager.default.contentsOfDirectory(atPath: outDir.path)) ?? []
            try expect(leftovers.isEmpty, "no partial output left behind: \(leftovers)")
            return (error as? LocalizedError)?.errorDescription
        }
    }

    static func testVideo(_ c: Context) async throws -> String? {
        var frames: [AnimationFrame] = []
        for i in 0..<24 {
            let ctx = ImageOps.makeContext(width: 320, height: 240, opaque: true)!
            ctx.setFillColor(RGBAColour(r: Double(i) / 23, g: 0.3, b: 0.6).cgColor)
            ctx.fill(CGRect(x: 0, y: 0, width: 320, height: 240))
            frames.append(AnimationFrame(image: ctx.makeImage()!, delay: 1.0 / 12))
        }
        let mp4 = c.file("clip.mp4")
        try await MediaConverter.writeVideo(frames, to: mp4, fileType: .mp4)
        let asset = AssetInspector.inspect(mp4)
        try expect(asset.kind == .video, "MP4 recognised as video")
        var done: [String] = []
        for f in [Format.mov, .gif, .png] {
            var o = ConversionOptions()
            o.video.quality = .passthrough
            let outs = try await ConversionEngine.convert(asset, to: ConversionTarget(f), options: o, planner: c.planner)
            if f == .gif {
                try expect(try decode(outs[0]).frames > 5, "GIF has frames")
            } else if f == .png {
                try expect(try decode(outs[0]).width == 320, "frame size")
            } else {
                try expect(await MediaConverter.duration(outs[0]) ?? 0 > 1.5, "MOV duration")
            }
            done.append(f.shortName)
        }
        do {
            _ = try await ConversionEngine.convert(asset, to: ConversionTarget(.m4a), options: ConversionOptions(), planner: c.planner)
            throw Failure("silent clip should report no audio")
        } catch let e as HexError {
            try expect(e.localizedDescription.contains("no audio"), "clear message for missing audio")
        }
        return done.joined(separator: " ")
    }

    static func testTextGraphics(_ c: Context) async throws -> String? {
        for preset in GraphicPreset.allCases {
            let img = TextGraphics.graphic(preset, text: "Select anything.\nCreate anything.")
            try expect(img?.width == Int(preset.size.width) && img?.height == Int(preset.size.height), "\(preset.title) size")
        }
        var o = TextImageOptions()
        o.width = 800
        let png = TextGraphics.render("Hello from HEXSHIFT — wrapped text that should flow onto a second line nicely.", options: o)
        try expect((png?.height ?? 0) > 100, "text image height grows to fit")
        let svg = TextGraphics.svg("Hello SVG text", options: o)
        try expect(XMLValidator.isWellFormed(Data(svg.utf8)) && svg.contains("<tspan"), "SVG text graphic")
        let specimen = TextGraphics.specimen(family: "Helvetica")
        try expect(specimen != nil, "specimen card")
        return nil
    }

    static func testWorkflows(_ c: Context) async throws -> String? {
        let asset = AssetInspector.inspect(c.file("sample.png"))
        let web = try await WorkflowEngine.run(.quickWebExport, on: asset, planner: c.planner)
        try expect(web.outputs.first?.pathExtension == "webp", "web export is WebP")
        let social = try await WorkflowEngine.run(.socialMediaExport, on: asset, planner: c.planner)
        let d = try decode(social.outputs[0])
        try expect(d.width == 1080 && d.height == 1350, "social export is 1080×1350, got \(d.width)×\(d.height)")
        let pdf = AssetInspector.inspect(c.file("doc.pdf"))
        let opt = try await WorkflowEngine.run(.pdfOptimiser, on: pdf, planner: c.planner)
        try expect(!opt.outputs.isEmpty, "PDF optimiser output")
        let custom = Workflow(name: "Thumbs", steps: [.resize(maxWidth: 200, maxHeight: 200), .convert(format: .jpeg, quality: 0.7)])
        let t = try await WorkflowEngine.run(custom, on: asset, planner: c.planner)
        try expect(try decode(t.outputs[0]).width == 200, "custom workflow resize")
        return nil
    }

    static func testCompression(_ c: Context) async throws -> String? {
        let img = testImage(width: 1600, height: 1200, text: "Compression")
        let target = 60 * 1024
        let r = try ImageCompressor.findQuality(ImageOps.flatten(img), format: .jpeg, targetBytes: target)
        try expect(r.data.count <= target, "result \(r.data.count) ≤ \(target)")
        return "quality \(String(format: "%.2f", r.quality)) → \(r.data.count / 1024) KB"
    }

    static func testEngineRouting(_ c: Context) async throws -> String? {
        var counts: [String] = []
        for name in ["sample.png", "photo.jpg", "anim.gif", "doc.pdf", "shapes.svg", "notes.md", "table.csv", "clip.mp4"] {
            let url = c.file(name)
            guard FileManager.default.fileExists(atPath: url.path) else { continue }
            let t = ConversionEngine.targets(for: AssetInspector.inspect(url))
            try expect(!t.isEmpty, "\(name) has targets")
            counts.append("\(name):\(t.filter(\.isAvailable).count)")
        }
        return counts.joined(separator: " ")
    }
}
