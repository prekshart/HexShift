import Accelerate
import CoreGraphics
import Foundation
import ImageIO

/// A straight-forward 8-bit sRGB RGBA copy of an image for pixel analysis.
/// Rows are stored top-to-bottom. Colour values are premultiplied.
public struct PixelBuffer {
    public let width: Int
    public let height: Int
    public let bytesPerRow: Int
    public private(set) var data: [UInt8]

    public init?(image: CGImage, maxDimension: Int? = nil) {
        var w = image.width
        var h = image.height
        if let m = maxDimension, max(w, h) > m {
            let s = Double(m) / Double(max(w, h))
            w = max(1, Int((Double(w) * s).rounded()))
            h = max(1, Int((Double(h) * s).rounded()))
        }
        let bpr = w * 4
        var buf = [UInt8](repeating: 0, count: bpr * h)
        guard let cs = CGColorSpace(name: CGColorSpace.sRGB) else { return nil }
        let ok: Bool = buf.withUnsafeMutableBytes { ptr -> Bool in
            guard let ctx = CGContext(data: ptr.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: bpr, space: cs,
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.interpolationQuality = .high
            ctx.draw(image, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard ok else { return nil }
        width = w
        height = h
        bytesPerRow = bpr
        data = buf
    }

    @inline(__always) public func offset(x: Int, y: Int) -> Int { y * bytesPerRow + x * 4 }

    @inline(__always) public func alpha(x: Int, y: Int) -> UInt8 { data[offset(x: x, y: y) + 3] }

    /// Un-premultiplied colour of a pixel, 0...255 per channel.
    public func rgba(x: Int, y: Int) -> (r: Double, g: Double, b: Double, a: Double) {
        let i = offset(x: x, y: y)
        let a = Double(data[i + 3])
        if a == 0 { return (0, 0, 0, 0) }
        let k = 255.0 / a
        return (min(255, Double(data[i]) * k), min(255, Double(data[i + 1]) * k), min(255, Double(data[i + 2]) * k), a)
    }

    /// Luminance 0...1 of a pixel composited on white.
    public func luminanceOnWhite(x: Int, y: Int) -> Double {
        let i = offset(x: x, y: y)
        let a = Double(data[i + 3]) / 255
        let r = Double(data[i]) / 255 + (1 - a)
        let g = Double(data[i + 1]) / 255 + (1 - a)
        let b = Double(data[i + 2]) / 255 + (1 - a)
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }

    public func makeImage() -> CGImage? {
        guard let cs = CGColorSpace(name: CGColorSpace.sRGB) else { return nil }
        var copy = data
        return copy.withUnsafeMutableBytes { ptr -> CGImage? in
            guard let ctx = CGContext(data: ptr.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                      bytesPerRow: bytesPerRow, space: cs,
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
            return ctx.makeImage()
        }
    }
}

/// A decoded image whose pixels are already upright (EXIF orientation applied).
public struct LoadedImage {
    public let image: CGImage
    /// Source properties as read from the file (orientation not yet reset).
    public let properties: [CFString: Any]
    public let sourceType: String?

    public init(image: CGImage, properties: [CFString: Any], sourceType: String?) {
        self.image = image
        self.properties = properties
        self.sourceType = sourceType
    }
}

/// One frame of an animation.
public struct AnimationFrame {
    public let image: CGImage
    /// Seconds this frame stays on screen.
    public let delay: Double
    public init(image: CGImage, delay: Double) {
        self.image = image
        self.delay = delay
    }
}

public enum ImageLoader {
    public static func load(_ url: URL, index: Int = 0) throws -> LoadedImage {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil), CGImageSourceGetCount(src) > index else {
            throw HexError.unreadable(url.lastPathComponent)
        }
        return try load(source: src, index: index, name: url.lastPathComponent)
    }

    public static func load(data: Data, name: String = "image") throws -> LoadedImage {
        guard let src = CGImageSourceCreateWithData(data as CFData, nil), CGImageSourceGetCount(src) > 0 else {
            throw HexError.unreadable(name)
        }
        return try load(source: src, index: 0, name: name)
    }

    public static func load(source src: CGImageSource, index: Int, name: String) throws -> LoadedImage {
        let props = (CGImageSourceCopyPropertiesAtIndex(src, index, nil) as? [CFString: Any]) ?? [:]
        let orientation = (props[kCGImagePropertyOrientation] as? NSNumber)?.intValue ?? 1
        var image: CGImage?
        if orientation == 1 {
            image = CGImageSourceCreateImageAtIndex(src, index, [kCGImageSourceShouldCacheImmediately: true] as CFDictionary)
        } else {
            // Let ImageIO apply the EXIF transform while decoding at full size.
            let w = (props[kCGImagePropertyPixelWidth] as? NSNumber)?.intValue ?? 0
            let h = (props[kCGImagePropertyPixelHeight] as? NSNumber)?.intValue ?? 0
            let opts: [CFString: Any] = [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: max(w, h, 1),
                kCGImageSourceShouldCacheImmediately: true,
            ]
            image = CGImageSourceCreateThumbnailAtIndex(src, index, opts as CFDictionary)
                ?? CGImageSourceCreateImageAtIndex(src, index, nil)
        }
        guard let img = image else { throw HexError.unreadable(name) }
        return LoadedImage(image: img, properties: props, sourceType: CGImageSourceGetType(src) as String?)
    }

    /// Fast, bounded-size preview (used for thumbnails and analysis).
    public static func thumbnail(_ url: URL, maxPixelSize: Int) -> CGImage? {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixelSize,
        ]
        return CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary)
    }

    /// Reads every frame of an animated GIF / WebP / APNG / HEIC sequence.
    public static func loadAnimation(_ url: URL, maxFrames: Int = 1000) throws -> (frames: [AnimationFrame], loopCount: Int) {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { throw HexError.unreadable(url.lastPathComponent) }
        let count = CGImageSourceGetCount(src)
        guard count > 0 else { throw HexError.unreadable(url.lastPathComponent) }
        var frames: [AnimationFrame] = []
        for i in 0..<min(count, maxFrames) {
            guard let img = CGImageSourceCreateImageAtIndex(src, i, nil) else { continue }
            let props = (CGImageSourceCopyPropertiesAtIndex(src, i, nil) as? [CFString: Any]) ?? [:]
            frames.append(AnimationFrame(image: img, delay: frameDelay(props)))
        }
        guard !frames.isEmpty else { throw HexError.unreadable(url.lastPathComponent) }
        let global = (CGImageSourceCopyProperties(src, nil) as? [CFString: Any]) ?? [:]
        return (frames, loopCount(global))
    }

    static func frameDelay(_ props: [CFString: Any]) -> Double {
        let candidates: [(CFString, CFString, CFString)] = [
            (kCGImagePropertyGIFDictionary, kCGImagePropertyGIFUnclampedDelayTime, kCGImagePropertyGIFDelayTime),
            (kCGImagePropertyPNGDictionary, kCGImagePropertyAPNGUnclampedDelayTime, kCGImagePropertyAPNGDelayTime),
            (kCGImagePropertyWebPDictionary, kCGImagePropertyWebPUnclampedDelayTime, kCGImagePropertyWebPDelayTime),
            (kCGImagePropertyHEICSDictionary, kCGImagePropertyHEICSUnclampedDelayTime, kCGImagePropertyHEICSDelayTime),
        ]
        for (dictKey, unclamped, clamped) in candidates {
            if let d = props[dictKey] as? [CFString: Any] {
                let v = (d[unclamped] as? NSNumber)?.doubleValue ?? (d[clamped] as? NSNumber)?.doubleValue
                if let v, v > 0 { return max(0.02, v) }
            }
        }
        return 0.1
    }

    static func loopCount(_ props: [CFString: Any]) -> Int {
        let candidates: [(CFString, CFString)] = [
            (kCGImagePropertyGIFDictionary, kCGImagePropertyGIFLoopCount),
            (kCGImagePropertyPNGDictionary, kCGImagePropertyAPNGLoopCount),
            (kCGImagePropertyWebPDictionary, kCGImagePropertyWebPLoopCount),
            (kCGImagePropertyHEICSDictionary, kCGImagePropertyHEICSLoopCount),
        ]
        for (dictKey, key) in candidates {
            if let d = props[dictKey] as? [CFString: Any], let n = (d[key] as? NSNumber)?.intValue { return n }
        }
        return 0
    }
}

public enum Resampling: String, Codable, CaseIterable, Sendable {
    case lanczos, smooth, pixelated

    public var title: String {
        switch self {
        case .lanczos: return "Lanczos (sharpest)"
        case .smooth: return "Bicubic (smooth)"
        case .pixelated: return "Nearest neighbour (pixel art)"
        }
    }
}

/// Pixel-level image operations shared by the converter, editor and workflows.
public enum ImageOps {
    public static let sRGB: CGColorSpace = CGColorSpace(name: CGColorSpace.sRGB)!

    /// A colour space suitable for an 8-bit RGBA bitmap context.
    static func drawingSpace(for image: CGImage) -> CGColorSpace {
        if let cs = image.colorSpace, cs.model == .rgb, cs.supportsOutput { return cs }
        return sRGB
    }

    public static func makeContext(width: Int, height: Int, space: CGColorSpace = sRGB, opaque: Bool = false) -> CGContext? {
        let info = opaque ? CGImageAlphaInfo.noneSkipLast.rawValue : CGImageAlphaInfo.premultipliedLast.rawValue
        return CGContext(data: nil, width: max(1, width), height: max(1, height), bitsPerComponent: 8,
                         bytesPerRow: 0, space: space, bitmapInfo: info)
    }

    public static func hasAlpha(_ image: CGImage) -> Bool {
        switch image.alphaInfo {
        case .none, .noneSkipFirst, .noneSkipLast: return false
        default: return true
        }
    }

    /// Composites the image over an opaque matte (for JPEG/BMP and other alpha-less formats).
    public static func flatten(_ image: CGImage, matte: RGBAColour = .white) -> CGImage {
        guard hasAlpha(image) else { return image }
        let space = drawingSpace(for: image)
        guard let ctx = makeContext(width: image.width, height: image.height, space: space, opaque: true) else { return image }
        let rect = CGRect(x: 0, y: 0, width: image.width, height: image.height)
        ctx.setFillColor(matte.cgColor)
        ctx.fill(rect)
        ctx.draw(image, in: rect)
        return ctx.makeImage() ?? image
    }

    /// Converts CMYK, indexed or other models to RGB.
    public static func ensureRGB(_ image: CGImage) -> CGImage {
        if let cs = image.colorSpace, cs.model == .rgb || cs.model == .monochrome { return image }
        return redraw(image, space: sRGB) ?? image
    }

    public static func toSRGB(_ image: CGImage) -> CGImage {
        if let cs = image.colorSpace, cs.name == CGColorSpace.sRGB { return image }
        return redraw(image, space: sRGB) ?? image
    }

    public static func toDisplayP3(_ image: CGImage) -> CGImage {
        if let cs = image.colorSpace, cs.name == CGColorSpace.displayP3 { return image }
        guard let p3 = CGColorSpace(name: CGColorSpace.displayP3) else { return image }
        return redraw(image, space: p3) ?? image
    }

    static func redraw(_ image: CGImage, space: CGColorSpace) -> CGImage? {
        guard let ctx = makeContext(width: image.width, height: image.height, space: space, opaque: !hasAlpha(image)) else { return nil }
        ctx.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
        return ctx.makeImage()
    }

    public static func resize(_ image: CGImage, to size: CGSize, method: Resampling = .lanczos) -> CGImage {
        let w = max(1, Int(size.width.rounded()))
        let h = max(1, Int(size.height.rounded()))
        if w == image.width && h == image.height { return image }
        if method == .lanczos, let out = vImageResize(image, width: w, height: h) { return out }
        let space = drawingSpace(for: image)
        guard let ctx = makeContext(width: w, height: h, space: space, opaque: !hasAlpha(image)) else { return image }
        ctx.interpolationQuality = method == .pixelated ? .none : .high
        ctx.draw(image, in: CGRect(x: 0, y: 0, width: w, height: h))
        return ctx.makeImage() ?? image
    }

    /// Lanczos resampling through Accelerate.
    static func vImageResize(_ image: CGImage, width: Int, height: Int) -> CGImage? {
        let space = drawingSpace(for: image)
        let alpha = hasAlpha(image)
        guard var format = vImage_CGImageFormat(
            bitsPerComponent: 8, bitsPerPixel: 32, colorSpace: space,
            bitmapInfo: CGBitmapInfo(rawValue: alpha ? CGImageAlphaInfo.premultipliedLast.rawValue : CGImageAlphaInfo.noneSkipLast.rawValue)
        ) else { return nil }
        guard var source = try? vImage_Buffer(cgImage: image, format: format) else { return nil }
        defer { source.free() }
        guard var dest = try? vImage_Buffer(width: width, height: height, bitsPerPixel: 32) else { return nil }
        defer { dest.free() }
        let err = vImageScale_ARGB8888(&source, &dest, nil, vImage_Flags(kvImageHighQualityResampling))
        guard err == kvImageNoError else { return nil }
        return try? dest.createCGImage(format: format)
    }

    /// Crops using top-left-origin pixel coordinates.
    public static func crop(_ image: CGImage, to rect: CGRect) -> CGImage {
        let bounds = CGRect(x: 0, y: 0, width: image.width, height: image.height)
        let r = rect.integral.intersection(bounds)
        guard !r.isNull, r.width >= 1, r.height >= 1 else { return image }
        return image.cropping(to: r) ?? image
    }

    public static func rotate90(_ image: CGImage, clockwise: Bool) -> CGImage {
        let w = image.height
        let h = image.width
        guard let ctx = makeContext(width: w, height: h, space: drawingSpace(for: image), opaque: !hasAlpha(image)) else { return image }
        // Rotate around the origin, then shift the result back into view.
        if clockwise {
            ctx.translateBy(x: 0, y: CGFloat(h))
            ctx.rotate(by: -.pi / 2)
        } else {
            ctx.translateBy(x: CGFloat(w), y: 0)
            ctx.rotate(by: .pi / 2)
        }
        ctx.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
        return ctx.makeImage() ?? image
    }

    public static func flip(_ image: CGImage, horizontal: Bool) -> CGImage {
        guard let ctx = makeContext(width: image.width, height: image.height, space: drawingSpace(for: image), opaque: !hasAlpha(image)) else { return image }
        if horizontal {
            ctx.translateBy(x: CGFloat(image.width), y: 0)
            ctx.scaleBy(x: -1, y: 1)
        } else {
            ctx.translateBy(x: 0, y: CGFloat(image.height))
            ctx.scaleBy(x: 1, y: -1)
        }
        ctx.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
        return ctx.makeImage() ?? image
    }

    /// Fits the image into a transparent square canvas (used for icons).
    public static func squareFit(_ image: CGImage, size: Int) -> CGImage {
        guard let ctx = makeContext(width: size, height: size, space: sRGB) else { return image }
        ctx.interpolationQuality = .high
        let scale = min(Double(size) / Double(image.width), Double(size) / Double(image.height))
        let w = Double(image.width) * scale
        let h = Double(image.height) * scale
        ctx.draw(image, in: CGRect(x: (Double(size) - w) / 2, y: (Double(size) - h) / 2, width: w, height: h))
        return ctx.makeImage() ?? image
    }

    /// Scales so the longest side is at most `maxPixelSize`.
    public static func limit(_ image: CGImage, maxPixelSize: Int?) -> CGImage {
        guard let m = maxPixelSize, m > 0, max(image.width, image.height) > m else { return image }
        let s = Double(m) / Double(max(image.width, image.height))
        return resize(image, to: CGSize(width: Double(image.width) * s, height: Double(image.height) * s))
    }

    /// Size that fits within maxWidth/maxHeight keeping aspect ratio (never upscales).
    public static func fittedSize(width: Int, height: Int, maxWidth: Int?, maxHeight: Int?) -> CGSize {
        var s = 1.0
        if let mw = maxWidth, mw > 0, width > mw { s = min(s, Double(mw) / Double(width)) }
        if let mh = maxHeight, mh > 0, height > mh { s = min(s, Double(mh) / Double(height)) }
        return CGSize(width: max(1, (Double(width) * s).rounded()), height: max(1, (Double(height) * s).rounded()))
    }

    /// Centre crop to an aspect ratio (w:h).
    public static func cropToAspect(_ image: CGImage, ratioW: Double, ratioH: Double) -> CGImage {
        let target = ratioW / ratioH
        let current = Double(image.width) / Double(image.height)
        var rect = CGRect(x: 0, y: 0, width: image.width, height: image.height)
        if current > target {
            let w = Double(image.height) * target
            rect = CGRect(x: (Double(image.width) - w) / 2, y: 0, width: w, height: Double(image.height))
        } else if current < target {
            let h = Double(image.width) / target
            rect = CGRect(x: 0, y: (Double(image.height) - h) / 2, width: Double(image.width), height: h)
        }
        return crop(image, to: rect)
    }

    /// Draws an image onto a canvas of exactly `size`, cropping to fill.
    public static func fill(_ image: CGImage, size: CGSize) -> CGImage {
        let cropped = cropToAspect(image, ratioW: Double(size.width), ratioH: Double(size.height))
        return resize(cropped, to: size)
    }
}

/// Simple RGBA colour used across the engine (sRGB, 0...1).
public struct RGBAColour: Codable, Hashable, Sendable {
    public var r: Double
    public var g: Double
    public var b: Double
    public var a: Double

    public init(r: Double, g: Double, b: Double, a: Double = 1) {
        self.r = r
        self.g = g
        self.b = b
        self.a = a
    }

    public static let white = RGBAColour(r: 1, g: 1, b: 1)
    public static let black = RGBAColour(r: 0, g: 0, b: 0)
    public static let clear = RGBAColour(r: 0, g: 0, b: 0, a: 0)

    public var cgColor: CGColor {
        CGColor(colorSpace: ImageOps.sRGB, components: [CGFloat(r), CGFloat(g), CGFloat(b), CGFloat(a)])
            ?? CGColor(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b), alpha: CGFloat(a))
    }

    public init?(hex: String) {
        guard let c = ColourMath.parse(hex) else { return nil }
        self = c
    }

    public var hex: String { ColourMath.hex(self) }
}
