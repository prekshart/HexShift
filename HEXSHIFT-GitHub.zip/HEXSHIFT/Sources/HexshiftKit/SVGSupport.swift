import AppKit
import Foundation
import WebKit

/// SVG reading. AppKit's built-in SVG renderer is tried first; WebKit is the fallback.
/// SVG files are rendered without network access or scripts.
public enum SVGSupport {
    final class RootParser: NSObject, XMLParserDelegate {
        var size: CGSize?
        func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?, qualifiedName: String?, attributes: [String: String] = [:]) {
            guard name == "svg" || name.hasSuffix(":svg") else { return }
            func length(_ s: String?) -> CGFloat? {
                guard var v = s?.trimmingCharacters(in: .whitespaces), !v.isEmpty, !v.hasSuffix("%") else { return nil }
                var factor: CGFloat = 1
                for (unit, f) in [("px", 1.0), ("pt", 4.0 / 3.0), ("mm", 96 / 25.4), ("cm", 96 / 2.54), ("in", 96.0), ("em", 16.0)] where v.hasSuffix(unit) {
                    v = String(v.dropLast(unit.count))
                    factor = CGFloat(f)
                }
                return Double(v).map { CGFloat($0) * factor }
            }
            let w = length(attributes["width"])
            let h = length(attributes["height"])
            var vb: CGSize?
            if let viewBox = attributes["viewBox"] {
                let nums = viewBox.split(whereSeparator: { $0 == " " || $0 == "," }).compactMap { Double($0) }
                if nums.count == 4 { vb = CGSize(width: nums[2], height: nums[3]) }
            }
            if let w, let h {
                size = CGSize(width: w, height: h)
            } else if let vb {
                if let w { size = CGSize(width: w, height: w * vb.height / max(1, vb.width)) }
                else if let h { size = CGSize(width: h * vb.width / max(1, vb.height), height: h) }
                else { size = vb }
            }
            parser.abortParsing()
        }
    }

    public static func intrinsicSize(of url: URL) -> CGSize? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        let parser = XMLParser(data: data)
        let delegate = RootParser()
        parser.delegate = delegate
        parser.shouldResolveExternalEntities = false
        parser.parse()
        if let s = delegate.size, s.width > 0, s.height > 0 { return s }
        return nil
    }

    /// AppKit SVG rendering (no network, no scripts).
    public static func renderNative(_ url: URL, scale: Double = 1) -> CGImage? {
        guard let image = NSImage(contentsOf: url), !image.representations.isEmpty else { return nil }
        var size = intrinsicSize(of: url) ?? image.size
        if size.width <= 0 || size.height <= 0 { size = CGSize(width: 512, height: 512) }
        let w = max(1, Int((size.width * scale).rounded()))
        let h = max(1, Int((size.height * scale).rounded()))
        guard let ctx = ImageOps.makeContext(width: w, height: h) else { return nil }
        let gc = NSGraphicsContext(cgContext: ctx, flipped: false)
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = gc
        image.draw(in: NSRect(x: 0, y: 0, width: w, height: h), from: .zero, operation: .sourceOver, fraction: 1)
        NSGraphicsContext.restoreGraphicsState()
        return ctx.makeImage()
    }

    /// Writes a vector PDF (AppKit path) — falls back to WebKit's PDF output.
    @MainActor
    public static func writePDF(_ url: URL, output: URL) async throws {
        if let image = NSImage(contentsOf: url), !image.representations.isEmpty {
            var size = intrinsicSize(of: url) ?? image.size
            if size.width <= 0 || size.height <= 0 { size = CGSize(width: 512, height: 512) }
            try FileWriter.writeAtomically(to: output) { tmp in
                var box = CGRect(origin: .zero, size: size)
                guard let ctx = CGContext(tmp as CFURL, mediaBox: &box, [kCGPDFContextCreator: "HEXSHIFT"] as CFDictionary) else {
                    throw HexError.writeFailed("Could not create the PDF.")
                }
                ctx.beginPDFPage(nil)
                let gc = NSGraphicsContext(cgContext: ctx, flipped: false)
                NSGraphicsContext.saveGraphicsState()
                NSGraphicsContext.current = gc
                image.draw(in: box, from: .zero, operation: .sourceOver, fraction: 1)
                NSGraphicsContext.restoreGraphicsState()
                ctx.endPDFPage()
                ctx.closePDF()
                try ImageEncoder.validate(tmp, format: .pdf)
            }
            return
        }
        let data = try await WebSnapshotter.pdf(of: url, size: intrinsicSize(of: url) ?? CGSize(width: 512, height: 512))
        try FileWriter.writeAtomically(to: output) { tmp in
            try data.write(to: tmp)
            try ImageEncoder.validate(tmp, format: .pdf)
        }
    }

    /// Raster rendering with automatic fallback.
    public static func render(_ url: URL, scale: Double = 1) async throws -> CGImage {
        if let img = renderNative(url, scale: scale) { return img }
        let size = intrinsicSize(of: url) ?? CGSize(width: 512, height: 512)
        return try await WebSnapshotter.image(of: url, size: size, scale: scale)
    }
}

/// Offscreen WebKit renderer for SVG/HTML snapshots.
@MainActor
final class WebSnapshotter: NSObject, WKNavigationDelegate {
    private var continuation: CheckedContinuation<Void, Error>?
    private let webView: WKWebView
    private let window: NSWindow

    /// Blocks every network request, so an SVG (or HTML) file can't fetch remote images,
    /// fonts or trackers while HEXSHIFT renders it. Compiled once and cached.
    private static var cachedBlocker: WKContentRuleList?

    static func networkBlocker() async -> WKContentRuleList? {
        if let cachedBlocker { return cachedBlocker }
        let rules = #"[{"trigger":{"url-filter":"^(https?|ftp|wss?)://"},"action":{"type":"block"}}]"#
        let list: WKContentRuleList? = await withCheckedContinuation { cont in
            WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "HEXSHIFT.offline", encodedContentRuleList: rules) { list, _ in
                cont.resume(returning: list)
            }
        }
        cachedBlocker = list
        return list
    }

    init(size: CGSize, blocker: WKContentRuleList?) {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .nonPersistent()
        if let blocker { config.userContentController.add(blocker) }
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.defaultWebpagePreferences.allowsContentJavaScript = false
        webView = WKWebView(frame: CGRect(origin: .zero, size: size), configuration: config)
        webView.setValue(false, forKey: "drawsBackground")
        window = NSWindow(contentRect: CGRect(x: -20000, y: -20000, width: size.width, height: size.height),
                          styleMask: [.borderless], backing: .buffered, defer: false)
        window.contentView = webView
        super.init()
        webView.navigationDelegate = self
    }

    func load(_ url: URL) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            continuation = cont
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
    }

    nonisolated func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        Task { @MainActor in
            self.continuation?.resume()
            self.continuation = nil
        }
    }

    nonisolated func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        Task { @MainActor in
            self.continuation?.resume(throwing: error)
            self.continuation = nil
        }
    }

    nonisolated func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        Task { @MainActor in
            self.continuation?.resume(throwing: error)
            self.continuation = nil
        }
    }

    static func image(of url: URL, size: CGSize, scale: Double) async throws -> CGImage {
        let s = WebSnapshotter(size: size, blocker: await networkBlocker())
        try await s.load(url)
        let config = WKSnapshotConfiguration()
        config.rect = CGRect(origin: .zero, size: size)
        config.snapshotWidth = NSNumber(value: Double(size.width) * scale)
        let image = try await s.webView.takeSnapshot(configuration: config)
        var rect = CGRect(origin: .zero, size: image.size)
        guard let cg = image.cgImage(forProposedRect: &rect, context: nil, hints: nil) else {
            throw HexError.message("The SVG could not be rendered.")
        }
        return cg
    }

    static func pdf(of url: URL, size: CGSize) async throws -> Data {
        let s = WebSnapshotter(size: size, blocker: await networkBlocker())
        try await s.load(url)
        let config = WKPDFConfiguration()
        config.rect = CGRect(origin: .zero, size: size)
        return try await s.webView.pdf(configuration: config)
    }
}
