import Foundation
import ImageIO
import UniformTypeIdentifiers

/// Broad family a format belongs to. Drives which tools HEXSHIFT offers.
public enum FormatCategory: String, Codable, Sendable {
    case raster, vector, document, spreadsheet, presentation, video, audio, font, other
}

/// Every file format HEXSHIFT knows how to read and/or write.
/// Whether a conversion is actually possible on this Mac is decided at runtime
/// by `ConversionEngine.targets(for:)` — never by the extension alone.
public enum Format: String, CaseIterable, Codable, Sendable, Identifiable {
    // Raster images
    case png, jpeg, heic, avif, webp, tiff, bmp, gif, ico, icns, jp2, tga, psd, raw
    // Vector / page description
    case svg, pdf, eps, ai
    // Documents and text
    case txt, rtf, docx, doc, odt, html, md, json
    // Tables and slides
    case csv, xlsx, pptx, key, pages, numbers
    // Video
    case mp4, mov, m4v, webm, mkv, avi
    // Audio
    case mp3, wav, m4a, aiff, aac, flac
    // Fonts
    case ttf, otf

    public var id: String { rawValue }

    public var displayName: String {
        switch self {
        case .png: return "PNG"
        case .jpeg: return "JPEG"
        case .heic: return "HEIC"
        case .avif: return "AVIF"
        case .webp: return "WebP"
        case .tiff: return "TIFF"
        case .bmp: return "BMP"
        case .gif: return "GIF"
        case .ico: return "ICO"
        case .icns: return "ICNS"
        case .jp2: return "JPEG 2000"
        case .tga: return "TGA"
        case .psd: return "PSD"
        case .raw: return "RAW"
        case .svg: return "SVG"
        case .pdf: return "PDF"
        case .eps: return "EPS"
        case .ai: return "AI"
        case .txt: return "TXT"
        case .rtf: return "RTF"
        case .docx: return "DOCX"
        case .doc: return "DOC"
        case .odt: return "ODT"
        case .html: return "HTML"
        case .md: return "Markdown"
        case .json: return "JSON"
        case .csv: return "CSV"
        case .xlsx: return "XLSX"
        case .pptx: return "PPTX"
        case .key: return "Keynote"
        case .pages: return "Pages"
        case .numbers: return "Numbers"
        case .mp4: return "MP4"
        case .mov: return "MOV"
        case .m4v: return "M4V"
        case .webm: return "WebM"
        case .mkv: return "MKV"
        case .avi: return "AVI"
        case .mp3: return "MP3"
        case .wav: return "WAV"
        case .m4a: return "M4A"
        case .aiff: return "AIFF"
        case .aac: return "AAC"
        case .flac: return "FLAC"
        case .ttf: return "TTF"
        case .otf: return "OTF"
        }
    }

    /// Short label used on the radial wheel (≤ 5 characters where possible).
    public var shortName: String {
        switch self {
        case .jpeg: return "JPG"
        case .jp2: return "JP2"
        case .md: return "MD"
        case .key: return "KEY"
        default: return displayName.uppercased()
        }
    }

    /// Extension used when HEXSHIFT writes this format.
    public var fileExtension: String {
        switch self {
        case .jpeg: return "jpg"
        case .raw: return "dng"
        default: return rawValue
        }
    }

    public var category: FormatCategory {
        switch self {
        case .png, .jpeg, .heic, .avif, .webp, .tiff, .bmp, .gif, .ico, .icns, .jp2, .tga, .psd, .raw:
            return .raster
        case .svg, .pdf, .eps, .ai:
            return .vector
        case .txt, .rtf, .docx, .doc, .odt, .html, .md, .json, .pages:
            return .document
        case .csv, .xlsx, .numbers:
            return .spreadsheet
        case .pptx, .key:
            return .presentation
        case .mp4, .mov, .m4v, .webm, .mkv, .avi:
            return .video
        case .mp3, .wav, .m4a, .aiff, .aac, .flac:
            return .audio
        case .ttf, .otf:
            return .font
        }
    }

    /// UTI used with ImageIO (CGImageSource / CGImageDestination).
    public var imageIOType: String? {
        switch self {
        case .png: return "public.png"
        case .jpeg: return "public.jpeg"
        case .heic: return "public.heic"
        case .avif: return "public.avif"
        case .webp: return "org.webmproject.webp"
        case .tiff: return "public.tiff"
        case .bmp: return "com.microsoft.bmp"
        case .gif: return "com.compuserve.gif"
        case .ico: return "com.microsoft.ico"
        case .icns: return "com.apple.icns"
        case .jp2: return "public.jpeg-2000"
        case .tga: return "com.truevision.tga-image"
        case .psd: return "com.adobe.photoshop-image"
        case .pdf: return "com.adobe.pdf"
        default: return nil
        }
    }

    public var utType: UTType? {
        switch self {
        case .md: return UTType("net.daringfireball.markdown") ?? UTType(filenameExtension: "md")
        case .raw: return .rawImage
        default: return UTType(filenameExtension: fileExtension)
        }
    }

    /// True for formats that can hold transparency.
    public var supportsAlpha: Bool {
        switch self {
        case .png, .heic, .avif, .webp, .tiff, .gif, .ico, .icns, .jp2, .tga, .svg, .pdf, .psd: return true
        default: return false
        }
    }

    /// True for formats where a quality slider makes sense.
    public var isLossy: Bool {
        switch self {
        case .jpeg, .heic, .avif, .webp, .jp2: return true
        default: return false
        }
    }

    /// True for formats that can carry several animation frames.
    public var supportsAnimation: Bool {
        switch self {
        case .gif, .webp, .png: return true
        default: return false
        }
    }

    // MARK: - Detection

    static let extensionMap: [String: Format] = {
        var map: [String: Format] = [:]
        for f in Format.allCases { map[f.rawValue] = f }
        let extra: [String: Format] = [
            "jpg": .jpeg, "jpe": .jpeg, "jfif": .jpeg, "pjpeg": .jpeg,
            "heif": .heic, "hif": .heic, "heics": .heic, "avci": .heic,
            "tif": .tiff,
            "j2k": .jp2, "jpf": .jp2, "jpx": .jp2, "jpm": .jp2,
            "htm": .html, "xhtml": .html,
            "markdown": .md, "mdown": .md, "mkd": .md, "mkdn": .md,
            "text": .txt, "log": .txt,
            "aif": .aiff, "aifc": .aiff,
            "tsv": .csv,
            "cr2": .raw, "cr3": .raw, "crw": .raw, "nef": .raw, "nrw": .raw,
            "arw": .raw, "srf": .raw, "sr2": .raw, "raf": .raw, "orf": .raw,
            "rw2": .raw, "pef": .raw, "dng": .raw, "3fr": .raw, "erf": .raw,
            "kdc": .raw, "mos": .raw, "mrw": .raw, "x3f": .raw, "srw": .raw,
            "iiq": .raw, "rwl": .raw, "gpr": .raw,
            "apng": .png,
            "keynote": .key,
            "ttc": .ttf,
        ]
        for (k, v) in extra { map[k] = v }
        return map
    }()

    /// Best guess of a file's format: extension first, then content sniffing,
    /// then the system's UTType.
    public static func detect(_ url: URL) -> Format? {
        let ext = url.pathExtension.lowercased()
        let byExt = extensionMap[ext]
        let sniffed = sniff(url)
        switch (byExt, sniffed) {
        case let (e?, s?):
            if e == s { return e }
            // Camera RAW files are mostly TIFF-based containers.
            if e == .raw { return .raw }
            // Illustrator files are PDF- or PostScript-based; keep the AI identity.
            if e == .ai { return .ai }
            // A mislabelled image (e.g. PNG saved as .jpg): trust the content.
            if e.category == .raster && s.category == .raster { return s }
            // Same family (e.g. .m4v holding an mp42 brand): keep the extension.
            if e.category == s.category { return e }
            // Text heuristics (html/svg) are weaker than an explicit extension.
            if s == .html || s == .svg { return e }
            return s
        case let (e?, nil):
            return e
        case let (nil, s?):
            return s
        case (nil, nil):
            if let type = (try? url.resourceValues(forKeys: [.contentTypeKey]))?.contentType {
                return fromUTType(type)
            }
            return nil
        }
    }

    public static func fromUTType(_ type: UTType) -> Format? {
        if type.conforms(to: .rawImage) { return .raw }
        for f in Format.allCases where f != .raw {
            if let t = f.utType, type == t { return f }
        }
        if let ext = type.preferredFilenameExtension, let f = extensionMap[ext.lowercased()] { return f }
        if type.conforms(to: .pdf) { return .pdf }
        if type.conforms(to: .png) { return .png }
        if type.conforms(to: .jpeg) { return .jpeg }
        if type.conforms(to: .tiff) { return .tiff }
        if type.conforms(to: .gif) { return .gif }
        if type.conforms(to: .heic) || type.conforms(to: .heif) { return .heic }
        if type.conforms(to: .svg) { return .svg }
        if type.conforms(to: .html) { return .html }
        if type.conforms(to: .rtf) { return .rtf }
        if type.conforms(to: .plainText) { return .txt }
        if type.conforms(to: .mpeg4Movie) { return .mp4 }
        if type.conforms(to: .quickTimeMovie) { return .mov }
        if type.conforms(to: .mp3) { return .mp3 }
        if type.conforms(to: .wav) { return .wav }
        if type.conforms(to: .aiff) { return .aiff }
        if type.conforms(to: .mpeg4Audio) { return .m4a }
        return nil
    }

    /// Looks at the first bytes of a file to recognise common formats.
    public static func sniff(_ url: URL) -> Format? {
        guard let handle = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? handle.close() }
        guard let data = try? handle.read(upToCount: 64), data.count >= 4 else { return nil }
        let b = [UInt8](data)
        func ascii(_ range: Range<Int>) -> String {
            guard range.upperBound <= b.count else { return "" }
            return String(bytes: b[range], encoding: .ascii) ?? ""
        }
        if b.starts(with: [0x89, 0x50, 0x4E, 0x47]) { return .png }
        if b.starts(with: [0xFF, 0xD8, 0xFF]) { return .jpeg }
        if ascii(0..<4) == "GIF8" { return .gif }
        if ascii(0..<4) == "RIFF" && ascii(8..<12) == "WEBP" { return .webp }
        if ascii(0..<4) == "RIFF" && ascii(8..<12) == "WAVE" { return .wav }
        if ascii(0..<4) == "RIFF" && ascii(8..<12) == "AVI " { return .avi }
        if ascii(0..<4) == "FORM" && (ascii(8..<12) == "AIFF" || ascii(8..<12) == "AIFC") { return .aiff }
        if ascii(0..<5) == "%PDF-" { return .pdf }
        if ascii(0..<4) == "%!PS" { return .eps }
        if b.starts(with: [0xC5, 0xD0, 0xD3, 0xC6]) { return .eps } // DOS EPS binary header
        if b.starts(with: [0x49, 0x49, 0x2A, 0x00]) || b.starts(with: [0x4D, 0x4D, 0x00, 0x2A]) { return .tiff }
        if ascii(0..<2) == "BM" { return .bmp }
        if ascii(0..<4) == "8BPS" { return .psd }
        if ascii(0..<4) == "icns" { return .icns }
        if b.starts(with: [0x00, 0x00, 0x01, 0x00]) { return .ico }
        if ascii(0..<5) == "{\\rtf" { return .rtf }
        if ascii(0..<4) == "fLaC" { return .flac }
        if ascii(0..<3) == "ID3" || (b[0] == 0xFF && (b[1] & 0xE0) == 0xE0) { return .mp3 }
        if b.starts(with: [0x1A, 0x45, 0xDF, 0xA3]) {
            // Matroska / WebM: the doctype string appears early in the header.
            let head = String(decoding: b, as: UTF8.self)
            return head.contains("webm") ? .webm : .mkv
        }
        if b.starts(with: [0x00, 0x00, 0x00, 0x0C, 0x6A, 0x50, 0x20, 0x20]) { return .jp2 }
        if b.starts(with: [0x00, 0x01, 0x00, 0x00, 0x00]) { return .ttf }
        if ascii(0..<4) == "OTTO" { return .otf }
        if ascii(4..<8) == "ftyp" {
            let brand = ascii(8..<12).lowercased()
            // Some AVIF files use the generic HEIF brand "mif1" and list "avif" as a compatible brand.
            if brand == "mif1" || brand == "msf1" {
                let boxSize = min(b.count, Int(b[0]) << 24 | Int(b[1]) << 16 | Int(b[2]) << 8 | Int(b[3]))
                if boxSize > 16, ascii(16..<boxSize).lowercased().contains("avi") { return .avif }
            }
            switch brand {
            case "heic", "heix", "heim", "heis", "hevc", "hevx", "mif1", "msf1": return .heic
            case "avif", "avis": return .avif
            case "qt  ": return .mov
            case "m4a ", "m4b ", "m4p ": return .m4a
            case "m4v ", "m4vh", "m4vp": return .m4v
            case "crx ": return .raw
            default: return .mp4
            }
        }
        if b.starts(with: [0x50, 0x4B, 0x03, 0x04]) { return nil } // ZIP container: rely on extension
        // Text-ish formats
        let head = String(decoding: b, as: UTF8.self).lowercased()
        if head.contains("<svg") { return .svg }
        if head.hasPrefix("<?xml") && url.pathExtension.lowercased() == "svg" { return .svg }
        if head.contains("<!doctype html") || head.hasPrefix("<html") { return .html }
        return nil
    }
}

/// What kind of asset the user selected. Drives the context-aware menu.
public enum AssetKind: String, Codable, Sendable {
    case image, animatedImage, rawImage, vector, pdf, document, spreadsheet, presentation, video, audio, font, unknown

    public var title: String {
        switch self {
        case .image: return "Image"
        case .animatedImage: return "Animated image"
        case .rawImage: return "RAW photo"
        case .vector: return "Vector"
        case .pdf: return "PDF"
        case .document: return "Document"
        case .spreadsheet: return "Spreadsheet"
        case .presentation: return "Presentation"
        case .video: return "Video"
        case .audio: return "Audio"
        case .font: return "Font"
        case .unknown: return "File"
        }
    }
}
