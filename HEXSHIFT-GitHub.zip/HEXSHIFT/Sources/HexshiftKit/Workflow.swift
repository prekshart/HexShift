import CoreGraphics
import Foundation

/// One step of a user-defined workflow.
public enum WorkflowStep: Codable, Hashable, Sendable {
    case resize(maxWidth: Int?, maxHeight: Int?)
    case resizeExact(width: Int, height: Int)
    case cropAspect(width: Double, height: Double)
    case convert(format: Format, quality: Double)
    case compressTo(kilobytes: Int, format: Format)
    case removeBackground
    case stripMetadata(gpsOnly: Bool)
    case autoEnhance
    case grayscale
    case copyToClipboard
    case pdfCompress
    case pdfStripMetadata
    case pdfSearchable
    case extractText

    public var title: String {
        switch self {
        case let .resize(w, h):
            if let w, let h { return "Fit within \(w) × \(h) px" }
            if let w { return "Resize width to \(w) px" }
            if let h { return "Resize height to \(h) px" }
            return "Resize"
        case let .resizeExact(w, h): return "Resize to exactly \(w) × \(h) px"
        case let .cropAspect(w, h): return "Crop to \(Self.ratio(w)):\(Self.ratio(h))"
        case let .convert(f, q): return f.isLossy ? "Export \(f.displayName) (quality \(Int(q * 100)))" : "Export \(f.displayName)"
        case let .compressTo(kb, f): return "Compress to ≤ \(kb) KB as \(f.displayName)"
        case .removeBackground: return "Remove background"
        case let .stripMetadata(gpsOnly): return gpsOnly ? "Remove location data" : "Remove all metadata"
        case .autoEnhance: return "Auto enhance"
        case .grayscale: return "Black & white"
        case .copyToClipboard: return "Copy result to clipboard"
        case .pdfCompress: return "Compress PDF"
        case .pdfStripMetadata: return "Remove PDF metadata"
        case .pdfSearchable: return "Make PDF searchable (OCR)"
        case .extractText: return "Extract text (TXT)"
        }
    }

    static func ratio(_ v: Double) -> String { v == v.rounded() ? String(Int(v)) : String(v) }

    public var isImageStep: Bool {
        switch self {
        case .resize, .resizeExact, .cropAspect, .convert, .compressTo, .removeBackground, .stripMetadata, .autoEnhance, .grayscale:
            return true
        default:
            return false
        }
    }

    public var isPDFStep: Bool {
        switch self {
        case .pdfCompress, .pdfStripMetadata, .pdfSearchable, .extractText: return true
        default: return false
        }
    }
}

public struct Workflow: Codable, Hashable, Identifiable, Sendable {
    public var id: UUID
    public var name: String
    public var symbol: String
    public var steps: [WorkflowStep]
    public var isBuiltIn: Bool

    public init(id: UUID = UUID(), name: String, symbol: String = "bolt", steps: [WorkflowStep], isBuiltIn: Bool = false) {
        self.id = id
        self.name = name
        self.symbol = symbol
        self.steps = steps
        self.isBuiltIn = isBuiltIn
    }

    public func applies(to kind: AssetKind) -> Bool {
        let imageish: Set<AssetKind> = [.image, .rawImage, .animatedImage]
        let core = steps.filter { $0 != .copyToClipboard }
        if core.isEmpty { return false }
        if core.allSatisfy({ $0.isPDFStep }) { return kind == .pdf }
        if core.allSatisfy({ $0.isImageStep || $0 == .extractText }) { return imageish.contains(kind) }
        return false
    }

    public var summary: String { steps.map(\.title).joined(separator: " → ") }

    public static let quickWebExport = Workflow(
        id: UUID(uuidString: "6A0C3D4B-0001-4C1E-9F00-000000000001")!, name: "Quick Web Export", symbol: "globe",
        steps: [.resize(maxWidth: 1600, maxHeight: nil), .convert(format: .webp, quality: 0.8), .stripMetadata(gpsOnly: true)], isBuiltIn: true)
    public static let socialMediaExport = Workflow(
        id: UUID(uuidString: "6A0C3D4B-0001-4C1E-9F00-000000000002")!, name: "Social Media Export", symbol: "square.and.arrow.up",
        steps: [.cropAspect(width: 4, height: 5), .resizeExact(width: 1080, height: 1350), .convert(format: .jpeg, quality: 0.9)], isBuiltIn: true)
    public static let transparentAsset = Workflow(
        id: UUID(uuidString: "6A0C3D4B-0001-4C1E-9F00-000000000003")!, name: "Transparent Asset", symbol: "person.crop.square",
        steps: [.removeBackground, .convert(format: .png, quality: 1), .copyToClipboard], isBuiltIn: true)
    public static let pdfOptimiser = Workflow(
        id: UUID(uuidString: "6A0C3D4B-0001-4C1E-9F00-000000000004")!, name: "PDF Optimiser", symbol: "doc.zipper",
        steps: [.pdfCompress, .pdfStripMetadata], isBuiltIn: true)

    public static let builtIns: [Workflow] = [quickWebExport, socialMediaExport, transparentAsset, pdfOptimiser]
}

public struct WorkflowResult: Sendable {
    public var outputs: [URL] = []
    public var copyToClipboard = false
    public var notes: [String] = []
}

public enum WorkflowEngine {
    public static func run(_ workflow: Workflow, on asset: AssetInfo, planner: OutputPlanner,
                           defaults: ImageExportOptions = ImageExportOptions()) async throws -> WorkflowResult {
        var result = WorkflowResult()
        result.copyToClipboard = workflow.steps.contains(.copyToClipboard)
        if asset.kind == .pdf {
            return try runPDF(workflow, asset: asset, planner: planner, result: result)
        }
        guard [.image, .rawImage, .animatedImage].contains(asset.kind) else {
            throw HexError.message("“\(workflow.name)” works on images or PDFs.")
        }
        let loaded = try ImageLoader.load(asset.url)
        var image = loaded.image
        var format: Format = (asset.format.flatMap { ImageEncoder.canWrite($0) && $0 != .pdf && $0 != .svg ? $0 : nil }) ?? .png
        var options = defaults
        var targetBytes: Int?
        var textOutput: String?
        for step in workflow.steps {
            try Task.checkCancellation()
            switch step {
            case let .resize(mw, mh):
                let size = ImageOps.fittedSize(width: image.width, height: image.height, maxWidth: mw, maxHeight: mh)
                image = ImageOps.resize(image, to: size)
            case let .resizeExact(w, h):
                image = ImageOps.fill(image, size: CGSize(width: w, height: h))
            case let .cropAspect(w, h):
                image = ImageOps.cropToAspect(image, ratioW: w, ratioH: h)
            case let .convert(f, q):
                format = f
                options.quality = q
            case let .compressTo(kb, f):
                format = f
                targetBytes = kb * 1024
            case .removeBackground:
                image = try BackgroundRemoval.removeBackground(image)
                if !format.supportsAlpha { format = .png }
            case let .stripMetadata(gpsOnly):
                options.metadata = gpsOnly ? .stripGPS : .stripAll
            case .autoEnhance:
                image = ImageEffects.autoEnhance(image)
            case .grayscale:
                var a = Adjustments()
                a.grayscale = true
                image = ImageEffects.apply(a, to: image)
            case .extractText:
                textOutput = try OCRService.recognize(image).text
            case .copyToClipboard, .pdfCompress, .pdfStripMetadata, .pdfSearchable:
                break
            }
        }
        if let target = targetBytes {
            options.quality = try ImageCompressor.findQuality(format.supportsAlpha ? image : ImageOps.flatten(image), format: format, targetBytes: target).quality
        }
        let slug = PaletteExporter.slug(workflow.name)
        let dir = planner.folder(for: asset.url)
        let dest = OutputPlanner.unique(dir.appendingPathComponent("\(asset.baseName)-\(slug)").appendingPathExtension(format.fileExtension), avoiding: asset.url)
        try ImageEncoder.write(image, sourceProperties: loaded.properties, format: format, to: dest, options: options)
        result.outputs.append(dest)
        if let text = textOutput, !text.isEmpty {
            let txt = OutputPlanner.unique(dir.appendingPathComponent("\(asset.baseName)-text").appendingPathExtension("txt"))
            try FileWriter.writeAtomically(to: txt) { try Data(text.utf8).write(to: $0) }
            result.outputs.append(txt)
        }
        return result
    }

    static func runPDF(_ workflow: Workflow, asset: AssetInfo, planner: OutputPlanner, result: WorkflowResult) throws -> WorkflowResult {
        var result = result
        let tmpDir = try FileWriter.makeTemporaryDirectory()
        defer { try? FileManager.default.removeItem(at: tmpDir) }
        var current = asset.url
        var step = 0
        func next() -> URL {
            step += 1
            return tmpDir.appendingPathComponent("step\(step).pdf")
        }
        var extractedText: String?
        for s in workflow.steps {
            try Task.checkCancellation()
            switch s {
            case .pdfCompress:
                let out = next()
                do {
                    let r = try PDFEngine.compress(current, output: out)
                    result.notes.append("Compressed \(ByteCountFormatter.string(fromByteCount: r.before, countStyle: .file)) → \(ByteCountFormatter.string(fromByteCount: r.after, countStyle: .file))")
                    current = out
                } catch {
                    result.notes.append((error as? LocalizedError)?.errorDescription ?? "Compression skipped.")
                }
            case .pdfStripMetadata:
                let out = next()
                try PDFEngine.stripMetadata(current, output: out)
                current = out
            case .pdfSearchable:
                let out = next()
                try PDFEngine.makeSearchable(current, output: out)
                current = out
            case .extractText:
                extractedText = try PDFEngine.extractText(current).text
            default:
                break
            }
        }
        let dir = planner.folder(for: asset.url)
        let slug = PaletteExporter.slug(workflow.name)
        if current != asset.url {
            let dest = OutputPlanner.unique(dir.appendingPathComponent("\(asset.baseName)-\(slug)").appendingPathExtension("pdf"), avoiding: asset.url)
            try FileWriter.writeAtomically(to: dest) { tmp in try FileManager.default.copyItem(at: current, to: tmp) }
            result.outputs.append(dest)
        }
        if let text = extractedText {
            let dest = OutputPlanner.unique(dir.appendingPathComponent("\(asset.baseName)-text").appendingPathExtension("txt"))
            try FileWriter.writeAtomically(to: dest) { try Data(text.utf8).write(to: $0) }
            result.outputs.append(dest)
        }
        guard !result.outputs.isEmpty else { throw HexError.message(result.notes.first ?? "The workflow produced no output.") }
        return result
    }
}
