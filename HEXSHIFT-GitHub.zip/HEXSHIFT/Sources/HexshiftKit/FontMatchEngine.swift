import AppKit
import CoreGraphics
import CoreText
import Foundation

// Analysis-by-synthesis font matching.
//
// For every candidate face the recognised text is rebuilt glyph by glyph, mapped onto the
// sample (same ink height, same line extent), each glyph is allowed to slide a few pixels to
// its best spot (letter-spacing and kerning differ between fonts), the stroke weight is allowed
// to vary (screenshots are often rendered bolder than the outline), and the synthetic line is
// given the same resolution history as the sample before the two are compared.
// Candidates are narrowed in three passes so thousands of faces stay fast.

/// Greyscale image, row-major, values 0…1 (ink = 1).
struct GrayImage {
    var width: Int
    var height: Int
    var px: [Float]

    init(width: Int, height: Int, px: [Float]? = nil) {
        self.width = max(1, width)
        self.height = max(1, height)
        self.px = px ?? [Float](repeating: 0, count: self.width * self.height)
    }

    subscript(x: Int, y: Int) -> Float {
        get { px[y * width + x] }
        set { px[y * width + x] = newValue }
    }
}

/// One glyph image at the engine's working em size, positioned relative to the pen on the baseline.
struct PlacedGlyph {
    var image: GrayImage
    var left: Double     // image left, relative to the pen
    var top: Double      // image top, relative to the baseline (negative = above)
    var pen: Double      // pen x along the line
    /// The part of the image that is at least half ink (how the sample's extents are measured too).
    var solid: (x0: Int, y0: Int, x1: Int, y1: Int)

    init(image: GrayImage, left: Double, top: Double, pen: Double) {
        self.image = image
        self.left = left
        self.top = top
        self.pen = pen
        var x0 = image.width, y0 = image.height, x1 = 0, y1 = 0
        for y in 0..<image.height { for x in 0..<image.width where image.px[y * image.width + x] > 0.5 {
            x0 = min(x0, x); x1 = max(x1, x + 1); y0 = min(y0, y); y1 = max(y1, y + 1)
        } }
        solid = x1 > x0 ? (x0, y0, x1, y1) : (0, 0, image.width, image.height)
    }
}

enum MatchEngine {
    static let workHeight = 64.0
    static let pad = 16
    static let slide = 8              // px each glyph may move sideways (at workHeight)
    static let slideY = 2
    static let stretchWeight = 0.05
    static let thicknessWeight = 0.004
    static let thicknessFull: [Int] = [-1, 0, 1, 2, 3]
    static let thicknessQuick: [Int] = [0, 1, 2]

    // MARK: Sample

    struct Sample {
        let text: String
        let work: GrayImage          // ink at workHeight, padded
        let compare: GrayImage       // `work` as it is compared (lightly blurred)
        let factor: Double           // working pixels per original pixel
        let sigma: Double
        let top: Int, bottom: Int, left: Int, right: Int   // ink extents in `work`
        // Half-resolution copy for the quick first pass.
        let small: GrayImage
        let smallTop: Int, smallBottom: Int, smallLeft: Int, smallRight: Int
    }

    static func prepare(ink: [Float], width: Int, height: Int, text: String) -> Sample? {
        guard let box = inkBox(ink, width: width, height: height) else { return nil }
        let m = 2
        let x0 = max(0, box.minX - m), y0 = max(0, box.minY - m)
        let x1 = min(width, box.maxX + 1 + m), y1 = min(height, box.maxY + 1 + m)
        var crop = GrayImage(width: x1 - x0, height: y1 - y0)
        for y in 0..<crop.height { for x in 0..<crop.width { crop[x, y] = ink[(y + y0) * width + (x + x0)] } }
        let inkH = Double(box.maxY - box.minY + 1)
        let f = workHeight / inkH
        let scaled = resizeBilinear(crop, width: Int((Double(crop.width) * f).rounded()), height: Int((Double(crop.height) * f).rounded()))
        let work = padded(scaled, pad)
        guard let wb = inkBox(work.px, width: work.width, height: work.height) else { return nil }
        let sigma = max(1.0, 0.5 * f)
        let compare = f > 1.15 ? gaussian(work, sigma: 0.6) : gaussian(work, sigma: sigma)
        let half = resizeArea(work, width: work.width / 2, height: work.height / 2)
        guard let hb = inkBox(half.px, width: half.width, height: half.height) else { return nil }
        return Sample(text: text, work: work, compare: compare, factor: f, sigma: sigma,
                      top: wb.minY, bottom: wb.maxY + 1, left: wb.minX, right: wb.maxX + 1,
                      small: gaussian(half, sigma: max(0.7, 0.25 * f)),
                      smallTop: hb.minY, smallBottom: hb.maxY + 1, smallLeft: hb.minX, smallRight: hb.maxX + 1)
    }

    // MARK: Scoring

    enum Pass { case quick, full, detailed }

    struct Score {
        let value: Double
        let dice: Double
        let stretch: Double
        let thickness: Int
    }

    /// Scores one candidate (its glyphs laid out at `em` px per em) against the sample.
    static func score(_ sample: Sample, glyphs: [PlacedGlyph], em: Double, pass: Pass) -> Score? {
        guard !glyphs.isEmpty else { return nil }
        let quick = pass == .quick
        let target = quick ? sample.small : sample.compare
        let sTop = Double(quick ? sample.smallTop : sample.top), sBottom = Double(quick ? sample.smallBottom : sample.bottom)
        let sLeft = Double(quick ? sample.smallLeft : sample.left), sRight = Double(quick ? sample.smallRight : sample.right)
        var cTop = Double.greatestFiniteMagnitude, cBottom = -Double.greatestFiniteMagnitude
        var cLeft = Double.greatestFiniteMagnitude, cRight = -Double.greatestFiniteMagnitude
        for g in glyphs {
            cTop = min(cTop, g.top + Double(g.solid.y0)); cBottom = max(cBottom, g.top + Double(g.solid.y1))
            cLeft = min(cLeft, g.pen + g.left + Double(g.solid.x0)); cRight = max(cRight, g.pen + g.left + Double(g.solid.x1))
        }
        guard cBottom > cTop, cRight > cLeft else { return nil }
        let s = (sBottom - sTop) / (cBottom - cTop)
        let c = sTop - s * cTop
        let a = (sRight - sLeft) / (cRight - cLeft)
        let b = sLeft - a * cLeft
        guard s > 0, a > 0 else { return nil }
        let stretch = abs(log(a / s))
        var comp = GrayImage(width: target.width, height: target.height)
        let slideX = pass == .detailed ? slide : 0
        let slideY = pass == .detailed ? Self.slideY : 0
        for g in glyphs {
            let gw = max(1, Int((Double(g.image.width) * s).rounded())), gh = max(1, Int((Double(g.image.height) * s).rounded()))
            let scaled = resizeBilinear(g.image, width: gw, height: gh)
            var x = Int((a * (g.pen + g.left) + b).rounded())
            var y = Int((s * g.top + c).rounded())
            if slideX > 0 || slideY > 0 {
                let off = bestOffset(template: scaled, at: x, y, in: target, sigma: sample.sigma, rx: slideX, ry: slideY)
                x += off.dx
                y += off.dy
            }
            stamp(scaled, into: &comp, x: x, y: y)
        }
        var best = (dice: -1.0, r: 0)
        for r in quick ? [0, 1] : (pass == .full ? thicknessQuick : thicknessFull) {
            let m = r == 0 ? comp : morph(comp, radius: r)
            let degraded: GrayImage
            if quick {
                degraded = gaussian(m, sigma: max(0.7, 0.25 * sample.factor))
            } else if sample.factor > 1.15 {
                degraded = degrade(m, factor: sample.factor)
            } else {
                degraded = gaussian(m, sigma: sample.sigma)
            }
            let d = dice(target, degraded)
            if d > best.dice { best = (d, r) }
        }
        // Screens usually render text a little heavier than its outline, so up to 2 px of extra
        // weight is free; thinning or heavier changes cost a little.
        let thicknessPenalty = (0...2).contains(best.r) ? 0 : thicknessWeight * Double(abs(best.r))
        let value = best.dice - stretchWeight * stretch - thicknessPenalty
        return Score(value: value, dice: best.dice, stretch: stretch, thickness: best.r)
    }

    /// Gives the synthetic line the sample's history: rasterised at the original (smaller)
    /// size, then enlarged to the working size.
    static func degrade(_ img: GrayImage, factor f: Double) -> GrayImage {
        let w = max(1, Int((Double(img.width) / f).rounded())), h = max(1, Int((Double(img.height) / f).rounded()))
        let small = resizeArea(img, width: w, height: h)
        return gaussian(resizeBilinear(small, width: img.width, height: img.height), sigma: 0.6)
    }

    static func bestOffset(template: GrayImage, at x: Int, _ y: Int, in target: GrayImage, sigma: Double,
                           rx: Int, ry: Int) -> (dx: Int, dy: Int) {
        let p = 3
        let t = gaussian(padded(template, p), sigma: sigma)
        var tNorm: Float = 0
        for v in t.px { tNorm += v * v }
        guard tNorm > 0 else { return (0, 0) }
        var best: (v: Float, dx: Int, dy: Int) = (-1, 0, 0)
        for dy in -ry...ry {
            let oy = y - p + dy
            guard oy >= 0, oy + t.height <= target.height else { continue }
            for dx in -rx...rx {
                let ox = x - p + dx
                guard ox >= 0, ox + t.width <= target.width else { continue }
                var num: Float = 0, den: Float = 0
                target.px.withUnsafeBufferPointer { sp in
                    t.px.withUnsafeBufferPointer { tp in
                        for yy in 0..<t.height {
                            let trow = yy * t.width, srow = (oy + yy) * target.width + ox
                            for xx in 0..<t.width {
                                let sv = sp[srow + xx]
                                num += sv * tp[trow + xx]
                                den += sv * sv
                            }
                        }
                    }
                }
                guard den > 0 else { continue }
                let v = num / (den * tNorm).squareRoot()
                if v > best.v { best = (v, dx, dy) }
            }
        }
        return (best.dx, best.dy)
    }

    // MARK: Glyph layout

    /// Glyphs of `text` in an installed font at `em` px, via Core Text (kerning and ligatures included).
    /// Returns nil if the font lacks any of the characters.
    static func layoutInstalled(_ text: String, postScriptName: String, em: Double) -> [PlacedGlyph]? {
        let font = CTFontCreateWithName(postScriptName as CFString, em, nil)
        guard (CTFontCopyPostScriptName(font) as String) == postScriptName else { return nil }
        let attrs: [NSAttributedString.Key: Any] = [NSAttributedString.Key(kCTFontAttributeName as String): font]
        let line = CTLineCreateWithAttributedString(NSAttributedString(string: text, attributes: attrs))
        guard let runs = CTLineGetGlyphRuns(line) as? [CTRun] else { return nil }
        var out: [PlacedGlyph] = []
        var cache: [CGGlyph: (GrayImage, Double, Double)?] = [:]
        for run in runs {
            let runAttrs = CTRunGetAttributes(run) as NSDictionary
            if let runFont = runAttrs[kCTFontAttributeName as String] {
                // A different font in the run means Core Text had to substitute: the face lacks a character.
                let rf = runFont as! CTFont
                if (CTFontCopyPostScriptName(rf) as String) != postScriptName { return nil }
            }
            let n = CTRunGetGlyphCount(run)
            var glyphs = [CGGlyph](repeating: 0, count: n)
            var positions = [CGPoint](repeating: .zero, count: n)
            CTRunGetGlyphs(run, CFRange(location: 0, length: n), &glyphs)
            CTRunGetPositions(run, CFRange(location: 0, length: n), &positions)
            for i in 0..<n {
                let entry: (GrayImage, Double, Double)?
                if let hit = cache[glyphs[i]] { entry = hit } else {
                    entry = renderGlyph(glyphs[i], font: font)
                    cache[glyphs[i]] = entry
                }
                guard let (img, left, top) = entry else { continue }   // spaces have no ink
                out.append(PlacedGlyph(image: img, left: left, top: top, pen: Double(positions[i].x)))
            }
        }
        return out
    }

    /// Renders one glyph with its ink box and offsets from the pen on the baseline (y down).
    static func renderGlyph(_ glyph: CGGlyph, font: CTFont) -> (GrayImage, Double, Double)? {
        var g = glyph
        var rect = CGRect.zero
        CTFontGetBoundingRectsForGlyphs(font, .default, &g, &rect, 1)
        guard rect.width > 0.5, rect.height > 0.5 else { return nil }
        let margin: CGFloat = 3
        let W = Int(ceil(rect.width + 2 * margin)), H = Int(ceil(rect.height + 2 * margin))
        guard W < 2000, H < 2000,
              let ctx = CGContext(data: nil, width: W, height: H, bitsPerComponent: 8, bytesPerRow: W,
                                  space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGImageAlphaInfo.none.rawValue),
              let data = ctx.data else { return nil }
        ctx.setFillColor(gray: 0, alpha: 1)
        ctx.fill(CGRect(x: 0, y: 0, width: W, height: H))
        ctx.setFillColor(gray: 1, alpha: 1)
        ctx.setShouldAntialias(true)
        ctx.setShouldSmoothFonts(false)
        let ox = (margin - rect.minX).rounded(), oy = (margin - rect.minY).rounded()
        var pos = CGPoint(x: ox, y: oy)
        CTFontDrawGlyphs(font, &g, &pos, 1, ctx)
        let bytes = data.bindMemory(to: UInt8.self, capacity: W * H)
        var minX = W, minY = H, maxX = -1, maxY = -1
        for y in 0..<H { for x in 0..<W where bytes[y * W + x] > 5 {
            minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
        } }
        guard maxX >= minX, maxY >= minY else { return nil }
        var img = GrayImage(width: maxX - minX + 1, height: maxY - minY + 1)
        for y in 0..<img.height { for x in 0..<img.width {
            img[x, y] = Float(bytes[(y + minY) * W + (x + minX)]) / 255
        } }
        // Memory row 0 is the top of the bitmap; the baseline sits at row H - oy.
        let baselineRow = Double(H) - Double(oy)
        return (img, Double(minX) - Double(ox), Double(minY) - baselineRow)
    }

    /// Glyphs of `text` from the bundled reference (no kerning; accents folded to base letters).
    static func layoutReference(_ text: String, face: FontReference.Face, reference: FontReference) -> [PlacedGlyph]? {
        let folded = text.folding(options: [.diacriticInsensitive, .widthInsensitive], locale: nil)
        let table = reference.glyphs(Set(folded).union([" ", "n"]), of: face)
        var pen = 0.0
        var out: [PlacedGlyph] = []
        let space = table[" "]?.advance ?? Double(reference.em) * 0.26
        for ch in folded {
            if ch == " " || ch.isWhitespace { pen += space; continue }
            guard let g = table[ch] else {
                // Unknown character: leave a gap the width of an "n" so the rest still lines up.
                pen += table["n"]?.advance ?? Double(reference.em) * 0.5
                continue
            }
            if g.width > 0 && g.height > 0 {
                out.append(PlacedGlyph(image: GrayImage(width: g.width, height: g.height, px: g.pixels),
                                       left: Double(g.left), top: Double(g.top), pen: pen))
            }
            pen += g.advance
        }
        return out.isEmpty ? nil : out
    }

    // MARK: Image helpers

    static func inkBox(_ p: [Float], width w: Int, height h: Int) -> (minX: Int, minY: Int, maxX: Int, maxY: Int)? {
        var minX = w, minY = h, maxX = -1, maxY = -1
        for y in 0..<h { for x in 0..<w where p[y * w + x] > 0.5 {
            minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
        } }
        guard maxX > minX + 1, maxY > minY + 1 else { return nil }
        return (minX, minY, maxX, maxY)
    }

    static func padded(_ img: GrayImage, _ p: Int) -> GrayImage {
        var out = GrayImage(width: img.width + 2 * p, height: img.height + 2 * p)
        for y in 0..<img.height {
            let src = y * img.width, dst = (y + p) * out.width + p
            for x in 0..<img.width { out.px[dst + x] = img.px[src + x] }
        }
        return out
    }

    static func stamp(_ g: GrayImage, into comp: inout GrayImage, x: Int, y: Int) {
        let y0 = max(0, y), x0 = max(0, x)
        let y1 = min(comp.height, y + g.height), x1 = min(comp.width, x + g.width)
        guard y1 > y0, x1 > x0 else { return }
        for yy in y0..<y1 {
            let crow = yy * comp.width, grow = (yy - y) * g.width - x
            for xx in x0..<x1 {
                let v = g.px[grow + xx]
                if v > comp.px[crow + xx] { comp.px[crow + xx] = v }
            }
        }
    }

    /// Bilinear when enlarging; area-average when shrinking (so small results aren't aliased).
    static func resizeBilinear(_ src: GrayImage, width: Int, height: Int) -> GrayImage {
        let w = max(1, width), h = max(1, height)
        if w == src.width && h == src.height { return src }
        if w < src.width && h < src.height { return resizeArea(src, width: w, height: h) }
        var out = GrayImage(width: w, height: h)
        let sx = Double(src.width) / Double(w), sy = Double(src.height) / Double(h)
        for y in 0..<h {
            let fy = max(0, (Double(y) + 0.5) * sy - 0.5)
            let y0 = min(src.height - 1, Int(fy)), y1 = min(src.height - 1, y0 + 1)
            let ty = Float(fy - Double(y0))
            for x in 0..<w {
                let fx = max(0, (Double(x) + 0.5) * sx - 0.5)
                let x0 = min(src.width - 1, Int(fx)), x1 = min(src.width - 1, x0 + 1)
                let tx = Float(fx - Double(x0))
                let a = src.px[y0 * src.width + x0], b = src.px[y0 * src.width + x1]
                let c = src.px[y1 * src.width + x0], d = src.px[y1 * src.width + x1]
                out.px[y * w + x] = (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty
            }
        }
        return out
    }

    /// Area-average resize (for shrinking: behaves like a rasteriser's anti-aliasing).
    static func resizeArea(_ src: GrayImage, width: Int, height: Int) -> GrayImage {
        guard let r = FontMatcher.resample(src.px, width: src.width, height: src.height, toHeight: max(1, height), toWidth: max(1, width))
        else { return GrayImage(width: width, height: height) }
        return GrayImage(width: r.width, height: max(1, height), px: r.pixels)
    }

    static func gaussian(_ img: GrayImage, sigma: Double) -> GrayImage {
        guard sigma > 0.05 else { return img }
        let r = max(1, Int(ceil(sigma * 3)))
        var k = [Float](repeating: 0, count: 2 * r + 1)
        var sum: Float = 0
        for i in -r...r { let v = Float(exp(-Double(i * i) / (2 * sigma * sigma))); k[i + r] = v; sum += v }
        for i in 0..<k.count { k[i] /= sum }
        let w = img.width, h = img.height
        var tmp = [Float](repeating: 0, count: w * h)
        var out = [Float](repeating: 0, count: w * h)
        k.withUnsafeBufferPointer { kp in
            img.px.withUnsafeBufferPointer { src in
                tmp.withUnsafeMutableBufferPointer { t in
                    for y in 0..<h {
                        let row = y * w
                        for x in 0..<w {
                            var acc: Float = 0
                            let lo = max(-r, -x), hi = min(r, w - 1 - x)
                            if lo <= hi { for i in lo...hi { acc += src[row + x + i] * kp[i + r] } }
                            t[row + x] = acc
                        }
                    }
                }
            }
            tmp.withUnsafeBufferPointer { t in
                out.withUnsafeMutableBufferPointer { o in
                    for y in 0..<h {
                        let lo = max(-r, -y), hi = min(r, h - 1 - y)
                        for x in 0..<w {
                            var acc: Float = 0
                            if lo <= hi { for i in lo...hi { acc += t[(y + i) * w + x] * kp[i + r] } }
                            o[y * w + x] = acc
                        }
                    }
                }
            }
        }
        return GrayImage(width: w, height: h, px: out)
    }

    private static var disks: [Int: [(Int, Int)]] = {
        var d: [Int: [(Int, Int)]] = [:]
        for r in 1...5 {
            var offs: [(Int, Int)] = []
            for dy in -r...r { for dx in -r...r where dx * dx + dy * dy <= r * r { offs.append((dx, dy)) } }
            d[r] = offs
        }
        return d
    }()

    /// Grey dilation (radius > 0) or erosion (radius < 0) with a disk.
    static func morph(_ img: GrayImage, radius: Int) -> GrayImage {
        let r = min(5, abs(radius))
        guard r > 0, let offs = disks[r] else { return img }
        let w = img.width, h = img.height
        let dilate = radius > 0
        var out = [Float](repeating: dilate ? 0 : 1, count: w * h)
        img.px.withUnsafeBufferPointer { src in
            out.withUnsafeMutableBufferPointer { dst in
                for y in 0..<h {
                    for x in 0..<w {
                        var v: Float = dilate ? 0 : 1
                        for (dx, dy) in offs {
                            let xx = x + dx, yy = y + dy
                            let s: Float = (xx >= 0 && xx < w && yy >= 0 && yy < h) ? src[yy * w + xx] : 0
                            if dilate { if s > v { v = s } } else { if s < v { v = s } }
                        }
                        dst[y * w + x] = v
                    }
                }
            }
        }
        return GrayImage(width: w, height: h, px: out)
    }

    static func dice(_ a: GrayImage, _ b: GrayImage) -> Double {
        let n = min(a.px.count, b.px.count)
        var inter: Float = 0, uni: Float = 0
        for i in 0..<n {
            let x = a.px[i], y = b.px[i]
            inter += min(x, y)
            uni += max(x, y)
        }
        return uni > 0 ? Double(inter / uni) : 0
    }
}
