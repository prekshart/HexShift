import Foundation

/// Safe file output: write to a hidden temporary file next to the destination,
/// validate it, then move it into place. Failed conversions leave nothing behind.
public enum FileWriter {
    public static func writeAtomically(to url: URL, allowOverwrite: Bool = false, _ body: (URL) throws -> Void) throws {
        let fm = FileManager.default
        let dir = url.deletingLastPathComponent()
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let tmp = dir.appendingPathComponent(".hexshift-\(UUID().uuidString.prefix(8))-\(url.lastPathComponent)")
        do {
            try body(tmp)
            guard fm.fileExists(atPath: tmp.path) else { throw HexError.invalidOutput("No file was produced.") }
            if fm.fileExists(atPath: url.path) {
                guard allowOverwrite else { throw HexError.wouldOverwriteOriginal }
                _ = try fm.replaceItemAt(url, withItemAt: tmp)
            } else {
                try fm.moveItem(at: tmp, to: url)
            }
        } catch {
            try? fm.removeItem(at: tmp)
            throw error
        }
    }

    /// Async variant for AVFoundation exports and other asynchronous writers.
    public static func writeAtomicallyAsync(to url: URL, _ body: (URL) async throws -> Void) async throws {
        let fm = FileManager.default
        let dir = url.deletingLastPathComponent()
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let tmp = dir.appendingPathComponent(".hexshift-\(UUID().uuidString.prefix(8))-\(url.lastPathComponent)")
        do {
            try await body(tmp)
            guard fm.fileExists(atPath: tmp.path) else { throw HexError.invalidOutput("No file was produced.") }
            guard !fm.fileExists(atPath: url.path) else { throw HexError.wouldOverwriteOriginal }
            try fm.moveItem(at: tmp, to: url)
        } catch {
            try? fm.removeItem(at: tmp)
            throw error
        }
    }

    /// A fresh private temporary folder (callers remove it when done).
    public static func makeTemporaryDirectory() throws -> URL {
        let base = FileManager.default.temporaryDirectory.appendingPathComponent("HEXSHIFT", isDirectory: true)
        let dir = base.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    /// Removes leftovers from previous sessions (temporary folders older than a day).
    public static func cleanStaleTemporaryFiles() {
        let fm = FileManager.default
        let base = fm.temporaryDirectory.appendingPathComponent("HEXSHIFT", isDirectory: true)
        guard let items = try? fm.contentsOfDirectory(at: base, includingPropertiesForKeys: [.contentModificationDateKey]) else { return }
        let cutoff = Date().addingTimeInterval(-24 * 3600)
        for item in items {
            let date = (try? item.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
            if date < cutoff { try? fm.removeItem(at: item) }
        }
    }
}

/// Optional command-line tools HEXSHIFT can use when they are installed.
/// Nothing is bundled or downloaded automatically.
public enum ExternalTool: String, CaseIterable, Sendable {
    case ffmpeg, pandoc, soffice, gs, avifenc, potrace

    public var displayName: String {
        switch self {
        case .ffmpeg: return "FFmpeg"
        case .pandoc: return "Pandoc"
        case .soffice: return "LibreOffice"
        case .gs: return "Ghostscript"
        case .avifenc: return "libavif (avifenc)"
        case .potrace: return "Potrace"
        }
    }

    public var purpose: String {
        switch self {
        case .ffmpeg: return "WebM/MKV/AVI video, MP3 audio"
        case .pandoc: return "Higher-fidelity Markdown, Word and HTML conversion"
        case .soffice: return "High-fidelity Word, PowerPoint and Excel to PDF"
        case .gs: return "EPS and legacy Illustrator files, strongest PDF compression"
        case .avifenc: return "AVIF export on macOS versions without a built-in AVIF encoder"
        case .potrace: return "Smoother single-colour vector tracing"
        }
    }

    public var installHint: String {
        switch self {
        case .ffmpeg: return "Install it with Homebrew: brew install ffmpeg"
        case .pandoc: return "Install it with Homebrew: brew install pandoc"
        case .soffice: return "Install LibreOffice from libreoffice.org or with: brew install --cask libreoffice"
        case .gs: return "Install it with Homebrew: brew install ghostscript"
        case .avifenc: return "Install it with Homebrew: brew install libavif"
        case .potrace: return "Install it with Homebrew: brew install potrace"
        }
    }

    var executableName: String { rawValue }
}

public struct ProcessResult: Sendable {
    public let status: Int32
    public let stdout: String
    public let stderr: String
}

public enum ExternalTools {
    static let searchDirectories = [
        "/opt/homebrew/bin", "/usr/local/bin", "/opt/local/bin", "/usr/bin",
        "/Applications/LibreOffice.app/Contents/MacOS",
    ]

    private static let cacheLock = NSLock()
    private static var cache: [ExternalTool: String?] = [:]

    /// GUI apps don't inherit the shell PATH, so look in the usual install locations.
    public static func path(_ tool: ExternalTool) -> String? {
        cacheLock.lock()
        defer { cacheLock.unlock() }
        if let cached = cache[tool] { return cached }
        var found: String?
        for dir in searchDirectories {
            let candidate = (dir as NSString).appendingPathComponent(tool.executableName)
            if FileManager.default.isExecutableFile(atPath: candidate) { found = candidate; break }
        }
        cache[tool] = found
        return found
    }

    public static func refresh() {
        cacheLock.lock()
        cache.removeAll()
        cacheLock.unlock()
    }

    public static var installedSummary: [(ExternalTool, String?)] {
        ExternalTool.allCases.map { ($0, path($0)) }
    }

    /// Runs a tool with arguments (never through a shell) and captures its output.
    @discardableResult
    public static func run(_ executable: String, _ arguments: [String], timeout: TimeInterval = 600,
                           environment: [String: String]? = nil) throws -> ProcessResult {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        if let environment { process.environment = environment }
        let outPipe = Pipe()
        let errPipe = Pipe()
        process.standardOutput = outPipe
        process.standardError = errPipe
        process.standardInput = FileHandle.nullDevice

        // Drain pipes concurrently so large outputs never block the child.
        let outBox = DataBox()
        let errBox = DataBox()
        let group = DispatchGroup()
        group.enter()
        DispatchQueue.global().async {
            outBox.data = outPipe.fileHandleForReading.readDataToEndOfFile()
            group.leave()
        }
        group.enter()
        DispatchQueue.global().async {
            errBox.data = errPipe.fileHandleForReading.readDataToEndOfFile()
            group.leave()
        }

        try process.run()
        let deadline = Date().addingTimeInterval(timeout)
        while process.isRunning {
            if Date() > deadline {
                process.terminate()
                throw HexError.message("\((executable as NSString).lastPathComponent) took too long and was stopped.")
            }
            if Task.isCancelled {
                process.terminate()
                throw HexError.cancelled
            }
            Thread.sleep(forTimeInterval: 0.05)
        }
        group.wait()
        return ProcessResult(status: process.terminationStatus,
                             stdout: String(decoding: outBox.data, as: UTF8.self),
                             stderr: String(decoding: errBox.data, as: UTF8.self))
    }
}

/// Reference box so concurrent readers can hand data back without capturing a var.
final class DataBox: @unchecked Sendable {
    var data = Data()
}
