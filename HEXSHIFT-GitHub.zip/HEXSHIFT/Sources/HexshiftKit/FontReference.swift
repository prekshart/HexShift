import Foundation

/// Bundled reference of popular free Google Fonts, so the font finder can name fonts that
/// aren't installed on this Mac. It holds small greyscale glyph images and metrics only —
/// enough to compare shapes — not the fonts themselves.
///
/// File format (little-endian), written by `tools/build_font_reference.py`:
///   "HXFR" u32 version, u32 em, u32 faceCount, u32 charCount, u32 chars[charCount]
///   per face: u16 len + family utf8, u16 len + slug utf8, u16 weight, u8 italic, u8 category,
///             i16 ascender, i16 descender, i16 xHeight, i16 capHeight,
///             u32 blobOffset, u32 blobSize, u32 rawSize
///   blob (raw DEFLATE): per char u8 kind (0 missing, 1 glyph, 2 advance only), then for a glyph
///             u8 w, u8 h, i8 left, i8 top, u16 advance×16, 4-bit greyscale bitmap (w×h, row-major,
///             two pixels per byte); for kind 2 just u16 advance×16
public final class FontReference: @unchecked Sendable {
    public struct Face: Sendable, Hashable {
        public let index: Int
        public let family: String
        public let slug: String
        public let weight: Int
        public let italic: Bool
        public let category: FontCategory
        public let ascender: Int
        public let descender: Int
        public let xHeight: Int
        public let capHeight: Int
        fileprivate let blobOffset: Int
        fileprivate let blobSize: Int
        fileprivate let rawSize: Int

        public var googleFontsURL: URL? { URL(string: "https://fonts.google.com/specimen/\(slug)") }
        public var styleName: String {
            let names = [100: "Thin", 200: "ExtraLight", 300: "Light", 400: "Regular", 500: "Medium",
                         600: "SemiBold", 700: "Bold", 800: "ExtraBold", 900: "Black"]
            let base = names[(weight + 50) / 100 * 100] ?? "\(weight)"
            return italic ? (base == "Regular" ? "Italic" : base + " Italic") : base
        }
    }

    /// One glyph image at `em` pixels per em. `top`/`left` are offsets from the pen position
    /// on the baseline (y grows downward); `advance` is in pixels.
    public struct Glyph: Sendable {
        public let width: Int
        public let height: Int
        public let left: Int
        public let top: Int
        public let advance: Double
        public let pixels: [Float]
    }

    public let em: Int
    public let faces: [Face]
    private let charIndex: [Character: Int]
    private let data: Data
    private var rawCache: [Int: Data] = [:]
    private let lock = NSLock()

    /// The reference bundled with the app, if present.
    public static let shared: FontReference? = {
        for url in candidateURLs() {
            if let data = try? Data(contentsOf: url, options: .mappedIfSafe), let ref = FontReference(data: data) { return ref }
        }
        return nil
    }()

    private static func candidateURLs() -> [URL] {
        var urls: [URL] = []
        if let u = Bundle.main.url(forResource: "FontReference", withExtension: "bin") { urls.append(u) }
        if let env = ProcessInfo.processInfo.environment["HEXSHIFT_RESOURCES"] {
            urls.append(URL(fileURLWithPath: env).appendingPathComponent("FontReference.bin"))
        }
        let exe = URL(fileURLWithPath: CommandLine.arguments.first ?? "").resolvingSymlinksInPath().deletingLastPathComponent()
        urls.append(exe.appendingPathComponent("../Resources/FontReference.bin").standardizedFileURL)
        urls.append(URL(fileURLWithPath: FileManager.default.currentDirectoryPath).appendingPathComponent("Resources/FontReference.bin"))
        return urls
    }

    public init?(data: Data) {
        var r = Reader(data: data)
        guard r.bytes(4) == Array("HXFR".utf8), r.u32() == 1 else { return nil }
        em = Int(r.u32())
        let faceCount = Int(r.u32()), charCount = Int(r.u32())
        guard faceCount < 100_000, charCount < 10_000 else { return nil }
        var index: [Character: Int] = [:]
        for i in 0..<charCount {
            if let scalar = Unicode.Scalar(r.u32()) { index[Character(scalar)] = i }
        }
        charIndex = index
        var list: [Face] = []
        for i in 0..<faceCount {
            let family = r.string(), slug = r.string()
            let weight = Int(r.u16()), italic = r.u8() != 0
            let cat: FontCategory
            switch r.u8() {
            case 1: cat = .serif
            case 2: cat = .sansSerif
            case 3: cat = .monospace
            case 4: cat = .display
            case 5: cat = .script
            default: cat = .unknown
            }
            let asc = Int(r.i16()), desc = Int(r.i16()), xh = Int(r.i16()), caps = Int(r.i16())
            let off = Int(r.u32()), size = Int(r.u32()), raw = Int(r.u32())
            guard !r.failed else { return nil }
            list.append(Face(index: i, family: family, slug: slug, weight: weight, italic: italic, category: cat,
                             ascender: asc, descender: desc, xHeight: xh, capHeight: caps,
                             blobOffset: off, blobSize: size, rawSize: raw))
        }
        guard !r.failed else { return nil }
        faces = list
        self.data = data
    }

    public func supports(_ ch: Character) -> Bool { charIndex[ch] != nil }

    /// Decompressed glyph records of a face (small cache: a match touches each face once or twice).
    private func records(of face: Face) -> Data? {
        lock.lock()
        if let hit = rawCache[face.index] { lock.unlock(); return hit }
        lock.unlock()
        let slice = data.subdata(in: face.blobOffset..<(face.blobOffset + face.blobSize))
        guard let raw = try? (slice as NSData).decompressed(using: .zlib) as Data, raw.count == face.rawSize else { return nil }
        lock.lock()
        if rawCache.count >= 64 { rawCache.removeAll(keepingCapacity: true) }
        rawCache[face.index] = raw
        lock.unlock()
        return raw
    }

    /// The glyphs for `chars` in `face` (characters the face doesn't have are left out).
    public func glyphs(_ chars: Set<Character>, of face: Face) -> [Character: Glyph] {
        guard let raw = records(of: face) else { return [:] }
        let wanted = Set(chars.compactMap { charIndex[$0] })
        var reverse: [Int: Character] = [:]
        for ch in chars { if let i = charIndex[ch] { reverse[i] = ch } }
        var out: [Character: Glyph] = [:]
        var r = Reader(data: raw)
        for i in 0..<charIndex.count {
            let kind = r.u8()
            if kind == 2 {
                let adv = Double(r.u16()) / 16
                if wanted.contains(i), let ch = reverse[i] { out[ch] = Glyph(width: 0, height: 0, left: 0, top: 0, advance: adv, pixels: []) }
                continue
            }
            guard kind == 1 else { continue }
            let w = Int(r.u8()), h = Int(r.u8()), left = Int(r.i8()), top = Int(r.i8())
            let adv = Double(r.u16()) / 16
            let count = (w * h + 1) / 2
            guard wanted.contains(i), let ch = reverse[i] else { r.skip(count); continue }
            let packed = r.bytes(count)
            var px = [Float](repeating: 0, count: w * h)
            for k in 0..<(w * h) {
                let byte = packed[k / 2]
                px[k] = Float(k % 2 == 0 ? byte >> 4 : byte & 0x0F) / 15
            }
            if r.failed { break }
            out[ch] = Glyph(width: w, height: h, left: left, top: top, advance: adv, pixels: px)
        }
        return out
    }

    public func glyph(_ ch: Character, of face: Face) -> Glyph? {
        glyphs([ch], of: face)[ch]
    }
}

private struct Reader {
    let data: Data
    var pos = 0
    var failed = false
    init(data: Data) { self.data = data }

    mutating func bytes(_ n: Int) -> [UInt8] {
        guard n >= 0, pos + n <= data.count else { failed = true; return [UInt8](repeating: 0, count: max(0, n)) }
        let start = data.startIndex + pos
        pos += n
        return [UInt8](data[start..<(start + n)])
    }
    mutating func skip(_ n: Int) {
        if pos + n <= data.count { pos += n } else { failed = true }
    }
    mutating func u8() -> UInt8 {
        guard pos < data.count else { failed = true; return 0 }
        let v = data[data.startIndex + pos]
        pos += 1
        return v
    }
    mutating func i8() -> Int8 { Int8(bitPattern: u8()) }
    mutating func u16() -> UInt16 { let a = u8(), b = u8(); return UInt16(a) | UInt16(b) << 8 }
    mutating func i16() -> Int16 { Int16(bitPattern: u16()) }
    mutating func u32() -> UInt32 {
        let b = bytes(4)
        return UInt32(b[0]) | UInt32(b[1]) << 8 | UInt32(b[2]) << 16 | UInt32(b[3]) << 24
    }
    mutating func string() -> String {
        let n = Int(u16())
        return String(decoding: bytes(n), as: UTF8.self)
    }
}
