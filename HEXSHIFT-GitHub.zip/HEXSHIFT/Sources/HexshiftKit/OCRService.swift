import CoreGraphics
import Foundation
import Vision

public struct OCRLine: Hashable, Sendable {
    public let text: String
    public let confidence: Float
    /// Normalised (0...1) box, origin at the bottom-left (Vision convention).
    public let boundingBox: CGRect

    // CGRect only became Hashable in the macOS 15 SDK, so hash it by hand (works with Xcode 15 and 16).
    public func hash(into hasher: inout Hasher) {
        hasher.combine(text)
        hasher.combine(confidence)
        hasher.combineRect(boundingBox)
    }
}

extension Hasher {
    /// Hashes a CGRect's components (CGRect isn't Hashable before the macOS 15 SDK).
    public mutating func combineRect(_ r: CGRect) {
        combine(r.origin.x); combine(r.origin.y); combine(r.size.width); combine(r.size.height)
    }
}

public struct OCRResult: Sendable {
    public let lines: [OCRLine]
    public let imageSize: CGSize

    /// Lines in reading order, with blank lines between paragraphs.
    public var text: String {
        guard !lines.isEmpty else { return "" }
        var out = ""
        var previous: OCRLine?
        for line in lines {
            if let p = previous {
                let gap = p.boundingBox.minY - line.boundingBox.maxY
                let lineHeight = max(p.boundingBox.height, line.boundingBox.height)
                out += gap > lineHeight * 0.9 ? "\n\n" : "\n"
            }
            out += line.text
            previous = line
        }
        return out
    }

    public var averageConfidence: Float {
        guard !lines.isEmpty else { return 0 }
        return lines.map(\.confidence).reduce(0, +) / Float(lines.count)
    }

    /// Lines Vision was unsure about (shown to the user for checking).
    public var uncertainLines: [OCRLine] { lines.filter { $0.confidence < 0.5 } }

    /// Lines converted to top-left-origin pixel rectangles.
    public func pixelRect(for line: OCRLine) -> CGRect {
        let b = line.boundingBox
        return CGRect(x: b.minX * imageSize.width, y: (1 - b.maxY) * imageSize.height,
                      width: b.width * imageSize.width, height: b.height * imageSize.height)
    }
}

/// On-device text recognition with Apple Vision. Nothing leaves the Mac.
public enum OCRService {
    public static func recognize(_ image: CGImage, fast: Bool = false, languages: [String]? = nil) throws -> OCRResult {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = fast ? .fast : .accurate
        request.usesLanguageCorrection = true
        request.automaticallyDetectsLanguage = true
        if let languages, !languages.isEmpty { request.recognitionLanguages = languages }
        let handler = VNImageRequestHandler(cgImage: image, options: [:])
        try handler.perform([request])
        let observations = request.results ?? []
        var lines: [OCRLine] = []
        for obs in observations {
            guard let candidate = obs.topCandidates(1).first else { continue }
            let text = candidate.string.trimmingCharacters(in: .whitespaces)
            if text.isEmpty { continue }
            lines.append(OCRLine(text: text, confidence: candidate.confidence, boundingBox: obs.boundingBox))
        }
        // Reading order: top to bottom, then left to right within a row.
        lines.sort { a, b in
            let rowTolerance = min(a.boundingBox.height, b.boundingBox.height) * 0.5
            if abs(a.boundingBox.midY - b.boundingBox.midY) > rowTolerance { return a.boundingBox.midY > b.boundingBox.midY }
            return a.boundingBox.minX < b.boundingBox.minX
        }
        return OCRResult(lines: lines, imageSize: CGSize(width: image.width, height: image.height))
    }

    /// Recognises text in an image file or every page of a PDF.
    public static func recognize(url: URL) throws -> (text: String, uncertain: Int, pages: Int) {
        let format = Format.detect(url)
        if format == .pdf || format == .ai {
            let r = try PDFEngine.extractText(url, ocrIfNeeded: true)
            return (r.text, r.lowConfidenceLines, PDFEngine.pageCount(url))
        }
        let image = try ImageLoader.load(url).image
        let r = try recognize(image)
        return (r.text, r.uncertainLines.count, 1)
    }

    /// Character-level boxes for a recognised line (used by the font matcher).
    public static func characterBoxes(_ image: CGImage) throws -> [(String, CGRect)] {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = false
        let handler = VNImageRequestHandler(cgImage: image, options: [:])
        try handler.perform([request])
        var boxes: [(String, CGRect)] = []
        for obs in request.results ?? [] {
            guard let candidate = obs.topCandidates(1).first else { continue }
            let s = candidate.string
            var index = s.startIndex
            while index < s.endIndex {
                let next = s.index(after: index)
                if !s[index].isWhitespace,
                   let box = try? candidate.boundingBox(for: index..<next) {
                    boxes.append((String(s[index]), box.boundingBox))
                }
                index = next
            }
        }
        return boxes
    }
}
