import AppKit
import CoreGraphics
import CoreText
import Foundation

/// Low-level Core Text helpers.
public enum TextDrawing {
    public static func font(name: String?, size: CGFloat, bold: Bool = false) -> CTFont {
        if let name, !name.isEmpty {
            let f = CTFontCreateWithName(name as CFString, size, nil)
            if bold, let b = CTFontCreateCopyWithSymbolicTraits(f, size, nil, .traitBold, .traitBold) { return b }
            return f
        }
        let base = CTFontCreateUIFontForLanguage(bold ? .emphasizedSystem : .system, size, nil)
            ?? CTFontCreateWithName("Helvetica" as CFString, size, nil)
        return base
    }

    public static func draw(_ text: String, in ctx: CGContext, at point: CGPoint, fontSize: CGFloat,
                            colour: RGBAColour, bold: Bool, fontName: String? = nil) {
        let attrs: [NSAttributedString.Key: Any] = [
            NSAttributedString.Key(kCTFontAttributeName as String): font(name: fontName, size: fontSize, bold: bold),
            NSAttributedString.Key(kCTForegroundColorAttributeName as String): colour.cgColor,
        ]
        let line = CTLineCreateWithAttributedString(NSAttributedString(string: text, attributes: attrs))
        ctx.saveGState()
        ctx.textMatrix = .identity
        ctx.textPosition = point
        CTLineDraw(line, ctx)
        ctx.restoreGState()
    }

    static func attributed(_ text: String, font: CTFont, colour: RGBAColour, alignment: CTTextAlignment,
                           lineSpacing: CGFloat, kerning: CGFloat = 0) -> NSAttributedString {
        var align = alignment
        var multiple = lineSpacing
        let style: CTParagraphStyle = withUnsafeBytes(of: &align) { alignPtr in
            withUnsafeBytes(of: &multiple) { multPtr in
                let settings = [
                    CTParagraphStyleSetting(spec: .alignment, valueSize: MemoryLayout<CTTextAlignment>.size, value: alignPtr.baseAddress!),
                    CTParagraphStyleSetting(spec: .lineHeightMultiple, valueSize: MemoryLayout<CGFloat>.size, value: multPtr.baseAddress!),
                ]
                return CTParagraphStyleCreate(settings, settings.count)
            }
        }
        var attrs: [NSAttributedString.Key: Any] = [
            NSAttributedString.Key(kCTFontAttributeName as String): font,
            NSAttributedString.Key(kCTForegroundColorAttributeName as String): colour.cgColor,
            NSAttributedString.Key(kCTParagraphStyleAttributeName as String): style,
        ]
        if kerning != 0 { attrs[NSAttributedString.Key(kCTKernAttributeName as String)] = kerning }
        return NSAttributedString(string: text, attributes: attrs)
    }

    /// Size the text needs when wrapped to `width`.
    static func measure(_ attr: NSAttributedString, width: CGFloat) -> CGSize {
        let setter = CTFramesetterCreateWithAttributedString(attr)
        return CTFramesetterSuggestFrameSizeWithConstraints(setter, CFRange(location: 0, length: 0), nil,
                                                            CGSize(width: width, height: .greatestFiniteMagnitude), nil)
    }

    /// Draws wrapped text into a rect (CG coordinates, origin bottom-left), top-aligned.
    static func drawFrame(_ attr: NSAttributedString, in rect: CGRect, ctx: CGContext, verticallyCentred: Bool = false) {
        let setter = CTFramesetterCreateWithAttributedString(attr)
        var r = rect
        if verticallyCentred {
            let needed = measure(attr, width: rect.width).height
            if needed < rect.height { r = CGRect(x: rect.minX, y: rect.minY + (rect.height - needed) / 2, width: rect.width, height: needed + 2) }
        }
        let path = CGPath(rect: r, transform: nil)
        let frame = CTFramesetterCreateFrame(setter, CFRange(location: 0, length: 0), path, nil)
        ctx.saveGState()
        ctx.textMatrix = .identity
        CTFrameDraw(frame, ctx)
        ctx.restoreGState()
    }

    /// Largest font size (≤ max) at which the text fits the box.
    static func fittingSize(_ text: String, fontName: String?, bold: Bool, box: CGSize, maxSize: CGFloat, minSize: CGFloat = 10,
                            lineSpacing: CGFloat, alignment: CTTextAlignment) -> CGFloat {
        var lo = minSize, hi = maxSize
        for _ in 0..<14 {
            let mid = (lo + hi) / 2
            let attr = attributed(text, font: font(name: fontName, size: mid, bold: bold), colour: .black, alignment: alignment, lineSpacing: lineSpacing)
            let s = measure(attr, width: box.width)
            if s.height <= box.height && s.width <= box.width + 1 { lo = mid } else { hi = mid }
        }
        return floor(lo)
    }
}

public enum TextAlign: String, Codable, CaseIterable, Sendable {
    case left, center, right

    var ct: CTTextAlignment {
        switch self {
        case .left: return .left
        case .center: return .center
        case .right: return .right
        }
    }

    var svgAnchor: String {
        switch self {
        case .left: return "start"
        case .center: return "middle"
        case .right: return "end"
        }
    }
}

public struct TextImageOptions: Codable, Hashable, Sendable {
    public var width: Int = 1080
    /// nil = grow to fit the text.
    public var height: Int?
    public var fontName: String?
    public var fontSize: Double = 44
    public var bold: Bool = false
    public var textColour = RGBAColour(r: 0.17, g: 0.16, b: 0.16)
    /// Alpha 0 gives a transparent PNG.
    public var background = RGBAColour.white
    public var alignment: TextAlign = .left
    public var padding: Double = 72
    public var lineSpacing: Double = 1.25

    public init() {}
}

public enum GraphicPreset: String, Codable, CaseIterable, Sendable, Identifiable {
    case instagramQuote, announcement, presentationTitle, poster, webBanner

    public var id: String { rawValue }

    public var title: String {
        switch self {
        case .instagramQuote: return "Instagram Quote"
        case .announcement: return "Announcement Post"
        case .presentationTitle: return "Presentation Title"
        case .poster: return "Simple Poster"
        case .webBanner: return "Website Banner"
        }
    }

    public var size: CGSize {
        switch self {
        case .instagramQuote: return CGSize(width: 1080, height: 1350)
        case .announcement: return CGSize(width: 1080, height: 1080)
        case .presentationTitle: return CGSize(width: 1920, height: 1080)
        case .poster: return CGSize(width: 1414, height: 2000)
        case .webBanner: return CGSize(width: 1600, height: 500)
        }
    }
}

public struct GraphicStyle: Codable, Hashable, Sendable {
    public var accent = RGBAColour(r: 1.0, g: 0.42, b: 0.30)
    public var background = RGBAColour(r: 0.98, g: 0.96, b: 0.93)
    public var text = RGBAColour(r: 0.15, g: 0.14, b: 0.13)
    public var headlineFont: String?
    public var bodyFont: String?
    public var alignment: TextAlign = .left
    public var label: String = "ANNOUNCEMENT"

    public init() {}
}

/// Text → image / SVG, typographic graphics and font specimen sheets.
public enum TextGraphics {
    public static func render(_ text: String, options: TextImageOptions) -> CGImage? {
        let font = TextDrawing.font(name: options.fontName, size: CGFloat(options.fontSize), bold: options.bold)
        let attr = TextDrawing.attributed(text, font: font, colour: options.textColour, alignment: options.alignment.ct,
                                          lineSpacing: CGFloat(options.lineSpacing))
        let pad = CGFloat(options.padding)
        let innerW = CGFloat(options.width) - pad * 2
        guard innerW > 10 else { return nil }
        let needed = TextDrawing.measure(attr, width: innerW)
        let h = options.height ?? Int(ceil(needed.height + pad * 2))
        guard let ctx = ImageOps.makeContext(width: options.width, height: max(1, h), opaque: options.background.a >= 1) else { return nil }
        let full = CGRect(x: 0, y: 0, width: options.width, height: h)
        if options.background.a > 0 {
            ctx.setFillColor(options.background.cgColor)
            ctx.fill(full)
        }
        let box = full.insetBy(dx: pad, dy: pad)
        TextDrawing.drawFrame(attr, in: box, ctx: ctx, verticallyCentred: options.height != nil)
        return ctx.makeImage()
    }

    /// Real SVG text (selectable and editable), wrapped like the PNG version.
    public static func svg(_ text: String, options: TextImageOptions) -> String {
        let font = TextDrawing.font(name: options.fontName, size: CGFloat(options.fontSize), bold: options.bold)
        let attr = TextDrawing.attributed(text, font: font, colour: options.textColour, alignment: options.alignment.ct,
                                          lineSpacing: CGFloat(options.lineSpacing))
        let pad = CGFloat(options.padding)
        let innerW = CGFloat(options.width) - pad * 2
        let setter = CTFramesetterCreateWithAttributedString(attr)
        let needed = TextDrawing.measure(attr, width: innerW)
        let h = options.height ?? Int(ceil(needed.height + pad * 2))
        let path = CGPath(rect: CGRect(x: 0, y: 0, width: innerW, height: needed.height + 4), transform: nil)
        let frame = CTFramesetterCreateFrame(setter, CFRange(location: 0, length: 0), path, nil)
        let lines = (CTFrameGetLines(frame) as? [CTLine]) ?? []
        let ns = text as NSString
        let family = (CTFontCopyFamilyName(font) as String)
        let lineHeight = CGFloat(options.fontSize) * CGFloat(options.lineSpacing) * 1.2
        let x: CGFloat
        switch options.alignment {
        case .left: x = pad
        case .center: x = CGFloat(options.width) / 2
        case .right: x = CGFloat(options.width) - pad
        }
        var out = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        out += "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"\(options.width)\" height=\"\(h)\" viewBox=\"0 0 \(options.width) \(h)\">\n"
        if options.background.a > 0 {
            out += "  <rect width=\"100%\" height=\"100%\" fill=\"\(options.background.hex)\"\(options.background.a < 1 ? " fill-opacity=\"\(options.background.a)\"" : "")/>\n"
        }
        out += "  <text font-family=\"\(PaletteExporter.xmlEscape(family)), \(FontMatcher.category(of: font).cssGeneric)\" font-size=\"\(Int(options.fontSize))\" font-weight=\"\(options.bold ? 700 : FontMatcher.cssWeight(of: font))\" fill=\"\(options.textColour.hex)\" text-anchor=\"\(options.alignment.svgAnchor)\">\n"
        var y = pad + CGFloat(options.fontSize)
        for line in lines {
            let r = CTLineGetStringRange(line)
            let s = ns.substring(with: NSRange(location: r.location, length: r.length)).trimmingCharacters(in: .newlines)
            out += "    <tspan x=\"\(Int(x))\" y=\"\(Int(y))\">\(PaletteExporter.xmlEscape(s))</tspan>\n"
            y += lineHeight
        }
        out += "  </text>\n</svg>\n"
        return out
    }

    // MARK: Create Graphic from Text

    /// The first line is the headline; anything after it is supporting text.
    public static func graphic(_ preset: GraphicPreset, text: String, style: GraphicStyle = GraphicStyle()) -> CGImage? {
        let size = preset.size
        let W = size.width, H = size.height
        guard let ctx = ImageOps.makeContext(width: Int(W), height: Int(H), opaque: true) else { return nil }
        let parts = text.trimmingCharacters(in: .whitespacesAndNewlines).components(separatedBy: "\n")
        let headline = parts.first ?? ""
        let body = parts.dropFirst().joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
        let align = style.alignment.ct

        func fill(_ c: RGBAColour, _ r: CGRect) {
            ctx.setFillColor(c.cgColor)
            ctx.fill(r)
        }
        func block(_ string: String, font: String?, bold: Bool, maxSize: CGFloat, box: CGRect, colour: RGBAColour,
                   spacing: CGFloat = 1.1, alignment: CTTextAlignment? = nil, centred: Bool = false) {
            guard !string.isEmpty else { return }
            let s = TextDrawing.fittingSize(string, fontName: font, bold: bold, box: box.size, maxSize: maxSize,
                                            lineSpacing: spacing, alignment: alignment ?? align)
            let attr = TextDrawing.attributed(string, font: TextDrawing.font(name: font, size: s, bold: bold), colour: colour,
                                              alignment: alignment ?? align, lineSpacing: spacing)
            TextDrawing.drawFrame(attr, in: box, ctx: ctx, verticallyCentred: centred)
        }

        switch preset {
        case .instagramQuote:
            fill(style.background, CGRect(x: 0, y: 0, width: W, height: H))
            let serif = style.headlineFont ?? "Georgia"
            TextDrawing.draw("“", in: ctx, at: CGPoint(x: 96, y: H - 300), fontSize: 260, colour: style.accent, bold: true, fontName: serif)
            var quote = headline
            var attribution = body
            if attribution.isEmpty, let dash = quote.range(of: " — ") {
                attribution = String(quote[dash.upperBound...])
                quote = String(quote[..<dash.lowerBound])
            }
            block(quote, font: serif, bold: false, maxSize: 96, box: CGRect(x: 110, y: 330, width: W - 220, height: H - 700),
                  colour: style.text, spacing: 1.15, centred: true)
            if !attribution.isEmpty {
                block("— " + attribution, font: style.bodyFont, bold: true, maxSize: 34, box: CGRect(x: 110, y: 200, width: W - 220, height: 90), colour: style.text)
            }
            fill(style.accent, CGRect(x: 110, y: 150, width: 120, height: 10))
        case .announcement:
            fill(style.background, CGRect(x: 0, y: 0, width: W, height: H))
            fill(style.accent, CGRect(x: 0, y: H - 190, width: W, height: 190))
            block(style.label.uppercased(), font: style.bodyFont, bold: true, maxSize: 40,
                  box: CGRect(x: 90, y: H - 150, width: W - 180, height: 80), colour: .white, spacing: 1)
            block(headline, font: style.headlineFont, bold: true, maxSize: 120, box: CGRect(x: 90, y: body.isEmpty ? 160 : 420, width: W - 180, height: body.isEmpty ? H - 420 : H - 680),
                  colour: style.text, spacing: 1.05, centred: true)
            block(body, font: style.bodyFont, bold: false, maxSize: 42, box: CGRect(x: 90, y: 120, width: W - 180, height: 260), colour: style.text, spacing: 1.3)
        case .presentationTitle:
            let dark = RGBAColour(r: 0.11, g: 0.11, b: 0.12)
            fill(dark, CGRect(x: 0, y: 0, width: W, height: H))
            fill(style.accent, CGRect(x: 160, y: H / 2 - 40, width: 140, height: 10))
            block(headline, font: style.headlineFont, bold: true, maxSize: 150, box: CGRect(x: 160, y: H / 2, width: W - 320, height: H / 2 - 140),
                  colour: .white, spacing: 1.02, alignment: .left)
            block(body, font: style.bodyFont, bold: false, maxSize: 54, box: CGRect(x: 160, y: 160, width: W - 320, height: H / 2 - 260),
                  colour: RGBAColour(r: 0.8, g: 0.78, b: 0.75), spacing: 1.25, alignment: .left)
        case .poster:
            fill(style.background, CGRect(x: 0, y: 0, width: W, height: H))
            fill(style.accent, CGRect(x: 0, y: 0, width: W, height: H * 0.36))
            block(headline, font: style.headlineFont, bold: true, maxSize: 260, box: CGRect(x: 100, y: H * 0.42, width: W - 200, height: H * 0.5),
                  colour: style.text, spacing: 0.95, centred: true)
            block(body, font: style.bodyFont, bold: false, maxSize: 64, box: CGRect(x: 100, y: 120, width: W - 200, height: H * 0.36 - 220),
                  colour: .white, spacing: 1.25)
        case .webBanner:
            fill(style.background, CGRect(x: 0, y: 0, width: W, height: H))
            ctx.setFillColor(style.accent.cgColor)
            ctx.fillEllipse(in: CGRect(x: W - 420, y: -160, width: 640, height: 640))
            block(headline, font: style.headlineFont, bold: true, maxSize: 96, box: CGRect(x: 90, y: body.isEmpty ? 90 : 190, width: W - 620, height: body.isEmpty ? H - 180 : H - 260),
                  colour: style.text, spacing: 1.05, alignment: .left, centred: true)
            block(body, font: style.bodyFont, bold: false, maxSize: 36, box: CGRect(x: 90, y: 80, width: W - 620, height: 100), colour: style.text, spacing: 1.2, alignment: .left)
        }
        return ctx.makeImage()
    }

    // MARK: Typography reference card

    public static func specimen(family: String, sample: String = "Sphinx of black quartz, judge my vow") -> CGImage? {
        let W: CGFloat = 1600
        let members = (NSFontManager.shared.availableMembers(ofFontFamily: family) ?? []).compactMap { m -> (String, String)? in
            guard m.count > 1, let ps = m[0] as? String else { return nil }
            return (ps, m[1] as? String ?? "")
        }
        let first = members.first?.0 ?? family
        let styleRows = min(members.count, 12)
        let H: CGFloat = 1120 + CGFloat(styleRows) * 70
        guard let ctx = ImageOps.makeContext(width: Int(W), height: Int(H), opaque: true) else { return nil }
        ctx.setFillColor(RGBAColour(r: 0.98, g: 0.97, b: 0.95).cgColor)
        ctx.fill(CGRect(x: 0, y: 0, width: W, height: H))
        let ink = RGBAColour(r: 0.15, g: 0.14, b: 0.13)
        let grey = RGBAColour(r: 0.45, g: 0.43, b: 0.40)
        let accent = RGBAColour(r: 1.0, g: 0.42, b: 0.30)
        var y = H - 150
        TextDrawing.draw(family, in: ctx, at: CGPoint(x: 90, y: y), fontSize: 92, colour: ink, bold: false, fontName: first)
        y -= 70
        let details = FontMatcher.details(forPostScriptName: first)
        let meta = [details?.category.title, details.map { _ in "\(members.count) styles" }, details?.designer, details?.manufacturer]
            .compactMap { $0 }.joined(separator: "  ·  ")
        TextDrawing.draw(meta, in: ctx, at: CGPoint(x: 92, y: y), fontSize: 26, colour: grey, bold: false)
        ctx.setFillColor(accent.cgColor)
        ctx.fill(CGRect(x: 92, y: y - 40, width: 120, height: 6))
        y -= 140
        for size: CGFloat in [72, 48, 32, 20] {
            TextDrawing.draw(sample, in: ctx, at: CGPoint(x: 90, y: y), fontSize: size, colour: ink, bold: false, fontName: first)
            TextDrawing.draw("\(Int(size)) pt", in: ctx, at: CGPoint(x: 92, y: y - 30), fontSize: 18, colour: grey, bold: false)
            y -= size + 80
        }
        for line in ["ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz", "0123456789 !?&@#%*()[]{}“”"] {
            TextDrawing.draw(line, in: ctx, at: CGPoint(x: 90, y: y), fontSize: 40, colour: ink, bold: false, fontName: first)
            y -= 64
        }
        y -= 20
        for (ps, style) in members.prefix(styleRows) {
            TextDrawing.draw(style.isEmpty ? ps : style, in: ctx, at: CGPoint(x: 90, y: y), fontSize: 36, colour: ink, bold: false, fontName: ps)
            TextDrawing.draw(ps, in: ctx, at: CGPoint(x: 900, y: y + 6), fontSize: 20, colour: grey, bold: false)
            y -= 70
        }
        return ctx.makeImage()
    }
}
