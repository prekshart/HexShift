import Foundation

/// Small calculators used by the Designer Tools and the inspector.
public enum AspectRatio {
    public static func gcd(_ a: Int, _ b: Int) -> Int {
        var x = abs(a), y = abs(b)
        while y != 0 { (x, y) = (y, x % y) }
        return max(1, x)
    }

    /// "16:9", or "≈ 16:9 (1.78)" when the exact ratio is unwieldy.
    public static func describe(width: Int, height: Int) -> String {
        guard width > 0, height > 0 else { return "—" }
        let g = gcd(width, height)
        let w = width / g, h = height / g
        let decimal = String(format: "%.2f", Double(width) / Double(height))
        if w <= 32 && h <= 32 { return "\(w):\(h) (\(decimal))" }
        // Snap to a familiar ratio when close.
        let common: [(Int, Int)] = [(1, 1), (4, 5), (5, 4), (3, 2), (2, 3), (4, 3), (3, 4), (16, 9), (9, 16), (16, 10), (10, 16), (21, 9), (1, 2), (2, 1)]
        let r = Double(width) / Double(height)
        if let best = common.min(by: { abs(Double($0.0) / Double($0.1) - r) < abs(Double($1.0) / Double($1.1) - r) }),
           abs(Double(best.0) / Double(best.1) - r) < 0.02 {
            return "≈ \(best.0):\(best.1) (\(decimal))"
        }
        return "\(decimal):1"
    }
}

public enum PrintMath {
    public static func mm(fromPoints pt: Double) -> String { String(format: "%.0f", pt / 72 * 25.4) }
    public static func inches(pixels: Int, dpi: Double) -> Double { Double(pixels) / max(1, dpi) }
    public static func pixels(inches: Double, dpi: Double) -> Int { Int((inches * dpi).rounded()) }
}
