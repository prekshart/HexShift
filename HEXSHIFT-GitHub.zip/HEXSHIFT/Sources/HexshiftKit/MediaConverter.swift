import AVFoundation
import CoreGraphics
import CoreMedia
import CoreVideo
import Foundation

public enum VideoQuality: String, Codable, CaseIterable, Sendable {
    case high, hevc, p1080, p720, p540, passthrough

    public var title: String {
        switch self {
        case .high: return "High quality (H.264)"
        case .hevc: return "Smaller file (HEVC)"
        case .p1080: return "1080p"
        case .p720: return "720p (smaller)"
        case .p540: return "540p (smallest)"
        case .passthrough: return "Same quality (re-wrap, fastest)"
        }
    }

    var preset: String {
        switch self {
        case .high: return AVAssetExportPresetHighestQuality
        case .hevc: return AVAssetExportPresetHEVCHighestQuality
        case .p1080: return AVAssetExportPreset1920x1080
        case .p720: return AVAssetExportPreset1280x720
        case .p540: return AVAssetExportPreset960x540
        case .passthrough: return AVAssetExportPresetPassthrough
        }
    }
}

public struct VideoOptions: Codable, Hashable, Sendable {
    public var quality: VideoQuality = .high
    public var gifFPS: Double = 12
    public var gifMaxWidth: Int = 640
    /// Seconds. nil = from the beginning.
    public var start: Double?
    /// Seconds. nil = to the end (GIF/WebP default to the first 10 s).
    public var end: Double?
    /// Seconds for single-frame extraction. nil = 1 s in (or the middle of short clips).
    public var frameTime: Double?

    public init() {}
}

/// Video and audio conversion with AVFoundation; FFmpeg is used only for
/// formats macOS can't handle natively (WebM, MKV, AVI, MP3 encoding, FLAC).
public enum MediaConverter {
    static let nativeVideo: Set<Format> = [.mp4, .mov, .m4v]
    static let nativeAudio: Set<Format> = [.m4a, .wav, .aiff, .mp3, .aac]

    public static func targets(for source: Format) -> [(Format, String?)] {
        let hasFFmpeg = ExternalTools.path(.ffmpeg) != nil
        var out: [(Format, String?)] = []
        switch source.category {
        case .video:
            if nativeVideo.contains(source) {
                for f in [Format.mp4, .mov, .m4v] where f != source { out.append((f, nil)) }
                out.append((.gif, "Animated GIF (first 10 s unless trimmed)"))
                out.append((.webp, "Animated WebP (first 10 s unless trimmed)"))
                out.append((.png, "Single frame"))
                out.append((.jpeg, "Single frame"))
                out.append((.m4a, "Audio only"))
                out.append((.wav, "Audio only"))
                out.append((.aiff, "Audio only"))
                out.append((.webm, hasFFmpeg ? nil : "Needs FFmpeg"))
                out.append((.mp3, hasFFmpeg ? "Audio only" : "Needs FFmpeg"))
            } else {
                for f in [Format.mp4, .mov, .webm, .mp3, .m4a, .wav] where f != source {
                    out.append((f, hasFFmpeg ? nil : "Needs FFmpeg"))
                }
            }
        case .audio:
            if nativeAudio.contains(source) {
                for f in [Format.m4a, .wav, .aiff] where f != source { out.append((f, nil)) }
            }
            for f in [Format.mp3, .flac] where f != source { out.append((f, hasFFmpeg ? nil : "Needs FFmpeg")) }
            if !nativeAudio.contains(source) {
                for f in [Format.m4a, .wav] where f != source { out.append((f, hasFFmpeg ? nil : "Needs FFmpeg")) }
            }
        default:
            break
        }
        return out
    }

    public static func needsFFmpeg(source: Format, target: Format) -> Bool {
        if source.category == .video && !nativeVideo.contains(source) { return true }
        if source.category == .audio && !nativeAudio.contains(source) { return true }
        return [.webm, .mkv, .avi, .mp3, .flac].contains(target)
    }

    public static func duration(_ url: URL) async -> Double? {
        let asset = AVURLAsset(url: url)
        guard let d = try? await asset.load(.duration) else { return nil }
        return d.seconds.isFinite ? d.seconds : nil
    }

    /// Main entry point.
    public static func convert(_ url: URL, from source: Format, to target: Format, output: URL, options: VideoOptions) async throws {
        if needsFFmpeg(source: source, target: target) {
            try ffmpegConvert(url, to: target, output: output, options: options)
            return
        }
        switch target {
        case .mp4, .mov, .m4v:
            if source.category == .raster {
                try await animatedImageToVideo(url, output: output, fileType: fileType(for: target))
            } else {
                try await exportVideo(url, to: target, output: output, options: options)
            }
        case .m4a, .wav, .aiff:
            try await extractAudio(url, to: target, output: output, options: options)
        case .gif, .webp:
            let frames = try await videoFrames(url, options: options)
            try ImageEncoder.writeAnimation(frames, loopCount: 0, format: target, to: output)
        case .png, .jpeg, .heic, .tiff:
            let d = await duration(url) ?? 0
            let t = options.frameTime ?? (d > 2 ? 1 : d / 2)
            try await extractFrame(url, at: t, format: target, output: output)
        default:
            throw HexError.unsupportedConversion(from: source.displayName, to: target.displayName)
        }
    }

    static func fileType(for format: Format) -> AVFileType {
        switch format {
        case .mov: return .mov
        case .m4v: return .m4v
        case .m4a: return .m4a
        case .wav: return .wav
        case .aiff: return .aiff
        default: return .mp4
        }
    }

    static func timeRange(_ options: VideoOptions, duration: Double?) -> CMTimeRange? {
        guard options.start != nil || options.end != nil else { return nil }
        let s = max(0, options.start ?? 0)
        let e = options.end ?? duration ?? s
        guard e > s else { return nil }
        return CMTimeRange(start: CMTime(seconds: s, preferredTimescale: 600), end: CMTime(seconds: e, preferredTimescale: 600))
    }

    // MARK: AVAssetExportSession

    static func runExport(asset: AVAsset, preset: String, fileType: AVFileType, to url: URL, timeRange: CMTimeRange?) async throws {
        guard let session = AVAssetExportSession(asset: asset, presetName: preset) else {
            throw HexError.message("This media can't be exported with the chosen quality setting.")
        }
        guard session.supportedFileTypes.contains(fileType) else {
            throw HexError.message("This media can't be written as .\(fileType.rawValue.components(separatedBy: ".").last ?? "file") with the chosen setting.")
        }
        session.outputURL = url
        session.outputFileType = fileType
        session.shouldOptimizeForNetworkUse = true
        if let timeRange { session.timeRange = timeRange }
        let box = ExportSessionBox(session)
        await withTaskCancellationHandler {
            await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
                box.session.exportAsynchronously { cont.resume() }
            }
        } onCancel: {
            box.session.cancelExport()
        }
        if Task.isCancelled { throw HexError.cancelled }
        guard session.status == .completed else {
            throw HexError.writeFailed(session.error?.localizedDescription ?? "The export did not complete.")
        }
    }

    public static func exportVideo(_ url: URL, to target: Format, output: URL, options: VideoOptions) async throws {
        let asset = AVURLAsset(url: url)
        let d = await duration(url)
        try await FileWriter.writeAtomicallyAsync(to: output) { tmp in
            var preset = options.quality.preset
            // HEVC presets only write to MOV/MP4/M4V on supported hardware; fall back if needed.
            if options.quality == .hevc {
                let ok = await AVAssetExportSession.compatibility(ofExportPreset: preset, with: asset, outputFileType: fileType(for: target))
                if !ok { preset = AVAssetExportPresetHighestQuality }
            }
            try await runExport(asset: asset, preset: preset, fileType: fileType(for: target), to: tmp, timeRange: timeRange(options, duration: d))
            try await validateMedia(tmp, expectVideo: true)
        }
    }

    public static func extractAudio(_ url: URL, to target: Format, output: URL, options: VideoOptions) async throws {
        let asset = AVURLAsset(url: url)
        let audioTracks = (try? await asset.loadTracks(withMediaType: .audio)) ?? []
        guard !audioTracks.isEmpty else { throw HexError.message("This file has no audio track.") }
        let d = await duration(url)
        try await FileWriter.writeAtomicallyAsync(to: output) { tmp in
            if target == .m4a {
                try await runExport(asset: asset, preset: AVAssetExportPresetAppleM4A, fileType: .m4a, to: tmp, timeRange: timeRange(options, duration: d))
            } else {
                // Decode to PCM. Video containers are first reduced to an M4A.
                let source = Format.detect(url)
                var decodeURL = url
                var tmpDir: URL?
                if source?.category == .video || options.start != nil || options.end != nil {
                    let dir = try FileWriter.makeTemporaryDirectory()
                    tmpDir = dir
                    let m4a = dir.appendingPathComponent("audio.m4a")
                    try await runExport(asset: asset, preset: AVAssetExportPresetAppleM4A, fileType: .m4a, to: m4a, timeRange: timeRange(options, duration: d))
                    decodeURL = m4a
                }
                defer { if let tmpDir { try? FileManager.default.removeItem(at: tmpDir) } }
                try transcodePCM(decodeURL, to: tmp, bigEndian: target == .aiff)
            }
            try await validateMedia(tmp, expectVideo: false)
        }
    }

    static func transcodePCM(_ input: URL, to output: URL, bigEndian: Bool) throws {
        let file = try AVAudioFile(forReading: input)
        let format = file.processingFormat
        let settings: [String: Any] = [
            AVFormatIDKey: kAudioFormatLinearPCM,
            AVSampleRateKey: format.sampleRate,
            AVNumberOfChannelsKey: format.channelCount,
            AVLinearPCMBitDepthKey: 16,
            AVLinearPCMIsFloatKey: false,
            AVLinearPCMIsBigEndianKey: bigEndian,
            AVLinearPCMIsNonInterleaved: false,
        ]
        let out = try AVAudioFile(forWriting: output, settings: settings, commonFormat: format.commonFormat, interleaved: format.isInterleaved)
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: 65536) else {
            throw HexError.writeFailed("Could not allocate an audio buffer.")
        }
        while file.framePosition < file.length {
            try Task.checkCancellation()
            try file.read(into: buffer)
            if buffer.frameLength == 0 { break }
            try out.write(from: buffer)
        }
    }

    // MARK: Frames

    public static func videoFrames(_ url: URL, options: VideoOptions, maxFrames: Int = 400) async throws -> [AnimationFrame] {
        let asset = AVURLAsset(url: url)
        let d = await duration(url) ?? 0
        let fps = max(1, min(30, options.gifFPS))
        let start = max(0, options.start ?? 0)
        let end = min(d, options.end ?? min(d, start + 10))
        guard end > start else { throw HexError.message("The selected time range is empty.") }
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: options.gifMaxWidth, height: options.gifMaxWidth * 4)
        let tolerance = CMTime(seconds: 0.5 / fps, preferredTimescale: 600)
        generator.requestedTimeToleranceBefore = tolerance
        generator.requestedTimeToleranceAfter = tolerance
        var frames: [AnimationFrame] = []
        var t = start
        while t < end && frames.count < maxFrames {
            try Task.checkCancellation()
            let result = try await generator.image(at: CMTime(seconds: t, preferredTimescale: 600))
            frames.append(AnimationFrame(image: result.image, delay: 1 / fps))
            t += 1 / fps
        }
        guard !frames.isEmpty else { throw HexError.message("No frames could be read from this video.") }
        return frames
    }

    public static func extractFrame(_ url: URL, at seconds: Double, format: Format, output: URL) async throws {
        let image = try await frameImage(url, at: seconds)
        try ImageEncoder.write(image, format: format, to: output)
    }

    public static func frameImage(_ url: URL, at seconds: Double, maxSize: CGSize? = nil) async throws -> CGImage {
        let asset = AVURLAsset(url: url)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.requestedTimeToleranceBefore = .zero
        generator.requestedTimeToleranceAfter = .zero
        if let maxSize { generator.maximumSize = maxSize }
        let result = try await generator.image(at: CMTime(seconds: max(0, seconds), preferredTimescale: 600))
        return result.image
    }

    // MARK: Animated image → video

    public static func animatedImageToVideo(_ url: URL, output: URL, fileType: AVFileType) async throws {
        let (frames, _) = try ImageLoader.loadAnimation(url)
        try await writeVideo(frames, to: output, fileType: fileType)
    }

    public static func writeVideo(_ frames: [AnimationFrame], to output: URL, fileType: AVFileType) async throws {
        guard let first = frames.first?.image else { throw HexError.message("No frames to write.") }
        let w = max(2, (first.width / 2) * 2)
        let h = max(2, (first.height / 2) * 2)
        try await FileWriter.writeAtomicallyAsync(to: output) { tmp in
            let writer = try AVAssetWriter(outputURL: tmp, fileType: fileType)
            let settings: [String: Any] = [AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: w, AVVideoHeightKey: h]
            let input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
            input.expectsMediaDataInRealTime = false
            let attrs: [String: Any] = [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32ARGB,
                kCVPixelBufferWidthKey as String: w,
                kCVPixelBufferHeightKey as String: h,
            ]
            let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: attrs)
            guard writer.canAdd(input) else { throw HexError.writeFailed("The video writer rejected the settings.") }
            writer.add(input)
            guard writer.startWriting() else { throw HexError.writeFailed(writer.error?.localizedDescription ?? "Could not start writing.") }
            writer.startSession(atSourceTime: .zero)
            var time = CMTime.zero
            for frame in frames {
                try Task.checkCancellation()
                while !input.isReadyForMoreMediaData { try await Task.sleep(nanoseconds: 5_000_000) }
                guard let buffer = pixelBuffer(from: frame.image, width: w, height: h) else { continue }
                if !adaptor.append(buffer, withPresentationTime: time) {
                    throw HexError.writeFailed(writer.error?.localizedDescription ?? "A frame could not be written.")
                }
                time = CMTimeAdd(time, CMTime(seconds: max(0.02, frame.delay), preferredTimescale: 600))
            }
            input.markAsFinished()
            writer.endSession(atSourceTime: time)
            let box = AssetWriterBox(writer)
            await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
                box.writer.finishWriting { cont.resume() }
            }
            guard writer.status == .completed else { throw HexError.writeFailed(writer.error?.localizedDescription ?? "Writing failed.") }
            try await validateMedia(tmp, expectVideo: true)
        }
    }

    static func pixelBuffer(from image: CGImage, width: Int, height: Int) -> CVPixelBuffer? {
        var pb: CVPixelBuffer?
        let attrs: [String: Any] = [kCVPixelBufferCGImageCompatibilityKey as String: true, kCVPixelBufferCGBitmapContextCompatibilityKey as String: true]
        guard CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32ARGB, attrs as CFDictionary, &pb) == kCVReturnSuccess,
              let buffer = pb else { return nil }
        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        guard let ctx = CGContext(data: CVPixelBufferGetBaseAddress(buffer), width: width, height: height, bitsPerComponent: 8,
                                  bytesPerRow: CVPixelBufferGetBytesPerRow(buffer), space: ImageOps.sRGB,
                                  bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue) else { return nil }
        ctx.setFillColor(RGBAColour.white.cgColor)
        ctx.fill(CGRect(x: 0, y: 0, width: width, height: height))
        ctx.interpolationQuality = .high
        ctx.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
        return buffer
    }

    static func validateMedia(_ url: URL, expectVideo: Bool) async throws {
        let asset = AVURLAsset(url: url)
        let tracks = (try? await asset.loadTracks(withMediaType: expectVideo ? .video : .audio)) ?? []
        let d = (try? await asset.load(.duration))?.seconds ?? 0
        guard !tracks.isEmpty, d > 0 else { throw HexError.invalidOutput("The written media file has no playable \(expectVideo ? "video" : "audio").") }
    }

    // MARK: FFmpeg adapter

    public static func ffmpegConvert(_ url: URL, to target: Format, output: URL, options: VideoOptions) throws {
        guard let ffmpeg = ExternalTools.path(.ffmpeg) else {
            throw HexError.missingTool(name: "FFmpeg", hint: ExternalTool.ffmpeg.installHint)
        }
        var args = ["-hide_banner", "-loglevel", "error", "-y"]
        if let s = options.start { args += ["-ss", String(format: "%.3f", s)] }
        args += ["-i", url.path]
        if let e = options.end { args += ["-t", String(format: "%.3f", e - (options.start ?? 0))] }
        switch target {
        case .webm: args += ["-c:v", "libvpx-vp9", "-crf", "32", "-b:v", "0", "-c:a", "libopus"]
        case .mp4, .m4v: args += ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "21", "-c:a", "aac", "-movflags", "+faststart"]
        case .mov: args += ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", "-c:a", "aac"]
        case .mkv: args += ["-c", "copy"]
        case .mp3: args += ["-vn", "-c:a", "libmp3lame", "-q:a", "2"]
        case .m4a, .aac: args += ["-vn", "-c:a", "aac", "-b:a", "192k"]
        case .wav: args += ["-vn", "-c:a", "pcm_s16le"]
        case .aiff: args += ["-vn", "-c:a", "pcm_s16be"]
        case .flac: args += ["-vn", "-c:a", "flac"]
        case .gif: args += ["-vf", "fps=\(Int(options.gifFPS)),scale=\(options.gifMaxWidth):-1:flags=lanczos"]
        default: throw HexError.unsupportedConversion(from: "This media", to: target.displayName)
        }
        try FileWriter.writeAtomically(to: output) { tmp in
            let r = try ExternalTools.run(ffmpeg, args + [tmp.path], timeout: 3600)
            guard r.status == 0 else { throw HexError.writeFailed("FFmpeg: \(r.stderr.prefix(300))") }
        }
    }
}

/// Reference wrappers so non-Sendable AVFoundation objects can cross into completion handlers.
final class ExportSessionBox: @unchecked Sendable {
    let session: AVAssetExportSession
    init(_ s: AVAssetExportSession) { session = s }
}

final class AssetWriterBox: @unchecked Sendable {
    let writer: AVAssetWriter
    init(_ w: AVAssetWriter) { writer = w }
}
