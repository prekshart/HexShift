import AppKit
import Foundation

/// CSV ⇄ XLSX ⇄ JSON / HTML / Markdown / PDF.
/// XLSX is written as a minimal, standards-compliant SpreadsheetML package.
public enum TableConverter {
    public static let targets: [Format] = [.xlsx, .csv, .json, .html, .md, .pdf]

    public static func read(_ url: URL, format: Format) throws -> [[String]] {
        switch format {
        case .csv:
            let text = try DocumentConverter.readPlainText(url)
            let delimiter: Character? = url.pathExtension.lowercased() == "tsv" ? "\t" : nil
            return parseCSV(text, delimiter: delimiter)
        case .xlsx:
            return try readXLSX(url)
        default:
            throw HexError.unsupportedConversion(from: format.displayName, to: "a table")
        }
    }

    // MARK: CSV

    public static func detectDelimiter(_ text: String) -> Character {
        let sample = text.prefix(4000)
        let candidates: [Character] = [",", ";", "\t", "|"]
        var best: Character = ","
        var bestCount = 0
        for c in candidates {
            let n = sample.filter { $0 == c }.count
            if n > bestCount { bestCount = n; best = c }
        }
        return best
    }

    public static func parseCSV(_ text: String, delimiter: Character? = nil) -> [[String]] {
        let d = delimiter ?? detectDelimiter(text)
        var rows: [[String]] = []
        var row: [String] = []
        var field = ""
        var inQuotes = false
        var iterator = Array(text.replacingOccurrences(of: "\r\n", with: "\n")).makeIterator()
        var pending: Character? = nil
        func next() -> Character? {
            if let p = pending { pending = nil; return p }
            return iterator.next()
        }
        while let c = next() {
            if inQuotes {
                if c == "\"" {
                    if let n = next() {
                        if n == "\"" { field.append("\"") } else { inQuotes = false; pending = n }
                    } else {
                        inQuotes = false
                    }
                } else {
                    field.append(c)
                }
            } else if c == "\"" && field.isEmpty {
                inQuotes = true
            } else if c == d {
                row.append(field)
                field = ""
            } else if c == "\n" || c == "\r" {
                row.append(field)
                rows.append(row)
                row = []
                field = ""
            } else {
                field.append(c)
            }
        }
        if !field.isEmpty || !row.isEmpty {
            row.append(field)
            rows.append(row)
        }
        // Drop trailing empty rows
        while let last = rows.last, last.allSatisfy({ $0.isEmpty }) { rows.removeLast() }
        return rows
    }

    public static func csvString(_ rows: [[String]], delimiter: Character = ",") -> String {
        rows.map { row in
            row.map { field in
                if field.contains(delimiter) || field.contains("\"") || field.contains("\n") || field.contains("\r") {
                    return "\"" + field.replacingOccurrences(of: "\"", with: "\"\"") + "\""
                }
                return field
            }.joined(separator: String(delimiter))
        }.joined(separator: "\n") + "\n"
    }

    // MARK: Other text outputs

    public static func json(_ rows: [[String]]) -> String {
        guard let header = rows.first else { return "[]\n" }
        let keys = header.enumerated().map { $0.element.isEmpty ? "column\($0.offset + 1)" : $0.element }
        var objects: [[String: Any]] = []
        for row in rows.dropFirst() {
            var obj: [String: Any] = [:]
            for (i, key) in keys.enumerated() {
                let v = i < row.count ? row[i] : ""
                if let n = Double(v), !v.isEmpty, v.range(of: "^-?(0|[1-9]\\d*)(\\.\\d+)?$", options: .regularExpression) != nil {
                    obj[key] = n.truncatingRemainder(dividingBy: 1) == 0 && abs(n) < 1e15 ? Int(n) as Any : n as Any
                } else {
                    obj[key] = v
                }
            }
            objects.append(obj)
        }
        guard let data = try? JSONSerialization.data(withJSONObject: objects, options: [.prettyPrinted, .sortedKeys]) else { return "[]\n" }
        return String(decoding: data, as: UTF8.self) + "\n"
    }

    public static func html(_ rows: [[String]], title: String = "Table") -> String {
        var s = "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>\(MarkdownRenderer.escape(title))</title>"
        s += "<style>body{font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:10pt;color:#222}"
        s += "table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:4px 8px;text-align:left}th{background:#f2f0ec}</style></head><body><table>"
        for (i, row) in rows.enumerated() {
            let tag = i == 0 ? "th" : "td"
            s += "<tr>" + row.map { "<\(tag)>" + MarkdownRenderer.escape($0) + "</\(tag)>" }.joined() + "</tr>"
        }
        return s + "</table></body></html>\n"
    }

    public static func markdown(_ rows: [[String]]) -> String {
        guard let header = rows.first else { return "" }
        let width = rows.map(\.count).max() ?? header.count
        func line(_ r: [String]) -> String {
            let cells = (0..<width).map { i in i < r.count ? r[i].replacingOccurrences(of: "|", with: "\\|") : "" }
            return "| " + cells.joined(separator: " | ") + " |"
        }
        var out = [line(header), "|" + String(repeating: " --- |", count: width)]
        out += rows.dropFirst().map(line)
        return out.joined(separator: "\n") + "\n"
    }

    @MainActor
    public static func writePDF(_ rows: [[String]], to url: URL, title: String) throws {
        var options = DocumentOptions()
        options.landscape = (rows.map(\.count).max() ?? 0) > 6
        options.margin = 36
        let attr = try DocumentConverter.attributedString(fromHTML: html(rows, title: title))
        try DocumentConverter.write(attr, as: .pdf, to: url, options: options)
    }

    public static func write(_ rows: [[String]], as format: Format, to url: URL, title: String) throws {
        switch format {
        case .csv:
            try FileWriter.writeAtomically(to: url) { try Data(csvString(rows).utf8).write(to: $0) }
        case .json:
            try FileWriter.writeAtomically(to: url) { try Data(json(rows).utf8).write(to: $0) }
        case .html:
            try FileWriter.writeAtomically(to: url) { try Data(html(rows, title: title).utf8).write(to: $0) }
        case .md:
            try FileWriter.writeAtomically(to: url) { try Data(markdown(rows).utf8).write(to: $0) }
        case .xlsx:
            try writeXLSX(rows, to: url)
        default:
            throw HexError.unsupportedConversion(from: "A table", to: format.displayName)
        }
    }

    // MARK: XLSX writer

    public static func columnName(_ index: Int) -> String {
        var n = index + 1
        var s = ""
        while n > 0 {
            let r = (n - 1) % 26
            s = String(UnicodeScalar(65 + r)!) + s
            n = (n - 1) / 26
        }
        return s
    }

    static func xml(_ s: String) -> String {
        var out = ""
        for scalar in s.unicodeScalars {
            switch scalar {
            case "&": out += "&amp;"
            case "<": out += "&lt;"
            case ">": out += "&gt;"
            case "\"": out += "&quot;"
            default:
                // Strip control characters that XML 1.0 forbids.
                if scalar.value < 0x20 && scalar != "\t" && scalar != "\n" && scalar != "\r" { continue }
                out.unicodeScalars.append(scalar)
            }
        }
        return out
    }

    public static func writeXLSX(_ rows: [[String]], to url: URL, sheetName: String = "Sheet1") throws {
        let tmp = try FileWriter.makeTemporaryDirectory()
        defer { try? FileManager.default.removeItem(at: tmp) }
        let fm = FileManager.default
        for dir in ["_rels", "docProps", "xl/_rels", "xl/worksheets"] {
            try fm.createDirectory(at: tmp.appendingPathComponent(dir), withIntermediateDirectories: true)
        }
        let files: [(String, String)] = [
            ("[Content_Types].xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>
            """),
            ("_rels/.rels", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>
            """),
            ("docProps/app.xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>HEXSHIFT</Application></Properties>
            """),
            ("xl/workbook.xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="\(xml(String(sheetName.prefix(31))))" sheetId="1" r:id="rId1"/></sheets></workbook>
            """),
            ("xl/_rels/workbook.xml.rels", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>
            """),
            ("xl/styles.xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs></styleSheet>
            """),
            ("xl/worksheets/sheet1.xml", sheetXML(rows)),
        ]
        for (path, content) in files {
            try Data(content.utf8).write(to: tmp.appendingPathComponent(path))
        }
        try FileWriter.writeAtomically(to: url) { out in
            // -X: no extra attributes, -nw: no wildcard expansion (the [Content_Types] name), -q quiet
            let result = try ExternalTools.run("/usr/bin/zip", ["-X", "-nw", "-q", out.path] + files.map { $0.0 },
                                               timeout: 120, environment: nil, workingDirectory: tmp)
            guard result.status == 0 else { throw HexError.writeFailed("zip failed: \(result.stderr.prefix(200))") }
            let check = try readXLSX(out)
            guard check.count == rows.filter({ !$0.allSatisfy { $0.isEmpty } }).count || check.count == rows.count else {
                throw HexError.invalidOutput("The spreadsheet did not read back correctly.")
            }
        }
    }

    static func sheetXML(_ rows: [[String]]) -> String {
        var s = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
        s += "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>"
        let numberPattern = try? NSRegularExpression(pattern: "^-?(\\d+\\.?\\d*|\\.\\d+)([eE][-+]?\\d+)?$")
        for (r, row) in rows.enumerated() {
            s += "<row r=\"\(r + 1)\">"
            for (c, value) in row.enumerated() where !value.isEmpty {
                let ref = columnName(c) + "\(r + 1)"
                let style = r == 0 ? " s=\"1\"" : ""
                let isNumber = r > 0 && numberPattern?.firstMatch(in: value, range: NSRange(value.startIndex..., in: value)) != nil
                    && !(value.hasPrefix("0") && value.count > 1 && !value.hasPrefix("0."))
                if isNumber {
                    s += "<c r=\"\(ref)\"\(style)><v>\(value)</v></c>"
                } else {
                    s += "<c r=\"\(ref)\" t=\"inlineStr\"\(style)><is><t xml:space=\"preserve\">\(xml(value))</t></is></c>"
                }
            }
            s += "</row>"
        }
        return s + "</sheetData></worksheet>"
    }

    // MARK: XLSX reader (first worksheet)

    public static func readXLSX(_ url: URL) throws -> [[String]] {
        func entry(_ name: String) -> Data? {
            guard let r = try? ExternalTools.runData("/usr/bin/unzip", ["-p", url.path, name]), r.status == 0, !r.data.isEmpty else { return nil }
            return r.data
        }
        var sheetPath = "xl/worksheets/sheet1.xml"
        if entry(sheetPath) == nil, let list = try? ExternalTools.run("/usr/bin/unzip", ["-Z1", url.path]) {
            if let first = list.stdout.split(separator: "\n").map(String.init).filter({ $0.hasPrefix("xl/worksheets/sheet") && $0.hasSuffix(".xml") }).sorted().first {
                sheetPath = first
            }
        }
        guard let sheet = entry(sheetPath) else { throw HexError.unreadable(url.lastPathComponent) }
        var shared: [String] = []
        if let ss = entry("xl/sharedStrings.xml") {
            let p = SharedStringsParser()
            let parser = XMLParser(data: ss)
            parser.delegate = p
            parser.parse()
            shared = p.strings
        }
        let p = SheetParser(shared: shared)
        let parser = XMLParser(data: sheet)
        parser.delegate = p
        guard parser.parse() else { throw HexError.unreadable(url.lastPathComponent) }
        return p.rows
    }

    static func columnIndex(_ ref: String) -> Int {
        var n = 0
        for ch in ref.uppercased() {
            guard let a = ch.asciiValue, a >= 65, a <= 90 else { break }
            n = n * 26 + Int(a - 64)
        }
        return max(0, n - 1)
    }

    final class SharedStringsParser: NSObject, XMLParserDelegate {
        var strings: [String] = []
        private var current = ""
        private var inT = false
        private var inSI = false
        private var inRPh = false

        func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?, qualifiedName: String?, attributes: [String: String] = [:]) {
            switch name {
            case "si": inSI = true; current = ""
            case "t": inT = true
            case "rPh": inRPh = true
            default: break
            }
        }

        func parser(_ parser: XMLParser, foundCharacters string: String) {
            if inSI && inT && !inRPh { current += string }
        }

        func parser(_ parser: XMLParser, didEndElement name: String, namespaceURI: String?, qualifiedName: String?) {
            switch name {
            case "si": strings.append(current); inSI = false
            case "t": inT = false
            case "rPh": inRPh = false
            default: break
            }
        }
    }

    final class SheetParser: NSObject, XMLParserDelegate {
        let shared: [String]
        var rows: [[String]] = []
        private var row: [String] = []
        private var rowIndex = 0
        private var cellRef = ""
        private var cellType = ""
        private var value = ""
        private var capturing = false
        private var inInline = false

        init(shared: [String]) { self.shared = shared }

        func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?, qualifiedName: String?, attributes: [String: String] = [:]) {
            switch name {
            case "row":
                row = []
                if let r = attributes["r"], let n = Int(r) {
                    while rowIndex < n - 1 { rows.append([]); rowIndex += 1 }
                }
            case "c":
                cellRef = attributes["r"] ?? ""
                cellType = attributes["t"] ?? ""
                value = ""
            case "v": capturing = true
            case "is": inInline = true
            case "t": if inInline { capturing = true }
            default: break
            }
        }

        func parser(_ parser: XMLParser, foundCharacters string: String) {
            if capturing { value += string }
        }

        func parser(_ parser: XMLParser, didEndElement name: String, namespaceURI: String?, qualifiedName: String?) {
            switch name {
            case "v", "t": capturing = false
            case "is": inInline = false
            case "c":
                var text = value
                if cellType == "s", let i = Int(value), i >= 0, i < shared.count { text = shared[i] }
                if cellType == "b" { text = value == "1" ? "TRUE" : "FALSE" }
                let col = cellRef.isEmpty ? row.count : TableConverter.columnIndex(cellRef)
                while row.count < col { row.append("") }
                if row.count == col { row.append(text) } else if col < row.count { row[col] = text }
            case "row":
                rows.append(row)
                rowIndex += 1
            default: break
            }
        }
    }
}

extension ExternalTools {
    /// Variant of `run` that keeps stdout as raw bytes and supports a working directory.
    public static func runData(_ executable: String, _ arguments: [String], timeout: TimeInterval = 120) throws -> (status: Int32, data: Data) {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        let out = Pipe()
        process.standardOutput = out
        process.standardError = FileHandle.nullDevice
        process.standardInput = FileHandle.nullDevice
        let box = DataBox()
        let group = DispatchGroup()
        group.enter()
        DispatchQueue.global().async {
            box.data = out.fileHandleForReading.readDataToEndOfFile()
            group.leave()
        }
        try process.run()
        let deadline = Date().addingTimeInterval(timeout)
        while process.isRunning {
            if Date() > deadline { process.terminate(); break }
            Thread.sleep(forTimeInterval: 0.02)
        }
        group.wait()
        return (process.terminationStatus, box.data)
    }

    @discardableResult
    public static func run(_ executable: String, _ arguments: [String], timeout: TimeInterval, environment: [String: String]?,
                           workingDirectory: URL) throws -> ProcessResult {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        process.currentDirectoryURL = workingDirectory
        if let environment { process.environment = environment }
        let outPipe = Pipe()
        let errPipe = Pipe()
        process.standardOutput = outPipe
        process.standardError = errPipe
        process.standardInput = FileHandle.nullDevice
        let outBox = DataBox()
        let errBox = DataBox()
        let group = DispatchGroup()
        group.enter()
        DispatchQueue.global().async { outBox.data = outPipe.fileHandleForReading.readDataToEndOfFile(); group.leave() }
        group.enter()
        DispatchQueue.global().async { errBox.data = errPipe.fileHandleForReading.readDataToEndOfFile(); group.leave() }
        try process.run()
        let deadline = Date().addingTimeInterval(timeout)
        while process.isRunning {
            if Date() > deadline { process.terminate(); throw HexError.message("The helper tool took too long and was stopped.") }
            Thread.sleep(forTimeInterval: 0.02)
        }
        group.wait()
        return ProcessResult(status: process.terminationStatus,
                             stdout: String(decoding: outBox.data, as: UTF8.self),
                             stderr: String(decoding: errBox.data, as: UTF8.self))
    }
}
