import CoreGraphics
import CoreServices
import Foundation
import ImageIO

/// Everything HEXSHIFT knows about a selected file, gathered cheaply
/// (no full decode) so the radial menu can open instantly.
public struct AssetInfo: Identifiable, Hashable, Sendable {
    public let id: UUID
    public let url: URL
    public let format: Format?
    public let kind: AssetKind
    public let fileSize: Int64
    public var pixelWidth: Int?
    public var pixelHeight: Int?
    public var frameCount: Int
    public var pageCount: Int?
    public var hasAlpha: Bool?
    public var dpi: Double?
    public var colorModel: String?
    public var profileName: String?
    public var bitDepth: Int?
    public var orientation: Int?
    public var hasGPS: Bool
    public var hasEXIF: Bool
    public var isScreenshot: Bool

    public var name: String { url.lastPathComponent }
    public var baseName: String { url.deletingPathExtension().lastPathComponent }
    public var isAnimated: Bool { frameCount > 1 }

    public static func == (lhs: AssetInfo, rhs: AssetInfo) -> Bool { lhs.id == rhs.id }
    public func hash(into hasher: inout Hasher) { hasher.combine(id) }

    /// "PNG · 2.1 MB · 1920 × 1080"
    public var summary: String {
        var parts: [String] = []
        parts.append(format?.displayName ?? (url.pathExtension.isEmpty ? kind.title : url.pathExtension.uppercased()))
        parts.append(ByteCountFormatter.string(fromByteCount: fileSize, countStyle: .file))
        if let w = pixelWidth, let h = pixelHeight { parts.append("\(w) × \(h)") }
        if let p = pageCount, kind == .pdf || format == .ai { parts.append(p == 1 ? "1 page" : "\(p) pages") }
        if frameCount > 1 { parts.append("\(frameCount) frames") }
        return parts.joined(separator: " · ")
    }
}

public enum AssetInspector {
    public static func inspect(_ url: URL) -> AssetInfo {
        let format = Format.detect(url)
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey, .totalFileAllocatedSizeKey]))
        let fileSize = Int64(size?.fileSize ?? size?.totalFileAllocatedSize ?? 0)
        var info = AssetInfo(
            id: UUID(), url: url, format: format, kind: kind(for: format, url: url),
            fileSize: fileSize, pixelWidth: nil, pixelHeight: nil, frameCount: 1,
            pageCount: nil, hasAlpha: nil, dpi: nil, colorModel: nil, profileName: nil,
            bitDepth: nil, orientation: nil, hasGPS: false, hasEXIF: false, isScreenshot: false
        )

        switch info.kind {
        case .image, .animatedImage, .rawImage:
            fillImageInfo(&info)
            if info.frameCount > 1 && info.kind == .image { info = info.with(kind: .animatedImage) }
            info.isScreenshot = isScreenCapture(url)
        case .pdf:
            if let doc = CGPDFDocument(url as CFURL) {
                info.pageCount = doc.numberOfPages
                if let page = doc.page(at: 1) {
                    let box = page.getBoxRect(.cropBox)
                    let rotated = page.rotationAngle % 180 != 0
                    info.pixelWidth = Int((rotated ? box.height : box.width).rounded())
                    info.pixelHeight = Int((rotated ? box.width : box.height).rounded())
                }
            }
        case .vector:
            if format == .ai, let doc = CGPDFDocument(url as CFURL) {
                info.pageCount = doc.numberOfPages
            }
            if format == .svg, let size = SVGSupport.intrinsicSize(of: url) {
                info.pixelWidth = Int(size.width.rounded())
                info.pixelHeight = Int(size.height.rounded())
            }
        default:
            break
        }
        return info
    }

    public static func kind(for format: Format?, url: URL) -> AssetKind {
        guard let format else { return .unknown }
        switch format.category {
        case .raster:
            if format == .raw { return .rawImage }
            return .image
        case .vector:
            return format == .pdf ? .pdf : .vector
        case .document: return .document
        case .spreadsheet: return .spreadsheet
        case .presentation: return .presentation
        case .video: return .video
        case .audio: return .audio
        case .font: return .font
        case .other: return .unknown
        }
    }

    static func fillImageInfo(_ info: inout AssetInfo) {
        guard let src = CGImageSourceCreateWithURL(info.url as CFURL, [kCGImageSourceShouldCache: false] as CFDictionary) else { return }
        info.frameCount = max(1, CGImageSourceGetCount(src))
        guard let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any] else { return }
        var w = props[kCGImagePropertyPixelWidth] as? Int
        var h = props[kCGImagePropertyPixelHeight] as? Int
        let orientation = (props[kCGImagePropertyOrientation] as? NSNumber)?.intValue ?? 1
        if orientation >= 5, orientation <= 8 { swap(&w, &h) }
        info.pixelWidth = w
        info.pixelHeight = h
        info.orientation = orientation
        info.hasAlpha = props[kCGImagePropertyHasAlpha] as? Bool
        info.dpi = (props[kCGImagePropertyDPIWidth] as? NSNumber)?.doubleValue
        info.colorModel = props[kCGImagePropertyColorModel] as? String
        info.profileName = props[kCGImagePropertyProfileName] as? String
        info.bitDepth = (props[kCGImagePropertyDepth] as? NSNumber)?.intValue
        info.hasGPS = (props[kCGImagePropertyGPSDictionary] as? [CFString: Any])?.isEmpty == false
        info.hasEXIF = (props[kCGImagePropertyExifDictionary] as? [CFString: Any])?.isEmpty == false
    }

    /// macOS marks screenshots with kMDItemIsScreenCapture; fall back to the name.
    public static func isScreenCapture(_ url: URL) -> Bool {
        if let item = MDItemCreateWithURL(kCFAllocatorDefault, url as CFURL),
           let value = MDItemCopyAttribute(item, "kMDItemIsScreenCapture" as CFString) {
            if let b = value as? Bool { return b }
            if let n = value as? NSNumber { return n.boolValue }
        }
        let name = url.lastPathComponent.lowercased()
        return name.hasPrefix("screenshot") || name.hasPrefix("screen shot")
            || name.hasPrefix("cleanshot") || name.hasPrefix("hexshift capture")
    }

    /// Detailed, human-readable properties for the Inspect panel.
    public static func detailedProperties(_ url: URL) -> [(String, String)] {
        var rows: [(String, String)] = []
        let info = inspect(url)
        rows.append(("Name", info.name))
        rows.append(("Kind", info.format.map { "\($0.displayName) \(info.kind.title.lowercased())" } ?? info.kind.title))
        rows.append(("File size", ByteCountFormatter.string(fromByteCount: info.fileSize, countStyle: .file)))
        if let w = info.pixelWidth, let h = info.pixelHeight {
            rows.append((info.kind == .pdf ? "Page size" : "Dimensions", info.kind == .pdf ? "\(w) × \(h) pt (\(PrintMath.mm(fromPoints: Double(w))) × \(PrintMath.mm(fromPoints: Double(h))) mm)" : "\(w) × \(h) px"))
            if info.kind != .pdf {
                rows.append(("Aspect ratio", AspectRatio.describe(width: w, height: h)))
                let dpi = info.dpi ?? 72
                rows.append(("Resolution", String(format: "%.0f ppi%@", dpi, info.dpi == nil ? " (not stored, 72 assumed)" : "")))
                rows.append(("Print size", String(format: "%.2f × %.2f in at %.0f ppi · %.2f × %.2f in at 300 ppi",
                                                  Double(w) / dpi, Double(h) / dpi, dpi, Double(w) / 300, Double(h) / 300)))
            }
        }
        if let p = info.pageCount { rows.append(("Pages", "\(p)")) }
        if info.frameCount > 1 { rows.append(("Frames", "\(info.frameCount) (animated)")) }
        if let m = info.colorModel { rows.append(("Colour model", m + (info.bitDepth.map { " · \($0)-bit" } ?? ""))) }
        if let p = info.profileName { rows.append(("Colour profile", p)) }
        if let a = info.hasAlpha {
            var text = a ? "Has alpha channel" : "No alpha channel"
            if a, let transparent = TransparencyCheck.hasTransparentPixels(url) {
                text += transparent ? " · contains transparent pixels" : " · fully opaque pixels"
            }
            rows.append(("Transparency", text))
        }
        if info.kind == .image || info.kind == .rawImage || info.kind == .animatedImage {
            rows.append(("EXIF", info.hasEXIF ? "Present" : "None"))
            rows.append(("Location (GPS)", info.hasGPS ? "Present — can be stripped on export" : "None"))
            rows.append(contentsOf: exifHighlights(url))
        }
        if info.kind == .pdf || info.format == .ai {
            rows.append(contentsOf: PDFEngine.documentProperties(url))
        }
        if let dates = try? url.resourceValues(forKeys: [.creationDateKey, .contentModificationDateKey]) {
            let f = DateFormatter()
            f.dateStyle = .medium
            f.timeStyle = .short
            if let c = dates.creationDate { rows.append(("Created", f.string(from: c))) }
            if let m = dates.contentModificationDate { rows.append(("Modified", f.string(from: m))) }
        }
        rows.append(("Location", url.deletingLastPathComponent().path))
        return rows
    }

    static func exifHighlights(_ url: URL) -> [(String, String)] {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil),
              let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any] else { return [] }
        var rows: [(String, String)] = []
        let tiff = props[kCGImagePropertyTIFFDictionary] as? [CFString: Any] ?? [:]
        let exif = props[kCGImagePropertyExifDictionary] as? [CFString: Any] ?? [:]
        let make = tiff[kCGImagePropertyTIFFMake] as? String
        let model = tiff[kCGImagePropertyTIFFModel] as? String
        if make != nil || model != nil {
            rows.append(("Camera", [make, model].compactMap { $0 }.joined(separator: " ")))
        }
        if let lens = exif[kCGImagePropertyExifLensModel] as? String { rows.append(("Lens", lens)) }
        if let date = exif[kCGImagePropertyExifDateTimeOriginal] as? String { rows.append(("Taken", date)) }
        var exposure: [String] = []
        if let f = exif[kCGImagePropertyExifFNumber] as? Double { exposure.append(String(format: "ƒ/%.1f", f)) }
        if let t = exif[kCGImagePropertyExifExposureTime] as? Double, t > 0 {
            exposure.append(t >= 1 ? String(format: "%.1fs", t) : "1/\(Int((1 / t).rounded()))s")
        }
        if let iso = (exif[kCGImagePropertyExifISOSpeedRatings] as? [Int])?.first { exposure.append("ISO \(iso)") }
        if let fl = exif[kCGImagePropertyExifFocalLength] as? Double { exposure.append(String(format: "%.0f mm", fl)) }
        if !exposure.isEmpty { rows.append(("Exposure", exposure.joined(separator: " · "))) }
        if let software = tiff[kCGImagePropertyTIFFSoftware] as? String { rows.append(("Software", software)) }
        return rows
    }
}

extension AssetInfo {
    func with(kind: AssetKind) -> AssetInfo {
        AssetInfo(id: id, url: url, format: format, kind: kind, fileSize: fileSize,
                  pixelWidth: pixelWidth, pixelHeight: pixelHeight, frameCount: frameCount,
                  pageCount: pageCount, hasAlpha: hasAlpha, dpi: dpi, colorModel: colorModel,
                  profileName: profileName, bitDepth: bitDepth, orientation: orientation,
                  hasGPS: hasGPS, hasEXIF: hasEXIF, isScreenshot: isScreenshot)
    }
}

/// Checks whether an image actually uses its alpha channel.
public enum TransparencyCheck {
    public static func hasTransparentPixels(_ url: URL) -> Bool? {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        // Work on a bounded thumbnail so huge images stay fast.
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceThumbnailMaxPixelSize: 1024,
        ]
        guard let image = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return nil }
        return hasTransparentPixels(image)
    }

    public static func hasTransparentPixels(_ image: CGImage) -> Bool {
        switch image.alphaInfo {
        case .none, .noneSkipFirst, .noneSkipLast: return false
        default: break
        }
        guard let buffer = PixelBuffer(image: image) else { return false }
        for y in 0..<buffer.height {
            for x in 0..<buffer.width where buffer.alpha(x: x, y: y) < 255 { return true }
        }
        return false
    }
}
