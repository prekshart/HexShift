import Foundation

public enum OutputDestination: Codable, Hashable, Sendable {
    case sameFolder
    case desktop
    case downloads
    case custom(path: String)
    case clipboardOnly
    case askEveryTime

    public var title: String {
        switch self {
        case .sameFolder: return "Same folder as original"
        case .desktop: return "Desktop"
        case .downloads: return "Downloads"
        case let .custom(path): return (path as NSString).lastPathComponent
        case .clipboardOnly: return "Clipboard only"
        case .askEveryTime: return "Ask every time"
        }
    }
}

public enum NamingRule: Codable, Hashable, Sendable {
    /// originalfilename-converted.extension (default)
    case suffix(String)
    /// originalfilename.newextension
    case originalName
    /// originalfilename-1.extension, -2, …
    case numbered
    /// originalfilename-20261024-0132.extension
    case timestamp
    /// Tokens: {name} {ext} {format} {date} {time} {n} {w} {h}
    case custom(String)

    public var title: String {
        switch self {
        case let .suffix(s): return "Add “\(s)”"
        case .originalName: return "Original name, new extension"
        case .numbered: return "Numbered copies"
        case .timestamp: return "Timestamp suffix"
        case let .custom(p): return "Custom: \(p)"
        }
    }
}

public struct OutputSettings: Codable, Hashable, Sendable {
    public var destination: OutputDestination = .sameFolder
    public var naming: NamingRule = .suffix("-converted")
    public init() {}
    public init(destination: OutputDestination, naming: NamingRule) {
        self.destination = destination
        self.naming = naming
    }
}

/// Decides where outputs go and what they are called. Never returns a path
/// that already exists, and never the source file itself.
public struct OutputPlanner: Sendable {
    public var settings: OutputSettings
    /// A folder chosen by the user for this run ("Ask every time"), or the
    /// temporary folder used for "Clipboard only".
    public var folderOverride: URL?

    public init(settings: OutputSettings, folderOverride: URL? = nil) {
        self.settings = settings
        self.folderOverride = folderOverride
    }

    public static func clipboardStagingFolder() -> URL {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("HEXSHIFT/Clipboard-\(UUID().uuidString.prefix(8))", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    public func folder(for source: URL?) -> URL {
        if let o = folderOverride { return o }
        let fm = FileManager.default
        let home = fm.homeDirectoryForCurrentUser
        switch settings.destination {
        case .sameFolder:
            if let s = source {
                let dir = s.deletingLastPathComponent()
                if fm.isWritableFile(atPath: dir.path) && !Self.isInternalFolder(dir) { return dir }
            }
            return fm.urls(for: .desktopDirectory, in: .userDomainMask).first ?? home
        case .desktop:
            return fm.urls(for: .desktopDirectory, in: .userDomainMask).first ?? home
        case .downloads:
            return fm.urls(for: .downloadsDirectory, in: .userDomainMask).first ?? home
        case let .custom(path):
            let url = URL(fileURLWithPath: path, isDirectory: true)
            try? fm.createDirectory(at: url, withIntermediateDirectories: true)
            return url
        case .clipboardOnly:
            return OutputPlanner.clipboardStagingFolder()
        case .askEveryTime:
            // The UI resolves this into folderOverride; fall back to Desktop.
            return fm.urls(for: .desktopDirectory, in: .userDomainMask).first ?? home
        }
    }

    /// - Parameters:
    ///   - source: original file (nil for generated content such as text exports)
    ///   - baseName: name without extension to start from
    ///   - ext: extension of the output
    ///   - part: page/frame number when one source produces several files
    public func url(for source: URL?, baseName: String? = nil, ext: String, format: String? = nil,
                    part: Int? = nil, partCount: Int? = nil, pixelSize: (Int, Int)? = nil) -> URL {
        let dir = folder(for: source)
        let name = baseName ?? source?.deletingPathExtension().lastPathComponent ?? "HEXSHIFT"
        var stem: String
        let date = Date()
        switch settings.naming {
        case let .suffix(s):
            stem = name + s
        case .originalName:
            stem = name
        case .numbered:
            stem = name
        case .timestamp:
            stem = name + "-" + Self.stamp(date, "yyyyMMdd-HHmmss")
        case let .custom(pattern):
            stem = pattern
                .replacingOccurrences(of: "{name}", with: name)
                .replacingOccurrences(of: "{ext}", with: ext)
                .replacingOccurrences(of: "{format}", with: (format ?? ext).lowercased())
                .replacingOccurrences(of: "{date}", with: Self.stamp(date, "yyyy-MM-dd"))
                .replacingOccurrences(of: "{time}", with: Self.stamp(date, "HHmmss"))
                .replacingOccurrences(of: "{w}", with: pixelSize.map { "\($0.0)" } ?? "")
                .replacingOccurrences(of: "{h}", with: pixelSize.map { "\($0.1)" } ?? "")
                .replacingOccurrences(of: "{n}", with: part.map { "\($0)" } ?? "1")
            stem = Self.sanitize(stem)
            if stem.isEmpty { stem = name }
        }
        if let part, (partCount ?? 2) > 1 {
            let digits = max(2, String(partCount ?? part).count)
            stem += "-" + String(format: "%0\(digits)d", part)
        }
        if case .numbered = settings.naming {
            var n = 1
            while true {
                let candidate = dir.appendingPathComponent("\(stem)-\(n)").appendingPathExtension(ext)
                if !FileManager.default.fileExists(atPath: candidate.path) && candidate.standardizedFileURL != source?.standardizedFileURL {
                    return candidate
                }
                n += 1
            }
        }
        return Self.unique(dir.appendingPathComponent(stem).appendingPathExtension(ext), avoiding: source)
    }

    /// HEXSHIFT's own scratch folders (clipboard staging, screen captures). Outputs for
    /// files that live there go to the Desktop instead, where the user can see them.
    public static func isInternalFolder(_ dir: URL) -> Bool {
        let fm = FileManager.default
        let path = dir.standardizedFileURL.path + "/"
        var roots = [fm.temporaryDirectory.appendingPathComponent("HEXSHIFT", isDirectory: true)]
        if let caches = fm.urls(for: .cachesDirectory, in: .userDomainMask).first {
            roots.append(caches.appendingPathComponent("HEXSHIFT", isDirectory: true))
        }
        return roots.contains { path.hasPrefix($0.standardizedFileURL.path + "/") }
    }

    /// Adds " 2", " 3"… until the name is free (Finder style).
    public static func unique(_ url: URL, avoiding source: URL? = nil) -> URL {
        let fm = FileManager.default
        func taken(_ u: URL) -> Bool {
            fm.fileExists(atPath: u.path) || (source != nil && u.standardizedFileURL.path == source!.standardizedFileURL.path)
        }
        if !taken(url) { return url }
        let dir = url.deletingLastPathComponent()
        let ext = url.pathExtension
        let stem = url.deletingPathExtension().lastPathComponent
        var n = 2
        while true {
            let candidate = dir.appendingPathComponent("\(stem) \(n)").appendingPathExtension(ext)
            if !taken(candidate) { return candidate }
            n += 1
        }
    }

    /// Folder for outputs that produce many files (e.g. "Frames").
    public func folderURL(for source: URL?, name: String) -> URL {
        let dir = folder(for: source)
        var candidate = dir.appendingPathComponent(name, isDirectory: true)
        var n = 2
        while FileManager.default.fileExists(atPath: candidate.path) {
            candidate = dir.appendingPathComponent("\(name) \(n)", isDirectory: true)
            n += 1
        }
        return candidate
    }

    static func stamp(_ date: Date, _ format: String) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = format
        return f.string(from: date)
    }

    static func sanitize(_ s: String) -> String {
        let bad = CharacterSet(charactersIn: "/:\\?%*|\"<>")
        return s.components(separatedBy: bad).joined(separator: "-").trimmingCharacters(in: .whitespaces)
    }
}
