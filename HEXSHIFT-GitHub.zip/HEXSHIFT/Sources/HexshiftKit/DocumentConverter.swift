import AppKit
import Foundation

public struct DocumentOptions: Codable, Hashable, Sendable {
    public var pageSize: PDFPageSize = .a4
    public var landscape: Bool = false
    /// Page margin in points (54 pt = 0.75 in).
    public var margin: Double = 54
    /// nil = system font
    public var fontName: String?
    public var fontSize: Double = 12
    public var lineSpacing: Double = 1.25
    /// Use Pandoc / LibreOffice / Pages & Keynote when installed (higher fidelity).
    public var useExternalEngines: Bool = true

    public init() {}

    public var paperSize: CGSize {
        let s = pageSize.size ?? PDFPageSize.a4.size!
        return landscape ? CGSize(width: s.height, height: s.width) : s
    }
}

/// Text and word-processing conversions built on AppKit's document engine
/// (the same engine TextEdit uses), with optional higher-fidelity adapters.
public enum DocumentConverter {
    public static let readable: Set<Format> = [.txt, .rtf, .docx, .doc, .odt, .html, .md, .json]
    public static let writable: [Format] = [.pdf, .docx, .rtf, .txt, .md, .html, .odt, .doc]

    static func documentType(for format: Format) -> NSAttributedString.DocumentType? {
        switch format {
        case .rtf: return .rtf
        case .docx: return .officeOpenXML
        case .doc: return .docFormat
        case .odt: return .openDocument
        case .html: return .html
        case .txt, .json: return .plain
        default: return nil
        }
    }

    public static func readPlainText(_ url: URL) throws -> String {
        var encoding = String.Encoding.utf8
        if let s = try? String(contentsOf: url, usedEncoding: &encoding) { return s }
        if let s = try? String(contentsOf: url, encoding: .utf8) { return s }
        if let s = try? String(contentsOf: url, encoding: .isoLatin1) { return s }
        throw HexError.unreadable(url.lastPathComponent)
    }

    @MainActor
    public static func styledFromPlain(_ text: String, options: DocumentOptions = DocumentOptions()) -> NSAttributedString {
        let size = CGFloat(options.fontSize)
        let font = options.fontName.flatMap { NSFont(name: $0, size: size) } ?? NSFont.systemFont(ofSize: size)
        let para = NSMutableParagraphStyle()
        para.lineHeightMultiple = CGFloat(options.lineSpacing)
        para.paragraphSpacing = size * 0.4
        return NSAttributedString(string: text, attributes: [.font: font, .foregroundColor: NSColor.black, .paragraphStyle: para])
    }

    @MainActor
    public static func attributedString(fromHTML html: String) throws -> NSAttributedString {
        let opts: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.html,
            .characterEncoding: String.Encoding.utf8.rawValue,
            .timeout: 8,
        ]
        return try NSAttributedString(data: Data(html.utf8), options: opts, documentAttributes: nil)
    }

    @MainActor
    public static func attributedString(from url: URL, format: Format, options: DocumentOptions = DocumentOptions()) throws -> NSAttributedString {
        switch format {
        case .txt, .json:
            return styledFromPlain(try readPlainText(url), options: options)
        case .md:
            let md = try readPlainText(url)
            return try attributedString(fromHTML: MarkdownRenderer.html(from: md, title: url.deletingPathExtension().lastPathComponent))
        case .pdf, .ai:
            return try PDFEngine.attributedText(url)
        case .html:
            let opts: [NSAttributedString.DocumentReadingOptionKey: Any] = [
                .documentType: NSAttributedString.DocumentType.html,
                .characterEncoding: String.Encoding.utf8.rawValue,
                .timeout: 8,
            ]
            return try NSAttributedString(url: url, options: opts, documentAttributes: nil)
        default:
            guard let type = documentType(for: format) else {
                throw HexError.unsupportedConversion(from: format.displayName, to: "text")
            }
            do {
                return try NSAttributedString(url: url, options: [.documentType: type], documentAttributes: nil)
            } catch {
                throw HexError.unreadable(url.lastPathComponent)
            }
        }
    }

    @MainActor
    public static func write(_ attr: NSAttributedString, as format: Format, to url: URL,
                             options: DocumentOptions = DocumentOptions(), title: String? = nil) throws {
        try FileWriter.writeAtomically(to: url) { tmp in
            switch format {
            case .pdf:
                try exportPDF(attr, to: tmp, options: options)
            case .txt:
                try Data(attr.string.utf8).write(to: tmp)
            case .md:
                try Data(MarkdownWriter.markdown(from: attr).utf8).write(to: tmp)
            default:
                guard let type = documentType(for: format) else {
                    throw HexError.unsupportedConversion(from: "Text", to: format.displayName)
                }
                var docAttrs: [NSAttributedString.DocumentAttributeKey: Any] = [.documentType: type]
                if let title { docAttrs[.title] = title }
                if format == .html { docAttrs[.characterEncoding] = String.Encoding.utf8.rawValue }
                let data = try attr.data(from: NSRange(location: 0, length: attr.length), documentAttributes: docAttrs)
                try data.write(to: tmp)
            }
            try validateDocument(tmp, format: format)
        }
    }

    /// Paginates styled text into a PDF using the print system (handles images and tables).
    @MainActor
    public static func exportPDF(_ attr: NSAttributedString, to url: URL, options: DocumentOptions = DocumentOptions()) throws {
        let paper = options.paperSize
        let m = CGFloat(options.margin)
        let printInfo = NSPrintInfo(dictionary: [NSPrintInfo.AttributeKey.jobSavingURL: url])
        printInfo.jobDisposition = .save
        printInfo.orientation = options.landscape ? .landscape : .portrait
        printInfo.paperSize = paper
        printInfo.topMargin = m
        printInfo.bottomMargin = m
        printInfo.leftMargin = m
        printInfo.rightMargin = m
        printInfo.horizontalPagination = .fit
        printInfo.verticalPagination = .automatic
        printInfo.isHorizontallyCentered = false
        printInfo.isVerticallyCentered = false

        let width = max(72, paper.width - 2 * m)
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: width, height: max(72, paper.height - 2 * m)))
        textView.appearance = NSAppearance(named: .aqua)
        textView.isEditable = false
        textView.drawsBackground = false
        textView.textContainerInset = .zero
        textView.textContainer?.lineFragmentPadding = 0
        textView.textContainer?.widthTracksTextView = true
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.textContainer?.containerSize = NSSize(width: width, height: CGFloat.greatestFiniteMagnitude)
        textView.textColor = .black
        let content = NSMutableAttributedString(attributedString: attr)
        // Text without an explicit colour would follow Dark Mode; force print colours.
        content.enumerateAttribute(.foregroundColor, in: NSRange(location: 0, length: content.length)) { value, range, _ in
            if value == nil { content.addAttribute(.foregroundColor, value: NSColor.black, range: range) }
        }
        textView.textStorage?.setAttributedString(content)
        if let container = textView.textContainer { textView.layoutManager?.ensureLayout(for: container) }
        textView.sizeToFit()

        let operation = NSPrintOperation(view: textView, printInfo: printInfo)
        operation.showsPrintPanel = false
        operation.showsProgressPanel = false
        var ok = false
        NSAppearance(named: .aqua)?.performAsCurrentDrawingAppearance {
            ok = operation.run()
        }
        let written = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.intValue ?? 0
        guard ok, written > 0 else { throw HexError.writeFailed("The PDF could not be generated.") }
    }

    static func validateDocument(_ url: URL, format: Format) throws {
        let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.intValue ?? 0
        guard size > 0 else { throw HexError.invalidOutput("The document is empty.") }
        switch format {
        case .pdf:
            try ImageEncoder.validate(url, format: .pdf)
        case .docx, .odt, .xlsx, .pptx:
            // Office Open XML / ODF are ZIP containers.
            guard Format.sniffZip(url) else { throw HexError.invalidOutput("The \(format.displayName) container is invalid.") }
        default:
            break
        }
    }

    // MARK: - High level

    /// Converts a document file to another document format (or PDF).
    /// External engines (LibreOffice, Pages, Pandoc) run on a background thread so the app stays
    /// responsive; only AppKit's document importer/exporter, which needs the main thread, runs there.
    public static func convert(_ url: URL, from source: Format, to target: Format, output: URL,
                               options: DocumentOptions = DocumentOptions()) async throws {
        if options.useExternalEngines {
            let handled: Bool = await withCheckedContinuation { cont in
                DispatchQueue.global(qos: .userInitiated).async {
                    cont.resume(returning: tryExternalEngines(url, from: source, to: target, output: output))
                }
            }
            if handled { return }
        }
        try Task.checkCancellation()
        try await MainActor.run {
            try convertBuiltIn(url, from: source, to: target, output: output, options: options)
        }
    }

    static func tryExternalEngines(_ url: URL, from source: Format, to target: Format, output: URL) -> Bool {
        if target == .pdf, [.docx, .doc, .odt, .rtf].contains(source) {
            if (try? OfficeAdapters.convertWithLibreOffice(url, to: .pdf, output: output)) != nil { return true }
            if (try? OfficeAdapters.convertWithIWork(url, source: source, to: .pdf, output: output)) != nil { return true }
        }
        if OfficeAdapters.pandocHandles(source: source, target: target),
           (try? OfficeAdapters.convertWithPandoc(url, from: source, to: target, output: output)) != nil { return true }
        return false
    }

    /// The built-in engine only (AppKit's document system + the Markdown renderer).
    @MainActor
    public static func convertBuiltIn(_ url: URL, from source: Format, to target: Format, output: URL,
                                      options: DocumentOptions = DocumentOptions()) throws {
        if source == .md && target == .html {
            let md = try readPlainText(url)
            try FileWriter.writeAtomically(to: output) { tmp in
                try Data(MarkdownRenderer.html(from: md, title: url.deletingPathExtension().lastPathComponent).utf8).write(to: tmp)
            }
            return
        }
        let attr = try attributedString(from: url, format: source, options: options)
        try write(attr, as: target, to: output, options: options, title: url.deletingPathExtension().lastPathComponent)
    }

    /// Text selected anywhere → document.
    @MainActor
    public static func export(text: String, as target: Format, to output: URL, options: DocumentOptions = DocumentOptions(),
                              treatAsMarkdown: Bool = false, title: String? = nil) throws {
        if target == .md || (target == .txt && !treatAsMarkdown) {
            try FileWriter.writeAtomically(to: output) { tmp in try Data(text.utf8).write(to: tmp) }
            return
        }
        if target == .html && treatAsMarkdown {
            try FileWriter.writeAtomically(to: output) { tmp in
                try Data(MarkdownRenderer.html(from: text, title: title).utf8).write(to: tmp)
            }
            return
        }
        let attr: NSAttributedString
        if treatAsMarkdown {
            attr = try attributedString(fromHTML: MarkdownRenderer.html(from: text, title: title))
        } else {
            attr = styledFromPlain(text, options: options)
        }
        try write(attr, as: target, to: output, options: options, title: title)
    }

    /// Word count and similar quick facts.
    public static func statistics(_ text: String) -> (words: Int, characters: Int, lines: Int, readingMinutes: Int) {
        let words = text.split { $0.isWhitespace || $0.isNewline }.count
        return (words, text.count, text.components(separatedBy: .newlines).count, max(1, Int((Double(words) / 230).rounded(.up))))
    }

    /// Fonts used in a styled document (actual metadata).
    @MainActor
    public static func fontsUsed(_ url: URL, format: Format) -> [(family: String, face: String, sizes: [CGFloat])] {
        guard let attr = try? attributedString(from: url, format: format) else { return [] }
        var map: [String: (String, String, Set<CGFloat>)] = [:]
        attr.enumerateAttribute(.font, in: NSRange(location: 0, length: attr.length)) { value, _, _ in
            guard let f = value as? NSFont else { return }
            let key = f.fontName
            var entry = map[key] ?? (f.familyName ?? f.fontName, f.displayName ?? f.fontName, [])
            entry.2.insert((f.pointSize * 2).rounded() / 2)
            map[key] = entry
        }
        return map.values.map { ($0.0, $0.1, $0.2.sorted()) }.sorted { $0.family < $1.family }
    }
}

extension Format {
    /// True when the file is a ZIP container (DOCX/XLSX/PPTX/ODT…).
    static func sniffZip(_ url: URL) -> Bool {
        guard let h = try? FileHandle(forReadingFrom: url) else { return false }
        defer { try? h.close() }
        guard let d = try? h.read(upToCount: 4), d.count == 4 else { return false }
        return [UInt8](d) == [0x50, 0x4B, 0x03, 0x04]
    }
}
