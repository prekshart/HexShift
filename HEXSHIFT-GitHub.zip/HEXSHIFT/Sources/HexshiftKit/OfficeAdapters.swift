import AppKit
import Foundation

/// Optional high-fidelity engines. Each is used only when installed on this Mac.
public enum OfficeAdapters {
    // MARK: Availability

    public static let keynoteID = "com.apple.iWork.Keynote"
    public static let pagesID = "com.apple.iWork.Pages"
    public static let numbersID = "com.apple.iWork.Numbers"

    public static func isInstalled(bundleID: String) -> Bool {
        NSWorkspace.shared.urlForApplication(withBundleIdentifier: bundleID) != nil
    }

    public static var hasKeynote: Bool { isInstalled(bundleID: keynoteID) }
    public static var hasPages: Bool { isInstalled(bundleID: pagesID) }
    public static var hasNumbers: Bool { isInstalled(bundleID: numbersID) }
    public static var hasLibreOffice: Bool { ExternalTools.path(.soffice) != nil }
    public static var hasPandoc: Bool { ExternalTools.path(.pandoc) != nil }

    // MARK: LibreOffice (headless)

    public static func convertWithLibreOffice(_ url: URL, to target: Format, output: URL) throws {
        guard let soffice = ExternalTools.path(.soffice) else {
            throw HexError.missingTool(name: "LibreOffice", hint: ExternalTool.soffice.installHint)
        }
        let outDir = try FileWriter.makeTemporaryDirectory()
        let profile = try FileWriter.makeTemporaryDirectory()
        defer {
            try? FileManager.default.removeItem(at: outDir)
            try? FileManager.default.removeItem(at: profile)
        }
        let result = try ExternalTools.run(soffice, [
            "-env:UserInstallation=\(profile.absoluteString)",
            "--headless", "--norestore", "--convert-to", target.fileExtension,
            "--outdir", outDir.path, url.path,
        ], timeout: 300)
        let produced = outDir.appendingPathComponent(url.deletingPathExtension().lastPathComponent).appendingPathExtension(target.fileExtension)
        guard result.status == 0, FileManager.default.fileExists(atPath: produced.path) else {
            throw HexError.writeFailed("LibreOffice could not convert the file.")
        }
        try FileWriter.writeAtomically(to: output) { tmp in
            try FileManager.default.copyItem(at: produced, to: tmp)
            if target == .pdf { try ImageEncoder.validate(tmp, format: .pdf) }
        }
    }

    // MARK: Pages / Keynote / Numbers (AppleScript, needs Automation permission)

    /// Which iWork app can open this source format.
    public static func iWorkApp(for source: Format) -> String? {
        switch source {
        case .pptx, .key: return hasKeynote ? keynoteID : nil
        case .docx, .doc, .pages, .rtf, .txt: return hasPages ? pagesID : nil
        case .xlsx, .csv, .numbers: return hasNumbers ? numbersID : nil
        default: return nil
        }
    }

    /// AppleScript export format constants for each app.
    static func exportClause(app: String, target: Format) -> String? {
        switch (app, target) {
        case (_, .pdf): return "PDF"
        case (keynoteID, .pptx): return "Microsoft PowerPoint"
        case (pagesID, .docx): return "Microsoft Word"
        case (pagesID, .txt): return "unformatted text"
        case (numbersID, .xlsx): return "Microsoft Excel"
        case (numbersID, .csv): return "CSV"
        default: return nil
        }
    }

    public static func iWorkTargets(for source: Format) -> [Format] {
        guard let app = iWorkApp(for: source) else { return [] }
        let all: [Format] = [.pdf, .pptx, .docx, .txt, .xlsx, .csv]
        return all.filter { exportClause(app: app, target: $0) != nil && $0 != source }
    }

    public static func convertWithIWork(_ url: URL, source: Format, to target: Format, output: URL) throws {
        guard let app = iWorkApp(for: source), let clause = exportClause(app: app, target: target) else {
            throw HexError.unsupportedConversion(from: source.displayName, to: target.displayName)
        }
        let tmpDir = try FileWriter.makeTemporaryDirectory()
        defer { try? FileManager.default.removeItem(at: tmpDir) }
        let tmpOut = tmpDir.appendingPathComponent("export").appendingPathExtension(target.fileExtension)
        let script = """
        on run argv
            set inFile to POSIX file (item 1 of argv)
            set outFile to POSIX file (item 2 of argv)
            tell application id "\(app)"
                set theDoc to open inFile
                delay 0.5
                export theDoc to outFile as \(clause)
                close theDoc saving no
            end tell
        end run
        """
        let result = try ExternalTools.run("/usr/bin/osascript", ["-e", script, url.path, tmpOut.path], timeout: 300)
        guard result.status == 0, FileManager.default.fileExists(atPath: tmpOut.path) else {
            let reason = result.stderr.contains("-1743") || result.stderr.contains("Not authorized")
                ? "Allow HEXSHIFT to control the app in System Settings › Privacy & Security › Automation."
                : String(result.stderr.prefix(200))
            throw HexError.writeFailed(reason)
        }
        try FileWriter.writeAtomically(to: output) { tmp in
            try FileManager.default.copyItem(at: tmpOut, to: tmp)
            if target == .pdf { try ImageEncoder.validate(tmp, format: .pdf) }
        }
    }

    // MARK: Pandoc

    static let pandocNames: [Format: String] = [.md: "gfm", .docx: "docx", .html: "html", .odt: "odt", .rtf: "rtf", .txt: "plain"]

    public static func pandocHandles(source: Format, target: Format) -> Bool {
        guard hasPandoc else { return false }
        let readable: Set<Format> = [.md, .docx, .html, .odt]
        let writable: Set<Format> = [.md, .docx, .html, .odt, .rtf, .txt]
        // Only where Pandoc clearly beats the built-in engine.
        let worthIt = (source == .md && (target == .docx || target == .odt)) || (target == .md && (source == .docx || source == .html || source == .odt))
        return readable.contains(source) && writable.contains(target) && worthIt
    }

    public static func convertWithPandoc(_ url: URL, from source: Format, to target: Format, output: URL) throws {
        guard let pandoc = ExternalTools.path(.pandoc), let from = pandocNames[source], let to = pandocNames[target] else {
            throw HexError.missingTool(name: "Pandoc", hint: ExternalTool.pandoc.installHint)
        }
        try FileWriter.writeAtomically(to: output) { tmp in
            var args = ["-f", from, "-t", to, "-o", tmp.path, url.path]
            if target == .html { args.insert("--standalone", at: 0) }
            let r = try ExternalTools.run(pandoc, args, timeout: 180)
            guard r.status == 0 else { throw HexError.writeFailed("Pandoc failed: \(r.stderr.prefix(200))") }
        }
    }
}
