import CoreGraphics
import CoreImage
import Foundation
import ImageIO
import Vision

/// Non-destructive colour adjustments (Core Image).
public struct Adjustments: Codable, Hashable, Sendable {
    /// Exposure in EV, -2...2
    public var exposure: Double = 0
    /// -0.5...0.5
    public var brightness: Double = 0
    /// 0.5...1.5
    public var contrast: Double = 1
    /// 0...2
    public var saturation: Double = 1
    /// -1...1 (negative recovers highlights)
    public var highlights: Double = 0
    /// -1...1 (positive lifts shadows)
    public var shadows: Double = 0
    /// -1 (cooler) ... 1 (warmer)
    public var warmth: Double = 0
    /// -1 (green) ... 1 (magenta)
    public var tint: Double = 0
    /// 0...2
    public var sharpness: Double = 0
    /// -1...1
    public var vibrance: Double = 0
    public var grayscale: Bool = false

    public init() {}

    public var isIdentity: Bool { self == Adjustments() }
}

public enum ImageEffects {
    public static let context: CIContext = CIContext(options: [.cacheIntermediates: false])

    public static func apply(_ adj: Adjustments, to image: CGImage) -> CGImage {
        if adj.isIdentity { return image }
        let input = CIImage(cgImage: image)
        let output = apply(adj, to: input)
        return render(output, extent: input.extent, like: image) ?? image
    }

    public static func apply(_ adj: Adjustments, to input: CIImage) -> CIImage {
        var img = input
        if adj.exposure != 0 {
            img = img.applyingFilter("CIExposureAdjust", parameters: [kCIInputEVKey: adj.exposure])
        }
        if adj.brightness != 0 || adj.contrast != 1 || adj.saturation != 1 {
            img = img.applyingFilter("CIColorControls", parameters: [
                kCIInputBrightnessKey: adj.brightness,
                kCIInputContrastKey: adj.contrast,
                kCIInputSaturationKey: adj.saturation,
            ])
        }
        if adj.highlights != 0 || adj.shadows != 0 {
            img = img.applyingFilter("CIHighlightShadowAdjust", parameters: [
                "inputHighlightAmount": 1 + min(0, adj.highlights) * 0.9 + max(0, adj.highlights) * 0,
                "inputShadowAmount": adj.shadows,
            ])
            if adj.highlights > 0 {
                img = img.applyingFilter("CIToneCurve", parameters: [
                    "inputPoint0": CIVector(x: 0, y: 0),
                    "inputPoint1": CIVector(x: 0.25, y: 0.25),
                    "inputPoint2": CIVector(x: 0.5, y: 0.5),
                    "inputPoint3": CIVector(x: 0.75, y: 0.75 + 0.12 * adj.highlights),
                    "inputPoint4": CIVector(x: 1, y: 1),
                ])
            }
        }
        if adj.warmth != 0 || adj.tint != 0 {
            // Raising the source neutral above the 6500 K target warms the image; lowering it cools.
            img = img.applyingFilter("CITemperatureAndTint", parameters: [
                "inputNeutral": CIVector(x: 6500 + adj.warmth * 3000, y: adj.tint * 60),
                "inputTargetNeutral": CIVector(x: 6500, y: 0),
            ])
        }
        if adj.vibrance != 0 {
            img = img.applyingFilter("CIVibrance", parameters: ["inputAmount": adj.vibrance])
        }
        if adj.sharpness > 0 {
            img = img.applyingFilter("CISharpenLuminance", parameters: [kCIInputSharpnessKey: adj.sharpness * 0.8, kCIInputRadiusKey: 1.6])
        }
        if adj.grayscale {
            img = img.applyingFilter("CIPhotoEffectMono")
        }
        return img.cropped(to: input.extent)
    }

    /// Apple's automatic enhancement (exposure, vibrance, tone curve, highlights).
    public static func autoEnhance(_ image: CGImage) -> CGImage {
        var img = CIImage(cgImage: image)
        let extent = img.extent
        for filter in img.autoAdjustmentFilters(options: [.redEye: false]) {
            filter.setValue(img, forKey: kCIInputImageKey)
            if let out = filter.outputImage { img = out }
        }
        return render(img.cropped(to: extent), extent: extent, like: image) ?? image
    }

    /// Renders keeping the original colour space when possible (wide gamut stays wide).
    public static func render(_ image: CIImage, extent: CGRect, like original: CGImage?) -> CGImage? {
        var space = ImageOps.sRGB
        if let cs = original?.colorSpace, cs.model == .rgb { space = cs }
        return context.createCGImage(image, from: extent, format: .RGBA8, colorSpace: space)
    }

    public static func gaussianBlur(_ image: CGImage, radius: Double) -> CGImage {
        let ci = CIImage(cgImage: image)
        let out = ci.clampedToExtent().applyingGaussianBlur(sigma: radius).cropped(to: ci.extent)
        return render(out, extent: ci.extent, like: image) ?? image
    }

    public static func pixellate(_ image: CGImage, scale: Double) -> CGImage {
        let ci = CIImage(cgImage: image)
        let out = ci.clampedToExtent().applyingFilter("CIPixellate", parameters: [kCIInputScaleKey: max(2, scale),
                                                                                kCIInputCenterKey: CIVector(x: 0, y: 0)]).cropped(to: ci.extent)
        return render(out, extent: ci.extent, like: image) ?? image
    }
}

// MARK: - Background removal (Apple Vision, on-device)

public enum BackgroundMode: Codable, Hashable, Sendable {
    case transparent
    case solid(RGBAColour)
    case gradient(RGBAColour, RGBAColour, angle: Double)
    case blur(radius: Double)
    case image(path: String)

    public var title: String {
        switch self {
        case .transparent: return "Transparent"
        case .solid: return "Solid colour"
        case .gradient: return "Gradient"
        case .blur: return "Blurred"
        case .image: return "Custom image"
        }
    }
}

public enum BackgroundRemoval {
    /// Full-resolution greyscale mask: white = subject.
    public static func subjectMask(for image: CGImage) throws -> CGImage {
        let handler = VNImageRequestHandler(cgImage: image, options: [:])
        let request = VNGenerateForegroundInstanceMaskRequest()
        do {
            try handler.perform([request])
            if let result = request.results?.first, !result.allInstances.isEmpty {
                let buffer = try result.generateScaledMaskForImage(forInstances: result.allInstances, from: handler)
                let ci = CIImage(cvPixelBuffer: buffer)
                if let mask = renderMask(ci, width: image.width, height: image.height) { return mask }
            }
        } catch {
            // Fall through to person segmentation.
        }
        // Fallback: people only.
        let person = VNGeneratePersonSegmentationRequest()
        person.qualityLevel = .accurate
        person.outputPixelFormat = kCVPixelFormatType_OneComponent8
        try handler.perform([person])
        guard let buffer = person.results?.first?.pixelBuffer else { throw HexError.noSubjectFound }
        let ci = CIImage(cvPixelBuffer: buffer)
        guard let mask = renderMask(ci, width: image.width, height: image.height), maskCoverage(mask) > 0.005 else {
            throw HexError.noSubjectFound
        }
        return mask
    }

    static func renderMask(_ ci: CIImage, width: Int, height: Int) -> CGImage? {
        let sx = CGFloat(width) / ci.extent.width
        let sy = CGFloat(height) / ci.extent.height
        let scaled = ci.transformed(by: CGAffineTransform(translationX: -ci.extent.minX, y: -ci.extent.minY).scaledBy(x: sx, y: sy))
        let rect = CGRect(x: 0, y: 0, width: width, height: height)
        return ImageEffects.context.createCGImage(scaled.cropped(to: rect), from: rect, format: .L8,
                                                  colorSpace: CGColorSpaceCreateDeviceGray())
    }

    /// Fraction of the mask that is "subject".
    public static func maskCoverage(_ mask: CGImage) -> Double {
        guard let buf = PixelBuffer(image: mask, maxDimension: 128) else { return 0 }
        var on = 0
        for y in 0..<buf.height {
            for x in 0..<buf.width where buf.data[buf.offset(x: x, y: y)] > 127 { on += 1 }
        }
        return Double(on) / Double(buf.width * buf.height)
    }

    /// - Parameters:
    ///   - feather: edge softness in pixels (0 = hard edge)
    ///   - edgeShift: negative shrinks the mask (removes halos), positive grows it
    public static func composite(_ image: CGImage, mask: CGImage, mode: BackgroundMode,
                                 feather: Double = 1, edgeShift: Double = 0) -> CGImage? {
        let fg = CIImage(cgImage: image)
        let extent = fg.extent
        var m = CIImage(cgImage: mask)
        if m.extent.size != extent.size {
            m = m.transformed(by: CGAffineTransform(scaleX: extent.width / m.extent.width, y: extent.height / m.extent.height))
        }
        if edgeShift < -0.25 {
            m = m.applyingFilter("CIMorphologyMinimum", parameters: [kCIInputRadiusKey: -edgeShift])
        } else if edgeShift > 0.25 {
            m = m.applyingFilter("CIMorphologyMaximum", parameters: [kCIInputRadiusKey: edgeShift])
        }
        if feather > 0.1 {
            m = m.clampedToExtent().applyingGaussianBlur(sigma: feather)
        }
        m = m.cropped(to: extent)

        let background: CIImage
        switch mode {
        case .transparent:
            background = CIImage(color: CIColor(red: 0, green: 0, blue: 0, alpha: 0)).cropped(to: extent)
        case let .solid(c):
            background = CIImage(color: CIColor(cgColor: c.cgColor)).cropped(to: extent)
        case let .gradient(a, b, angle):
            let rad = angle * .pi / 180
            let cx = extent.midX, cy = extent.midY
            let half = 0.5 * (abs(sin(rad)) * extent.width + abs(cos(rad)) * extent.height)
            // CSS-style angle: 0° = towards top.
            let dx = sin(rad) * half, dy = cos(rad) * half
            let gradient = CIFilter(name: "CILinearGradient", parameters: [
                "inputPoint0": CIVector(x: cx - dx, y: cy - dy),
                "inputPoint1": CIVector(x: cx + dx, y: cy + dy),
                "inputColor0": CIColor(cgColor: a.cgColor),
                "inputColor1": CIColor(cgColor: b.cgColor),
            ])?.outputImage
            background = (gradient ?? CIImage(color: CIColor(cgColor: a.cgColor))).cropped(to: extent)
        case let .blur(radius):
            background = fg.clampedToExtent().applyingGaussianBlur(sigma: max(1, radius)).cropped(to: extent)
        case let .image(path):
            if let bgImage = try? ImageLoader.load(URL(fileURLWithPath: path)).image {
                let filled = ImageOps.fill(bgImage, size: extent.size)
                background = CIImage(cgImage: filled)
            } else {
                background = CIImage(color: CIColor(red: 1, green: 1, blue: 1)).cropped(to: extent)
            }
        }
        let output = fg.applyingFilter("CIBlendWithMask", parameters: [
            kCIInputBackgroundImageKey: background,
            kCIInputMaskImageKey: m,
        ])
        return ImageEffects.context.createCGImage(output, from: extent, format: .RGBA8, colorSpace: image.colorSpace?.model == .rgb ? image.colorSpace! : ImageOps.sRGB)
    }

    /// One call: detect the subject and composite.
    public static func removeBackground(_ image: CGImage, mode: BackgroundMode = .transparent, feather: Double = 1) throws -> CGImage {
        let mask = try subjectMask(for: image)
        guard let out = composite(image, mask: mask, mode: mode, feather: feather) else {
            throw HexError.message("The background could not be removed.")
        }
        return out
    }
}
