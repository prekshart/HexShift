import Foundation

/// User-facing errors. Messages follow the HEXSHIFT copy guidelines:
/// say what happened, never pretend something succeeded.
public enum HexError: LocalizedError, Sendable {
    case unsupportedConversion(from: String, to: String)
    case unreadable(String)
    case writeFailed(String)
    case invalidOutput(String)
    case missingTool(name: String, hint: String)
    case permissionMissing(String)
    case noSubjectFound
    case noTextFound
    case cancelled
    case wouldOverwriteOriginal
    case message(String)

    public var errorDescription: String? {
        switch self {
        case let .unsupportedConversion(from, to):
            return "\(from) cannot currently be exported directly as \(to). Choose one of the available formats instead."
        case let .unreadable(name):
            return "“\(name)” could not be read. It may be damaged, protected, or in an unsupported variant of its format."
        case let .writeFailed(detail):
            return "The output file could not be written. \(detail)"
        case let .invalidOutput(detail):
            return "The conversion did not produce a valid file, so nothing was saved. \(detail)"
        case let .missingTool(name, hint):
            return "This conversion needs \(name), which isn't installed. \(hint)"
        case let .permissionMissing(what):
            return "\(what) permission is required for this action."
        case .noSubjectFound:
            return "No clear foreground subject was found in this image."
        case .noTextFound:
            return "No readable text was found."
        case .cancelled:
            return "Cancelled."
        case .wouldOverwriteOriginal:
            return "HEXSHIFT never overwrites the original file without confirmation."
        case let .message(text):
            return text
        }
    }
}
