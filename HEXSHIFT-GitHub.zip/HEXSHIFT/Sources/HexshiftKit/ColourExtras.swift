import Foundation

// MARK: - Perceptual spaces, APCA, generated palettes and colour-vision simulation

extension ColourMath {
    @inline(__always) static func linear(_ v: Double) -> Double { v <= 0.04045 ? v / 12.92 : pow((v + 0.055) / 1.055, 2.4) }
    @inline(__always) static func gamma(_ v: Double) -> Double { v <= 0.0031308 ? 12.92 * v : 1.055 * pow(v, 1 / 2.4) - 0.055 }
    @inline(__always) static func clamp01(_ v: Double) -> Double { min(1, max(0, v)) }

    public static func labString(_ c: RGBAColour) -> String {
        let v = lab(c)
        return String(format: "lab(%.1f%% %.1f %.1f)", v.l, v.a, v.b)
    }

    // MARK: OKLab / OKLCH (Björn Ottosson, 2020)

    public struct OKLCH: Sendable, Equatable {
        public var l: Double   // 0...1
        public var c: Double   // 0...~0.4
        public var h: Double   // degrees
        public init(l: Double, c: Double, h: Double) { self.l = l; self.c = c; self.h = h }
    }

    public static func oklab(_ col: RGBAColour) -> (l: Double, a: Double, b: Double) {
        let r = linear(col.r), g = linear(col.g), b = linear(col.b)
        let l = cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b)
        let m = cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b)
        let s = cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b)
        return (0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
                1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
                0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s)
    }

    public static func fromOKLab(l L: Double, a: Double, b: Double, alpha: Double = 1) -> RGBAColour {
        let l_ = L + 0.3963377774 * a + 0.2158037573 * b
        let m_ = L - 0.1055613458 * a - 0.0638541728 * b
        let s_ = L - 0.0894841775 * a - 1.2914855480 * b
        let l = l_ * l_ * l_, m = m_ * m_ * m_, s = s_ * s_ * s_
        let r = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
        let g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
        let bb = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
        return RGBAColour(r: clamp01(gamma(r)), g: clamp01(gamma(g)), b: clamp01(gamma(bb)), a: alpha)
    }

    public static func oklch(_ c: RGBAColour) -> OKLCH {
        let v = oklab(c)
        let chroma = (v.a * v.a + v.b * v.b).squareRoot()
        var hue = atan2(v.b, v.a) * 180 / .pi
        if hue < 0 { hue += 360 }
        return OKLCH(l: v.l, c: chroma, h: chroma < 0.0001 ? 0 : hue)
    }

    public static func fromOKLCH(_ v: OKLCH, alpha: Double = 1) -> RGBAColour {
        let rad = v.h * .pi / 180
        return fromOKLab(l: v.l, a: v.c * cos(rad), b: v.c * sin(rad), alpha: alpha)
    }

    public static func oklchString(_ c: RGBAColour) -> String {
        let v = oklch(c)
        return String(format: "oklch(%.1f%% %.3f %.1f)", v.l * 100, v.c, v.h)
    }

    // MARK: APCA (WCAG 3 draft contrast, APCA-W3 0.0.98G)

    /// Lightness contrast Lc, roughly −108…106. Positive = dark text on light background.
    /// |Lc| ≥ 75 suits body text, ≥ 60 content text, ≥ 45 large/bold headlines, ≥ 30 non-text UI.
    public static func apcaContrast(text: RGBAColour, background: RGBAColour) -> Double {
        func y(_ c: RGBAColour) -> Double {
            0.2126729 * pow(c.r, 2.4) + 0.7151522 * pow(c.g, 2.4) + 0.0721750 * pow(c.b, 2.4)
        }
        func clampBlack(_ v: Double) -> Double { v < 0.022 ? v + pow(0.022 - v, 1.414) : v }
        let ys = clampBlack(y(text)), yb = clampBlack(y(background))
        guard abs(yb - ys) >= 0.0005 else { return 0 }
        if yb > ys {
            let sapc = (pow(yb, 0.56) - pow(ys, 0.57)) * 1.14
            return sapc < 0.1 ? 0 : (sapc - 0.027) * 100
        } else {
            let sapc = (pow(yb, 0.65) - pow(ys, 0.62)) * 1.14
            return sapc > -0.1 ? 0 : (sapc + 0.027) * 100
        }
    }

    public static func apcaRating(_ lc: Double) -> String {
        switch abs(lc) {
        case 90...: return "Excellent for any text"
        case 75..<90: return "Good for body text"
        case 60..<75: return "OK for content text, 16 px+"
        case 45..<60: return "Headlines and large text only"
        case 30..<45: return "Non-text UI and placeholders only"
        default: return "Too low for text"
        }
    }

    // MARK: Generated palettes

    public enum Harmony: String, CaseIterable, Sendable {
        case complementary, analogous, triadic, splitComplementary, tetradic
        public var title: String {
            switch self {
            case .complementary: return "Complementary"
            case .analogous: return "Analogous"
            case .triadic: return "Triadic"
            case .splitComplementary: return "Split complementary"
            case .tetradic: return "Tetradic"
            }
        }
        var offsets: [Double] {
            switch self {
            case .complementary: return [0, 180]
            case .analogous: return [-30, 0, 30]
            case .triadic: return [0, 120, 240]
            case .splitComplementary: return [0, 150, 210]
            case .tetradic: return [0, 90, 180, 270]
            }
        }
    }

    /// Hue rotations done in OKLCH, so lightness and chroma stay perceptually even.
    public static func harmony(_ kind: Harmony, of base: RGBAColour) -> [RGBAColour] {
        let v = oklch(base)
        return kind.offsets.map { offset in
            if offset == 0 { return base }
            var w = v
            w.h = (v.h + offset).truncatingRemainder(dividingBy: 360)
            if w.h < 0 { w.h += 360 }
            return fitInGamut(w, alpha: base.a)
        }
    }

    /// Reduces chroma until the colour fits in sRGB (keeps hue and lightness).
    public static func fitInGamut(_ v: OKLCH, alpha: Double = 1) -> RGBAColour {
        var w = v
        for _ in 0..<24 {
            let rad = w.h * .pi / 180
            let a = w.c * cos(rad), b = w.c * sin(rad)
            let l_ = w.l + 0.3963377774 * a + 0.2158037573 * b
            let m_ = w.l - 0.1055613458 * a - 0.0638541728 * b
            let s_ = w.l - 0.0894841775 * a - 1.2914855480 * b
            let l = l_ * l_ * l_, m = m_ * m_ * m_, s = s_ * s_ * s_
            let r = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
            let g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
            let bb = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
            if [r, g, bb].allSatisfy({ $0 >= -0.0005 && $0 <= 1.0005 }) { break }
            w.c *= 0.9
        }
        return fromOKLCH(w, alpha: alpha)
    }

    /// An 11-step scale (50, 100…900, 950) built in OKLCH — the base colour sits at its natural step.
    public static func tonalScale(_ base: RGBAColour) -> [(step: Int, colour: RGBAColour)] {
        let steps = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950]
        let lightness: [Double] = [0.97, 0.93, 0.87, 0.79, 0.70, 0.62, 0.54, 0.46, 0.38, 0.30, 0.22]
        let v = oklch(base)
        // Which step is closest to the base colour? Keep it exact.
        let nearest = lightness.enumerated().min { abs($0.element - v.l) < abs($1.element - v.l) }?.offset ?? 5
        return steps.enumerated().map { i, step in
            if i == nearest { return (step, base) }
            // Chroma tapers towards the very light and very dark ends.
            let t = lightness[i]
            let taper = 1 - pow(abs(t - 0.6) / 0.45, 2) * 0.65
            let w = OKLCH(l: t, c: v.c * max(0.2, taper), h: v.h)
            return (step, fitInGamut(w, alpha: 1))
        }
    }

    /// Simple tints (towards white) and shades (towards black), mixed in OKLab.
    public static func tintsAndShades(_ base: RGBAColour, count: Int = 4) -> (tints: [RGBAColour], shades: [RGBAColour]) {
        let o = oklab(base)
        func mix(_ target: (Double, Double, Double), _ t: Double) -> RGBAColour {
            fromOKLab(l: o.l + (target.0 - o.l) * t, a: o.a + (target.1 - o.a) * t, b: o.b + (target.2 - o.b) * t)
        }
        guard count > 0 else { return ([], []) }
        let n = Double(count + 1)
        let tints = (1...count).map { mix((1, 0, 0), Double($0) / n) }
        let shades = (1...count).map { mix((0, 0, 0), Double($0) / n) }
        return (tints, shades)
    }

    // MARK: Colour-vision deficiency simulation (Machado, Oliveira & Fernandes 2009, severity 1.0)

    public enum VisionDeficiency: String, CaseIterable, Sendable {
        case protanopia, deuteranopia, tritanopia, achromatopsia
        public var title: String {
            switch self {
            case .protanopia: return "Protanopia (no red cones)"
            case .deuteranopia: return "Deuteranopia (no green cones)"
            case .tritanopia: return "Tritanopia (no blue cones)"
            case .achromatopsia: return "Achromatopsia (no colour)"
            }
        }
        public var shortTitle: String {
            switch self {
            case .protanopia: return "Protan"
            case .deuteranopia: return "Deutan"
            case .tritanopia: return "Tritan"
            case .achromatopsia: return "Mono"
            }
        }
        var matrix: [Double] {
            switch self {
            case .protanopia: return [0.152286, 1.052583, -0.204868, 0.114503, 0.786281, 0.099216, -0.003882, -0.048116, 1.051998]
            case .deuteranopia: return [0.367322, 0.860646, -0.227968, 0.280085, 0.672501, 0.047413, -0.011820, 0.042940, 0.968881]
            case .tritanopia: return [1.255528, -0.076749, -0.178779, -0.078411, 0.930809, 0.147602, 0.004733, 0.691367, 0.303900]
            case .achromatopsia: return [0.2126, 0.7152, 0.0722, 0.2126, 0.7152, 0.0722, 0.2126, 0.7152, 0.0722]
            }
        }
    }

    public static func simulate(_ c: RGBAColour, _ kind: VisionDeficiency) -> RGBAColour {
        let r = linear(c.r), g = linear(c.g), b = linear(c.b)
        let m = kind.matrix
        let nr = m[0] * r + m[1] * g + m[2] * b
        let ng = m[3] * r + m[4] * g + m[5] * b
        let nb = m[6] * r + m[7] * g + m[8] * b
        return RGBAColour(r: clamp01(gamma(clamp01(nr))), g: clamp01(gamma(clamp01(ng))), b: clamp01(gamma(clamp01(nb))), a: c.a)
    }
}

// MARK: - More palette exports

extension PaletteExporter {
    /// `tailwind.config.js` colours block. A single base colour also gets a 50–950 scale.
    public static func tailwindConfig(_ colours: [(name: String, colour: RGBAColour)], includeScales: Bool = true) -> String {
        var lines = ["// tailwind.config.js", "module.exports = {", "  theme: {", "    extend: {", "      colors: {"]
        for (i, c) in colours.enumerated() {
            let key = slug(c.name.isEmpty ? "colour-\(i + 1)" : c.name)
            if includeScales {
                lines.append("        '\(key)': {")
                for (step, colour) in ColourMath.tonalScale(c.colour) {
                    lines.append("          \(step): '\(colour.hex)',")
                }
                lines.append("          DEFAULT: '\(c.colour.hex)',")
                lines.append("        },")
            } else {
                lines.append("        '\(key)': '\(c.colour.hex)',")
            }
        }
        lines += ["      },", "    },", "  },", "};"]
        return lines.joined(separator: "\n") + "\n"
    }

    /// A SwiftUI `Color` extension.
    public static func swiftUIExtension(_ colours: [(name: String, colour: RGBAColour)]) -> String {
        var lines = ["import SwiftUI", "", "extension Color {"]
        for (i, c) in colours.enumerated() {
            let words = slug(c.name.isEmpty ? "colour-\(i + 1)" : c.name).split(separator: "-")
            var ident = words.enumerated().map { $0.offset == 0 ? String($0.element) : $0.element.capitalized }.joined()
            if let f = ident.first, f.isNumber { ident = "c" + ident }
            lines.append(String(format: "    static let %@ = Color(.sRGB, red: %.4f, green: %.4f, blue: %.4f, opacity: %.3f) // %@",
                                ident, c.colour.r, c.colour.g, c.colour.b, c.colour.a, c.colour.hex))
        }
        lines.append("}")
        return lines.joined(separator: "\n") + "\n"
    }

    /// GIMP / Inkscape / Krita palette (.gpl).
    public static func gimpPalette(_ colours: [(name: String, colour: RGBAColour)], title: String = "HEXSHIFT") -> String {
        var lines = ["GIMP Palette", "Name: \(title)", "Columns: \(min(8, max(1, colours.count)))", "#"]
        for (i, c) in colours.enumerated() {
            let (r, g, b) = ColourMath.rgb255(c.colour)
            lines.append(String(format: "%3ld %3ld %3ld\t%@", r, g, b, c.name.isEmpty ? "Colour \(i + 1)" : c.name))
        }
        return lines.joined(separator: "\n") + "\n"
    }

    /// Adobe Swatch Exchange (.ase), readable by Photoshop, Illustrator, InDesign, Affinity and Procreate.
    public static func aseData(_ colours: [(name: String, colour: RGBAColour)]) -> Data {
        var d = Data()
        func u16(_ v: UInt16) { var be = v.bigEndian; d.append(Data(bytes: &be, count: 2)) }
        func u32(_ v: UInt32) { var be = v.bigEndian; d.append(Data(bytes: &be, count: 4)) }
        func f32(_ v: Float) { var be = v.bitPattern.bigEndian; d.append(Data(bytes: &be, count: 4)) }
        d.append(contentsOf: Array("ASEF".utf8))
        u16(1); u16(0)
        u32(UInt32(colours.count))
        for (i, c) in colours.enumerated() {
            let name = c.name.isEmpty ? c.colour.hex : c.name
            let utf16 = Array(name.utf16) + [0]
            // Block body: name length (UInt16, in UTF-16 units incl. terminator), name, model, values, type.
            let bodyLength = 2 + utf16.count * 2 + 4 + 12 + 2
            u16(0x0001)
            u32(UInt32(bodyLength))
            u16(UInt16(utf16.count))
            for unit in utf16 { u16(unit) }
            d.append(contentsOf: Array("RGB ".utf8))
            f32(Float(c.colour.r)); f32(Float(c.colour.g)); f32(Float(c.colour.b))
            u16(2) // normal (not global/spot)
            _ = i
        }
        return d
    }
}
