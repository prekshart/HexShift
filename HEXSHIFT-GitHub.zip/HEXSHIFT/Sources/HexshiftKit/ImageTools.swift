import CoreGraphics
import Foundation
import ImageIO

/// Size-targeted compression for images.
public enum ImageCompressor {
    public struct Result: Sendable {
        public let url: URL
        public let before: Int64
        public let after: Int64
        public let quality: Double
        public var saving: Double { before > 0 ? 1 - Double(after) / Double(before) : 0 }
    }

    /// Picks a sensible lossy format for the source (keeps transparency when present).
    public static func defaultFormat(for asset: AssetInfo) -> Format {
        if let f = asset.format, f.isLossy, ImageEncoder.canWrite(f) { return f }
        return (asset.hasAlpha ?? false) ? .webp : .jpeg
    }

    /// Binary-searches the quality that lands just under `targetBytes`.
    public static func findQuality(_ image: CGImage, format: Format, targetBytes: Int) throws -> (quality: Double, data: Data) {
        var lo = 0.05, hi = 0.98
        var best: (Double, Data)?
        if let top = try? ImageEncoder.encodedData(image, format: format, quality: hi), top.count <= targetBytes {
            return (hi, top)
        }
        for _ in 0..<9 {
            try Task.checkCancellation()
            let mid = (lo + hi) / 2
            let data = try ImageEncoder.encodedData(image, format: format, quality: mid)
            if data.count <= targetBytes {
                best = (mid, data)
                lo = mid
            } else {
                hi = mid
            }
        }
        if let best { return best }
        let floor = try ImageEncoder.encodedData(image, format: format, quality: 0.05)
        return (0.05, floor)
    }

    public static func compress(_ asset: AssetInfo, format: Format? = nil, quality: Double = 0.75, targetBytes: Int? = nil,
                                maxPixelSize: Int? = nil, metadata: MetadataPolicy = .stripGPS, planner: OutputPlanner) throws -> Result {
        let loaded = try ImageLoader.load(asset.url)
        var image = ImageOps.limit(loaded.image, maxPixelSize: maxPixelSize)
        let fmt = format ?? defaultFormat(for: asset)
        if !fmt.supportsAlpha { image = ImageOps.flatten(image) }
        var q = quality
        if let target = targetBytes {
            q = try findQuality(image, format: fmt, targetBytes: target).quality
        }
        var opts = ImageExportOptions()
        opts.quality = q
        opts.metadata = metadata
        let dest = planner.url(for: asset.url, ext: fmt.fileExtension, format: fmt.displayName, pixelSize: (image.width, image.height))
        try ImageEncoder.write(image, sourceProperties: loaded.properties, format: fmt, to: dest, options: opts)
        let after = PDFEngine.fileSize(dest)
        return Result(url: dest, before: asset.fileSize, after: after, quality: q)
    }

    /// Quick estimate for the UI (encodes a downscaled copy and extrapolates).
    public static func estimate(_ image: CGImage, format: Format, quality: Double) -> Int? {
        let maxSide = 1200
        let scaled = ImageOps.limit(image, maxPixelSize: maxSide)
        guard let data = try? ImageEncoder.encodedData(scaled, format: format, quality: quality) else { return nil }
        let factor = Double(image.width * image.height) / Double(max(1, scaled.width * scaled.height))
        return Int(Double(data.count) * factor)
    }
}

/// One-step image edits that always write a new file.
public enum QuickImageEdits {
    public static func rotate(_ asset: AssetInfo, clockwise: Bool, planner: OutputPlanner) throws -> URL {
        let loaded = try ImageLoader.load(asset.url)
        let rotated = ImageOps.rotate90(loaded.image, clockwise: clockwise)
        let fmt = writableFormat(for: asset)
        let dest = planner.url(for: asset.url, ext: fmt.fileExtension, format: fmt.displayName, pixelSize: (rotated.width, rotated.height))
        var opts = ImageExportOptions()
        opts.metadata = .preserve
        opts.quality = 0.92
        try ImageEncoder.write(rotated, sourceProperties: loaded.properties, format: fmt, to: dest, options: opts)
        return dest
    }

    public static func flip(_ asset: AssetInfo, horizontal: Bool, planner: OutputPlanner) throws -> URL {
        let loaded = try ImageLoader.load(asset.url)
        let flipped = ImageOps.flip(loaded.image, horizontal: horizontal)
        let fmt = writableFormat(for: asset)
        let dest = planner.url(for: asset.url, ext: fmt.fileExtension, format: fmt.displayName)
        var opts = ImageExportOptions()
        opts.metadata = .preserve
        opts.quality = 0.92
        try ImageEncoder.write(flipped, sourceProperties: loaded.properties, format: fmt, to: dest, options: opts)
        return dest
    }

    /// Removes metadata without re-encoding when ImageIO allows it (lossless), else re-encodes.
    public static func stripMetadata(_ asset: AssetInfo, gpsOnly: Bool, planner: OutputPlanner) throws -> URL {
        let fmt = asset.format ?? .png
        let dest = planner.url(for: asset.url, ext: (asset.format ?? .png).fileExtension, format: fmt.displayName)
        try FileWriter.writeAtomically(to: dest) { tmp in
            guard let src = CGImageSourceCreateWithURL(asset.url as CFURL, nil), let type = CGImageSourceGetType(src),
                  let destRef = CGImageDestinationCreateWithURL(tmp as CFURL, type, 1, nil) else {
                throw HexError.unreadable(asset.name)
            }
            var options: [CFString: Any] = [kCGImageMetadataShouldExcludeGPS: true]
            if !gpsOnly {
                let empty = CGImageMetadataCreateMutable()
                // Keep orientation so the picture doesn't rotate.
                if let o = asset.orientation, o != 1 {
                    CGImageMetadataSetValueMatchingImageProperty(empty, kCGImagePropertyTIFFDictionary, kCGImagePropertyTIFFOrientation, NSNumber(value: o))
                }
                options[kCGImageDestinationMetadata] = empty
                options[kCGImageDestinationMergeMetadata] = false
                options[kCGImageMetadataShouldExcludeXMP] = true
            }
            var error: Unmanaged<CFError>?
            if !CGImageDestinationCopyImageSource(destRef, src, options as CFDictionary, &error) {
                // Formats that can't be copied losslessly: re-encode instead.
                try? FileManager.default.removeItem(at: tmp)
                let loaded = try ImageLoader.load(asset.url)
                var o = ImageExportOptions()
                o.metadata = gpsOnly ? .stripGPS : .stripAll
                o.quality = 0.95
                guard ImageEncoder.canWrite(fmt) else { throw HexError.unsupportedConversion(from: fmt.displayName, to: fmt.displayName) }
                switch fmt {
                case .webp:
                    try ImageEncoder.encodeWebP(loaded.image, quality: 0.95, lossless: false).write(to: tmp)
                default:
                    guard let t = fmt.imageIOType else { throw HexError.unsupportedConversion(from: fmt.displayName, to: fmt.displayName) }
                    let props = ImageEncoder.destinationProperties(source: loaded.properties, format: fmt, options: o)
                    try ImageEncoder.writeImageIO([(loaded.image, props)], type: t, to: tmp)
                }
            }
            try ImageEncoder.validate(tmp, format: fmt)
        }
        return dest
    }

    static func writableFormat(for asset: AssetInfo) -> Format {
        if let f = asset.format, ImageEncoder.canWrite(f), f != .pdf, f != .svg { return f }
        return .png
    }

    /// Exports scale variants (@1x, @1.5x, @2x, @3x, @4x…), treating the source image as `sourceScale`.
    /// Raster sources are never upscaled; SVGs render sharply at any scale.
    public static func exportScales(_ asset: AssetInfo, scales: [Double], sourceScale: Double, planner: OutputPlanner,
                                    format: Format? = nil, matte: RGBAColour = .white) async throws -> [URL] {
        var outputs: [URL] = []
        let fmt: Format = format ?? (asset.format == .svg ? .png : writableFormat(for: asset))
        var options = ImageExportOptions()
        options.matte = matte
        let base: CGImage? = asset.format == .svg ? nil : try ImageLoader.load(asset.url).image
        for s in Set(scales).sorted() where s > 0 {
            try Task.checkCancellation()
            let image: CGImage
            if let base {
                guard s <= sourceScale + 0.0001 else { continue }
                let factor = s / max(0.01, sourceScale)
                image = abs(factor - 1) < 0.0001 ? base : ImageOps.resize(base, to: CGSize(width: Double(base.width) * factor, height: Double(base.height) * factor))
            } else {
                image = try await SVGSupport.render(asset.url, scale: s)
            }
            let suffix = abs(s - 1) < 0.0001 ? "" : "@\(scaleLabel(s))x"
            let dir = planner.folder(for: asset.url)
            let dest = OutputPlanner.unique(dir.appendingPathComponent(asset.baseName + suffix).appendingPathExtension(fmt.fileExtension), avoiding: asset.url)
            try ImageEncoder.write(image, format: fmt, to: dest, options: options)
            outputs.append(dest)
        }
        return outputs
    }

    /// 1 → "1", 1.5 → "1.5", 0.75 → "0.75"
    public static func scaleLabel(_ s: Double) -> String {
        s.formatted(.number.locale(Locale(identifier: "en_US_POSIX")).precision(.fractionLength(0...2)).grouping(.never))
    }

    /// Parses "1, 1.5, 2x, @3x" into scales.
    public static func parseScales(_ text: String) -> [Double] {
        text.split(whereSeparator: { $0 == "," || $0 == " " || $0 == ";" })
            .compactMap { Double($0.trimmingCharacters(in: CharacterSet(charactersIn: "@xX ")).replacingOccurrences(of: ",", with: ".")) }
            .filter { $0 > 0 && $0 <= 16 }
    }
}

/// A visual "design reference" board: capture, palette, font candidates, text.
public enum DesignReference {
    public static func board(capture: CGImage, palette: [PaletteColour], fonts: [FontCandidate], text: String?) -> CGImage? {
        let W = 1800
        let previewMaxH = 900.0
        let scale = min(1.0, min(Double(W - 160) / Double(capture.width), previewMaxH / Double(capture.height)))
        let pw = Double(capture.width) * scale, ph = Double(capture.height) * scale
        let fontRows = min(fonts.count, 5)
        let H = Int(ph) + 640 + fontRows * 90
        guard let ctx = ImageOps.makeContext(width: W, height: H, opaque: true) else { return nil }
        let bg = RGBAColour(r: 0.98, g: 0.97, b: 0.95)
        let ink = RGBAColour(r: 0.15, g: 0.14, b: 0.13)
        let grey = RGBAColour(r: 0.45, g: 0.43, b: 0.40)
        ctx.setFillColor(bg.cgColor)
        ctx.fill(CGRect(x: 0, y: 0, width: W, height: H))
        var y = Double(H) - 110
        TextDrawing.draw("Design reference", in: ctx, at: CGPoint(x: 80, y: y), fontSize: 54, colour: ink, bold: true)
        let f = DateFormatter()
        f.dateStyle = .medium
        f.timeStyle = .short
        TextDrawing.draw("Captured with HEXSHIFT · \(f.string(from: Date()))", in: ctx, at: CGPoint(x: 82, y: y - 44), fontSize: 22, colour: grey, bold: false)
        y -= 80
        let imgRect = CGRect(x: 80, y: y - ph, width: pw, height: ph)
        ctx.interpolationQuality = .high
        ctx.draw(capture, in: imgRect)
        ctx.setStrokeColor(RGBAColour(r: 0, g: 0, b: 0, a: 0.12).cgColor)
        ctx.stroke(imgRect, width: 1)
        y = Double(imgRect.minY) - 70
        TextDrawing.draw("Palette", in: ctx, at: CGPoint(x: 80, y: y), fontSize: 28, colour: ink, bold: true)
        y -= 150
        for (i, c) in palette.prefix(8).enumerated() {
            let x = 80 + i * 200
            let r = CGRect(x: x, y: Int(y), width: 170, height: 110)
            ctx.addPath(CGPath(roundedRect: r, cornerWidth: 16, cornerHeight: 16, transform: nil))
            ctx.setFillColor(c.colour.cgColor)
            ctx.fillPath()
            TextDrawing.draw(c.colour.hex, in: ctx, at: CGPoint(x: x, y: Int(y) - 32), fontSize: 22, colour: ink, bold: true)
            TextDrawing.draw("\(Int((c.weight * 100).rounded()))%", in: ctx, at: CGPoint(x: x + 120, y: Int(y) - 32), fontSize: 18, colour: grey, bold: false)
        }
        y -= 110
        if fontRows > 0 {
            TextDrawing.draw("Similar fonts (estimated from pixels)", in: ctx, at: CGPoint(x: 80, y: y), fontSize: 28, colour: ink, bold: true)
            y -= 70
            let sample = (text?.split(separator: "\n").first.map(String.init) ?? "Sphinx of black quartz").prefix(40)
            for c in fonts.prefix(fontRows) {
                if c.isInstalled {
                    TextDrawing.draw(String(sample), in: ctx, at: CGPoint(x: 80, y: y), fontSize: 40, colour: ink, bold: false, fontName: c.postScriptName)
                } else if let preview = FontMatcher.referencePreview(text: String(sample), candidate: c, emPixels: 40, asMask: true) {
                    let r = CGRect(x: 80, y: Double(y) - 12, width: Double(preview.width), height: Double(preview.height))
                    ctx.saveGState()
                    ctx.clip(to: r, mask: preview)
                    ctx.setFillColor(ink.cgColor)
                    ctx.fill(r)
                    ctx.restoreGState()
                }
                TextDrawing.draw("\(c.familyName) \(c.styleName)\(c.isInstalled ? "" : " (Google Fonts)") · ≈\(Int((c.similarity * 100).rounded()))%", in: ctx, at: CGPoint(x: 1100, y: y + 8), fontSize: 22, colour: grey, bold: false)
                y -= 90
            }
        }
        return ctx.makeImage()
    }
}
