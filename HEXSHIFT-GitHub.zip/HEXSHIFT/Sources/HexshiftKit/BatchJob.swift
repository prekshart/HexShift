import Combine
import Foundation

public struct BatchFailure: Identifiable, Hashable, Sendable {
    public let id = UUID()
    public let item: URL
    public let message: String
}

/// A bounded background queue that processes many files, reporting progress,
/// per-file errors and supporting cancellation. Originals are never modified.
@MainActor
public final class BatchJob: ObservableObject, Identifiable {
    public let id = UUID()
    public let title: String
    public let total: Int
    public let startedAt = Date()

    @Published public private(set) var completed = 0
    @Published public private(set) var failures: [BatchFailure] = []
    @Published public private(set) var outputs: [URL] = []
    @Published public private(set) var isFinished = false
    @Published public private(set) var isCancelled = false
    @Published public private(set) var currentItem: String?

    public var succeeded: Int { completed - failures.count }
    public var fractionComplete: Double { total == 0 ? 1 : Double(completed) / Double(total) }

    /// Called once on the main actor when the job ends (finished or cancelled).
    public var onFinish: ((BatchJob) -> Void)?

    private var task: Task<Void, Never>?

    public typealias Operation = @Sendable (URL) async throws -> [URL]

    public init(title: String, items: [URL], concurrency: Int = 0, operation: @escaping Operation) {
        self.title = title
        self.total = items.count
        let limit = concurrency > 0 ? concurrency : max(1, min(4, ProcessInfo.processInfo.activeProcessorCount / 2))
        task = Task { [weak self] in
            await self?.run(items: items, limit: limit, operation: operation)
        }
    }

    public func cancel() {
        guard !isFinished else { return }
        isCancelled = true
        task?.cancel()
    }

    /// Waits until the job is done (used by the command-line tool and tests).
    public func wait() async {
        await task?.value
    }

    /// "37 of 40 files converted successfully."
    public var summary: String {
        let noun = total == 1 ? "file" : "files"
        if isCancelled { return "Cancelled — \(succeeded) of \(total) \(noun) converted." }
        if failures.isEmpty { return total == 1 ? "Converted successfully." : "All \(total) \(noun) converted successfully." }
        return "\(succeeded) of \(total) \(noun) converted successfully."
    }

    private struct ItemResult: Sendable {
        let item: URL
        let outputs: [URL]
        let error: String?
    }

    nonisolated private static func process(_ item: URL, _ operation: Operation) async -> ItemResult {
        if Task.isCancelled { return ItemResult(item: item, outputs: [], error: HexError.cancelled.localizedDescription) }
        do {
            let out = try await operation(item)
            return ItemResult(item: item, outputs: out, error: nil)
        } catch is CancellationError {
            return ItemResult(item: item, outputs: [], error: HexError.cancelled.localizedDescription)
        } catch {
            let message = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            return ItemResult(item: item, outputs: [], error: message)
        }
    }

    private func run(items: [URL], limit: Int, operation: @escaping Operation) async {
        await withTaskGroup(of: ItemResult.self) { group in
            var next = 0
            while next < items.count && next < limit {
                let item = items[next]
                next += 1
                group.addTask { await BatchJob.process(item, operation) }
            }
            while let result = await group.next() {
                record(result)
                if !Task.isCancelled && !isCancelled && next < items.count {
                    let item = items[next]
                    next += 1
                    currentItem = item.lastPathComponent
                    group.addTask { await BatchJob.process(item, operation) }
                }
            }
        }
        currentItem = nil
        isFinished = true
        onFinish?(self)
    }

    private func record(_ result: ItemResult) {
        completed += 1
        outputs.append(contentsOf: result.outputs)
        if let message = result.error {
            failures.append(BatchFailure(item: result.item, message: message))
        }
    }
}
