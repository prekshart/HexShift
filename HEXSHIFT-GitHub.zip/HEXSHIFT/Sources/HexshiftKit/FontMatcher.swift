import AppKit
import CoreGraphics
import CoreText
import Foundation

public enum FontCategory: String, Codable, Sendable {
    case serif, sansSerif, monospace, script, display, symbol, unknown

    public var title: String {
        switch self {
        case .serif: return "Serif"
        case .sansSerif: return "Sans-serif"
        case .monospace: return "Monospaced"
        case .script: return "Script"
        case .display: return "Display"
        case .symbol: return "Symbol"
        case .unknown: return "Other"
        }
    }

    public var cssGeneric: String {
        switch self {
        case .serif: return "serif"
        case .monospace: return "monospace"
        case .script: return "cursive"
        default: return "sans-serif"
        }
    }
}

/// Everything HEXSHIFT can tell about an installed font, straight from the font file.
public struct FontDetails: Hashable, Sendable {
    public let postScriptName: String
    public let familyName: String
    public let fullName: String
    public let styleName: String
    public let cssWeight: Int
    public let isItalic: Bool
    public let category: FontCategory
    public let isInstalled: Bool
    public let availableStyles: [String]
    public let designer: String?
    public let manufacturer: String?
    public let vendorURL: String?
    public let designerURL: String?
    public let licence: String?
    public let licenceURL: String?
    public let copyright: String?
    public let version: String?
    public let fileURL: URL?

    /// Best official source we can point to.
    public var sourceURL: URL? {
        if let v = vendorURL, let u = URL(string: v.hasPrefix("http") ? v : "https://" + v) { return u }
        if let d = designerURL, let u = URL(string: d.hasPrefix("http") ? d : "https://" + d) { return u }
        if fileURL?.path.hasPrefix("/System/Library/Fonts") == true, familyName.hasPrefix("SF") || familyName == "New York" {
            return URL(string: "https://developer.apple.com/fonts/")
        }
        return nil
    }

    public var licenceSummary: String {
        if let l = licence, !l.isEmpty { return l.count > 220 ? String(l.prefix(220)) + "…" : l }
        if fileURL?.path.hasPrefix("/System/Library") == true { return "Bundled with macOS — check Apple's licence before using it outside Apple platforms." }
        return "No licence information is stored in this font file."
    }
}

public struct FontCandidate: Identifiable, Hashable, Sendable {
    public var id: String { postScriptName }
    public let postScriptName: String
    public let familyName: String
    public let displayName: String
    public let styleName: String
    public let cssWeight: Int
    public let isItalic: Bool
    public let category: FontCategory
    /// 0...1 — approximate visual similarity, never a confirmation.
    public let similarity: Double
    /// Where the match comes from: installed on this Mac, or the bundled Google Fonts reference.
    public let source: FontSource

    public init(postScriptName: String, familyName: String, displayName: String, styleName: String, cssWeight: Int,
                isItalic: Bool, category: FontCategory, similarity: Double, source: FontSource) {
        self.postScriptName = postScriptName
        self.familyName = familyName
        self.displayName = displayName
        self.styleName = styleName
        self.cssWeight = cssWeight
        self.isItalic = isItalic
        self.category = category
        self.similarity = similarity
        self.source = source
    }

    public var isInstalled: Bool { source == .installed }
    public var googleFontsURL: URL? {
        if case let .googleFonts(slug) = source { return URL(string: "https://fonts.google.com/specimen/\(slug)") }
        return nil
    }
}

public enum FontSource: Hashable, Sendable {
    case installed
    case googleFonts(slug: String)
}

public struct TextSample: @unchecked Sendable {
    public let text: String
    /// Crop of the original capture around the line (for display).
    public let crop: CGImage
    /// Line box in capture pixels (top-left origin).
    public let rect: CGRect
    let prepared: MatchEngine.Sample
}

public struct FontMatchReport: Sendable {
    public let recognisedText: String
    public let lines: [String]
    public let sample: TextSample
    public let candidates: [FontCandidate]
    public let alignment: String?
    public let lineHeightRatio: Double?
    public let approxTextHeightPx: Double
    public let isLightOnDark: Bool
}

/// Identifies typefaces from pixels by rendering the recognised text in every
/// installed font and comparing shapes. Results are probabilistic and are always
/// presented as "visually similar", never as an exact match.
public enum FontMatcher {
    static let normHeight = 48

    static let excludedFamilyFragments = ["emoji", "symbol", "dingbat", "wingding", "webdings", "lastresort",
                                          "ornaments", "bodoni ornaments", "zapf dingbats", "apple braille", "noto sans symbols"]

    // MARK: Public API

    public static func analyse(image: CGImage, overrideText: String? = nil, limit: Int = 8,
                               allFaces: Bool = true, families: [String]? = nil,
                               progress: ((Double) -> Void)? = nil) throws -> FontMatchReport {
        let ocr = try OCRService.recognize(image)
        guard !ocr.lines.isEmpty else { throw HexError.noTextFound }
        // Use the longest line — more glyphs, better evidence.
        let best = ocr.lines.max { $0.text.count < $1.text.count }!
        let text = (overrideText?.trimmingCharacters(in: .whitespacesAndNewlines)).flatMap { $0.isEmpty ? nil : $0 } ?? best.text
        let rect = ocr.pixelRect(for: best)
        guard let (sample, lightOnDark) = makeSample(from: image, rect: rect, text: text) else { throw HexError.noTextFound }
        let candidates = rank(sample: sample, limit: limit, allFaces: allFaces, families: families, progress: progress)
        let (alignment, ratio) = layoutEstimate(ocr)
        return FontMatchReport(recognisedText: ocr.text, lines: ocr.lines.map(\.text), sample: sample, candidates: candidates,
                               alignment: alignment, lineHeightRatio: ratio, approxTextHeightPx: Double(rect.height),
                               isLightOnDark: lightOnDark)
    }

    public static func details(forPostScriptName name: String) -> FontDetails? {
        let font = CTFontCreateWithName(name as CFString, 24, nil)
        let ps = CTFontCopyPostScriptName(font) as String
        // CoreText substitutes a fallback when the name doesn't exist.
        guard ps == name || (CTFontCopyFullName(font) as String) == name else { return nil }
        return details(of: font)
    }

    public static func details(forFamily family: String) -> FontDetails? {
        guard let members = NSFontManager.shared.availableMembers(ofFontFamily: family), let first = members.first,
              let ps = first.first as? String else { return nil }
        let italicMask = Int(NSFontTraitMask.italicFontMask.rawValue)
        let regular = members.first { m in
            m.count > 3 && (m[2] as? Int) == 5 && ((m[3] as? Int ?? 0) & italicMask) == 0
        }
        return details(forPostScriptName: (regular?.first as? String) ?? ps)
    }

    public static func details(of font: CTFont) -> FontDetails {
        func name(_ key: CFString) -> String? {
            guard let s = CTFontCopyName(font, key) as String?, !s.isEmpty else { return nil }
            return s
        }
        let family = CTFontCopyFamilyName(font) as String
        let styles = (NSFontManager.shared.availableMembers(ofFontFamily: family) ?? []).compactMap { $0.count > 1 ? $0[1] as? String : nil }
        let fileURL = CTFontCopyAttribute(font, kCTFontURLAttribute) as? URL
        let traits = CTFontGetSymbolicTraits(font)
        return FontDetails(
            postScriptName: CTFontCopyPostScriptName(font) as String,
            familyName: family,
            fullName: CTFontCopyFullName(font) as String,
            styleName: name(kCTFontStyleNameKey) ?? "Regular",
            cssWeight: cssWeight(of: font),
            isItalic: traits.contains(.traitItalic),
            category: category(of: font),
            isInstalled: true,
            availableStyles: styles,
            designer: name(kCTFontDesignerNameKey),
            manufacturer: name(kCTFontManufacturerNameKey),
            vendorURL: name(kCTFontVendorURLNameKey),
            designerURL: name(kCTFontDesignerURLNameKey),
            licence: name(kCTFontLicenseNameKey),
            licenceURL: name(kCTFontLicenseURLNameKey),
            copyright: name(kCTFontCopyrightNameKey),
            version: name(kCTFontVersionNameKey),
            fileURL: fileURL
        )
    }

    public static func category(of font: CTFont) -> FontCategory {
        let traits = CTFontGetSymbolicTraits(font)
        if traits.contains(.traitMonoSpace) { return .monospace }
        let cls = traits.rawValue & CTFontSymbolicTraits.traitClassMask.rawValue
        switch cls {
        case CTFontStylisticClass.classOldStyleSerifs.rawValue, CTFontStylisticClass.classTransitionalSerifs.rawValue,
             CTFontStylisticClass.classModernSerifs.rawValue, CTFontStylisticClass.classClarendonSerifs.rawValue,
             CTFontStylisticClass.classSlabSerifs.rawValue, CTFontStylisticClass.classFreeformSerifs.rawValue:
            return .serif
        case CTFontStylisticClass.classSansSerif.rawValue: return .sansSerif
        case CTFontStylisticClass.classScripts.rawValue: return .script
        case CTFontStylisticClass.classOrnamentals.rawValue: return .display
        case CTFontStylisticClass.classSymbolic.rawValue: return .symbol
        default: break
        }
        let n = (CTFontCopyFamilyName(font) as String).lowercased()
        if n.contains("mono") || n.contains("code") || n.contains("courier") || n.contains("menlo") { return .monospace }
        if n.contains("sans") || n.contains("grotesk") || n.contains("gothic") || n.contains("helvetica") || n.contains("arial") || n.contains("avenir") || n.contains("futura") || n.contains("inter") { return .sansSerif }
        if n.contains("serif") || n.contains("times") || n.contains("georgia") || n.contains("garamond") || n.contains("baskerville") || n.contains("caslon") || n.contains("didot") || n.contains("bodoni") || n.contains("palatino") { return .serif }
        if n.contains("script") || n.contains("hand") || n.contains("brush") || n.contains("chalk") || n.contains("snell") || n.contains("zapfino") { return .script }
        return .unknown
    }

    public static func cssWeight(of font: CTFont) -> Int {
        let traits = CTFontCopyTraits(font) as NSDictionary
        let w = (traits[kCTFontWeightTrait as String] as? NSNumber)?.doubleValue ?? 0
        switch w {
        case ..<(-0.6): return 100
        case ..<(-0.45): return 200
        case ..<(-0.2): return 300
        case ..<0.1: return 400
        case ..<0.27: return 500
        case ..<0.35: return 600
        case ..<0.5: return 700
        case ..<0.6: return 800
        default: return 900
        }
    }

    public static func cssDeclaration(family: String, weight: Int, italic: Bool, category: FontCategory,
                                      sizePx: Double? = nil, lineHeight: Double? = nil, letterSpacing: Double? = nil,
                                      colour: String? = nil) -> String {
        var lines = ["font-family: \"\(family)\", \(category.cssGeneric);", "font-weight: \(weight);"]
        if italic { lines.append("font-style: italic;") }
        if let s = sizePx { lines.append("font-size: \(Int(s.rounded()))px;") }
        if let lh = lineHeight { lines.append("line-height: \(String(format: "%.2f", lh));") }
        if let ls = letterSpacing { lines.append("letter-spacing: \(String(format: "%.2f", ls))em;") }
        if let c = colour { lines.append("color: \(c);") }
        return lines.joined(separator: "\n")
    }

    /// The same font as SwiftUI code. Uses the PostScript name when known so the exact face is used.
    public static func swiftUIDeclaration(family: String, postScriptName: String? = nil, weight: Int, italic: Bool, size: Double?) -> String {
        let pt = size.map { String(format: "%.0f", $0) } ?? "17"
        var line = ".font(.custom(\"\(postScriptName ?? family)\", size: \(pt)))"
        if postScriptName == nil {
            let w: String
            switch weight {
            case ..<150: w = ".ultraLight"
            case ..<250: w = ".thin"
            case ..<350: w = ".light"
            case ..<450: w = ".regular"
            case ..<550: w = ".medium"
            case ..<650: w = ".semibold"
            case ..<750: w = ".bold"
            case ..<850: w = ".heavy"
            default: w = ".black"
            }
            line += "\n.fontWeight(\(w))"
            if italic { line += "\n.italic()" }
        }
        return line
    }

    // MARK: Sample preparation

    static func makeSample(from image: CGImage, rect: CGRect, text: String) -> (TextSample, Bool)? {
        let padY = rect.height * 0.25
        let padX = rect.height * 0.3
        let r = rect.insetBy(dx: -padX, dy: -padY).integral.intersection(CGRect(x: 0, y: 0, width: image.width, height: image.height))
        guard r.width > 4, r.height > 4, let crop = image.cropping(to: r), let buf = PixelBuffer(image: crop) else { return nil }
        let w = buf.width, h = buf.height
        var lum = [Float](repeating: 0, count: w * h)
        var hist = [Int](repeating: 0, count: 256)
        for y in 0..<h {
            for x in 0..<w {
                let l = Float(buf.luminanceOnWhite(x: x, y: y))
                lum[y * w + x] = l
                hist[min(255, max(0, Int(l * 255)))] += 1
            }
        }
        let t = Float(otsu(hist)) / 255
        var darkCount = 0
        var darkSum: Float = 0, lightSum: Float = 0
        for l in lum { if l < t { darkCount += 1; darkSum += l } else { lightSum += l } }
        let lightCount = lum.count - darkCount
        guard darkCount > 0, lightCount > 0 else { return nil }
        let darkMean = darkSum / Float(darkCount)
        let lightMean = lightSum / Float(lightCount)
        let lightOnDark = darkCount > lightCount
        let fg = lightOnDark ? lightMean : darkMean
        let bg = lightOnDark ? darkMean : lightMean
        let span = fg - bg
        guard abs(span) > 0.08 else { return nil }
        let ink = lum.map { min(1, max(0, ($0 - bg) / span)) }
        guard let prepared = MatchEngine.prepare(ink: ink, width: w, height: h, text: text) else { return nil }
        return (TextSample(text: text, crop: crop, rect: rect, prepared: prepared), lightOnDark)
    }


    static func otsu(_ hist: [Int]) -> Int {
        let total = hist.reduce(0, +)
        var sum = 0.0
        for i in 0..<256 { sum += Double(i * hist[i]) }
        var sumB = 0.0, wB = 0.0, best = 0.0
        var threshold = 127
        for i in 0..<256 {
            wB += Double(hist[i])
            if wB == 0 { continue }
            let wF = Double(total) - wB
            if wF == 0 { break }
            sumB += Double(i * hist[i])
            let mB = sumB / wB, mF = (sum - sumB) / wF
            let between = wB * wF * (mB - mF) * (mB - mF)
            if between > best { best = between; threshold = i }
        }
        return threshold
    }

    /// Bilinear resample of an ink map to a fixed height (keeping aspect) or to an exact size.
    static func resample(_ src: [Float], width: Int, height: Int, toHeight th: Int, toWidth tw: Int? = nil) -> (pixels: [Float], width: Int)? {
        guard width > 0, height > 0 else { return nil }
        let outW = tw ?? max(4, Int((Double(width) * Double(th) / Double(height)).rounded()))
        var out = [Float](repeating: 0, count: outW * th)
        let sx = Float(width) / Float(outW), sy = Float(height) / Float(th)
        for y in 0..<th {
            // Area-average when shrinking for anti-aliasing.
            let y0 = Float(y) * sy, y1 = Float(y + 1) * sy
            for x in 0..<outW {
                let x0 = Float(x) * sx, x1 = Float(x + 1) * sx
                var acc: Float = 0, wsum: Float = 0
                var yy = Int(y0)
                while Float(yy) < y1 && yy < height {
                    let wy = min(Float(yy + 1), y1) - max(Float(yy), y0)
                    var xx = Int(x0)
                    while Float(xx) < x1 && xx < width {
                        let wx = min(Float(xx + 1), x1) - max(Float(xx), x0)
                        let wgt = max(0, wx) * max(0, wy)
                        acc += src[yy * width + xx] * wgt
                        wsum += wgt
                        xx += 1
                    }
                    yy += 1
                }
                out[y * outW + x] = wsum > 0 ? acc / wsum : 0
            }
        }
        return (out, outW)
    }

    static func blur(_ p: [Float], width w: Int, height h: Int) -> [Float] {
        var out = p
        for y in 0..<h {
            for x in 0..<w {
                var acc: Float = 0
                var n: Float = 0
                for dy in -1...1 {
                    let yy = y + dy
                    if yy < 0 || yy >= h { continue }
                    for dx in -1...1 {
                        let xx = x + dx
                        if xx < 0 || xx >= w { continue }
                        acc += p[yy * w + xx]
                        n += 1
                    }
                }
                out[y * w + x] = acc / n
            }
        }
        return out
    }

    static func mean(_ p: [Float]) -> Float { p.isEmpty ? 0 : p.reduce(0, +) / Float(p.count) }


    // MARK: Ranking

    struct Face {
        let postScriptName: String
        let style: String
        let nsWeight: Int
        let italic: Bool
    }

    static func faces(of family: String) -> [Face] {
        (NSFontManager.shared.availableMembers(ofFontFamily: family) ?? []).compactMap { m in
            guard m.count >= 4, let ps = m[0] as? String else { return nil }
            let style = m[1] as? String ?? ""
            let weight = m[2] as? Int ?? 5
            let traits = m[3] as? Int ?? 0
            return Face(postScriptName: ps, style: style, nsWeight: weight,
                        italic: (traits & Int(NSFontTraitMask.italicFontMask.rawValue)) != 0)
        }
    }

    static func usableFamilies() -> [String] {
        NSFontManager.shared.availableFontFamilies.filter { fam in
            let l = fam.lowercased()
            return !fam.hasPrefix(".") && !excludedFamilyFragments.contains { l.contains($0) }
        }
    }

    /// A face that can be tried: installed on this Mac, or from the bundled Google Fonts reference.
    enum CandidateFace {
        case installed(family: String, face: Face)
        case reference(FontReference.Face)

        var family: String {
            switch self {
            case let .installed(f, _): return f
            case let .reference(r): return r.family
            }
        }
    }

    static let installedEM = 64.0

    static func layout(_ c: CandidateFace, text: String) -> [PlacedGlyph]? {
        switch c {
        case let .installed(_, face): return MatchEngine.layoutInstalled(text, postScriptName: face.postScriptName, em: installedEM)
        case let .reference(r):
            guard let ref = FontReference.shared else { return nil }
            return MatchEngine.layoutReference(text, face: r, reference: ref)
        }
    }

    /// Ranks candidate fonts for a sample, best family first.
    /// - Parameters:
    ///   - allFaces: try every weight and style (otherwise regular and bold only).
    ///   - families: limit the search to these installed families (and skip the reference).
    ///   - includeReference: also consider popular Google Fonts that aren't installed.
    public static func rank(sample: TextSample, limit: Int = 8, allFaces: Bool = true, families: [String]? = nil,
                            includeReference: Bool = true, progress: ((Double) -> Void)? = nil) -> [FontCandidate] {
        let text = sample.text
        let prepared = sample.prepared
        // Every candidate face. (NSFontManager is queried here, on this thread; Core Text is thread-safe.)
        var pool: [CandidateFace] = []
        let fams = families ?? usableFamilies()
        var installedNames = Set<String>()
        var secondaryLatin = Set<String>()
        for family in fams {
            let fs = faces(of: family)
            guard !fs.isEmpty else { continue }
            installedNames.insert(family.lowercased())
            if isMainlyNonLatin(fs[0].postScriptName) { secondaryLatin.insert(family) }
            if allFaces {
                pool += fs.map { CandidateFace.installed(family: family, face: $0) }
            } else {
                func closest(to weight: Int) -> Face {
                    fs.min { abs($0.nsWeight - weight) + ($0.italic ? 3 : 0) < abs($1.nsWeight - weight) + ($1.italic ? 3 : 0) }!
                }
                let regular = closest(to: 5), bold = closest(to: 9)
                pool.append(.installed(family: family, face: regular))
                if bold.postScriptName != regular.postScriptName { pool.append(.installed(family: family, face: bold)) }
            }
        }
        if includeReference, families == nil, let ref = FontReference.shared {
            for face in ref.faces where !installedNames.contains(face.family.lowercased()) {
                if !allFaces && ![400, 700].contains(face.weight) { continue }
                pool.append(.reference(face))
            }
        }
        guard !pool.isEmpty, !Task.isCancelled else { return [] }

        // Three passes: quick (half resolution, everyone) → full (no sliding) → detailed.
        func run(_ list: [CandidateFace], pass: MatchEngine.Pass, from p0: Double, to p1: Double) -> [(CandidateFace, MatchEngine.Score)] {
            var results = [(CandidateFace, MatchEngine.Score)?](repeating: nil, count: list.count)
            let lock = NSLock()
            var done = 0
            results.withUnsafeMutableBufferPointer { buf in
                let base = buf.baseAddress!
                DispatchQueue.concurrentPerform(iterations: list.count) { i in
                    if Task.isCancelled { return }
                    if let glyphs = layout(list[i], text: text),
                       var s = MatchEngine.score(prepared, glyphs: glyphs, em: installedEM, pass: pass) {
                        // Fonts made for another script often borrow their Latin letters from a well-known
                        // Latin font; when both match equally, prefer the original.
                        if case let .installed(family, _) = list[i], secondaryLatin.contains(family) {
                            s = MatchEngine.Score(value: s.value - 0.04, dice: s.dice, stretch: s.stretch, thickness: s.thickness)
                        }
                        base[i] = (list[i], s)
                    }
                    lock.lock()
                    done += 1
                    let n = done
                    lock.unlock()
                    if n % 25 == 0 { progress?(p0 + (p1 - p0) * Double(n) / Double(list.count)) }
                }
            }
            return results.compactMap { $0 }.sorted { $0.1.value > $1.1.value }
        }
        let quick = run(pool, pass: .quick, from: 0, to: 0.55)
        let full = run(Array(quick.prefix(200).map(\.0)), pass: .full, from: 0.55, to: 0.8)
        let detailed = run(Array(full.prefix(40).map(\.0)), pass: .detailed, from: 0.8, to: 1)
        progress?(1)

        // Best face per family.
        var seen = Set<String>()
        var out: [FontCandidate] = []
        for (face, score) in detailed {
            let key = face.family.lowercased()
            guard !seen.contains(key) else { continue }
            seen.insert(key)
            out.append(candidate(face, similarity: max(0, min(1, score.value))))
            if out.count == limit { break }
        }
        return out
    }

    /// True for fonts designed mainly for a non-Latin script (Indic, CJK, Arabic, Thai…), whose Latin
    /// letters are usually secondary.
    static func isMainlyNonLatin(_ postScriptName: String) -> Bool {
        let font = CTFontCreateWithName(postScriptName as CFString, 12, nil)
        let family = (CTFontCopyFamilyName(font) as String).lowercased()
        // Apple's script fonts (Sangam MN, Lava, Kohinoor…) by name, others by what they cover.
        if family.hasSuffix(" mn") || family.contains("sangam") || family.hasPrefix("lava ") || family.hasPrefix("kohinoor")
            || family.hasPrefix("noto sans ") && !["noto sans", "noto sans mono", "noto sans display"].contains(family) { return true }
        let set = CTFontCopyCharacterSet(font) as CharacterSet
        let probes: [UInt32] = [0x0915, 0x0995, 0x0A15, 0x0A95, 0x0B15, 0x0B95, 0x0C15, 0x0C95, 0x0D15, 0x0D9A,
                                0x0E01, 0x0E81, 0x0F40, 0x1000, 0x1780, 0xAC00, 0x3042, 0x4E2D,
                                0x1200, 0x13A0, 0x1820, 0x1401, 0x11315, 0x11013]
        // (Arabic and Hebrew aren't probed: Arial, Times New Roman and others include them.)
        return probes.contains { Unicode.Scalar($0).map { set.contains($0) } ?? false }
    }

    /// The bundled reference face behind a Google Fonts candidate.
    static func referenceFace(for c: FontCandidate) -> FontReference.Face? {
        guard case .googleFonts = c.source, let ref = FontReference.shared else { return nil }
        let matches = ref.faces.filter { $0.family == c.familyName && $0.italic == c.isItalic }
        return matches.min { abs($0.weight - c.cssWeight) < abs($1.weight - c.cssWeight) }
    }

    /// Preview of `text` in a font that isn't installed, drawn from the bundled reference glyphs.
    /// White ink with alpha = coverage (use as a template / mask). `emPixels` is the size of 1 em.
    /// With `asMask`, returns a greyscale image (white = ink) for `CGContext.clip(to:mask:)`.
    public static func referencePreview(text: String, candidate: FontCandidate, emPixels: Double, asMask: Bool = false) -> CGImage? {
        guard let ref = FontReference.shared, let face = referenceFace(for: candidate),
              let glyphs = MatchEngine.layoutReference(text, face: face, reference: ref) else { return nil }
        let k = emPixels / Double(ref.em)
        var minX = Double.greatestFiniteMagnitude, minY = Double.greatestFiniteMagnitude
        var maxX = -Double.greatestFiniteMagnitude, maxY = -Double.greatestFiniteMagnitude
        for g in glyphs {
            minX = min(minX, (g.pen + g.left) * k); maxX = max(maxX, (g.pen + g.left + Double(g.image.width)) * k)
        }
        minY = -Double(face.ascender) * k * 1.15
        maxY = Double(face.descender) * k * 1.15 + 2
        for g in glyphs { minY = min(minY, g.top * k); maxY = max(maxY, (g.top + Double(g.image.height)) * k) }
        let pad = 2.0
        let W = Int(ceil(maxX - minX + 2 * pad)), H = Int(ceil(maxY - minY + 2 * pad))
        guard W > 0, H > 0, W < 8000, H < 2000 else { return nil }
        var canvas = GrayImage(width: W, height: H)
        for g in glyphs {
            let gw = max(1, Int((Double(g.image.width) * k).rounded())), gh = max(1, Int((Double(g.image.height) * k).rounded()))
            let scaled = MatchEngine.resizeBilinear(g.image, width: gw, height: gh)
            MatchEngine.stamp(scaled, into: &canvas, x: Int(((g.pen + g.left) * k - minX + pad).rounded()),
                              y: Int((g.top * k - minY + pad).rounded()))
        }
        if asMask {
            let grey = canvas.px.map { UInt8(max(0, min(255, $0 * 255))) }
            guard let provider = CGDataProvider(data: Data(grey) as CFData) else { return nil }
            return CGImage(width: W, height: H, bitsPerComponent: 8, bitsPerPixel: 8, bytesPerRow: W,
                           space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.none.rawValue),
                           provider: provider, decode: nil, shouldInterpolate: true, intent: .defaultIntent)
        }
        var rgba = [UInt8](repeating: 0, count: W * H * 4)
        for i in 0..<(W * H) {
            let a = UInt8(max(0, min(255, canvas.px[i] * 255)))
            rgba[i * 4] = a; rgba[i * 4 + 1] = a; rgba[i * 4 + 2] = a; rgba[i * 4 + 3] = a
        }
        guard let provider = CGDataProvider(data: Data(rgba) as CFData) else { return nil }
        return CGImage(width: W, height: H, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: W * 4,
                       space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
                       provider: provider, decode: nil, shouldInterpolate: true, intent: .defaultIntent)
    }

    /// CSS for a Google Fonts match, including the stylesheet link that loads it.
    public static func googleFontsCSS(_ c: FontCandidate, sizePx: Double?) -> String {
        let family = c.familyName.replacingOccurrences(of: " ", with: "+")
        let link = "@import url('https://fonts.googleapis.com/css2?family=\(family):\(c.isItalic ? "ital,wght@1," : "wght@")\(c.cssWeight)&display=swap');"
        return link + "\n" + cssDeclaration(family: c.familyName, weight: c.cssWeight, italic: c.isItalic, category: c.category, sizePx: sizePx)
    }

    static func candidate(_ face: CandidateFace, similarity: Double) -> FontCandidate {
        switch face {
        case let .installed(family, f):
            let font = CTFontCreateWithName(f.postScriptName as CFString, 24, nil)
            return FontCandidate(postScriptName: f.postScriptName, familyName: family,
                                 displayName: CTFontCopyDisplayName(font) as String, styleName: f.style,
                                 cssWeight: cssWeight(of: font), isItalic: f.italic, category: category(of: font),
                                 similarity: similarity, source: .installed)
        case let .reference(r):
            return FontCandidate(postScriptName: "\(r.family.replacingOccurrences(of: " ", with: ""))-\(r.styleName.replacingOccurrences(of: " ", with: ""))",
                                 familyName: r.family, displayName: "\(r.family) \(r.styleName)", styleName: r.styleName,
                                 cssWeight: r.weight, isItalic: r.italic, category: r.category,
                                 similarity: similarity, source: .googleFonts(slug: r.slug))
        }
    }


    // MARK: Layout estimates

    static func layoutEstimate(_ ocr: OCRResult) -> (String?, Double?) {
        let lines = ocr.lines
        guard lines.count >= 2 else { return (nil, nil) }
        let W = ocr.imageSize.width
        let lefts = lines.map { Double($0.boundingBox.minX * W) }
        let rights = lines.map { Double($0.boundingBox.maxX * W) }
        let centres = lines.map { Double($0.boundingBox.midX * W) }
        func spread(_ v: [Double]) -> Double {
            let m = v.reduce(0, +) / Double(v.count)
            return (v.map { ($0 - m) * ($0 - m) }.reduce(0, +) / Double(v.count)).squareRoot()
        }
        let tol = Double(lines.map { $0.boundingBox.height }.reduce(0, +) / CGFloat(lines.count)) * Double(ocr.imageSize.height) * 0.6
        let l = spread(lefts), r = spread(rights), c = spread(centres)
        var alignment: String
        if l < tol && r < tol { alignment = "Justified (estimated)" }
        else if l <= min(r, c) { alignment = "Left aligned (estimated)" }
        else if r <= min(l, c) { alignment = "Right aligned (estimated)" }
        else { alignment = "Centred (estimated)" }
        // Line spacing: median distance between consecutive baselines / median line height.
        var gaps: [Double] = []
        var heights: [Double] = []
        for i in 1..<lines.count {
            let a = lines[i - 1].boundingBox, b = lines[i].boundingBox
            let d = Double(a.minY - b.minY) * Double(ocr.imageSize.height)
            if d > 0 { gaps.append(d) }
            heights.append(Double(b.height) * Double(ocr.imageSize.height))
        }
        gaps.sort()
        heights.sort()
        guard !gaps.isEmpty, !heights.isEmpty else { return (alignment, nil) }
        let ratio = gaps[gaps.count / 2] / max(1, heights[heights.count / 2])
        return (alignment, (ratio * 100).rounded() / 100)
    }
}
