import CoreGraphics
import Foundation

/// Colour conversions used by Colour Lens. All inputs are sRGB 0...1.
public enum ColourMath {
    // MARK: Formatting

    public static func hex(_ c: RGBAColour, includeAlpha: Bool = false) -> String {
        func h(_ v: Double) -> String { String(format: "%02X", Int((min(1, max(0, v)) * 255).rounded())) }
        var s = "#" + h(c.r) + h(c.g) + h(c.b)
        if includeAlpha && c.a < 1 { s += h(c.a) }
        return s
    }

    public static func rgb255(_ c: RGBAColour) -> (Int, Int, Int) {
        (Int((c.r * 255).rounded()), Int((c.g * 255).rounded()), Int((c.b * 255).rounded()))
    }

    public static func rgbString(_ c: RGBAColour) -> String {
        let (r, g, b) = rgb255(c)
        return "\(r), \(g), \(b)"
    }

    public static func cssRGB(_ c: RGBAColour) -> String {
        let (r, g, b) = rgb255(c)
        if c.a < 1 { return "rgb(\(r) \(g) \(b) / \(fmt(c.a, 2)))" }
        return "rgb(\(r), \(g), \(b))"
    }

    /// Hue 0...360, saturation and lightness 0...100.
    public static func hsl(_ c: RGBAColour) -> (h: Double, s: Double, l: Double) {
        let maxV = max(c.r, c.g, c.b)
        let minV = min(c.r, c.g, c.b)
        let l = (maxV + minV) / 2
        let d = maxV - minV
        var h = 0.0
        var s = 0.0
        if d > 1e-9 {
            s = l > 0.5 ? d / (2 - maxV - minV) : d / (maxV + minV)
            h = hue(c, maxV: maxV, delta: d)
        }
        return (h, s * 100, l * 100)
    }

    public static func hsv(_ c: RGBAColour) -> (h: Double, s: Double, v: Double) {
        let maxV = max(c.r, c.g, c.b)
        let minV = min(c.r, c.g, c.b)
        let d = maxV - minV
        let h = d > 1e-9 ? hue(c, maxV: maxV, delta: d) : 0
        let s = maxV > 1e-9 ? d / maxV : 0
        return (h, s * 100, maxV * 100)
    }

    static func hue(_ c: RGBAColour, maxV: Double, delta d: Double) -> Double {
        var h: Double
        if maxV == c.r {
            h = (c.g - c.b) / d + (c.g < c.b ? 6 : 0)
        } else if maxV == c.g {
            h = (c.b - c.r) / d + 2
        } else {
            h = (c.r - c.g) / d + 4
        }
        h *= 60
        return h >= 360 ? h - 360 : h
    }

    public static func hslString(_ c: RGBAColour) -> String {
        let v = hsl(c)
        return "\(Int(v.h.rounded()))°, \(Int(v.s.rounded()))%, \(Int(v.l.rounded()))%"
    }

    public static func cssHSL(_ c: RGBAColour) -> String {
        let v = hsl(c)
        return "hsl(\(Int(v.h.rounded())), \(Int(v.s.rounded()))%, \(Int(v.l.rounded()))%)"
    }

    public static func hsvString(_ c: RGBAColour) -> String {
        let v = hsv(c)
        return "\(Int(v.h.rounded()))°, \(Int(v.s.rounded()))%, \(Int(v.v.rounded()))%"
    }

    /// Naïve device-independent CMYK. Real print values need the printer's ICC profile.
    public static func cmyk(_ c: RGBAColour) -> (c: Double, m: Double, y: Double, k: Double) {
        let k = 1 - max(c.r, c.g, c.b)
        if k >= 1 - 1e-9 { return (0, 0, 0, 100) }
        let cc = (1 - c.r - k) / (1 - k)
        let mm = (1 - c.g - k) / (1 - k)
        let yy = (1 - c.b - k) / (1 - k)
        return (cc * 100, mm * 100, yy * 100, k * 100)
    }

    public static func cmykString(_ c: RGBAColour) -> String {
        let v = cmyk(c)
        return "\(Int(v.c.rounded()))%, \(Int(v.m.rounded()))%, \(Int(v.y.rounded()))%, \(Int(v.k.rounded()))%"
    }

    /// CSS Color 4 Display-P3 value for wide-gamut screens.
    public static func cssDisplayP3(r: Double, g: Double, b: Double) -> String {
        "color(display-p3 \(fmt(r, 4)) \(fmt(g, 4)) \(fmt(b, 4)))"
    }

    static func fmt(_ v: Double, _ digits: Int) -> String {
        var s = String(format: "%.\(digits)f", v)
        while s.contains(".") && (s.hasSuffix("0") || s.hasSuffix(".")) { s.removeLast() }
        return s
    }

    // MARK: Parsing

    /// Parses #RGB, #RRGGBB, #RRGGBBAA, rgb()/rgba(), hsl()/hsla() and "r, g, b".
    public static func parse(_ input: String) -> RGBAColour? {
        var s = input.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if s.isEmpty { return nil }
        if s.hasPrefix("#") || s.range(of: "^[0-9a-f]{3,8}$", options: .regularExpression) != nil {
            if s.hasPrefix("#") { s.removeFirst() }
            guard s.range(of: "^[0-9a-f]+$", options: .regularExpression) != nil else { return nil }
            var chars = Array(s)
            if chars.count == 3 || chars.count == 4 { chars = chars.flatMap { [$0, $0] } }
            guard chars.count == 6 || chars.count == 8 else { return nil }
            func byte(_ i: Int) -> Double { Double(Int(String(chars[i..<i + 2]), radix: 16) ?? 0) / 255 }
            return RGBAColour(r: byte(0), g: byte(2), b: byte(4), a: chars.count == 8 ? byte(6) : 1)
        }
        let numbers = s.components(separatedBy: CharacterSet(charactersIn: "0123456789.%-").inverted)
            .filter { !$0.isEmpty }
        func value(_ token: String, scale: Double) -> Double? {
            if token.hasSuffix("%") { return Double(token.dropLast()).map { $0 / 100 } }
            return Double(token).map { $0 / scale }
        }
        if s.hasPrefix("hsl") {
            guard numbers.count >= 3, let h = Double(numbers[0].replacingOccurrences(of: "%", with: "")),
                  let sat = value(numbers[1], scale: 100), let l = value(numbers[2], scale: 100) else { return nil }
            var c = fromHSL(h: h, s: sat, l: l)
            if numbers.count >= 4, let a = value(numbers[3], scale: 1) { c.a = min(1, max(0, a)) }
            return c
        }
        if s.hasPrefix("rgb") || numbers.count == 3 || numbers.count == 4 {
            guard numbers.count >= 3, let r = value(numbers[0], scale: 255), let g = value(numbers[1], scale: 255),
                  let b = value(numbers[2], scale: 255) else { return nil }
            var a = 1.0
            if numbers.count >= 4, let av = value(numbers[3], scale: 1) { a = av }
            guard [r, g, b].allSatisfy({ $0 >= 0 && $0 <= 1.0001 }) else { return nil }
            return RGBAColour(r: min(1, r), g: min(1, g), b: min(1, b), a: min(1, max(0, a)))
        }
        return nil
    }

    /// h in degrees, s and l 0...1.
    public static func fromHSL(h: Double, s: Double, l: Double) -> RGBAColour {
        let hh = (h.truncatingRemainder(dividingBy: 360) + 360).truncatingRemainder(dividingBy: 360) / 360
        if s <= 0 { return RGBAColour(r: l, g: l, b: l) }
        let q = l < 0.5 ? l * (1 + s) : l + s - l * s
        let p = 2 * l - q
        func f(_ tIn: Double) -> Double {
            var t = tIn
            if t < 0 { t += 1 }
            if t > 1 { t -= 1 }
            if t < 1.0 / 6 { return p + (q - p) * 6 * t }
            if t < 0.5 { return q }
            if t < 2.0 / 3 { return p + (q - p) * (2.0 / 3 - t) * 6 }
            return p
        }
        return RGBAColour(r: f(hh + 1.0 / 3), g: f(hh), b: f(hh - 1.0 / 3))
    }

    // MARK: Accessibility contrast (WCAG 2.x)

    public static func relativeLuminance(_ c: RGBAColour) -> Double {
        func lin(_ v: Double) -> Double { v <= 0.04045 ? v / 12.92 : pow((v + 0.055) / 1.055, 2.4) }
        return 0.2126 * lin(c.r) + 0.7152 * lin(c.g) + 0.0722 * lin(c.b)
    }

    public static func contrastRatio(_ a: RGBAColour, _ b: RGBAColour) -> Double {
        let l1 = relativeLuminance(a)
        let l2 = relativeLuminance(b)
        return (max(l1, l2) + 0.05) / (min(l1, l2) + 0.05)
    }

    public struct ContrastReport: Sendable {
        public let ratio: Double
        public var aaNormal: Bool { ratio >= 4.5 }
        public var aaLarge: Bool { ratio >= 3 }
        public var aaaNormal: Bool { ratio >= 7 }
        public var aaaLarge: Bool { ratio >= 4.5 }
        public var uiComponents: Bool { ratio >= 3 }
        public var ratioText: String { String(format: "%.2f:1", ratio) }
    }

    public static func contrast(_ foreground: RGBAColour, _ background: RGBAColour) -> ContrastReport {
        ContrastReport(ratio: contrastRatio(foreground, background))
    }

    // MARK: Lab (for clustering and ΔE)

    public struct Lab: Sendable {
        public var l: Double
        public var a: Double
        public var b: Double
    }

    public static func lab(_ c: RGBAColour) -> Lab {
        func lin(_ v: Double) -> Double { v <= 0.04045 ? v / 12.92 : pow((v + 0.055) / 1.055, 2.4) }
        let r = lin(c.r), g = lin(c.g), b = lin(c.b)
        // sRGB D65 → XYZ
        let x = (0.4124564 * r + 0.3575761 * g + 0.1804375 * b) / 0.95047
        let y = (0.2126729 * r + 0.7151522 * g + 0.0721750 * b)
        let z = (0.0193339 * r + 0.1191920 * g + 0.9503041 * b) / 1.08883
        func f(_ t: Double) -> Double { t > 0.008856 ? cbrt(t) : 7.787 * t + 16.0 / 116 }
        let fx = f(x), fy = f(y), fz = f(z)
        return Lab(l: 116 * fy - 16, a: 500 * (fx - fy), b: 200 * (fy - fz))
    }

    public static func fromLab(_ lab: Lab) -> RGBAColour {
        let fy = (lab.l + 16) / 116
        let fx = fy + lab.a / 500
        let fz = fy - lab.b / 200
        func finv(_ t: Double) -> Double { let t3 = t * t * t; return t3 > 0.008856 ? t3 : (t - 16.0 / 116) / 7.787 }
        let x = finv(fx) * 0.95047, y = finv(fy), z = finv(fz) * 1.08883
        var r = 3.2404542 * x - 1.5371385 * y - 0.4985314 * z
        var g = -0.9692660 * x + 1.8760108 * y + 0.0415560 * z
        var b = 0.0556434 * x - 0.2040259 * y + 1.0572252 * z
        func gam(_ v: Double) -> Double { v <= 0.0031308 ? 12.92 * v : 1.055 * pow(v, 1 / 2.4) - 0.055 }
        r = gam(r); g = gam(g); b = gam(b)
        return RGBAColour(r: min(1, max(0, r)), g: min(1, max(0, g)), b: min(1, max(0, b)))
    }

    public static func deltaE(_ a: Lab, _ b: Lab) -> Double {
        let dl = a.l - b.l, da = a.a - b.a, db = a.b - b.b
        return (dl * dl + da * da + db * db).squareRoot()
    }

    /// A friendly approximate colour name ("Teal", "Warm grey"…).
    public static func approximateName(_ c: RGBAColour) -> String {
        let v = hsl(c)
        if v.l < 8 { return "Black" }
        if v.l > 95 { return "White" }
        if v.s < 10 {
            if v.l < 30 { return "Charcoal" }
            if v.l < 70 { return "Grey" }
            return "Light grey"
        }
        let names: [(Double, String)] = [(15, "Red"), (40, "Orange"), (65, "Yellow"), (90, "Lime"), (150, "Green"),
                                         (185, "Teal"), (205, "Cyan"), (250, "Blue"), (275, "Indigo"), (300, "Purple"),
                                         (335, "Pink"), (360, "Red")]
        var base = "Red"
        for (limit, name) in names where v.h < limit { base = name; break }
        if v.l < 30 { return "Dark " + base.lowercased() }
        if v.l > 75 { return "Light " + base.lowercased() }
        if v.s < 35 { return "Muted " + base.lowercased() }
        return base
    }
}

// MARK: - Palette extraction (k-means++ in Lab space)

public struct PaletteColour: Hashable, Sendable {
    public let colour: RGBAColour
    /// Share of the image's (opaque) pixels, 0...1.
    public let weight: Double
}

public enum PaletteExtractor {
    public static func extract(from image: CGImage, count: Int = 6, ignoreTransparent: Bool = true) -> [PaletteColour] {
        guard let buffer = PixelBuffer(image: image, maxDimension: 160) else { return [] }
        var samples: [ColourMath.Lab] = []
        var rgbs: [RGBAColour] = []
        samples.reserveCapacity(buffer.width * buffer.height)
        for y in 0..<buffer.height {
            for x in 0..<buffer.width {
                let p = buffer.rgba(x: x, y: y)
                if ignoreTransparent && p.a < 128 { continue }
                let c = RGBAColour(r: p.r / 255, g: p.g / 255, b: p.b / 255)
                rgbs.append(c)
                samples.append(ColourMath.lab(c))
            }
        }
        guard !samples.isEmpty else { return [] }
        let k = max(1, min(count, 12))
        var centroids = initialCentroids(samples, k: k)
        var assignment = [Int](repeating: 0, count: samples.count)
        for _ in 0..<14 {
            var changed = false
            for (i, s) in samples.enumerated() {
                var best = 0
                var bestD = Double.greatestFiniteMagnitude
                for (j, c) in centroids.enumerated() {
                    let d = sq(s, c)
                    if d < bestD { bestD = d; best = j }
                }
                if assignment[i] != best { assignment[i] = best; changed = true }
            }
            var sums = [(Double, Double, Double, Int)](repeating: (0, 0, 0, 0), count: centroids.count)
            for (i, s) in samples.enumerated() {
                let a = assignment[i]
                sums[a].0 += s.l; sums[a].1 += s.a; sums[a].2 += s.b; sums[a].3 += 1
            }
            for j in centroids.indices where sums[j].3 > 0 {
                let n = Double(sums[j].3)
                centroids[j] = ColourMath.Lab(l: sums[j].0 / n, a: sums[j].1 / n, b: sums[j].2 / n)
            }
            if !changed { break }
        }
        var counts = [Int](repeating: 0, count: centroids.count)
        for a in assignment { counts[a] += 1 }
        // Merge clusters that are visually indistinguishable.
        var merged: [(lab: ColourMath.Lab, count: Int)] = []
        for (j, c) in centroids.enumerated() where counts[j] > 0 {
            if let idx = merged.firstIndex(where: { ColourMath.deltaE($0.lab, c) < 5 }) {
                let total = merged[idx].count + counts[j]
                let w1 = Double(merged[idx].count) / Double(total), w2 = Double(counts[j]) / Double(total)
                let l = merged[idx].lab
                merged[idx] = (ColourMath.Lab(l: l.l * w1 + c.l * w2, a: l.a * w1 + c.a * w2, b: l.b * w1 + c.b * w2), total)
            } else {
                merged.append((c, counts[j]))
            }
        }
        let total = Double(samples.count)
        return merged.sorted { $0.count > $1.count }.map {
            PaletteColour(colour: ColourMath.fromLab($0.lab), weight: Double($0.count) / total)
        }
    }

    static func sq(_ a: ColourMath.Lab, _ b: ColourMath.Lab) -> Double {
        let dl = a.l - b.l, da = a.a - b.a, db = a.b - b.b
        return dl * dl + da * da + db * db
    }

    /// Deterministic k-means++ seeding (no randomness, so results are repeatable).
    static func initialCentroids(_ samples: [ColourMath.Lab], k: Int) -> [ColourMath.Lab] {
        var centroids: [ColourMath.Lab] = []
        // Start from the most common lightness band's mean for stability.
        let mean = samples.reduce((0.0, 0.0, 0.0)) { ($0.0 + $1.l, $0.1 + $1.a, $0.2 + $1.b) }
        let n = Double(samples.count)
        let m = ColourMath.Lab(l: mean.0 / n, a: mean.1 / n, b: mean.2 / n)
        var first = samples[0]
        var bestD = Double.greatestFiniteMagnitude
        for s in samples {
            let d = sq(s, m)
            if d < bestD { bestD = d; first = s }
        }
        centroids.append(first)
        var dists = samples.map { sq($0, first) }
        while centroids.count < k {
            // Farthest-point selection weighted by distance (deterministic).
            guard let idx = dists.indices.max(by: { dists[$0] < dists[$1] }), dists[idx] > 1 else { break }
            let c = samples[idx]
            centroids.append(c)
            for i in samples.indices { dists[i] = min(dists[i], sq(samples[i], c)) }
        }
        return centroids
    }
}

// MARK: - Gradient estimation

public struct GradientEstimate: Sendable {
    public let start: RGBAColour
    public let end: RGBAColour
    /// CSS angle in degrees (0 = to top, 90 = to right).
    public let cssAngle: Double
    /// 0...1 — how well a linear gradient explains the region.
    public let fit: Double

    public var css: String {
        "linear-gradient(\(Int(cssAngle.rounded()))deg, \(start.hex), \(end.hex))"
    }

    public var isConvincing: Bool { fit >= 0.6 && ColourMath.deltaE(ColourMath.lab(start), ColourMath.lab(end)) > 4 }
}

public enum GradientEstimator {
    /// Fits colour(x, y) = c0 + gx·x + gy·y per channel by least squares.
    public static func estimate(_ image: CGImage) -> GradientEstimate? {
        guard let buf = PixelBuffer(image: image, maxDimension: 96), buf.width > 1, buf.height > 1 else { return nil }
        let w = buf.width, h = buf.height
        var sx = 0.0, sy = 0.0, sxx = 0.0, syy = 0.0, sxy = 0.0, n = 0.0
        var sc = [0.0, 0.0, 0.0], sxc = [0.0, 0.0, 0.0], syc = [0.0, 0.0, 0.0]
        var values: [(Double, Double, [Double])] = []
        for y in 0..<h {
            for x in 0..<w {
                let p = buf.rgba(x: x, y: y)
                if p.a < 128 { continue }
                let fx = Double(x) / Double(w - 1) - 0.5
                let fy = Double(y) / Double(h - 1) - 0.5
                let c = [p.r / 255, p.g / 255, p.b / 255]
                sx += fx; sy += fy; sxx += fx * fx; syy += fy * fy; sxy += fx * fy; n += 1
                for i in 0..<3 { sc[i] += c[i]; sxc[i] += fx * c[i]; syc[i] += fy * c[i] }
                values.append((fx, fy, c))
            }
        }
        guard n > 10 else { return nil }
        // Solve the 3x3 normal equations for each channel.
        let m: [[Double]] = [[n, sx, sy], [sx, sxx, sxy], [sy, sxy, syy]]
        var coeffs: [[Double]] = []
        for i in 0..<3 {
            guard let sol = solve3(m, [sc[i], sxc[i], syc[i]]) else { return nil }
            coeffs.append(sol)
        }
        // Direction of strongest change (weighted by luminance coefficients).
        let gx = 0.2126 * coeffs[0][1] + 0.7152 * coeffs[1][1] + 0.0722 * coeffs[2][1]
        let gy = 0.2126 * coeffs[0][2] + 0.7152 * coeffs[1][2] + 0.0722 * coeffs[2][2]
        var dx = gx, dy = gy
        // Use the summed absolute colour gradient when luminance is flat (hue-only gradients).
        if abs(gx) + abs(gy) < 1e-4 {
            dx = coeffs.reduce(0) { $0 + abs($1[1]) }
            dy = coeffs.reduce(0) { $0 + abs($1[2]) }
        }
        // Convert to per-pixel change so non-square regions get the right angle.
        let spanX = Double(w - 1), spanY = Double(h - 1)
        dx /= spanX
        dy /= spanY
        let len = (dx * dx + dy * dy).squareRoot()
        guard len > 1e-9 else { return nil }
        let ux = dx / len, uy = dy / len
        // The gradient line runs between the box corners projected onto the direction.
        let extent = 0.5 * (abs(ux) * spanX + abs(uy) * spanY)
        func colourAt(_ t: Double) -> RGBAColour {
            let px = ux * t / spanX, py = uy * t / spanY
            let v = (0..<3).map { i in min(1, max(0, coeffs[i][0] + coeffs[i][1] * px + coeffs[i][2] * py)) }
            return RGBAColour(r: v[0], g: v[1], b: v[2])
        }
        // R² across channels.
        var ssRes = 0.0, ssTot = 0.0
        let means = sc.map { $0 / n }
        for (fx, fy, c) in values {
            for i in 0..<3 {
                let pred = coeffs[i][0] + coeffs[i][1] * fx + coeffs[i][2] * fy
                ssRes += (c[i] - pred) * (c[i] - pred)
                ssTot += (c[i] - means[i]) * (c[i] - means[i])
            }
        }
        let fit = ssTot > 1e-9 ? max(0, 1 - ssRes / ssTot) : 0
        // Image y grows downward; CSS 0deg points up, 90deg right.
        let angle = (atan2(ux, -uy) * 180 / .pi + 360).truncatingRemainder(dividingBy: 360)
        // A gradient at θ from A to B looks identical to θ+180° from B to A; report the
        // conventional one (to the right / to the bottom) so results are predictable.
        if angle >= 180 - 0.001 {
            return GradientEstimate(start: colourAt(extent), end: colourAt(-extent), cssAngle: angle - 180, fit: fit)
        }
        return GradientEstimate(start: colourAt(-extent), end: colourAt(extent), cssAngle: angle, fit: fit)
    }

    static func solve3(_ a: [[Double]], _ b: [Double]) -> [Double]? {
        func det(_ m: [[Double]]) -> Double {
            m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
                - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
                + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
        }
        let d = det(a)
        guard abs(d) > 1e-12 else { return nil }
        var result: [Double] = []
        for col in 0..<3 {
            var m = a
            for row in 0..<3 { m[row][col] = b[row] }
            result.append(det(m) / d)
        }
        return result
    }
}

// MARK: - Palette export

public enum PaletteExporter {
    public static func slug(_ s: String) -> String {
        let lowered = s.lowercased().replacingOccurrences(of: " ", with: "-")
        let filtered = lowered.filter { $0.isLetter || $0.isNumber || $0 == "-" }
        return filtered.isEmpty ? "colour" : filtered
    }

    public static func cssVariables(_ colours: [(name: String, colour: RGBAColour)]) -> String {
        var lines = [":root {"]
        for (i, c) in colours.enumerated() {
            lines.append("  --\(slug(c.name.isEmpty ? "colour-\(i + 1)" : c.name)): \(c.colour.hex);")
        }
        lines.append("}")
        return lines.joined(separator: "\n") + "\n"
    }

    /// W3C Design Tokens Community Group format.
    public static func designTokensJSON(_ colours: [(name: String, colour: RGBAColour)], group: String = "color") -> String {
        var entries: [String] = []
        for (i, c) in colours.enumerated() {
            let key = slug(c.name.isEmpty ? "colour-\(i + 1)" : c.name)
            entries.append("    \"\(key)\": { \"$type\": \"color\", \"$value\": \"\(c.colour.hex)\" }")
        }
        return "{\n  \"\(group)\": {\n" + entries.joined(separator: ",\n") + "\n  }\n}\n"
    }

    public static func hexList(_ colours: [(name: String, colour: RGBAColour)]) -> String {
        colours.map { $0.colour.hex }.joined(separator: "\n") + "\n"
    }

    public static func svgSwatches(_ colours: [(name: String, colour: RGBAColour)]) -> String {
        let size = 120, pad = 16, labelH = 44
        let width = colours.count * (size + pad) + pad
        var out = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"\(width)\" height=\"\(size + labelH + pad * 2)\" viewBox=\"0 0 \(width) \(size + labelH + pad * 2)\">\n"
        out += "  <rect width=\"100%\" height=\"100%\" fill=\"#FFFFFF\"/>\n"
        for (i, c) in colours.enumerated() {
            let x = pad + i * (size + pad)
            out += "  <rect x=\"\(x)\" y=\"\(pad)\" width=\"\(size)\" height=\"\(size)\" rx=\"12\" fill=\"\(c.colour.hex)\"/>\n"
            out += "  <text x=\"\(x)\" y=\"\(pad + size + 20)\" font-family=\"-apple-system, Helvetica, Arial, sans-serif\" font-size=\"14\" fill=\"#2B2A28\">\(c.colour.hex)</text>\n"
            if !c.name.isEmpty {
                out += "  <text x=\"\(x)\" y=\"\(pad + size + 38)\" font-family=\"-apple-system, Helvetica, Arial, sans-serif\" font-size=\"12\" fill=\"#6E6A64\">\(xmlEscape(c.name))</text>\n"
            }
        }
        return out + "</svg>\n"
    }

    /// Renders a PNG palette sheet.
    public static func pngSheet(_ colours: [(name: String, colour: RGBAColour)]) -> CGImage? {
        let size = 240, pad = 32, labelH = 80
        let width = max(1, colours.count) * (size + pad) + pad
        let height = size + labelH + pad * 2
        guard let ctx = ImageOps.makeContext(width: width, height: height, opaque: true) else { return nil }
        ctx.setFillColor(RGBAColour.white.cgColor)
        ctx.fill(CGRect(x: 0, y: 0, width: width, height: height))
        for (i, c) in colours.enumerated() {
            let x = pad + i * (size + pad)
            let rect = CGRect(x: x, y: height - pad - size, width: size, height: size)
            ctx.addPath(CGPath(roundedRect: rect, cornerWidth: 24, cornerHeight: 24, transform: nil))
            ctx.setFillColor(c.colour.cgColor)
            ctx.fillPath()
            TextDrawing.draw(c.colour.hex, in: ctx, at: CGPoint(x: x, y: height - pad - size - 40), fontSize: 28, colour: RGBAColour(r: 0.17, g: 0.16, b: 0.16), bold: true)
            if !c.name.isEmpty {
                TextDrawing.draw(c.name, in: ctx, at: CGPoint(x: x, y: height - pad - size - 72), fontSize: 22, colour: RGBAColour(r: 0.43, g: 0.42, b: 0.39), bold: false)
            }
        }
        return ctx.makeImage()
    }

    static func xmlEscape(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;").replacingOccurrences(of: "\"", with: "&quot;")
    }
}
