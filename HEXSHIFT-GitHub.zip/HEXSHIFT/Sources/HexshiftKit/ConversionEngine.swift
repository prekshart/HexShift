import AppKit
import CoreText
import Foundation

public struct ConversionTarget: Identifiable, Hashable, Sendable {
    public enum Variant: String, Codable, Sendable {
        case standard, trace, animated, firstFrame, ocr, specimen
    }

    public let format: Format
    public let variant: Variant
    public let label: String
    /// Shown as a tooltip / warning (e.g. "Transparency will be flattened").
    public let note: String?
    /// False when a helper tool is missing; the note says what to install.
    public let isAvailable: Bool
    /// Conversions that should ask for settings first (PDF pages, video ranges…).
    public let prefersOptions: Bool

    public var id: String { "\(format.rawValue).\(variant.rawValue)" }

    public init(_ format: Format, variant: Variant = .standard, label: String? = nil, note: String? = nil,
                isAvailable: Bool = true, prefersOptions: Bool = false) {
        self.format = format
        self.variant = variant
        self.label = label ?? format.shortName
        self.note = note
        self.isAvailable = isAvailable
        self.prefersOptions = prefersOptions
    }
}

public struct ConversionOptions: Codable, Hashable, Sendable {
    public var image = ImageExportOptions()
    /// 0-based page indices; nil = all pages.
    public var pdfPages: [Int]?
    public var pdfDPI: Double = 150
    public var pdfTransparentBackground = false
    public var document = DocumentOptions()
    public var video = VideoOptions()
    /// Raster scale for SVG sources (1 = intrinsic size).
    public var svgScale: Double = 2

    public init() {}
}

/// Decides which conversions are genuinely possible for a file and performs them.
public enum ConversionEngine {
    static let rasterTargets: [Format] = [.png, .jpeg, .webp, .heic, .avif, .tiff, .gif, .bmp, .jp2, .ico, .icns, .pdf]

    public static func targets(for asset: AssetInfo, preferredOrder: [Format] = []) -> [ConversionTarget] {
        guard let source = asset.format else { return [] }
        var list: [ConversionTarget] = []
        let hasAlpha = asset.hasAlpha ?? false

        func addRaster(_ formats: [Format], variant: ConversionTarget.Variant = .standard, extraNote: String? = nil) {
            for f in formats where f != source || variant != .standard {
                guard ImageEncoder.canWrite(f) else {
                    if f == .avif {
                        list.append(ConversionTarget(f, variant: variant, note: "Needs an AVIF encoder. " + ExternalTool.avifenc.installHint, isAvailable: false))
                    }
                    continue
                }
                var note = extraNote
                if hasAlpha && !f.supportsAlpha && variant != .ocr { note = [note, "Any transparent areas will be filled with white."].compactMap { $0 }.joined(separator: " ") }
                if f == .ico { note = [note, "Multi-size icon (16–256 px)."].compactMap { $0 }.joined(separator: " ") }
                if f == .icns { note = [note, "macOS icon set (16–1024 px)."].compactMap { $0 }.joined(separator: " ") }
                list.append(ConversionTarget(f, variant: variant, note: note))
            }
        }

        switch asset.kind {
        case .image, .rawImage:
            addRaster(rasterTargets)
            list.append(ConversionTarget(.svg, variant: .standard, label: "SVG",
                                         note: "Wraps the pixels in an SVG file. This is not editable vector artwork — use SVG Trace for real shapes."))
            list.append(ConversionTarget(.svg, variant: .trace, label: "SVG Trace",
                                         note: "Traces the image into editable vector shapes (posterised, approximate)."))
            list.append(ConversionTarget(.txt, variant: .ocr, label: "TXT", note: "Extracts the text in the image (OCR)."))
            list.append(ConversionTarget(.docx, variant: .ocr, label: "DOCX", note: "Extracts the text in the image (OCR) into a Word document."))
        case .animatedImage:
            for f in [Format.gif, .webp, .png] where f != source || f == .png {
                list.append(ConversionTarget(f, variant: .animated, label: f == .png ? "APNG" : f.shortName,
                                             note: f == .png ? "Animated PNG — keeps every frame." : "Keeps the animation."))
            }
            list.append(ConversionTarget(.mp4, variant: .animated, note: "Converts the animation to a video (transparency becomes white)."))
            list.append(ConversionTarget(.mov, variant: .animated, note: "Converts the animation to a video (transparency becomes white)."))
            addRaster([.png, .jpeg, .webp, .heic, .tiff, .pdf], variant: .firstFrame, extraNote: "Keeps the first frame only — the animation is not preserved.")
        case .pdf:
            for f in [Format.png, .jpeg, .tiff, .webp, .heic] where ImageEncoder.canWrite(f) {
                list.append(ConversionTarget(f, note: "One image per page.", prefersOptions: (asset.pageCount ?? 1) > 1))
            }
            list.append(ConversionTarget(.txt, note: "Extracts the text (OCR is used for scanned pages)."))
            list.append(ConversionTarget(.docx, note: "Text and basic styling only — complex layouts, columns and tables need manual adjustment."))
            list.append(ConversionTarget(.rtf, note: "Text and basic styling only."))
            list.append(ConversionTarget(.md, note: "Text only."))
            list.append(ConversionTarget(.html, note: "Text and basic styling only."))
        case .vector:
            switch source {
            case .svg:
                for f in [Format.png, .jpeg, .webp, .heic, .tiff, .gif, .ico, .icns] where ImageEncoder.canWrite(f) {
                    list.append(ConversionTarget(f, note: f.supportsAlpha ? "Rendered at \(Int(2))× the SVG's size." : "Rendered at 2× on a white background."))
                }
                list.append(ConversionTarget(.pdf, note: "Keeps vector shapes."))
            case .ai:
                if Format.sniff(asset.url) == .pdf {
                    for f in [Format.pdf, .png, .jpeg, .tiff, .webp] where ImageEncoder.canWrite(f) {
                        list.append(ConversionTarget(f, note: f == .pdf ? "Uses the PDF-compatible content saved inside the .ai file. Layers are flattened." : "Uses the PDF-compatible content saved inside the .ai file."))
                    }
                } else {
                    let gs = ExternalTools.path(.gs) != nil
                    for f in [Format.pdf, .png, .jpeg] {
                        list.append(ConversionTarget(f, note: gs ? "Legacy PostScript Illustrator file, converted with Ghostscript." : "Needs Ghostscript. " + ExternalTool.gs.installHint, isAvailable: gs))
                    }
                }
            case .eps:
                let gs = ExternalTools.path(.gs) != nil
                for f in [Format.pdf, .png, .jpeg, .tiff] {
                    list.append(ConversionTarget(f, note: gs ? "Rendered with Ghostscript." : "macOS no longer reads PostScript. Needs Ghostscript: " + ExternalTool.gs.installHint, isAvailable: gs))
                }
            default: break
            }
        case .document:
            if source == .pages {
                for f in OfficeAdapters.iWorkTargets(for: .pages) {
                    list.append(ConversionTarget(f, note: "Exported by Pages (asks for Automation permission the first time)."))
                }
                if list.isEmpty { list.append(ConversionTarget(.pdf, note: "Needs Apple Pages installed.", isAvailable: false)) }
            } else {
                for f in DocumentConverter.writable where f != source {
                    var note: String?
                    if f == .pdf && [.docx, .doc, .odt].contains(source) {
                        note = OfficeAdapters.hasLibreOffice ? "Rendered with LibreOffice for best fidelity." :
                            "Complex layouts, embedded fonts and page structure may change."
                    }
                    if f == .md { note = "Headings, emphasis, links and lists are kept." }
                    if f == .txt { note = "Plain text — formatting is removed." }
                    list.append(ConversionTarget(f, note: note))
                }
                list.append(ConversionTarget(.png, note: "One image per page."))
                list.append(ConversionTarget(.jpeg, note: "One image per page."))
            }
        case .spreadsheet:
            if source == .numbers {
                for f in OfficeAdapters.iWorkTargets(for: .numbers) {
                    list.append(ConversionTarget(f, note: "Exported by Numbers."))
                }
                if list.isEmpty { list.append(ConversionTarget(.xlsx, note: "Needs Apple Numbers installed.", isAvailable: false)) }
            } else {
                for f in TableConverter.targets where f != source {
                    list.append(ConversionTarget(f, note: f == .xlsx ? "First sheet only, values (not formulas)." : (source == .xlsx ? "First sheet only." : nil)))
                }
            }
        case .presentation:
            let viaKeynote = OfficeAdapters.hasKeynote
            let viaLO = OfficeAdapters.hasLibreOffice
            let available = viaKeynote || viaLO
            let how = viaKeynote ? "Exported by Keynote." : viaLO ? "Rendered with LibreOffice." : "Needs Keynote or LibreOffice installed."
            list.append(ConversionTarget(.pdf, note: how, isAvailable: available))
            list.append(ConversionTarget(.png, note: available ? "One image per slide." : how, isAvailable: available))
            list.append(ConversionTarget(.jpeg, note: available ? "One image per slide." : how, isAvailable: available))
            if source == .key && viaKeynote { list.append(ConversionTarget(.pptx, note: "Exported by Keynote.")) }
        case .video, .audio:
            for (f, note) in MediaConverter.targets(for: source) {
                let needsTool = note?.hasPrefix("Needs") == true
                list.append(ConversionTarget(f, note: needsTool ? "Needs FFmpeg. " + ExternalTool.ffmpeg.installHint : note,
                                             isAvailable: !needsTool,
                                             prefersOptions: [.gif, .webp].contains(f)))
            }
        case .font:
            list.append(ConversionTarget(.png, variant: .specimen, label: "Specimen PNG", note: "Typography reference card."))
            list.append(ConversionTarget(.pdf, variant: .specimen, label: "Specimen PDF", note: "Typography reference card."))
        case .unknown:
            break
        }

        // Apply the user's preferred order (unknown formats keep their natural order).
        guard !preferredOrder.isEmpty else { return list }
        func rank(_ t: ConversionTarget) -> Int { preferredOrder.firstIndex(of: t.format) ?? 1000 }
        return list.enumerated().sorted { a, b in
            let ra = rank(a.element), rb = rank(b.element)
            return ra != rb ? ra < rb : a.offset < b.offset
        }.map(\.element)
    }

    // MARK: Converting

    public static func convert(_ asset: AssetInfo, to target: ConversionTarget, options: ConversionOptions,
                               planner: OutputPlanner) async throws -> [URL] {
        guard let source = asset.format else { throw HexError.unreadable(asset.name) }
        guard target.isAvailable else {
            throw HexError.message(target.note ?? "\(target.format.displayName) isn't available on this Mac.")
        }
        let url = asset.url
        let f = target.format
        func out(_ ext: String? = nil, size: (Int, Int)? = nil) -> URL {
            planner.url(for: url, ext: ext ?? f.fileExtension, format: f.displayName, pixelSize: size)
        }

        switch (asset.kind, target.variant) {
        case (.image, .ocr), (.rawImage, .ocr):
            let image = try ImageLoader.load(url).image
            let result = try OCRService.recognize(image)
            guard !result.text.isEmpty else { throw HexError.noTextFound }
            let dest = out()
            let docOptions = options.document
            try await MainActor.run {
                try DocumentConverter.export(text: result.text, as: f, to: dest, options: docOptions, title: asset.baseName)
            }
            return [dest]

        case (.image, _), (.rawImage, _), (.animatedImage, .firstFrame):
            let loaded = try ImageLoader.load(url)
            var opts = options.image
            if target.variant == .trace { opts.svgMode = .trace }
            let dest = out(size: (loaded.image.width, loaded.image.height))
            try ImageEncoder.write(loaded.image, sourceProperties: loaded.properties, format: f, to: dest, options: opts)
            return [dest]

        case (.animatedImage, _):
            if f == .mp4 || f == .mov {
                let dest = out()
                try await MediaConverter.animatedImageToVideo(url, output: dest, fileType: f == .mov ? .mov : .mp4)
                return [dest]
            }
            let (frames, loop) = try ImageLoader.loadAnimation(url)
            let dest = out(size: (frames[0].image.width, frames[0].image.height))
            try ImageEncoder.writeAnimation(frames, loopCount: loop, format: f, to: dest, options: options.image)
            return [dest]

        case (.pdf, _),
             (.vector, _) where source == .ai && Format.sniff(url) == .pdf:
            if f == .pdf {
                // AI → PDF: re-save the PDF-compatible content.
                let doc = try PDFEngine.open(url)
                let dest = out()
                try PDFEngine.save(doc, to: dest)
                return [dest]
            }
            if f.category == .raster {
                return try PDFEngine.exportPages(url, pages: options.pdfPages, dpi: options.pdfDPI, format: f, options: options.image,
                                                 planner: planner, transparentBackground: options.pdfTransparentBackground)
            }
            let dest = out()
            if f == .txt || f == .md {
                let extracted = try PDFEngine.extractText(url)
                guard !extracted.text.isEmpty else { throw HexError.noTextFound }
                let text = extracted.text
                try await MainActor.run {
                    try DocumentConverter.export(text: text, as: f, to: dest, options: options.document, title: asset.baseName)
                }
            } else {
                let attr = try PDFEngine.attributedText(url)
                guard attr.length > 0 else { throw HexError.noTextFound }
                let docOptions = options.document
                try await MainActor.run {
                    try DocumentConverter.write(attr, as: f, to: dest, options: docOptions, title: asset.baseName)
                }
            }
            return [dest]

        case (.vector, _):
            if source == .svg {
                if f == .pdf {
                    let dest = out()
                    try await SVGSupport.writePDF(url, output: dest)
                    return [dest]
                }
                let image = try await SVGSupport.render(url, scale: options.svgScale)
                let dest = out(size: (image.width, image.height))
                try ImageEncoder.write(image, format: f, to: dest, options: options.image)
                return [dest]
            }
            // EPS / PostScript AI via Ghostscript
            let pdf = try postScriptToPDF(url)
            defer { try? FileManager.default.removeItem(at: pdf.deletingLastPathComponent()) }
            if f == .pdf {
                let dest = out()
                try FileWriter.writeAtomically(to: dest) { tmp in try FileManager.default.copyItem(at: pdf, to: tmp) }
                return [dest]
            }
            return try PDFEngine.exportPages(pdf, pages: options.pdfPages, dpi: max(150, options.pdfDPI), format: f,
                                             options: options.image, planner: planner, namingSource: url)

        case (.document, _):
            if source == .pages {
                let dest = out()
                try OfficeAdapters.convertWithIWork(url, source: .pages, to: f, output: dest)
                return [dest]
            }
            if f.category == .raster {
                let tmpDir = try FileWriter.makeTemporaryDirectory()
                defer { try? FileManager.default.removeItem(at: tmpDir) }
                let pdf = tmpDir.appendingPathComponent("doc.pdf")
                let docOptions = options.document
                try await DocumentConverter.convert(url, from: source, to: .pdf, output: pdf, options: docOptions)
                return try PDFEngine.exportPages(pdf, pages: options.pdfPages, dpi: options.pdfDPI, format: f,
                                                 options: options.image, planner: planner, namingSource: url)
            }
            let dest = out()
            let docOptions = options.document
            try await DocumentConverter.convert(url, from: source, to: f, output: dest, options: docOptions)
            return [dest]

        case (.spreadsheet, _):
            let dest = out()
            if source == .numbers {
                try OfficeAdapters.convertWithIWork(url, source: .numbers, to: f, output: dest)
                return [dest]
            }
            let rows = try TableConverter.read(url, format: source)
            if f == .pdf {
                try await MainActor.run { try TableConverter.writePDF(rows, to: dest, title: asset.baseName) }
            } else {
                try TableConverter.write(rows, as: f, to: dest, title: asset.baseName)
            }
            return [dest]

        case (.presentation, _):
            if f == .pptx {
                let dest = out()
                try OfficeAdapters.convertWithIWork(url, source: source, to: .pptx, output: dest)
                return [dest]
            }
            let tmpDir = try FileWriter.makeTemporaryDirectory()
            defer { try? FileManager.default.removeItem(at: tmpDir) }
            let pdf = tmpDir.appendingPathComponent("slides.pdf")
            if OfficeAdapters.hasKeynote {
                try OfficeAdapters.convertWithIWork(url, source: source, to: .pdf, output: pdf)
            } else {
                try OfficeAdapters.convertWithLibreOffice(url, to: .pdf, output: pdf)
            }
            if f == .pdf {
                let dest = out()
                try FileWriter.writeAtomically(to: dest) { tmp in try FileManager.default.copyItem(at: pdf, to: tmp) }
                return [dest]
            }
            return try PDFEngine.exportPages(pdf, pages: options.pdfPages, dpi: options.pdfDPI, format: f,
                                             options: options.image, planner: planner, namingSource: url)

        case (.video, _), (.audio, _):
            let dest = out()
            try await MediaConverter.convert(url, from: source, to: f, output: dest, options: options.video)
            return [dest]

        case (.font, _):
            let image = try fontSpecimen(url)
            let dest = out()
            try ImageEncoder.write(image, format: f, to: dest, options: options.image)
            return [dest]

        default:
            throw HexError.unsupportedConversion(from: source.displayName, to: f.displayName)
        }
    }

    // MARK: Helpers

    /// EPS / PostScript → PDF through Ghostscript (macOS 14+ removed PostScript support).
    static func postScriptToPDF(_ url: URL) throws -> URL {
        guard let gs = ExternalTools.path(.gs) else {
            throw HexError.missingTool(name: "Ghostscript", hint: ExternalTool.gs.installHint)
        }
        let dir = try FileWriter.makeTemporaryDirectory()
        let pdf = dir.appendingPathComponent("converted.pdf")
        let r = try ExternalTools.run(gs, ["-dSAFER", "-dBATCH", "-dNOPAUSE", "-dEPSCrop", "-sDEVICE=pdfwrite",
                                           "-sOutputFile=\(pdf.path)", url.path], timeout: 300)
        guard r.status == 0, FileManager.default.fileExists(atPath: pdf.path) else {
            try? FileManager.default.removeItem(at: dir)
            throw HexError.writeFailed("Ghostscript could not read the file.")
        }
        return pdf
    }

    /// Renders a specimen sheet for a font file (registered for this process only — never installed).
    public static func fontSpecimen(_ url: URL) throws -> CGImage {
        var registrationError: Unmanaged<CFError>?
        let registered = CTFontManagerRegisterFontsForURL(url as CFURL, .process, &registrationError)
        defer { if registered { CTFontManagerUnregisterFontsForURL(url as CFURL, .process, nil) } }
        guard let descriptors = CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as? [CTFontDescriptor],
              let first = descriptors.first else { throw HexError.unreadable(url.lastPathComponent) }
        let font = CTFontCreateWithFontDescriptor(first, 24, nil)
        let family = CTFontCopyFamilyName(font) as String
        guard let image = TextGraphics.specimen(family: family) else { throw HexError.message("The specimen could not be drawn.") }
        return image
    }
}
