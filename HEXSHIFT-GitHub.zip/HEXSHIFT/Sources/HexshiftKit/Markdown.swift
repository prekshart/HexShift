import AppKit
import Foundation

/// A small, dependency-free Markdown → HTML renderer (CommonMark-ish subset:
/// headings, paragraphs, emphasis, code, links, images, lists, quotes, rules, tables).
public enum MarkdownRenderer {
    public static func html(from markdown: String, title: String? = nil, standalone: Bool = true) -> String {
        let body = renderBlocks(markdown.replacingOccurrences(of: "\r\n", with: "\n").components(separatedBy: "\n"))
        guard standalone else { return body }
        return """
        <!DOCTYPE html>
        <html><head><meta charset="utf-8"><title>\(escape(title ?? "Document"))</title>
        <style>
        body { font-family: -apple-system, "Helvetica Neue", Helvetica, Arial, sans-serif; font-size: 12pt; line-height: 1.5; color: #222; }
        h1 { font-size: 22pt; margin: 0.6em 0 0.3em; } h2 { font-size: 17pt; margin: 0.6em 0 0.3em; } h3 { font-size: 14pt; }
        code { font-family: Menlo, monospace; font-size: 10.5pt; background: #f2f0ec; }
        pre { font-family: Menlo, monospace; font-size: 10pt; background: #f2f0ec; padding: 8px; }
        blockquote { color: #555; margin-left: 1em; padding-left: 0.8em; border-left: 3px solid #ddd; }
        table { border-collapse: collapse; } td, th { border: 1px solid #ccc; padding: 4px 8px; } th { background: #f2f0ec; }
        </style></head><body>
        \(body)
        </body></html>
        """
    }

    static func renderBlocks(_ lines: [String]) -> String {
        var out: [String] = []
        var i = 0
        var paragraph: [String] = []

        func flushParagraph() {
            if !paragraph.isEmpty {
                out.append("<p>" + inline(paragraph.joined(separator: " ")) + "</p>")
                paragraph.removeAll()
            }
        }

        while i < lines.count {
            let line = lines[i]
            let trimmed = line.trimmingCharacters(in: .whitespaces)

            if trimmed.isEmpty {
                flushParagraph()
                i += 1
                continue
            }
            // Fenced code
            if trimmed.hasPrefix("```") || trimmed.hasPrefix("~~~") {
                flushParagraph()
                let fence = String(trimmed.prefix(3))
                var code: [String] = []
                i += 1
                while i < lines.count && !lines[i].trimmingCharacters(in: .whitespaces).hasPrefix(fence) {
                    code.append(lines[i])
                    i += 1
                }
                i += 1
                out.append("<pre><code>" + escape(code.joined(separator: "\n")) + "</code></pre>")
                continue
            }
            // ATX heading
            if let level = headingLevel(trimmed) {
                flushParagraph()
                var text = String(trimmed.dropFirst(level)).trimmingCharacters(in: .whitespaces)
                while text.hasSuffix("#") { text.removeLast() }
                out.append("<h\(level)>" + inline(text.trimmingCharacters(in: .whitespaces)) + "</h\(level)>")
                i += 1
                continue
            }
            // Setext heading ("Title" underlined with === or ---)
            if paragraph.isEmpty, i + 1 < lines.count, listMarker(line) == nil {
                let next = lines[i + 1].trimmingCharacters(in: .whitespaces)
                let isEquals = !next.isEmpty && next.allSatisfy { $0 == "=" }
                let isDashes = next.count >= 2 && next.allSatisfy { $0 == "-" }
                if isEquals || isDashes {
                    let level = isEquals ? 1 : 2
                    out.append("<h\(level)>" + inline(trimmed) + "</h\(level)>")
                    i += 2
                    continue
                }
            }
            // Horizontal rule
            if isRule(trimmed) {
                flushParagraph()
                out.append("<hr>")
                i += 1
                continue
            }
            // Blockquote
            if trimmed.hasPrefix(">") {
                flushParagraph()
                var quote: [String] = []
                while i < lines.count, lines[i].trimmingCharacters(in: .whitespaces).hasPrefix(">") {
                    var q = lines[i].trimmingCharacters(in: .whitespaces)
                    q.removeFirst()
                    if q.hasPrefix(" ") { q.removeFirst() }
                    quote.append(q)
                    i += 1
                }
                out.append("<blockquote>" + renderBlocks(quote) + "</blockquote>")
                continue
            }
            // Table
            if trimmed.hasPrefix("|") || (trimmed.contains("|") && i + 1 < lines.count && isTableSeparator(lines[i + 1])) {
                if i + 1 < lines.count, isTableSeparator(lines[i + 1]) {
                    flushParagraph()
                    let header = tableCells(trimmed)
                    var rows: [[String]] = []
                    i += 2
                    while i < lines.count, lines[i].contains("|"), !lines[i].trimmingCharacters(in: .whitespaces).isEmpty {
                        rows.append(tableCells(lines[i]))
                        i += 1
                    }
                    var html = "<table><thead><tr>" + header.map { "<th>" + inline($0) + "</th>" }.joined() + "</tr></thead><tbody>"
                    for r in rows { html += "<tr>" + r.map { "<td>" + inline($0) + "</td>" }.joined() + "</tr>" }
                    out.append(html + "</tbody></table>")
                    continue
                }
            }
            // Lists
            if listMarker(line) != nil {
                flushParagraph()
                let (html, next) = renderList(lines, start: i)
                out.append(html)
                i = next
                continue
            }
            paragraph.append(trimmed)
            i += 1
        }
        flushParagraph()
        return out.joined(separator: "\n")
    }

    static func headingLevel(_ s: String) -> Int? {
        var n = 0
        for c in s { if c == "#" { n += 1 } else { break } }
        guard n >= 1, n <= 6 else { return nil }
        let rest = s.dropFirst(n)
        return rest.isEmpty || rest.first == " " ? n : nil
    }

    static func isRule(_ s: String) -> Bool {
        let compact = s.replacingOccurrences(of: " ", with: "")
        guard compact.count >= 3, let f = compact.first, "-*_".contains(f) else { return false }
        return compact.allSatisfy { $0 == f }
    }

    static func isTableSeparator(_ line: String) -> Bool {
        let t = line.trimmingCharacters(in: .whitespaces)
        guard t.contains("-") else { return false }
        return t.allSatisfy { "|-: ".contains($0) }
    }

    static func tableCells(_ line: String) -> [String] {
        var t = line.trimmingCharacters(in: .whitespaces)
        if t.hasPrefix("|") { t.removeFirst() }
        if t.hasSuffix("|") { t.removeLast() }
        return t.components(separatedBy: "|").map { $0.trimmingCharacters(in: .whitespaces) }
    }

    /// Returns (ordered, indent, content) when the line starts a list item.
    static func listMarker(_ line: String) -> (ordered: Bool, indent: Int, content: String)? {
        let indent = line.prefix(while: { $0 == " " || $0 == "\t" }).reduce(0) { $0 + ($1 == "\t" ? 4 : 1) }
        let t = line.trimmingCharacters(in: .whitespaces)
        for bullet in ["- ", "* ", "+ "] where t.hasPrefix(bullet) {
            if isRule(t) { return nil }
            return (false, indent, String(t.dropFirst(2)))
        }
        let digits = t.prefix(while: { $0.isNumber })
        if !digits.isEmpty, digits.count <= 9 {
            let rest = t.dropFirst(digits.count)
            if rest.hasPrefix(". ") || rest.hasPrefix(") ") { return (true, indent, String(rest.dropFirst(2))) }
        }
        return nil
    }

    static func renderList(_ lines: [String], start: Int) -> (String, Int) {
        guard let first = listMarker(lines[start]) else { return ("", start + 1) }
        let tag = first.ordered ? "ol" : "ul"
        var html = "<\(tag)>"
        var i = start
        while i < lines.count {
            guard let m = listMarker(lines[i]) else {
                // Continuation line for the previous item
                let t = lines[i].trimmingCharacters(in: .whitespaces)
                if t.isEmpty || lines[i].prefix(while: { $0 == " " }).count < first.indent + 2 { break }
                html = String(html.dropLast(5)) + " " + inline(t) + "</li>"
                i += 1
                continue
            }
            if m.indent > first.indent {
                let (nested, next) = renderList(lines, start: i)
                if html.hasSuffix("</li>") { html = String(html.dropLast(5)) + nested + "</li>" } else { html += nested }
                i = next
                continue
            }
            if m.indent < first.indent || m.ordered != first.ordered { break }
            var content = m.content
            var checkbox = ""
            if content.hasPrefix("[ ] ") { checkbox = "☐ "; content.removeFirst(4) }
            if content.lowercased().hasPrefix("[x] ") { checkbox = "☑ "; content.removeFirst(4) }
            html += "<li>" + checkbox + inline(content) + "</li>"
            i += 1
        }
        return (html + "</\(tag)>", i)
    }

    // MARK: Inline

    static func inline(_ text: String) -> String {
        // Protect code spans first.
        var codeSpans: [String] = []
        var working = ""
        var rest = Substring(text)
        while let open = rest.firstIndex(of: "`") {
            working += rest[..<open]
            let after = rest[rest.index(after: open)...]
            if let close = after.firstIndex(of: "`") {
                codeSpans.append("<code>" + escape(String(after[..<close])) + "</code>")
                working += "\u{0}\(codeSpans.count - 1)\u{0}"
                rest = after[after.index(after: close)...]
            } else {
                working += rest[open...]
                rest = ""
            }
        }
        working += rest
        var s = escape(working)
        // Images then links
        s = replace(s, #"!\[([^\]]*)\]\(([^)\s]+)(?:\s+&quot;[^&]*&quot;)?\)"#, "<img alt=\"$1\" src=\"$2\">")
        s = replace(s, #"\[([^\]]+)\]\(([^)\s]+)(?:\s+&quot;[^&]*&quot;)?\)"#, "<a href=\"$2\">$1</a>")
        s = replace(s, #"&lt;(https?://[^\s&]+)&gt;"#, "<a href=\"$1\">$1</a>")
        // Emphasis
        s = replace(s, #"\*\*\*(.+?)\*\*\*"#, "<strong><em>$1</em></strong>")
        s = replace(s, #"\*\*(.+?)\*\*"#, "<strong>$1</strong>")
        s = replace(s, #"__(.+?)__"#, "<strong>$1</strong>")
        s = replace(s, #"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])"#, "<em>$1</em>")
        s = replace(s, #"(?<![\w_])_(?!\s)(.+?)(?<!\s)_(?![\w_])"#, "<em>$1</em>")
        s = replace(s, #"~~(.+?)~~"#, "<del>$1</del>")
        // Hard line break: two trailing spaces were collapsed when joining; support backslash.
        s = s.replacingOccurrences(of: "\\ ", with: "<br>")
        for (i, code) in codeSpans.enumerated() {
            s = s.replacingOccurrences(of: "\u{0}\(i)\u{0}", with: code)
        }
        return s
    }

    static func replace(_ s: String, _ pattern: String, _ template: String) -> String {
        guard let re = try? NSRegularExpression(pattern: pattern) else { return s }
        return re.stringByReplacingMatches(in: s, range: NSRange(s.startIndex..., in: s), withTemplate: template)
    }

    public static func escape(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;").replacingOccurrences(of: "\"", with: "&quot;")
    }
}

/// Converts styled text back to Markdown (headings by size, bold/italic, links, lists, code).
public enum MarkdownWriter {
    public static func markdown(from attributed: NSAttributedString) -> String {
        let string = attributed.string as NSString
        guard string.length > 0 else { return "" }
        let bodySize = dominantFontSize(attributed)
        var output: [String] = []
        var location = 0
        while location < string.length {
            let paraRange = string.paragraphRange(for: NSRange(location: location, length: 0))
            location = NSMaxRange(paraRange)
            var contentRange = paraRange
            // Trim the trailing newline
            while contentRange.length > 0 {
                let c = string.character(at: NSMaxRange(contentRange) - 1)
                if c == 10 || c == 13 || c == 0x2029 || c == 0x2028 { contentRange.length -= 1 } else { break }
            }
            let raw = string.substring(with: contentRange)
            if raw.trimmingCharacters(in: .whitespaces).isEmpty {
                if output.last != "" { output.append("") }
                continue
            }
            let para = attributed.attributedSubstring(from: contentRange)
            let font = para.attribute(.font, at: 0, effectiveRange: nil) as? NSFont
            let size = maxFontSize(para) ?? font?.pointSize ?? bodySize
            var prefix = ""
            if let style = para.attribute(.paragraphStyle, at: 0, effectiveRange: nil) as? NSParagraphStyle,
               let list = style.textLists.last {
                let depth = max(0, style.textLists.count - 1)
                let indent = String(repeating: "  ", count: depth)
                let ordered = list.markerFormat.rawValue.contains("decimal")
                prefix = indent + (ordered ? "1. " : "- ")
            }
            var text = inlineMarkdown(para)
            if !prefix.isEmpty {
                // Strip the visible list marker AppKit inserts ("\t•\t")
                text = text.replacingOccurrences(of: #"^\s*(\t?[•◦▪‣⁃–\-]|\t?\d+[.)])\t"#, with: "", options: .regularExpression)
                output.append(prefix + text.trimmingCharacters(in: .whitespaces))
                continue
            }
            if isMonospaced(font) && raw.count > 0 {
                output.append("    " + raw)
                continue
            }
            if size >= bodySize * 1.6 {
                output.append("# " + plain(para))
            } else if size >= bodySize * 1.3 {
                output.append("## " + plain(para))
            } else if size >= bodySize * 1.12 {
                output.append("### " + plain(para))
            } else {
                output.append(text)
            }
            output.append("")
        }
        while output.last == "" { output.removeLast() }
        return output.joined(separator: "\n") + "\n"
    }

    static func plain(_ a: NSAttributedString) -> String {
        a.string.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func isMonospaced(_ font: NSFont?) -> Bool {
        guard let font else { return false }
        return font.fontDescriptor.symbolicTraits.contains(.monoSpace)
    }

    static func dominantFontSize(_ a: NSAttributedString) -> CGFloat {
        var counts: [CGFloat: Int] = [:]
        a.enumerateAttribute(.font, in: NSRange(location: 0, length: a.length)) { value, range, _ in
            if let f = value as? NSFont { counts[(f.pointSize * 2).rounded() / 2, default: 0] += range.length }
        }
        return counts.max(by: { $0.value < $1.value })?.key ?? 12
    }

    static func maxFontSize(_ a: NSAttributedString) -> CGFloat? {
        var size: CGFloat?
        a.enumerateAttribute(.font, in: NSRange(location: 0, length: a.length)) { value, _, _ in
            if let f = value as? NSFont { size = max(size ?? 0, f.pointSize) }
        }
        return size
    }

    static func inlineMarkdown(_ a: NSAttributedString) -> String {
        var result = ""
        a.enumerateAttributes(in: NSRange(location: 0, length: a.length)) { attrs, range, _ in
            var piece = (a.string as NSString).substring(with: range)
            if piece.isEmpty { return }
            let font = attrs[.font] as? NSFont
            let traits = font?.fontDescriptor.symbolicTraits ?? []
            let trimmed = piece.trimmingCharacters(in: .whitespaces)
            if !trimmed.isEmpty {
                let leading = String(piece.prefix(while: { $0 == " " }))
                let trailing = String(piece.reversed().prefix(while: { $0 == " " }))
                var core = trimmed
                if traits.contains(.monoSpace) {
                    core = "`" + core + "`"
                } else {
                    core = escapeMarkdown(core)
                    if traits.contains(.bold) && traits.contains(.italic) { core = "***" + core + "***" }
                    else if traits.contains(.bold) { core = "**" + core + "**" }
                    else if traits.contains(.italic) { core = "*" + core + "*" }
                }
                if let link = attrs[.link] {
                    let href = (link as? URL)?.absoluteString ?? (link as? String) ?? ""
                    if !href.isEmpty { core = "[" + core + "](" + href + ")" }
                }
                if (attrs[.strikethroughStyle] as? Int ?? 0) != 0 { core = "~~" + core + "~~" }
                piece = leading + core + trailing
            }
            result += piece
        }
        return result
    }

    static func escapeMarkdown(_ s: String) -> String {
        var out = ""
        for c in s {
            if "\\`*_[]#".contains(c) { out.append("\\") }
            out.append(c)
        }
        return out
    }
}
