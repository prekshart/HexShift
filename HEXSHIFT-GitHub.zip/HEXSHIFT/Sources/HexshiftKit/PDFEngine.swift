import AppKit
import CoreGraphics
import CoreText
import Foundation
import PDFKit
import Quartz

public enum PDFPageSize: String, Codable, CaseIterable, Sendable {
    case fitImage, a4, letter, legal, a5, a3

    public var title: String {
        switch self {
        case .fitImage: return "Fit to image"
        case .a4: return "A4"
        case .letter: return "US Letter"
        case .legal: return "US Legal"
        case .a5: return "A5"
        case .a3: return "A3"
        }
    }

    /// Portrait size in points.
    public var size: CGSize? {
        switch self {
        case .fitImage: return nil
        case .a4: return CGSize(width: 595.28, height: 841.89)
        case .letter: return CGSize(width: 612, height: 792)
        case .legal: return CGSize(width: 612, height: 1008)
        case .a5: return CGSize(width: 419.53, height: 595.28)
        case .a3: return CGSize(width: 841.89, height: 1190.55)
        }
    }
}

public enum PDFSplitMode: Codable, Hashable, Sendable {
    case everyPage
    case chunks(Int)
    /// e.g. "1-3, 4-6, 7"
    case ranges(String)
}

public enum PDFCompressionLevel: String, Codable, CaseIterable, Sendable {
    case balanced, strong

    public var title: String {
        switch self {
        case .balanced: return "Balanced (re-compress images for screen)"
        case .strong: return "Strong (smallest, lower image quality)"
        }
    }
}

public struct PDFFontInfo: Hashable, Sendable {
    public let name: String
    public let rawName: String
    public let type: String
    public let embedded: Bool
    public var subset: Bool { rawName.range(of: "^[A-Z]{6}\\+", options: .regularExpression) != nil }
}

/// A rectangle to redact, in the page's visual coordinate space
/// (points, origin bottom-left, page rotation already applied).
public struct RedactionArea: Codable, Hashable, Sendable {
    public var pageIndex: Int
    public var rect: CGRect
    public init(pageIndex: Int, rect: CGRect) {
        self.pageIndex = pageIndex
        self.rect = rect
    }

    public func hash(into hasher: inout Hasher) {
        hasher.combine(pageIndex)
        hasher.combineRect(rect)
    }
}

public enum PageNumberPosition: String, Codable, CaseIterable, Sendable {
    case bottomCenter, bottomRight, bottomLeft, topCenter, topRight, topLeft

    public var title: String {
        switch self {
        case .bottomCenter: return "Bottom centre"
        case .bottomRight: return "Bottom right"
        case .bottomLeft: return "Bottom left"
        case .topCenter: return "Top centre"
        case .topRight: return "Top right"
        case .topLeft: return "Top left"
        }
    }
}

public enum PDFEngine {
    // MARK: Opening

    public static func open(_ url: URL, password: String? = nil) throws -> PDFDocument {
        guard let doc = PDFDocument(url: url) else { throw HexError.unreadable(url.lastPathComponent) }
        if doc.isLocked {
            if !doc.unlock(withPassword: password ?? "") {
                throw HexError.message("“\(url.lastPathComponent)” is password-protected. Use PDF & Documents › Remove Password first, then try again.")
            }
        }
        return doc
    }

    public static func pageCount(_ url: URL) -> Int {
        PDFDocument(url: url)?.pageCount ?? CGPDFDocument(url as CFURL)?.numberOfPages ?? 0
    }

    // MARK: Geometry

    /// Size of the page as it appears on screen (crop box, rotation applied).
    public static func visualSize(_ page: CGPDFPage) -> CGSize {
        let box = page.getBoxRect(.cropBox)
        let rot = ((page.rotationAngle % 360) + 360) % 360
        return (rot == 90 || rot == 270) ? CGSize(width: box.height, height: box.width) : box.size
    }

    /// Maps the page's native coordinates to its upright visual rectangle.
    public static func drawingTransform(_ page: CGPDFPage) -> CGAffineTransform {
        page.getDrawingTransform(.cropBox, rect: CGRect(origin: .zero, size: visualSize(page)), rotate: 0, preserveAspectRatio: true)
    }

    /// Draws page content plus visible annotations (comments, form values, stamps).
    static func drawPage(_ page: PDFPage, in ctx: CGContext, includeAnnotations: Bool = true) {
        guard let ref = page.pageRef else { return }
        let t = drawingTransform(ref)
        ctx.saveGState()
        ctx.concatenate(t)
        ctx.clip(to: ref.getBoxRect(.cropBox))
        ctx.drawPDFPage(ref)
        if includeAnnotations {
            for annotation in page.annotations where annotation.shouldDisplay {
                let type = annotation.type ?? ""
                if type == "Popup" || type == "Link" { continue }
                annotation.draw(with: .cropBox, in: ctx)
            }
        }
        ctx.restoreGState()
    }

    // MARK: Rendering to images

    public static func render(_ page: PDFPage, dpi: Double, transparent: Bool = false) -> CGImage? {
        guard let ref = page.pageRef else { return nil }
        let size = visualSize(ref)
        guard size.width > 0, size.height > 0 else { return nil }
        var scale = max(0.1, dpi / 72)
        // Keep memory bounded for huge pages.
        scale = min(scale, 16000 / max(size.width, size.height))
        let area = Double(size.width * size.height) * scale * scale
        if area > 150_000_000 { scale *= (150_000_000 / area).squareRoot() }
        let w = max(1, Int((size.width * scale).rounded()))
        let h = max(1, Int((size.height * scale).rounded()))
        guard let ctx = ImageOps.makeContext(width: w, height: h, space: ImageOps.sRGB, opaque: !transparent) else { return nil }
        if !transparent {
            ctx.setFillColor(RGBAColour.white.cgColor)
            ctx.fill(CGRect(x: 0, y: 0, width: w, height: h))
        }
        ctx.interpolationQuality = .high
        ctx.setShouldAntialias(true)
        ctx.scaleBy(x: scale, y: scale)
        drawPage(page, in: ctx)
        return ctx.makeImage()
    }

    /// Exports pages as images. `pages` are 0-based; nil means all pages.
    public static func exportPages(_ url: URL, pages: [Int]?, dpi: Double, format: Format,
                                   options: ImageExportOptions, planner: OutputPlanner,
                                   transparentBackground: Bool = false, namingSource: URL? = nil,
                                   progress: ((Int, Int) -> Void)? = nil) throws -> [URL] {
        let doc = try open(url)
        let all = Array(0..<doc.pageCount)
        let indices = (pages ?? all).filter { $0 >= 0 && $0 < doc.pageCount }
        guard !indices.isEmpty else { throw HexError.message("No valid pages were selected.") }
        var outputs: [URL] = []
        for (n, i) in indices.enumerated() {
            try Task.checkCancellation()
            guard let page = doc.page(at: i),
                  let image = render(page, dpi: dpi, transparent: transparentBackground && format.supportsAlpha) else {
                throw HexError.message("Page \(i + 1) could not be rendered.")
            }
            let out = planner.url(for: namingSource ?? url, ext: format.fileExtension, format: format.displayName,
                                  part: i + 1, partCount: doc.pageCount, pixelSize: (image.width, image.height))
            var opts = options
            opts.dpi = dpi
            try ImageEncoder.write(image, format: format, to: out, options: opts)
            outputs.append(out)
            progress?(n + 1, indices.count)
        }
        return outputs
    }

    // MARK: Creating PDFs

    static func pageInfo(_ rect: CGRect) -> CFDictionary {
        var r = rect
        let data = Data(bytes: &r, count: MemoryLayout<CGRect>.size)
        return [kCGPDFContextMediaBox as String: data as CFData] as CFDictionary
    }

    /// Builds a PDF with one page per image.
    public static func makePDF(fromImages urls: [URL], output: URL, pageSize: PDFPageSize = .fitImage,
                               margin: CGFloat = 0, fill: Bool = false) throws {
        guard !urls.isEmpty else { throw HexError.message("Choose at least one image.") }
        try FileWriter.writeAtomically(to: output) { tmp in
            var box = CGRect(x: 0, y: 0, width: 612, height: 792)
            guard let ctx = CGContext(tmp as CFURL, mediaBox: &box, [kCGPDFContextCreator: "HEXSHIFT"] as CFDictionary) else {
                throw HexError.writeFailed("Could not create the PDF.")
            }
            for url in urls {
                try Task.checkCancellation()
                let loaded = try ImageLoader.load(url)
                drawImagePage(loaded.image, dpi: ImageEncoder.dpi(from: loaded.properties) ?? 72, in: ctx,
                              pageSize: pageSize, margin: margin, fill: fill)
            }
            ctx.closePDF()
            try ImageEncoder.validate(tmp, format: .pdf)
        }
    }

    static func drawImagePage(_ image: CGImage, dpi: Double, in ctx: CGContext, pageSize: PDFPageSize, margin: CGFloat, fill: Bool) {
        let iw = CGFloat(image.width) * 72 / CGFloat(dpi > 0 ? dpi : 72)
        let ih = CGFloat(image.height) * 72 / CGFloat(dpi > 0 ? dpi : 72)
        var pageRect: CGRect
        var drawRect: CGRect
        if var s = pageSize.size {
            if iw > ih && s.height > s.width { s = CGSize(width: s.height, height: s.width) }
            pageRect = CGRect(origin: .zero, size: s)
            let avail = pageRect.insetBy(dx: margin, dy: margin)
            let scale = fill ? max(avail.width / iw, avail.height / ih) : min(avail.width / iw, avail.height / ih)
            drawRect = CGRect(x: avail.midX - iw * scale / 2, y: avail.midY - ih * scale / 2, width: iw * scale, height: ih * scale)
        } else {
            pageRect = CGRect(x: 0, y: 0, width: iw + margin * 2, height: ih + margin * 2)
            drawRect = CGRect(x: margin, y: margin, width: iw, height: ih)
        }
        ctx.beginPDFPage(pageInfo(pageRect))
        ctx.saveGState()
        ctx.clip(to: pageRect)
        ctx.interpolationQuality = .high
        ctx.draw(image, in: drawRect)
        ctx.restoreGState()
        ctx.endPDFPage()
    }

    /// Combines PDFs (all pages) and images (one page each) in order.
    public static func merge(_ urls: [URL], output: URL, imagePageSize: PDFPageSize = .fitImage) throws {
        guard !urls.isEmpty else { throw HexError.message("Choose files to merge.") }
        let merged = PDFDocument()
        let tmpDir = try FileWriter.makeTemporaryDirectory()
        defer { try? FileManager.default.removeItem(at: tmpDir) }
        for url in urls {
            try Task.checkCancellation()
            let format = Format.detect(url)
            var source: PDFDocument
            if format == .pdf || format == .ai {
                source = try open(url)
            } else if format?.category == .raster {
                let tmp = tmpDir.appendingPathComponent(UUID().uuidString + ".pdf")
                try makePDF(fromImages: [url], output: tmp, pageSize: imagePageSize)
                source = try open(tmp)
            } else {
                throw HexError.message("“\(url.lastPathComponent)” is not a PDF or image, so it can't be merged directly. Convert it to PDF first.")
            }
            for i in 0..<source.pageCount {
                if let page = source.page(at: i)?.copy() as? PDFPage {
                    merged.insert(page, at: merged.pageCount)
                }
            }
        }
        try save(merged, to: output)
    }

    public static func save(_ doc: PDFDocument, to url: URL, options: [PDFDocumentWriteOption: Any] = [:], allowOverwrite: Bool = false) throws {
        try FileWriter.writeAtomically(to: url, allowOverwrite: allowOverwrite) { tmp in
            let ok = options.isEmpty ? doc.write(to: tmp) : doc.write(to: tmp, withOptions: options)
            guard ok else { throw HexError.writeFailed("PDFKit could not write the document.") }
            try ImageEncoder.validate(tmp, format: .pdf)
        }
    }

    // MARK: Page operations

    /// Parses "1-3, 5, 8-" into 0-based page indices.
    public static func parsePageList(_ text: String, pageCount: Int) -> [Int]? {
        let trimmed = text.trimmingCharacters(in: .whitespaces).lowercased()
        if trimmed.isEmpty || trimmed == "all" { return Array(0..<pageCount) }
        guard let ranges = parseRanges(trimmed, pageCount: pageCount) else { return nil }
        var seen = Set<Int>()
        return ranges.flatMap { $0 }.filter { seen.insert($0).inserted }
    }

    public static func parseRanges(_ text: String, pageCount: Int) -> [[Int]]? {
        var result: [[Int]] = []
        for part in text.split(whereSeparator: { $0 == "," || $0 == ";" }) {
            let token = part.trimmingCharacters(in: .whitespaces)
            if token.isEmpty { continue }
            let pieces = token.split(separator: "-", omittingEmptySubsequences: false).map { $0.trimmingCharacters(in: .whitespaces) }
            if pieces.count == 1 {
                guard let n = Int(pieces[0]), n >= 1, n <= pageCount else { return nil }
                result.append([n - 1])
            } else if pieces.count == 2 {
                let a = pieces[0].isEmpty ? 1 : Int(pieces[0])
                let b = pieces[1].isEmpty ? pageCount : Int(pieces[1])
                guard let a, let b, a >= 1, b >= a, b <= pageCount else { return nil }
                result.append(Array((a - 1)...(b - 1)))
            } else {
                return nil
            }
        }
        return result.isEmpty ? nil : result
    }

    public static func extractPages(_ url: URL, pages: [Int], output: URL) throws {
        let doc = try open(url)
        let out = PDFDocument()
        for i in pages where i >= 0 && i < doc.pageCount {
            if let p = doc.page(at: i)?.copy() as? PDFPage { out.insert(p, at: out.pageCount) }
        }
        guard out.pageCount > 0 else { throw HexError.message("No valid pages were selected.") }
        try save(out, to: output)
    }

    public static func split(_ url: URL, mode: PDFSplitMode, planner: OutputPlanner) throws -> [URL] {
        let doc = try open(url)
        let n = doc.pageCount
        var groups: [[Int]] = []
        switch mode {
        case .everyPage:
            groups = (0..<n).map { [$0] }
        case let .chunks(size):
            let s = max(1, size)
            groups = stride(from: 0, to: n, by: s).map { Array($0..<min(n, $0 + s)) }
        case let .ranges(text):
            guard let r = parseRanges(text, pageCount: n) else { throw HexError.message("The page ranges “\(text)” aren't valid for a \(n)-page document.") }
            groups = r
        }
        var outputs: [URL] = []
        for (gi, group) in groups.enumerated() {
            try Task.checkCancellation()
            let part = PDFDocument()
            for i in group {
                if let p = doc.page(at: i)?.copy() as? PDFPage { part.insert(p, at: part.pageCount) }
            }
            let out = planner.url(for: url, ext: "pdf", format: "PDF", part: gi + 1, partCount: groups.count)
            try save(part, to: out)
            outputs.append(out)
        }
        return outputs
    }

    public static func rotate(_ doc: PDFDocument, pages: [Int], by degrees: Int) {
        for i in pages {
            guard let p = doc.page(at: i) else { continue }
            p.rotation = (((p.rotation + degrees) % 360) + 360) % 360
        }
    }

    // MARK: Optimisation

    public struct CompressionResult: Sendable {
        public let before: Int64
        public let after: Int64
        public var saving: Double { before > 0 ? 1 - Double(after) / Double(before) : 0 }
    }

    public static func compress(_ url: URL, output: URL, level: PDFCompressionLevel = .balanced) throws -> CompressionResult {
        let before = fileSize(url)
        if level == .strong, let gs = ExternalTools.path(.gs) {
            try FileWriter.writeAtomically(to: output) { tmp in
                let r = try ExternalTools.run(gs, ["-sDEVICE=pdfwrite", "-dCompatibilityLevel=1.6", "-dPDFSETTINGS=/ebook",
                                                   "-dNOPAUSE", "-dQUIET", "-dBATCH", "-dSAFER", "-sOutputFile=\(tmp.path)", url.path])
                guard r.status == 0 else { throw HexError.writeFailed("Ghostscript failed: \(r.stderr.prefix(200))") }
                try ImageEncoder.validate(tmp, format: .pdf)
            }
        } else {
            let doc = try open(url)
            var options: [PDFDocumentWriteOption: Any] = [.saveImagesAsJPEGOption: true, .optimizeImagesForScreenOption: true]
            let filterURL = URL(fileURLWithPath: "/System/Library/Filters/Reduce File Size.qfilter")
            if level == .strong, FileManager.default.fileExists(atPath: filterURL.path) {
                let filter: QuartzFilter? = QuartzFilter(url: filterURL)
                if let filter { options = [PDFDocumentWriteOption(rawValue: "QuartzFilter"): filter] }
            }
            try save(doc, to: output, options: options)
        }
        let after = fileSize(output)
        if after >= before {
            try? FileManager.default.removeItem(at: output)
            throw HexError.message("This PDF is already well optimised — compressing it would not make it smaller, so no copy was saved.")
        }
        return CompressionResult(before: before, after: after)
    }

    /// Removes title, author, subject, keywords, creator and producer.
    public static func stripMetadata(_ url: URL, output: URL) throws {
        let doc = try open(url)
        doc.documentAttributes = [:]
        try save(doc, to: output)
    }

    public static func fileSize(_ url: URL) -> Int64 {
        Int64((try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0)
    }

    // MARK: Text

    public struct ExtractedText: Sendable {
        public let text: String
        public let usedOCR: Bool
        public let lowConfidenceLines: Int
    }

    public static func extractText(_ url: URL, ocrIfNeeded: Bool = true, progress: ((Int, Int) -> Void)? = nil) throws -> ExtractedText {
        let doc = try open(url)
        var parts: [String] = []
        var usedOCR = false
        var lowConfidence = 0
        for i in 0..<doc.pageCount {
            try Task.checkCancellation()
            guard let page = doc.page(at: i) else { continue }
            var text = page.string ?? ""
            if ocrIfNeeded && text.trimmingCharacters(in: .whitespacesAndNewlines).count < 3,
               let image = render(page, dpi: 220) {
                let result = try OCRService.recognize(image)
                text = result.text
                lowConfidence += result.uncertainLines.count
                usedOCR = true
            }
            parts.append(text.trimmingCharacters(in: .newlines))
            progress?(i + 1, doc.pageCount)
        }
        return ExtractedText(text: parts.joined(separator: "\n\n"), usedOCR: usedOCR, lowConfidenceLines: lowConfidence)
    }

    /// Styled text (fonts, sizes) for conversions to Word/RTF/HTML.
    public static func attributedText(_ url: URL) throws -> NSAttributedString {
        let doc = try open(url)
        let result = NSMutableAttributedString()
        for i in 0..<doc.pageCount {
            guard let page = doc.page(at: i) else { continue }
            if let a = page.attributedString, a.length > 0 {
                if result.length > 0 { result.append(NSAttributedString(string: "\n\n")) }
                result.append(a)
            } else if let image = render(page, dpi: 220), let ocr = try? OCRService.recognize(image), !ocr.text.isEmpty {
                if result.length > 0 { result.append(NSAttributedString(string: "\n\n")) }
                result.append(NSAttributedString(string: ocr.text, attributes: [.font: NSFont.systemFont(ofSize: 12)]))
            }
        }
        return result
    }

    /// Adds an invisible OCR text layer so scanned pages become searchable and selectable.
    @discardableResult
    public static func makeSearchable(_ url: URL, output: URL, dpi: Double = 300, skipPagesWithText: Bool = true,
                                      progress: ((Int, Int) -> Void)? = nil) throws -> Int {
        let doc = try open(url)
        var recognisedPages = 0
        try FileWriter.writeAtomically(to: output) { tmp in
            var box = CGRect(x: 0, y: 0, width: 612, height: 792)
            guard let ctx = CGContext(tmp as CFURL, mediaBox: &box, [kCGPDFContextCreator: "HEXSHIFT"] as CFDictionary) else {
                throw HexError.writeFailed("Could not create the PDF.")
            }
            for i in 0..<doc.pageCount {
                try Task.checkCancellation()
                guard let page = doc.page(at: i), let ref = page.pageRef else { continue }
                let size = visualSize(ref)
                ctx.beginPDFPage(pageInfo(CGRect(origin: .zero, size: size)))
                drawPage(page, in: ctx)
                let hasText = (page.string ?? "").trimmingCharacters(in: .whitespacesAndNewlines).count > 3
                if !(skipPagesWithText && hasText), let image = render(page, dpi: dpi) {
                    let result = try OCRService.recognize(image)
                    drawInvisibleText(result, in: ctx, pageSize: size)
                    if !result.lines.isEmpty { recognisedPages += 1 }
                }
                ctx.endPDFPage()
                progress?(i + 1, doc.pageCount)
            }
            ctx.closePDF()
            try ImageEncoder.validate(tmp, format: .pdf)
        }
        return recognisedPages
    }

    static func drawInvisibleText(_ result: OCRResult, in ctx: CGContext, pageSize: CGSize) {
        ctx.saveGState()
        ctx.setTextDrawingMode(.invisible)
        for line in result.lines {
            let b = line.boundingBox
            let rect = CGRect(x: b.minX * pageSize.width, y: b.minY * pageSize.height,
                              width: b.width * pageSize.width, height: b.height * pageSize.height)
            guard rect.width > 1, rect.height > 1, !line.text.isEmpty else { continue }
            let font = CTFontCreateWithName("Helvetica" as CFString, rect.height * 0.8, nil)
            let attr = NSAttributedString(string: line.text, attributes: [NSAttributedString.Key(kCTFontAttributeName as String): font])
            let ctLine = CTLineCreateWithAttributedString(attr)
            let width = CTLineGetTypographicBounds(ctLine, nil, nil, nil)
            guard width > 0 else { continue }
            ctx.saveGState()
            ctx.textMatrix = .identity
            ctx.translateBy(x: rect.minX, y: rect.minY + rect.height * 0.18)
            ctx.scaleBy(x: rect.width / CGFloat(width), y: 1)
            ctx.textPosition = .zero
            CTLineDraw(ctLine, ctx)
            ctx.restoreGState()
        }
        ctx.restoreGState()
    }

    // MARK: Redaction (true, irreversible)

    /// Finds every occurrence of the terms and returns their rectangles.
    public static func redactionAreas(matching terms: [String], in url: URL, caseSensitive: Bool = false) throws -> [RedactionArea] {
        let doc = try open(url)
        var areas: [RedactionArea] = []
        for term in terms.map({ $0.trimmingCharacters(in: .whitespacesAndNewlines) }) where !term.isEmpty {
            let selections = doc.findString(term, withOptions: caseSensitive ? [] : [.caseInsensitive])
            for selection in selections {
                for page in selection.pages {
                    let index = doc.index(for: page)
                    guard let ref = page.pageRef else { continue }
                    let t = drawingTransform(ref)
                    for line in selection.selectionsByLine() {
                        let r = line.bounds(for: page)
                        guard r.width > 0, r.height > 0 else { continue }
                        areas.append(RedactionArea(pageIndex: index, rect: r.applying(t).insetBy(dx: -1.5, dy: -1.5)))
                    }
                }
            }
        }
        return areas
    }

    /// Pages containing redactions are flattened to images with the areas painted
    /// black, so the underlying text and vectors are destroyed — not merely covered.
    /// Other pages keep their vector content. Document metadata is not copied.
    public static func redact(_ url: URL, areas: [RedactionArea], output: URL, dpi: Double = 200,
                              keepTextSearchable: Bool = true) throws {
        guard !areas.isEmpty else { throw HexError.message("Mark at least one area to redact.") }
        let doc = try open(url)
        let byPage = Dictionary(grouping: areas, by: { $0.pageIndex })
        try FileWriter.writeAtomically(to: output) { tmp in
            var box = CGRect(x: 0, y: 0, width: 612, height: 792)
            guard let ctx = CGContext(tmp as CFURL, mediaBox: &box, [kCGPDFContextCreator: "HEXSHIFT"] as CFDictionary) else {
                throw HexError.writeFailed("Could not create the PDF.")
            }
            for i in 0..<doc.pageCount {
                try Task.checkCancellation()
                guard let page = doc.page(at: i), let ref = page.pageRef else { continue }
                let size = visualSize(ref)
                let pageRect = CGRect(origin: .zero, size: size)
                ctx.beginPDFPage(pageInfo(pageRect))
                if let rects = byPage[i], !rects.isEmpty {
                    guard var image = render(page, dpi: dpi) else { throw HexError.message("Page \(i + 1) could not be rendered for redaction.") }
                    image = paintBoxes(on: image, rects: rects.map { $0.rect }, pageSize: size) ?? image
                    ctx.interpolationQuality = .high
                    ctx.draw(image, in: pageRect)
                    if keepTextSearchable, let ocr = try? OCRService.recognize(image) {
                        drawInvisibleText(ocr, in: ctx, pageSize: size)
                    }
                } else {
                    drawPage(page, in: ctx)
                }
                ctx.endPDFPage()
            }
            ctx.closePDF()
            try ImageEncoder.validate(tmp, format: .pdf)
        }
    }

    static func paintBoxes(on image: CGImage, rects: [CGRect], pageSize: CGSize) -> CGImage? {
        guard let ctx = ImageOps.makeContext(width: image.width, height: image.height, opaque: true) else { return nil }
        let full = CGRect(x: 0, y: 0, width: image.width, height: image.height)
        ctx.draw(image, in: full)
        let sx = CGFloat(image.width) / pageSize.width
        let sy = CGFloat(image.height) / pageSize.height
        ctx.setFillColor(RGBAColour.black.cgColor)
        for r in rects {
            ctx.fill(CGRect(x: r.minX * sx, y: r.minY * sy, width: r.width * sx, height: r.height * sy).integral)
        }
        return ctx.makeImage()
    }

    // MARK: Annotations and stamps

    /// Adds page numbers as text annotations (kept as real annotations so the
    /// rest of the document — links, forms, outlines — is untouched).
    public static func addPageNumbers(_ url: URL, output: URL, format: String = "{n}", position: PageNumberPosition = .bottomCenter,
                                      fontSize: CGFloat = 10, startAt: Int = 1, skipFirstPage: Bool = false) throws {
        let doc = try open(url)
        let total = doc.pageCount
        for i in 0..<total {
            if skipFirstPage && i == 0 { continue }
            guard let page = doc.page(at: i) else { continue }
            let n = i + startAt - (skipFirstPage ? 1 : 0)
            let text = format.replacingOccurrences(of: "{n}", with: "\(n)").replacingOccurrences(of: "{total}", with: "\(total)")
            let bounds = page.bounds(for: .cropBox)
            let width: CGFloat = max(80, CGFloat(text.count) * fontSize * 0.7)
            let height = fontSize * 1.8
            let margin: CGFloat = 24
            let rect = annotationRect(for: position, in: bounds, rotation: page.rotation, size: CGSize(width: width, height: height), margin: margin)
            let annotation = PDFAnnotation(bounds: rect, forType: .freeText, withProperties: nil)
            annotation.contents = text
            annotation.font = NSFont.systemFont(ofSize: fontSize)
            annotation.fontColor = NSColor(white: 0.2, alpha: 1)
            annotation.color = .clear
            switch position {
            case .bottomCenter, .topCenter: annotation.alignment = .center
            case .bottomRight, .topRight: annotation.alignment = .right
            case .bottomLeft, .topLeft: annotation.alignment = .left
            }
            let border = PDFBorder()
            border.lineWidth = 0
            annotation.border = border
            page.addAnnotation(annotation)
        }
        try save(doc, to: output)
    }

    /// Positions in page space for an upright visual position (handles rotated pages).
    static func annotationRect(for position: PageNumberPosition, in bounds: CGRect, rotation: Int, size: CGSize, margin: CGFloat) -> CGRect {
        // Work in visual space, then rotate back into page space.
        let rot = ((rotation % 360) + 360) % 360
        let vw = (rot == 90 || rot == 270) ? bounds.height : bounds.width
        let vh = (rot == 90 || rot == 270) ? bounds.width : bounds.height
        var x: CGFloat
        let y: CGFloat
        switch position {
        case .bottomCenter, .topCenter: x = (vw - size.width) / 2
        case .bottomRight, .topRight: x = vw - size.width - margin
        case .bottomLeft, .topLeft: x = margin
        }
        x = max(0, x)
        switch position {
        case .bottomCenter, .bottomRight, .bottomLeft: y = margin - size.height / 4
        default: y = vh - margin - size.height
        }
        let visual = CGRect(x: x, y: max(0, y), width: size.width, height: size.height)
        // Map the visual rect back to unrotated page space.
        // /Rotate turns the page clockwise for display.
        var r: CGRect
        switch rot {
        case 90: r = CGRect(x: bounds.width - visual.maxY, y: visual.minX, width: visual.height, height: visual.width)
        case 180: r = CGRect(x: bounds.width - visual.maxX, y: bounds.height - visual.maxY, width: visual.width, height: visual.height)
        case 270: r = CGRect(x: visual.minY, y: bounds.height - visual.maxX, width: visual.height, height: visual.width)
        default: r = visual
        }
        return r.offsetBy(dx: bounds.minX, dy: bounds.minY)
    }

    /// Highlights (or underlines) every occurrence of a phrase.
    @discardableResult
    public static func markText(_ url: URL, terms: [String], output: URL, underline: Bool = false,
                                colour: NSColor = NSColor(red: 1, green: 0.85, blue: 0.2, alpha: 0.5)) throws -> Int {
        let doc = try open(url)
        var count = 0
        for term in terms where !term.isEmpty {
            for selection in doc.findString(term, withOptions: [.caseInsensitive]) {
                for line in selection.selectionsByLine() {
                    for page in line.pages {
                        let b = line.bounds(for: page)
                        guard b.width > 0 else { continue }
                        let a = PDFAnnotation(bounds: b, forType: underline ? .underline : .highlight, withProperties: nil)
                        a.color = underline ? NSColor.systemRed : colour
                        a.quadrilateralPoints = [
                            NSValue(point: NSPoint(x: 0, y: b.height)), NSValue(point: NSPoint(x: b.width, y: b.height)),
                            NSValue(point: NSPoint(x: 0, y: 0)), NSValue(point: NSPoint(x: b.width, y: 0)),
                        ]
                        page.addAnnotation(a)
                        count += 1
                    }
                }
            }
        }
        guard count > 0 else { throw HexError.message("The text wasn't found in this PDF.") }
        try save(doc, to: output)
        return count
    }

    /// Places an image (e.g. a signature) on a page and flattens it into the page content.
    public static func placeImage(_ image: CGImage, on url: URL, pageIndex: Int, visualRect: CGRect, output: URL) throws {
        let doc = try open(url)
        guard let page = doc.page(at: pageIndex), let ref = page.pageRef else { throw HexError.message("That page doesn't exist.") }
        let inverse = drawingTransform(ref).inverted()
        let pageRect = visualRect.applying(inverse)
        let annotation = ImageStampAnnotation(bounds: pageRect, image: image, rotation: page.rotation)
        page.addAnnotation(annotation)
        try save(doc, to: output, options: [.burnInAnnotationsOption: true])
    }

    /// Adds a diagonal text watermark/stamp on every page (flattened).
    public static func stampText(_ text: String, on url: URL, output: URL, opacity: CGFloat = 0.18) throws {
        let doc = try open(url)
        for i in 0..<doc.pageCount {
            guard let page = doc.page(at: i) else { continue }
            let annotation = TextStampAnnotation(bounds: page.bounds(for: .cropBox), text: text, opacity: opacity, rotation: page.rotation)
            page.addAnnotation(annotation)
        }
        try save(doc, to: output, options: [.burnInAnnotationsOption: true])
    }

    // MARK: Page size & margins

    public enum PageOrientation: String, Codable, CaseIterable, Sendable {
        case matchEachPage, portrait, landscape
        public var title: String {
            switch self {
            case .matchEachPage: return "Match each page"
            case .portrait: return "Portrait"
            case .landscape: return "Landscape"
            }
        }
    }

    /// Puts every page on a new page size (or its own size when `size` is `.fitImage`) with the
    /// given margin, scaling the content to fit and centring it. Text and vectors stay vector and
    /// selectable; links and form fields are not carried over (their appearance is).
    public static func resizePages(_ url: URL, output: URL, size: PDFPageSize, orientation: PageOrientation = .matchEachPage,
                                   margin: CGFloat = 0, allowEnlarge: Bool = true) throws {
        let doc = try open(url)
        guard doc.pageCount > 0 else { throw HexError.message("The PDF has no pages.") }
        try FileWriter.writeAtomically(to: output) { tmp in
            var box = CGRect(x: 0, y: 0, width: 612, height: 792)
            var info: [CFString: Any] = [kCGPDFContextCreator: "HEXSHIFT"]
            if let title = doc.documentAttributes?[PDFDocumentAttribute.titleAttribute] as? String { info[kCGPDFContextTitle] = title }
            guard let ctx = CGContext(tmp as CFURL, mediaBox: &box, info as CFDictionary) else {
                throw HexError.writeFailed("Could not create the PDF.")
            }
            for i in 0..<doc.pageCount {
                try Task.checkCancellation()
                guard let page = doc.page(at: i), let ref = page.pageRef else { continue }
                let original = visualSize(ref)
                var target = size.size ?? CGSize(width: original.width + margin * 2, height: original.height + margin * 2)
                let wantsLandscape: Bool
                switch orientation {
                case .matchEachPage: wantsLandscape = original.width > original.height
                case .portrait: wantsLandscape = false
                case .landscape: wantsLandscape = true
                }
                if size.size != nil, wantsLandscape != (target.width > target.height) {
                    target = CGSize(width: target.height, height: target.width)
                }
                let content = CGRect(x: margin, y: margin, width: max(1, target.width - margin * 2), height: max(1, target.height - margin * 2))
                var scale = min(content.width / original.width, content.height / original.height)
                if !allowEnlarge { scale = min(scale, 1) }
                let drawn = CGSize(width: original.width * scale, height: original.height * scale)
                let pageRect = CGRect(origin: .zero, size: target)
                ctx.beginPDFPage(pageInfo(pageRect))
                ctx.saveGState()
                ctx.translateBy(x: content.minX + (content.width - drawn.width) / 2, y: content.minY + (content.height - drawn.height) / 2)
                ctx.scaleBy(x: scale, y: scale)
                drawPage(page, in: ctx)
                ctx.restoreGState()
                ctx.endPDFPage()
            }
            ctx.closePDF()
            try ImageEncoder.validate(tmp, format: .pdf)
        }
    }

    // MARK: Markup (kept as real, editable PDF annotations)

    /// Converts a rectangle in the page's upright visual space (points, bottom-left origin)
    /// to PDF page space, which is what annotations use.
    public static func pageRect(fromVisual rect: CGRect, on page: PDFPage) -> CGRect {
        guard let ref = page.pageRef else { return rect }
        return rect.applying(drawingTransform(ref).inverted()).standardized
    }

    public static func pagePoint(fromVisual point: CGPoint, on page: PDFPage) -> CGPoint {
        guard let ref = page.pageRef else { return point }
        return point.applying(drawingTransform(ref).inverted())
    }

    @discardableResult
    public static func addTextBox(_ text: String, to page: PDFPage, visualRect: CGRect, fontSize: CGFloat = 14,
                                  colour: RGBAColour = .black) -> PDFAnnotation {
        let bounds = pageRect(fromVisual: visualRect, on: page)
        let a = PDFAnnotation(bounds: bounds, forType: .freeText, withProperties: nil)
        a.contents = text
        a.font = NSFont.systemFont(ofSize: fontSize)
        a.fontColor = NSColor(srgbRed: colour.r, green: colour.g, blue: colour.b, alpha: colour.a)
        a.color = .clear
        a.alignment = .left
        let border = PDFBorder()
        border.lineWidth = 0
        a.border = border
        page.addAnnotation(a)
        return a
    }

    @discardableResult
    public static func addNote(_ text: String, to page: PDFPage, visualPoint: CGPoint) -> PDFAnnotation {
        let p = pagePoint(fromVisual: visualPoint, on: page)
        let a = PDFAnnotation(bounds: CGRect(x: p.x, y: p.y - 22, width: 22, height: 22), forType: .text, withProperties: nil)
        a.contents = text
        a.iconType = .comment
        a.color = NSColor(srgbRed: 1, green: 0.84, blue: 0.2, alpha: 1)
        a.userName = NSFullUserName()
        a.modificationDate = Date()
        page.addAnnotation(a)
        return a
    }

    /// Freehand drawing. `strokes` are lists of points in visual page space.
    @discardableResult
    public static func addInk(_ strokes: [[CGPoint]], to page: PDFPage, colour: RGBAColour, lineWidth: CGFloat = 2.5) -> PDFAnnotation? {
        let converted = strokes.map { $0.map { pagePoint(fromVisual: $0, on: page) } }.filter { $0.count > 1 }
        let all = converted.flatMap { $0 }
        guard let first = all.first else { return nil }
        var bounds = CGRect(origin: first, size: .zero)
        for p in all { bounds = bounds.union(CGRect(origin: p, size: .zero)) }
        bounds = bounds.insetBy(dx: -lineWidth * 2, dy: -lineWidth * 2)
        let a = PDFAnnotation(bounds: bounds, forType: .ink, withProperties: nil)
        for stroke in converted {
            // Ink paths are relative to the annotation's bounds origin.
            let path = NSBezierPath()
            path.lineWidth = lineWidth
            path.lineCapStyle = .round
            path.lineJoinStyle = .round
            path.move(to: CGPoint(x: stroke[0].x - bounds.minX, y: stroke[0].y - bounds.minY))
            for p in stroke.dropFirst() { path.line(to: CGPoint(x: p.x - bounds.minX, y: p.y - bounds.minY)) }
            a.add(path)
        }
        let border = PDFBorder()
        border.lineWidth = lineWidth
        a.border = border
        a.color = NSColor(srgbRed: colour.r, green: colour.g, blue: colour.b, alpha: colour.a)
        page.addAnnotation(a)
        return a
    }

    /// A translucent highlight box, or an outlined rectangle.
    @discardableResult
    public static func addBox(to page: PDFPage, visualRect: CGRect, colour: RGBAColour, filled: Bool) -> PDFAnnotation {
        let a = PDFAnnotation(bounds: pageRect(fromVisual: visualRect, on: page), forType: .square, withProperties: nil)
        let ns = NSColor(srgbRed: colour.r, green: colour.g, blue: colour.b, alpha: 1)
        let border = PDFBorder()
        if filled {
            a.interiorColor = ns.withAlphaComponent(0.35)
            a.color = ns.withAlphaComponent(0.0)
            border.lineWidth = 0
        } else {
            a.color = ns
            border.lineWidth = 2
        }
        a.border = border
        page.addAnnotation(a)
        return a
    }

    // MARK: Passwords

    /// Writes a password-protected copy. PDFKit encrypts with AES; anyone with the password can open it.
    /// The owner password (if different) is needed to change the document's security later.
    public static func protect(_ url: URL, output: URL, password: String, ownerPassword: String? = nil) throws {
        guard !password.isEmpty else { throw HexError.message("Enter a password to protect the PDF.") }
        let doc = try open(url)
        let owner = (ownerPassword?.isEmpty == false) ? ownerPassword! : password
        let options: [PDFDocumentWriteOption: Any] = [
            .userPasswordOption: password,
            .ownerPasswordOption: owner,
        ]
        try FileWriter.writeAtomically(to: output) { tmp in
            guard doc.write(to: tmp, withOptions: options) else { throw HexError.writeFailed("PDFKit couldn't encrypt the document.") }
            guard let check = PDFDocument(url: tmp), check.isEncrypted, check.isLocked else {
                throw HexError.invalidOutput("The copy wasn't encrypted.")
            }
            guard check.unlock(withPassword: password), check.pageCount == doc.pageCount else {
                throw HexError.invalidOutput("The protected copy couldn't be opened with the new password.")
            }
        }
    }

    /// Writes an unprotected copy of a password-protected PDF. Needs the current password.
    public static func removePassword(_ url: URL, password: String, output: URL) throws {
        guard let doc = PDFDocument(url: url) else { throw HexError.unreadable(url.lastPathComponent) }
        guard doc.isEncrypted else { throw HexError.message("“\(url.lastPathComponent)” isn't password-protected.") }
        if doc.isLocked, !doc.unlock(withPassword: password) {
            throw HexError.message("That password isn't correct for “\(url.lastPathComponent)”.")
        }
        let copy = PDFDocument()
        for i in 0..<doc.pageCount {
            if let page = doc.page(at: i)?.copy() as? PDFPage { copy.insert(page, at: copy.pageCount) }
        }
        if var attributes = doc.documentAttributes {
            attributes.removeValue(forKey: PDFDocumentAttribute.creatorAttribute)
            copy.documentAttributes = attributes
        }
        try FileWriter.writeAtomically(to: output) { tmp in
            guard copy.write(to: tmp) else { throw HexError.writeFailed("The unprotected copy couldn't be saved.") }
            guard let check = PDFDocument(url: tmp), !check.isLocked, check.pageCount == doc.pageCount else {
                throw HexError.invalidOutput("The unprotected copy didn't open correctly.")
            }
        }
    }

    // MARK: Inspection

    public static func fontsUsed(_ url: URL, maxPages: Int = 300) -> [PDFFontInfo] {
        guard let doc = CGPDFDocument(url as CFURL) else { return [] }
        let collector = PDFFontCollector()
        let n = min(doc.numberOfPages, maxPages)
        if n >= 1 {
            for i in 1...n {
                guard let page = doc.page(at: i), let dict = page.dictionary else { continue }
                var resources: CGPDFDictionaryRef?
                if CGPDFDictionaryGetDictionary(dict, "Resources", &resources), let res = resources {
                    collector.scan(res, depth: 0)
                }
            }
        }
        return collector.fonts.values.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    public static func documentProperties(_ url: URL) -> [(String, String)] {
        guard let doc = PDFDocument(url: url) else { return [] }
        var rows: [(String, String)] = []
        let attrs = doc.documentAttributes ?? [:]
        func add(_ key: PDFDocumentAttribute, _ label: String) {
            if let v = attrs[key] {
                if let d = v as? Date {
                    rows.append((label, DateFormatter.localizedString(from: d, dateStyle: .medium, timeStyle: .short)))
                } else if let a = v as? [String] {
                    if !a.isEmpty { rows.append((label, a.joined(separator: ", "))) }
                } else {
                    let s = "\(v)"
                    if !s.isEmpty { rows.append((label, s)) }
                }
            }
        }
        add(.titleAttribute, "Title")
        add(.authorAttribute, "Author")
        add(.subjectAttribute, "Subject")
        add(.keywordsAttribute, "Keywords")
        add(.creatorAttribute, "Creator")
        add(.producerAttribute, "Producer")
        add(.creationDateAttribute, "PDF created")
        add(.modificationDateAttribute, "PDF modified")
        rows.append(("PDF version", "\(doc.majorVersion).\(doc.minorVersion)"))
        rows.append(("Encrypted", doc.isEncrypted ? "Yes" : "No"))
        if doc.isEncrypted {
            rows.append(("Permissions", "Copying \(doc.allowsCopying ? "allowed" : "blocked") · Printing \(doc.allowsPrinting ? "allowed" : "blocked")"))
        }
        var textPages = 0
        let sample = min(doc.pageCount, 10)
        for i in 0..<sample where ((doc.page(at: i)?.string ?? "").trimmingCharacters(in: .whitespacesAndNewlines).count > 3) {
            textPages += 1
        }
        rows.append(("Text layer", sample == 0 ? "—" : (textPages == sample ? "Yes (searchable)" : textPages == 0 ? "No (scanned/image only — OCR available)" : "Partial")))
        let fonts = fontsUsed(url, maxPages: 50)
        if !fonts.isEmpty {
            rows.append(("Fonts", fonts.prefix(8).map { $0.name }.joined(separator: ", ") + (fonts.count > 8 ? " +\(fonts.count - 8) more" : "")))
        }
        return rows
    }
}

// MARK: - Helpers

final class PDFFontCollector {
    var fonts: [String: PDFFontInfo] = [:]

    func scan(_ resources: CGPDFDictionaryRef, depth: Int) {
        var fontDict: CGPDFDictionaryRef?
        if CGPDFDictionaryGetDictionary(resources, "Font", &fontDict), let fontDict {
            CGPDFDictionaryApplyBlock(fontDict, { _, object, _ in
                var fd: CGPDFDictionaryRef?
                if CGPDFObjectGetValue(object, .dictionary, &fd), let fd { self.record(fd) }
                return true
            }, nil)
        }
        guard depth < 4 else { return }
        var xobjects: CGPDFDictionaryRef?
        if CGPDFDictionaryGetDictionary(resources, "XObject", &xobjects), let xobjects {
            CGPDFDictionaryApplyBlock(xobjects, { _, object, _ in
                var stream: CGPDFStreamRef?
                if CGPDFObjectGetValue(object, .stream, &stream), let stream, let dict = CGPDFStreamGetDictionary(stream) {
                    var sub: UnsafePointer<Int8>?
                    if CGPDFDictionaryGetName(dict, "Subtype", &sub), let sub, String(cString: sub) == "Form" {
                        var res: CGPDFDictionaryRef?
                        if CGPDFDictionaryGetDictionary(dict, "Resources", &res), let res { self.scan(res, depth: depth + 1) }
                    }
                }
                return true
            }, nil)
        }
    }

    func record(_ fd: CGPDFDictionaryRef) {
        var namePtr: UnsafePointer<Int8>?
        var raw = "Unnamed font"
        if CGPDFDictionaryGetName(fd, "BaseFont", &namePtr), let namePtr { raw = String(cString: namePtr) }
        var subtypePtr: UnsafePointer<Int8>?
        var type = "Font"
        if CGPDFDictionaryGetName(fd, "Subtype", &subtypePtr), let subtypePtr { type = String(cString: subtypePtr) }
        var embedded = hasFontFile(fd)
        if type == "Type0" {
            var arr: CGPDFArrayRef?
            if CGPDFDictionaryGetArray(fd, "DescendantFonts", &arr), let arr {
                var desc: CGPDFDictionaryRef?
                if CGPDFArrayGetDictionary(arr, 0, &desc), let desc { embedded = hasFontFile(desc) }
            }
        }
        if type == "Type3" { embedded = true }
        var clean = raw
        if clean.range(of: "^[A-Z]{6}\\+", options: .regularExpression) != nil { clean = String(clean.dropFirst(7)) }
        clean = clean.replacingOccurrences(of: ",", with: " ")
        let info = PDFFontInfo(name: clean, rawName: raw, type: type, embedded: embedded)
        if let existing = fonts[clean], existing.embedded { return }
        fonts[clean] = info
    }

    func hasFontFile(_ fd: CGPDFDictionaryRef) -> Bool {
        var desc: CGPDFDictionaryRef?
        guard CGPDFDictionaryGetDictionary(fd, "FontDescriptor", &desc), let desc else { return false }
        var stream: CGPDFStreamRef?
        for key in ["FontFile", "FontFile2", "FontFile3"] where CGPDFDictionaryGetStream(desc, key, &stream) {
            return true
        }
        return false
    }
}

/// Image annotation drawn into page content on save (used for signatures).
final class ImageStampAnnotation: PDFAnnotation {
    private var stampImage: CGImage?
    private var pageRotation = 0

    init(bounds: CGRect, image: CGImage, rotation: Int) {
        stampImage = image
        pageRotation = ((rotation % 360) + 360) % 360
        super.init(bounds: bounds, forType: .stamp, withProperties: nil)
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }

    override func draw(with box: PDFDisplayBox, in context: CGContext) {
        guard let image = stampImage else { return }
        context.saveGState()
        let b = bounds
        context.translateBy(x: b.midX, y: b.midY)
        // Counter-rotate so the image appears upright on rotated pages.
        context.rotate(by: CGFloat(pageRotation) * .pi / 180)
        let upright = (pageRotation == 90 || pageRotation == 270) ? CGSize(width: b.height, height: b.width) : b.size
        context.interpolationQuality = .high
        context.draw(image, in: CGRect(x: -upright.width / 2, y: -upright.height / 2, width: upright.width, height: upright.height))
        context.restoreGState()
    }
}

/// Large diagonal text stamp, flattened on save.
final class TextStampAnnotation: PDFAnnotation {
    private var text = ""
    private var opacity: CGFloat = 0.18
    private var pageRotation = 0

    init(bounds: CGRect, text: String, opacity: CGFloat, rotation: Int) {
        self.text = text
        self.opacity = opacity
        pageRotation = ((rotation % 360) + 360) % 360
        super.init(bounds: bounds, forType: .stamp, withProperties: nil)
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }

    override func draw(with box: PDFDisplayBox, in context: CGContext) {
        let b = bounds
        let diag = (b.width * b.width + b.height * b.height).squareRoot()
        let fontSize = max(24, diag / CGFloat(max(6, text.count)) * 1.1)
        let font = CTFontCreateWithName("Helvetica-Bold" as CFString, fontSize, nil)
        let colour = CGColor(gray: 0.3, alpha: opacity)
        let attr = NSAttributedString(string: text, attributes: [
            NSAttributedString.Key(kCTFontAttributeName as String): font,
            NSAttributedString.Key(kCTForegroundColorAttributeName as String): colour,
        ])
        let line = CTLineCreateWithAttributedString(attr)
        let width = CTLineGetTypographicBounds(line, nil, nil, nil)
        context.saveGState()
        context.translateBy(x: b.midX, y: b.midY)
        context.rotate(by: CGFloat(pageRotation) * .pi / 180 + .pi / 5)
        context.textMatrix = .identity
        context.textPosition = CGPoint(x: -CGFloat(width) / 2, y: -fontSize / 3)
        CTLineDraw(line, context)
        context.restoreGState()
    }
}
