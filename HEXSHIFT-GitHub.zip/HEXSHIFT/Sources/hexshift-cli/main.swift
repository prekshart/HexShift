import AppKit
import Foundation
import HexshiftKit

// hexshift-cli — scripting and testing front end for the HEXSHIFT engine.
//
//   hexshift-cli selftest [--keep] [filter]   run the end-to-end conversion tests
//   hexshift-cli formats                      what this Mac can read/write
//   hexshift-cli info <file>                  inspect a file
//   hexshift-cli targets <file>               list valid conversions
//   hexshift-cli convert <file> <format> [--quality 0.8] [--out <folder>] [--pages 1-3] [--dpi 150] [--trace]
//   hexshift-cli ocr <file>                   extract text
//   hexshift-cli palette <image> [count]      dominant colours
//   hexshift-cli fontmatch <image>            similar installed fonts

_ = NSApplication.shared  // AppKit document/print machinery expects an application object

let args = Array(CommandLine.arguments.dropFirst())

func usage() -> Never {
    print("""
    usage: hexshift-cli selftest [--keep] [filter]
           hexshift-cli formats
           hexshift-cli info <file>
           hexshift-cli targets <file>
           hexshift-cli convert <file> <format> [--quality 0.8] [--out <folder>] [--pages 1-3] [--dpi 150] [--trace]
           hexshift-cli ocr <file>
           hexshift-cli palette <image> [count]
           hexshift-cli fontmatch <image>
    """)
    exit(2)
}

func option(_ name: String) -> String? {
    guard let i = args.firstIndex(of: name), i + 1 < args.count else { return nil }
    return args[i + 1]
}

func fileArg(_ index: Int) -> URL {
    guard args.count > index else { usage() }
    let url = URL(fileURLWithPath: (args[index] as NSString).expandingTildeInPath)
    guard FileManager.default.fileExists(atPath: url.path) else {
        FileHandle.standardError.write(Data("No such file: \(url.path)\n".utf8))
        exit(1)
    }
    return url
}

func run() async -> Int32 {
    guard let command = args.first else { usage() }
    do {
        switch command {
        case "selftest":
            let keep = args.contains("--keep")
            let filter = args.dropFirst().first { !$0.hasPrefix("--") }
            let report = await SelfTest.run(keepFiles: keep, filter: filter)
            return report.failed == 0 ? 0 : 1

        case "formats":
            print("ImageIO writable: " + ImageEncoder.imageIOWritableTypes.sorted().joined(separator: ", "))
            print("ImageIO readable: \(ImageEncoder.imageIOReadableTypes.count) types")
            for f in Format.allCases where f.category == .raster || f.category == .vector {
                print("  " + f.displayName.padding(toLength: 10, withPad: " ", startingAt: 0) + " write: " + (ImageEncoder.canWrite(f) ? "yes" : "no"))
            }
            print("libwebp \(ImageEncoder.webpEncoderVersion)")
            for (tool, path) in ExternalTools.installedSummary {
                print("  \(tool.displayName): \(path ?? "not installed") — \(tool.purpose)")
            }
            print("Keynote: \(OfficeAdapters.hasKeynote)  Pages: \(OfficeAdapters.hasPages)  Numbers: \(OfficeAdapters.hasNumbers)")
            return 0

        case "info":
            for (k, v) in AssetInspector.detailedProperties(fileArg(1)) { print("\(k): \(v)") }
            return 0

        case "targets":
            let asset = AssetInspector.inspect(fileArg(1))
            print("\(asset.name) — \(asset.summary) [\(asset.kind.rawValue)]")
            for t in ConversionEngine.targets(for: asset) {
                print("  \(t.isAvailable ? "✓" : "✗") \(t.label)\(t.note.map { " — \($0)" } ?? "")")
            }
            return 0

        case "convert":
            let url = fileArg(1)
            guard args.count > 2, let format = Format(rawValue: args[2].lowercased()) ?? Format.allCases.first(where: { $0.fileExtension == args[2].lowercased() }) else { usage() }
            let asset = AssetInspector.inspect(url)
            let wantTrace = args.contains("--trace")
            let targets = ConversionEngine.targets(for: asset)
            guard let target = targets.first(where: { $0.format == format && ($0.variant == .trace) == wantTrace && $0.variant != .ocr })
                ?? targets.first(where: { $0.format == format }) else {
                print("Can't convert \(asset.name) to \(format.displayName). Options: " + targets.map(\.label).joined(separator: ", "))
                return 1
            }
            var options = ConversionOptions()
            if let q = option("--quality").flatMap(Double.init) { options.image.quality = q }
            if let d = option("--dpi").flatMap(Double.init) { options.pdfDPI = d }
            if let p = option("--pages") { options.pdfPages = PDFEngine.parsePageList(p, pageCount: asset.pageCount ?? 1) }
            var settings = OutputSettings()
            if let out = option("--out") { settings.destination = .custom(path: (out as NSString).expandingTildeInPath) }
            let outputs = try await ConversionEngine.convert(asset, to: target, options: options, planner: OutputPlanner(settings: settings))
            for o in outputs { print(o.path) }
            return 0

        case "ocr":
            let r = try OCRService.recognize(url: fileArg(1))
            print(r.text)
            if r.uncertain > 0 { FileHandle.standardError.write(Data("\(r.uncertain) line(s) recognised with low confidence\n".utf8)) }
            return 0

        case "palette":
            let image = try ImageLoader.load(fileArg(1)).image
            let count = args.count > 2 ? Int(args[2]) ?? 6 : 6
            for p in PaletteExtractor.extract(from: image, count: count) {
                print("\(p.colour.hex)  \(ColourMath.rgbString(p.colour))  \(Int((p.weight * 100).rounded()))%  \(ColourMath.approximateName(p.colour))")
            }
            return 0

        case "fontmatch":
            let image = try ImageLoader.load(fileArg(1)).image
            let report = try FontMatcher.analyse(image: image)
            print("Recognised: \(report.sample.text)")
            print("Visually similar installed fonts (estimates, not confirmed):")
            for c in report.candidates {
                print("  \(Int((c.similarity * 100).rounded()))%  \(c.familyName) \(c.styleName)")
            }
            return 0

        default:
            usage()
        }
    } catch {
        FileHandle.standardError.write(Data("Error: \((error as? LocalizedError)?.errorDescription ?? "\(error)")\n".utf8))
        return 1
    }
}

Task {
    let code = await run()
    exit(code)
}
RunLoop.main.run()
